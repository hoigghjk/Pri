package c.a.a.a;

/* loaded from: classes.dex */
public interface e<T, U> {
    U apply(T t);
}
