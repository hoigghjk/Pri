package c.a.a.a;

/* loaded from: classes.dex */
public interface f<T> {
    void a(c<T> cVar);
}
