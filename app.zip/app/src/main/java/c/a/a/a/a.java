package c.a.a.a;

import java.util.Objects;

/* loaded from: classes.dex */
final class a<T> extends c<T> {

    /* renamed from: a, reason: collision with root package name */
    private final Integer f1452a;

    /* renamed from: b, reason: collision with root package name */
    private final T f1453b;

    /* renamed from: c, reason: collision with root package name */
    private final d f1454c;

    a(Integer num, T t, d dVar) {
        this.f1452a = num;
        Objects.requireNonNull(t, "Null payload");
        this.f1453b = t;
        Objects.requireNonNull(dVar, "Null priority");
        this.f1454c = dVar;
    }

    @Override // c.a.a.a.c
    public Integer a() {
        return this.f1452a;
    }

    @Override // c.a.a.a.c
    public T b() {
        return this.f1453b;
    }

    @Override // c.a.a.a.c
    public d c() {
        return this.f1454c;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        Integer num = this.f1452a;
        if (num != null ? num.equals(cVar.a()) : cVar.a() == null) {
            if (this.f1453b.equals(cVar.b()) && this.f1454c.equals(cVar.c())) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        Integer num = this.f1452a;
        return (((((num == null ? 0 : num.hashCode()) ^ 1000003) * 1000003) ^ this.f1453b.hashCode()) * 1000003) ^ this.f1454c.hashCode();
    }

    public String toString() {
        return "Event{code=" + this.f1452a + ", payload=" + this.f1453b + ", priority=" + this.f1454c + "}";
    }
}
