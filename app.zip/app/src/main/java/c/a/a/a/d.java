package c.a.a.a;

/* loaded from: classes.dex */
public enum d {
    DEFAULT,
    VERY_LOW,
    HIGHEST
}
