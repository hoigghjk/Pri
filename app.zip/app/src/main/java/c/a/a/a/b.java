package c.a.a.a;

import java.util.Objects;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    private final String f1455a;

    private b(String str) {
        Objects.requireNonNull(str, "name is null");
        this.f1455a = str;
    }

    public static b b(String str) {
        return new b(str);
    }

    public String a() {
        return this.f1455a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof b) {
            return this.f1455a.equals(((b) obj).f1455a);
        }
        return false;
    }

    public int hashCode() {
        return this.f1455a.hashCode() ^ 1000003;
    }

    public String toString() {
        return "Encoding{name=\"" + this.f1455a + "\"}";
    }
}
