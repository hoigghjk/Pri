package android.support.v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.a;
import android.support.v4.media.session.e;
import java.lang.ref.WeakReference;
import java.util.List;

/* loaded from: classes.dex */
public abstract class c implements IBinder.DeathRecipient {

    /* renamed from: a, reason: collision with root package name */
    final Object f22a;

    /* renamed from: b, reason: collision with root package name */
    a f23b;

    /* renamed from: c, reason: collision with root package name */
    android.support.v4.media.session.a f24c;

    private class a extends Handler {
    }

    private static class b implements e.a {

        /* renamed from: a, reason: collision with root package name */
        private final WeakReference<c> f25a;

        b(c cVar) {
            this.f25a = new WeakReference<>(cVar);
        }

        @Override // android.support.v4.media.session.e.a
        public void a(Object obj) {
            c cVar = this.f25a.get();
            if (cVar != null) {
                cVar.c(MediaMetadataCompat.a(obj));
            }
        }

        @Override // android.support.v4.media.session.e.a
        public void b(int i2, int i3, int i4, int i5, int i6) {
            c cVar = this.f25a.get();
            if (cVar != null) {
                cVar.a(new d(i2, i3, i4, i5, i6));
            }
        }

        @Override // android.support.v4.media.session.e.a
        public void c(Object obj) {
            c cVar = this.f25a.get();
            if (cVar == null || cVar.f24c != null) {
                return;
            }
            cVar.d(PlaybackStateCompat.a(obj));
        }

        @Override // android.support.v4.media.session.e.a
        public void d(CharSequence charSequence) {
            c cVar = this.f25a.get();
            if (cVar != null) {
                cVar.f(charSequence);
            }
        }

        @Override // android.support.v4.media.session.e.a
        public void e(String str, Bundle bundle) {
            c cVar = this.f25a.get();
            if (cVar != null) {
                if (cVar.f24c == null || Build.VERSION.SDK_INT >= 23) {
                    cVar.h(str, bundle);
                }
            }
        }

        @Override // android.support.v4.media.session.e.a
        public void k() {
            c cVar = this.f25a.get();
            if (cVar != null) {
                cVar.g();
            }
        }

        @Override // android.support.v4.media.session.e.a
        public void o(Bundle bundle) {
            c cVar = this.f25a.get();
            if (cVar != null) {
                cVar.b(bundle);
            }
        }

        @Override // android.support.v4.media.session.e.a
        public void p(List<?> list) {
            c cVar = this.f25a.get();
            if (cVar != null) {
                cVar.e(MediaSessionCompat.QueueItem.b(list));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: android.support.v4.media.session.c$c, reason: collision with other inner class name */
    static class BinderC0009c extends a.AbstractBinderC0007a {

        /* renamed from: a, reason: collision with root package name */
        private final WeakReference<c> f26a;

        BinderC0009c(c cVar) {
            this.f26a = new WeakReference<>(cVar);
        }

        public void G1(ParcelableVolumeInfo parcelableVolumeInfo) {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(4, parcelableVolumeInfo != null ? new d(parcelableVolumeInfo.n, parcelableVolumeInfo.o, parcelableVolumeInfo.p, parcelableVolumeInfo.q, parcelableVolumeInfo.r) : null, null);
            }
        }

        public void M(MediaMetadataCompat mediaMetadataCompat) {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(3, mediaMetadataCompat, null);
            }
        }

        public void d(CharSequence charSequence) {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(6, charSequence, null);
            }
        }

        public void k() {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(8, null, null);
            }
        }

        @Override // android.support.v4.media.session.a
        public void k1(boolean z) {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(11, Boolean.valueOf(z), null);
            }
        }

        @Override // android.support.v4.media.session.a
        public void l(int i2) {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(9, Integer.valueOf(i2), null);
            }
        }

        public void o(Bundle bundle) {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(7, bundle, null);
            }
        }

        public void p(List<MediaSessionCompat.QueueItem> list) {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(5, list, null);
            }
        }

        @Override // android.support.v4.media.session.a
        public void r0(int i2) {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(12, Integer.valueOf(i2), null);
            }
        }

        @Override // android.support.v4.media.session.a
        public void t0() {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(13, null, null);
            }
        }

        @Override // android.support.v4.media.session.a
        public void v(boolean z) {
        }

        @Override // android.support.v4.media.session.a
        public void v1(PlaybackStateCompat playbackStateCompat) {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(2, playbackStateCompat, null);
            }
        }

        @Override // android.support.v4.media.session.a
        public void x1(String str, Bundle bundle) {
            c cVar = this.f26a.get();
            if (cVar != null) {
                cVar.i(1, str, bundle);
            }
        }
    }

    public c() {
        if (Build.VERSION.SDK_INT >= 21) {
            this.f22a = e.a(new b(this));
        } else {
            this.f24c = new BinderC0009c(this);
        }
    }

    public void a(d dVar) {
    }

    public void b(Bundle bundle) {
    }

    @Override // android.os.IBinder.DeathRecipient
    public void binderDied() {
        i(8, null, null);
    }

    public void c(MediaMetadataCompat mediaMetadataCompat) {
    }

    public void d(PlaybackStateCompat playbackStateCompat) {
    }

    public void e(List<MediaSessionCompat.QueueItem> list) {
    }

    public void f(CharSequence charSequence) {
    }

    public void g() {
    }

    public void h(String str, Bundle bundle) {
    }

    void i(int i2, Object obj, Bundle bundle) {
        a aVar = this.f23b;
        if (aVar != null) {
            Message obtainMessage = aVar.obtainMessage(i2, obj);
            obtainMessage.setData(bundle);
            obtainMessage.sendToTarget();
        }
    }
}
