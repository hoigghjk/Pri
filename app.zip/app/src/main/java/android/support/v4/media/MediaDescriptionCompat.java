package android.support.v4.media;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.d;
import android.support.v4.media.e;
import android.text.TextUtils;

/* loaded from: classes.dex */
public final class MediaDescriptionCompat implements Parcelable {
    public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();
    private final String n;
    private final CharSequence o;
    private final CharSequence p;
    private final CharSequence q;
    private final Bitmap r;
    private final Uri s;
    private final Bundle t;
    private final Uri u;
    private Object v;

    static class a implements Parcelable.Creator<MediaDescriptionCompat> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public MediaDescriptionCompat createFromParcel(Parcel parcel) {
            return Build.VERSION.SDK_INT < 21 ? new MediaDescriptionCompat(parcel) : MediaDescriptionCompat.a(d.a(parcel));
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public MediaDescriptionCompat[] newArray(int i2) {
            return new MediaDescriptionCompat[i2];
        }
    }

    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        private String f9a;

        /* renamed from: b, reason: collision with root package name */
        private CharSequence f10b;

        /* renamed from: c, reason: collision with root package name */
        private CharSequence f11c;

        /* renamed from: d, reason: collision with root package name */
        private CharSequence f12d;

        /* renamed from: e, reason: collision with root package name */
        private Bitmap f13e;

        /* renamed from: f, reason: collision with root package name */
        private Uri f14f;

        /* renamed from: g, reason: collision with root package name */
        private Bundle f15g;

        /* renamed from: h, reason: collision with root package name */
        private Uri f16h;

        public MediaDescriptionCompat a() {
            return new MediaDescriptionCompat(this.f9a, this.f10b, this.f11c, this.f12d, this.f13e, this.f14f, this.f15g, this.f16h);
        }

        public b b(CharSequence charSequence) {
            this.f12d = charSequence;
            return this;
        }

        public b c(Bundle bundle) {
            this.f15g = bundle;
            return this;
        }

        public b d(Bitmap bitmap) {
            this.f13e = bitmap;
            return this;
        }

        public b e(Uri uri) {
            this.f14f = uri;
            return this;
        }

        public b f(String str) {
            this.f9a = str;
            return this;
        }

        public b g(Uri uri) {
            this.f16h = uri;
            return this;
        }

        public b h(CharSequence charSequence) {
            this.f11c = charSequence;
            return this;
        }

        public b i(CharSequence charSequence) {
            this.f10b = charSequence;
            return this;
        }
    }

    MediaDescriptionCompat(Parcel parcel) {
        this.n = parcel.readString();
        this.o = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.p = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.q = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        ClassLoader classLoader = MediaDescriptionCompat.class.getClassLoader();
        this.r = (Bitmap) parcel.readParcelable(classLoader);
        this.s = (Uri) parcel.readParcelable(classLoader);
        this.t = parcel.readBundle(classLoader);
        this.u = (Uri) parcel.readParcelable(classLoader);
    }

    MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.n = str;
        this.o = charSequence;
        this.p = charSequence2;
        this.q = charSequence3;
        this.r = bitmap;
        this.s = uri;
        this.t = bundle;
        this.u = uri2;
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x006d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static android.support.v4.media.MediaDescriptionCompat a(java.lang.Object r9) {
        /*
            r0 = 0
            if (r9 == 0) goto L7e
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 21
            if (r1 < r2) goto L7e
            android.support.v4.media.MediaDescriptionCompat$b r2 = new android.support.v4.media.MediaDescriptionCompat$b
            r2.<init>()
            java.lang.String r3 = android.support.v4.media.d.f(r9)
            r2.f(r3)
            java.lang.CharSequence r3 = android.support.v4.media.d.h(r9)
            r2.i(r3)
            java.lang.CharSequence r3 = android.support.v4.media.d.g(r9)
            r2.h(r3)
            java.lang.CharSequence r3 = android.support.v4.media.d.b(r9)
            r2.b(r3)
            android.graphics.Bitmap r3 = android.support.v4.media.d.d(r9)
            r2.d(r3)
            android.net.Uri r3 = android.support.v4.media.d.e(r9)
            r2.e(r3)
            android.os.Bundle r3 = android.support.v4.media.d.c(r9)
            java.lang.String r4 = "android.support.v4.media.description.MEDIA_URI"
            if (r3 == 0) goto L4a
            android.support.v4.media.session.MediaSessionCompat.a(r3)
            android.os.Parcelable r5 = r3.getParcelable(r4)
            android.net.Uri r5 = (android.net.Uri) r5
            goto L4b
        L4a:
            r5 = r0
        L4b:
            if (r5 == 0) goto L63
            java.lang.String r6 = "android.support.v4.media.description.NULL_BUNDLE_FLAG"
            boolean r7 = r3.containsKey(r6)
            if (r7 == 0) goto L5d
            int r7 = r3.size()
            r8 = 2
            if (r7 != r8) goto L5d
            goto L64
        L5d:
            r3.remove(r4)
            r3.remove(r6)
        L63:
            r0 = r3
        L64:
            r2.c(r0)
            if (r5 == 0) goto L6d
            r2.g(r5)
            goto L78
        L6d:
            r0 = 23
            if (r1 < r0) goto L78
            android.net.Uri r0 = android.support.v4.media.e.a(r9)
            r2.g(r0)
        L78:
            android.support.v4.media.MediaDescriptionCompat r0 = r2.a()
            r0.v = r9
        L7e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.media.MediaDescriptionCompat.a(java.lang.Object):android.support.v4.media.MediaDescriptionCompat");
    }

    public Object b() {
        int i2;
        Object obj = this.v;
        if (obj != null || (i2 = Build.VERSION.SDK_INT) < 21) {
            return obj;
        }
        Object b2 = d.a.b();
        d.a.g(b2, this.n);
        d.a.i(b2, this.o);
        d.a.h(b2, this.p);
        d.a.c(b2, this.q);
        d.a.e(b2, this.r);
        d.a.f(b2, this.s);
        Bundle bundle = this.t;
        if (i2 < 23 && this.u != null) {
            if (bundle == null) {
                bundle = new Bundle();
                bundle.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
            }
            bundle.putParcelable("android.support.v4.media.description.MEDIA_URI", this.u);
        }
        d.a.d(b2, bundle);
        if (i2 >= 23) {
            e.a.a(b2, this.u);
        }
        Object a2 = d.a.a(b2);
        this.v = a2;
        return a2;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String toString() {
        return ((Object) this.o) + ", " + ((Object) this.p) + ", " + ((Object) this.q);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        if (Build.VERSION.SDK_INT >= 21) {
            d.i(b(), parcel, i2);
            return;
        }
        parcel.writeString(this.n);
        TextUtils.writeToParcel(this.o, parcel, i2);
        TextUtils.writeToParcel(this.p, parcel, i2);
        TextUtils.writeToParcel(this.q, parcel, i2);
        parcel.writeParcelable(this.r, i2);
        parcel.writeParcelable(this.s, i2);
        parcel.writeBundle(this.t);
        parcel.writeParcelable(this.u, i2);
    }
}
