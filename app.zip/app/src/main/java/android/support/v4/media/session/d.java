package android.support.v4.media.session;

/* loaded from: classes.dex */
public final class d {
    d(int i2, int i3, int i4, int i5, int i6) {
    }
}
