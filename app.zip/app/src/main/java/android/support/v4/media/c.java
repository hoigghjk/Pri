package android.support.v4.media;

import android.os.Bundle;
import java.util.List;

/* loaded from: classes.dex */
public abstract class c {
    public abstract void a(String str, Bundle bundle);

    public abstract void b(String str, Bundle bundle, List<MediaBrowserCompat$MediaItem> list);
}
