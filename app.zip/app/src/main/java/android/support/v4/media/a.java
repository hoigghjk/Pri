package android.support.v4.media;

import android.os.Bundle;

/* loaded from: classes.dex */
public abstract class a {
    public abstract void a(String str, Bundle bundle, Bundle bundle2);

    public abstract void b(String str, Bundle bundle, Bundle bundle2);

    public abstract void c(String str, Bundle bundle, Bundle bundle2);
}
