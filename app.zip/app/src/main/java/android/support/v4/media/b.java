package android.support.v4.media;

/* loaded from: classes.dex */
public abstract class b {
    public abstract void a(String str);

    public abstract void b(MediaBrowserCompat$MediaItem mediaBrowserCompat$MediaItem);
}
