package android.support.v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.g;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
    final int n;
    final long o;
    final long p;
    final float q;
    final long r;
    final int s;
    final CharSequence t;
    final long u;
    List<CustomAction> v;
    final long w;
    final Bundle x;
    private Object y;

    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new a();
        private final String n;
        private final CharSequence o;
        private final int p;
        private final Bundle q;
        private Object r;

        static class a implements Parcelable.Creator<CustomAction> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public CustomAction createFromParcel(Parcel parcel) {
                return new CustomAction(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public CustomAction[] newArray(int i2) {
                return new CustomAction[i2];
            }
        }

        CustomAction(Parcel parcel) {
            this.n = parcel.readString();
            this.o = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.p = parcel.readInt();
            this.q = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        }

        CustomAction(String str, CharSequence charSequence, int i2, Bundle bundle) {
            this.n = str;
            this.o = charSequence;
            this.p = i2;
            this.q = bundle;
        }

        public static CustomAction a(Object obj) {
            if (obj == null || Build.VERSION.SDK_INT < 21) {
                return null;
            }
            CustomAction customAction = new CustomAction(g.a.a(obj), g.a.d(obj), g.a.c(obj), g.a.b(obj));
            customAction.r = obj;
            return customAction;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public String toString() {
            return "Action:mName='" + ((Object) this.o) + ", mIcon=" + this.p + ", mExtras=" + this.q;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeString(this.n);
            TextUtils.writeToParcel(this.o, parcel, i2);
            parcel.writeInt(this.p);
            parcel.writeBundle(this.q);
        }
    }

    static class a implements Parcelable.Creator<PlaybackStateCompat> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public PlaybackStateCompat createFromParcel(Parcel parcel) {
            return new PlaybackStateCompat(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public PlaybackStateCompat[] newArray(int i2) {
            return new PlaybackStateCompat[i2];
        }
    }

    PlaybackStateCompat(int i2, long j2, long j3, float f2, long j4, int i3, CharSequence charSequence, long j5, List<CustomAction> list, long j6, Bundle bundle) {
        this.n = i2;
        this.o = j2;
        this.p = j3;
        this.q = f2;
        this.r = j4;
        this.s = i3;
        this.t = charSequence;
        this.u = j5;
        this.v = new ArrayList(list);
        this.w = j6;
        this.x = bundle;
    }

    PlaybackStateCompat(Parcel parcel) {
        this.n = parcel.readInt();
        this.o = parcel.readLong();
        this.q = parcel.readFloat();
        this.u = parcel.readLong();
        this.p = parcel.readLong();
        this.r = parcel.readLong();
        this.t = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.v = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.w = parcel.readLong();
        this.x = parcel.readBundle(MediaSessionCompat.class.getClassLoader());
        this.s = parcel.readInt();
    }

    public static PlaybackStateCompat a(Object obj) {
        ArrayList arrayList;
        if (obj == null || Build.VERSION.SDK_INT < 21) {
            return null;
        }
        List<Object> d2 = g.d(obj);
        if (d2 != null) {
            ArrayList arrayList2 = new ArrayList(d2.size());
            Iterator<Object> it = d2.iterator();
            while (it.hasNext()) {
                arrayList2.add(CustomAction.a(it.next()));
            }
            arrayList = arrayList2;
        } else {
            arrayList = null;
        }
        PlaybackStateCompat playbackStateCompat = new PlaybackStateCompat(g.i(obj), g.h(obj), g.c(obj), g.g(obj), g.a(obj), 0, g.e(obj), g.f(obj), arrayList, g.b(obj), Build.VERSION.SDK_INT >= 22 ? h.a(obj) : null);
        playbackStateCompat.y = obj;
        return playbackStateCompat;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String toString() {
        return "PlaybackState {state=" + this.n + ", position=" + this.o + ", buffered position=" + this.p + ", speed=" + this.q + ", updated=" + this.u + ", actions=" + this.r + ", error code=" + this.s + ", error message=" + this.t + ", custom actions=" + this.v + ", active item id=" + this.w + "}";
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.n);
        parcel.writeLong(this.o);
        parcel.writeFloat(this.q);
        parcel.writeLong(this.u);
        parcel.writeLong(this.p);
        parcel.writeLong(this.r);
        TextUtils.writeToParcel(this.t, parcel, i2);
        parcel.writeTypedList(this.v);
        parcel.writeLong(this.w);
        parcel.writeBundle(this.x);
        parcel.writeInt(this.s);
    }
}
