package android.support.v4.media;

import android.os.Bundle;
import android.support.v4.media.session.MediaSessionCompat;
import android.util.Log;

/* loaded from: classes.dex */
class MediaBrowserCompat$CustomActionResultReceiver extends a.b.b.a.b {
    private final String p;
    private final Bundle q;
    private final a r;

    @Override // a.b.b.a.b
    protected void a(int i2, Bundle bundle) {
        if (this.r == null) {
            return;
        }
        MediaSessionCompat.a(bundle);
        if (i2 == -1) {
            this.r.a(this.p, this.q, bundle);
            return;
        }
        if (i2 == 0) {
            this.r.c(this.p, this.q, bundle);
            return;
        }
        if (i2 == 1) {
            this.r.b(this.p, this.q, bundle);
            return;
        }
        Log.w("MediaBrowserCompat", "Unknown result code: " + i2 + " (extras=" + this.q + ", resultData=" + bundle + ")");
    }
}
