package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.SparseIntArray;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
class b extends a {

    /* renamed from: d, reason: collision with root package name */
    private final SparseIntArray f668d;

    /* renamed from: e, reason: collision with root package name */
    private final Parcel f669e;

    /* renamed from: f, reason: collision with root package name */
    private final int f670f;

    /* renamed from: g, reason: collision with root package name */
    private final int f671g;

    /* renamed from: h, reason: collision with root package name */
    private final String f672h;

    /* renamed from: i, reason: collision with root package name */
    private int f673i;

    /* renamed from: j, reason: collision with root package name */
    private int f674j;

    /* renamed from: k, reason: collision with root package name */
    private int f675k;

    b(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new b.e.a(), new b.e.a(), new b.e.a());
    }

    private b(Parcel parcel, int i2, int i3, String str, b.e.a<String, Method> aVar, b.e.a<String, Method> aVar2, b.e.a<String, Class> aVar3) {
        super(aVar, aVar2, aVar3);
        this.f668d = new SparseIntArray();
        this.f673i = -1;
        this.f674j = 0;
        this.f675k = -1;
        this.f669e = parcel;
        this.f670f = i2;
        this.f671g = i3;
        this.f674j = i2;
        this.f672h = str;
    }

    @Override // androidx.versionedparcelable.a
    public void A(byte[] bArr) {
        if (bArr == null) {
            this.f669e.writeInt(-1);
        } else {
            this.f669e.writeInt(bArr.length);
            this.f669e.writeByteArray(bArr);
        }
    }

    @Override // androidx.versionedparcelable.a
    protected void C(CharSequence charSequence) {
        TextUtils.writeToParcel(charSequence, this.f669e, 0);
    }

    @Override // androidx.versionedparcelable.a
    public void E(int i2) {
        this.f669e.writeInt(i2);
    }

    @Override // androidx.versionedparcelable.a
    public void G(Parcelable parcelable) {
        this.f669e.writeParcelable(parcelable, 0);
    }

    @Override // androidx.versionedparcelable.a
    public void I(String str) {
        this.f669e.writeString(str);
    }

    @Override // androidx.versionedparcelable.a
    public void a() {
        int i2 = this.f673i;
        if (i2 >= 0) {
            int i3 = this.f668d.get(i2);
            int dataPosition = this.f669e.dataPosition();
            this.f669e.setDataPosition(i3);
            this.f669e.writeInt(dataPosition - i3);
            this.f669e.setDataPosition(dataPosition);
        }
    }

    @Override // androidx.versionedparcelable.a
    protected a b() {
        Parcel parcel = this.f669e;
        int dataPosition = parcel.dataPosition();
        int i2 = this.f674j;
        if (i2 == this.f670f) {
            i2 = this.f671g;
        }
        return new b(parcel, dataPosition, i2, this.f672h + "  ", this.f665a, this.f666b, this.f667c);
    }

    @Override // androidx.versionedparcelable.a
    public boolean g() {
        return this.f669e.readInt() != 0;
    }

    @Override // androidx.versionedparcelable.a
    public byte[] i() {
        int readInt = this.f669e.readInt();
        if (readInt < 0) {
            return null;
        }
        byte[] bArr = new byte[readInt];
        this.f669e.readByteArray(bArr);
        return bArr;
    }

    @Override // androidx.versionedparcelable.a
    protected CharSequence k() {
        return (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(this.f669e);
    }

    @Override // androidx.versionedparcelable.a
    public boolean m(int i2) {
        while (this.f674j < this.f671g) {
            int i3 = this.f675k;
            if (i3 == i2) {
                return true;
            }
            if (String.valueOf(i3).compareTo(String.valueOf(i2)) > 0) {
                return false;
            }
            this.f669e.setDataPosition(this.f674j);
            int readInt = this.f669e.readInt();
            this.f675k = this.f669e.readInt();
            this.f674j += readInt;
        }
        return this.f675k == i2;
    }

    @Override // androidx.versionedparcelable.a
    public int o() {
        return this.f669e.readInt();
    }

    @Override // androidx.versionedparcelable.a
    public <T extends Parcelable> T q() {
        return (T) this.f669e.readParcelable(b.class.getClassLoader());
    }

    @Override // androidx.versionedparcelable.a
    public String s() {
        return this.f669e.readString();
    }

    @Override // androidx.versionedparcelable.a
    public void w(int i2) {
        a();
        this.f673i = i2;
        this.f668d.put(i2, this.f669e.dataPosition());
        E(0);
        E(i2);
    }

    @Override // androidx.versionedparcelable.a
    public void y(boolean z) {
        this.f669e.writeInt(z ? 1 : 0);
    }
}
