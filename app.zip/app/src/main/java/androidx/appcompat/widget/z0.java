package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;

/* loaded from: classes.dex */
class z0 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
    private static z0 w;
    private static z0 x;
    private final View n;
    private final CharSequence o;
    private final int p;
    private final Runnable q = new a();
    private final Runnable r = new b();
    private int s;
    private int t;
    private a1 u;
    private boolean v;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            z0.this.g(false);
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            z0.this.c();
        }
    }

    private z0(View view, CharSequence charSequence) {
        this.n = view;
        this.o = charSequence;
        this.p = b.g.l.s.a(ViewConfiguration.get(view.getContext()));
        b();
        view.setOnLongClickListener(this);
        view.setOnHoverListener(this);
    }

    private void a() {
        this.n.removeCallbacks(this.q);
    }

    private void b() {
        this.s = Integer.MAX_VALUE;
        this.t = Integer.MAX_VALUE;
    }

    private void d() {
        this.n.postDelayed(this.q, ViewConfiguration.getLongPressTimeout());
    }

    private static void e(z0 z0Var) {
        z0 z0Var2 = w;
        if (z0Var2 != null) {
            z0Var2.a();
        }
        w = z0Var;
        if (z0Var != null) {
            z0Var.d();
        }
    }

    public static void f(View view, CharSequence charSequence) {
        z0 z0Var = w;
        if (z0Var != null && z0Var.n == view) {
            e(null);
        }
        if (!TextUtils.isEmpty(charSequence)) {
            new z0(view, charSequence);
            return;
        }
        z0 z0Var2 = x;
        if (z0Var2 != null && z0Var2.n == view) {
            z0Var2.c();
        }
        view.setOnLongClickListener(null);
        view.setLongClickable(false);
        view.setOnHoverListener(null);
    }

    private boolean h(MotionEvent motionEvent) {
        int x2 = (int) motionEvent.getX();
        int y = (int) motionEvent.getY();
        if (Math.abs(x2 - this.s) <= this.p && Math.abs(y - this.t) <= this.p) {
            return false;
        }
        this.s = x2;
        this.t = y;
        return true;
    }

    void c() {
        if (x == this) {
            x = null;
            a1 a1Var = this.u;
            if (a1Var != null) {
                a1Var.c();
                this.u = null;
                b();
                this.n.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (w == this) {
            e(null);
        }
        this.n.removeCallbacks(this.r);
    }

    void g(boolean z) {
        long longPressTimeout;
        if (b.g.l.r.x(this.n)) {
            e(null);
            z0 z0Var = x;
            if (z0Var != null) {
                z0Var.c();
            }
            x = this;
            this.v = z;
            a1 a1Var = new a1(this.n.getContext());
            this.u = a1Var;
            a1Var.e(this.n, this.s, this.t, this.v, this.o);
            this.n.addOnAttachStateChangeListener(this);
            if (this.v) {
                longPressTimeout = 2500;
            } else {
                longPressTimeout = ((b.g.l.r.u(this.n) & 1) == 1 ? 3000L : 15000L) - ViewConfiguration.getLongPressTimeout();
            }
            this.n.removeCallbacks(this.r);
            this.n.postDelayed(this.r, longPressTimeout);
        }
    }

    @Override // android.view.View.OnHoverListener
    public boolean onHover(View view, MotionEvent motionEvent) {
        if (this.u != null && this.v) {
            return false;
        }
        AccessibilityManager accessibilityManager = (AccessibilityManager) this.n.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action != 7) {
            if (action == 10) {
                b();
                c();
            }
        } else if (this.n.isEnabled() && this.u == null && h(motionEvent)) {
            e(this);
        }
        return false;
    }

    @Override // android.view.View.OnLongClickListener
    public boolean onLongClick(View view) {
        this.s = view.getWidth() / 2;
        this.t = view.getHeight() / 2;
        g(true);
        return true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewAttachedToWindow(View view) {
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewDetachedFromWindow(View view) {
        c();
    }
}
