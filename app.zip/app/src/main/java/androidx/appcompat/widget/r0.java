package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;

/* loaded from: classes.dex */
public class r0 {

    /* renamed from: a, reason: collision with root package name */
    private static final ThreadLocal<TypedValue> f310a = new ThreadLocal<>();

    /* renamed from: b, reason: collision with root package name */
    static final int[] f311b = {-16842910};

    /* renamed from: c, reason: collision with root package name */
    static final int[] f312c = {R.attr.state_focused};

    /* renamed from: d, reason: collision with root package name */
    static final int[] f313d = {R.attr.state_pressed};

    /* renamed from: e, reason: collision with root package name */
    static final int[] f314e = {R.attr.state_checked};

    /* renamed from: f, reason: collision with root package name */
    static final int[] f315f = new int[0];

    /* renamed from: g, reason: collision with root package name */
    private static final int[] f316g = new int[1];

    public static void a(View view, Context context) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(b.a.j.u0);
        try {
            if (!obtainStyledAttributes.hasValue(b.a.j.z0)) {
                Log.e("ThemeUtils", "View " + view.getClass() + " is an AppCompat widget that can only be used with a Theme.AppCompat theme (or descendant).");
            }
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    public static int b(Context context, int i2) {
        ColorStateList e2 = e(context, i2);
        if (e2 != null && e2.isStateful()) {
            return e2.getColorForState(f311b, e2.getDefaultColor());
        }
        TypedValue f2 = f();
        context.getTheme().resolveAttribute(R.attr.disabledAlpha, f2, true);
        return d(context, i2, f2.getFloat());
    }

    public static int c(Context context, int i2) {
        int[] iArr = f316g;
        iArr[0] = i2;
        w0 t = w0.t(context, null, iArr);
        try {
            return t.b(0, 0);
        } finally {
            t.v();
        }
    }

    static int d(Context context, int i2, float f2) {
        return b.g.f.a.d(c(context, i2), Math.round(Color.alpha(r0) * f2));
    }

    public static ColorStateList e(Context context, int i2) {
        int[] iArr = f316g;
        iArr[0] = i2;
        w0 t = w0.t(context, null, iArr);
        try {
            return t.c(0);
        } finally {
            t.v();
        }
    }

    private static TypedValue f() {
        ThreadLocal<TypedValue> threadLocal = f310a;
        TypedValue typedValue = threadLocal.get();
        if (typedValue != null) {
            return typedValue;
        }
        TypedValue typedValue2 = new TypedValue();
        threadLocal.set(typedValue2);
        return typedValue2;
    }
}
