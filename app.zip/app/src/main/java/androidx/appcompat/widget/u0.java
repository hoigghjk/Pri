package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* loaded from: classes.dex */
public class u0 {

    /* renamed from: a, reason: collision with root package name */
    public ColorStateList f321a;

    /* renamed from: b, reason: collision with root package name */
    public PorterDuff.Mode f322b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f323c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f324d;

    void a() {
        this.f321a = null;
        this.f324d = false;
        this.f322b = null;
        this.f323c = false;
    }
}
