package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public class j0 implements androidx.appcompat.view.menu.p {
    private static Method S;
    private static Method T;
    private static Method U;
    private boolean A;
    int B;
    private View C;
    private int D;
    private DataSetObserver E;
    private View F;
    private Drawable G;
    private AdapterView.OnItemClickListener H;
    private AdapterView.OnItemSelectedListener I;
    final f J;
    private final e K;
    private final d L;
    private final b M;
    final Handler N;
    private final Rect O;
    private Rect P;
    private boolean Q;
    PopupWindow R;
    private Context n;
    private ListAdapter o;
    f0 p;
    private int q;
    private int r;
    private int s;
    private int t;
    private int u;
    private boolean v;
    private boolean w;
    private boolean x;
    private int y;
    private boolean z;

    class a implements AdapterView.OnItemSelectedListener {
        a() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
            f0 f0Var;
            if (i2 == -1 || (f0Var = j0.this.p) == null) {
                return;
            }
            f0Var.setListSelectionHidden(false);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    private class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            j0.this.r();
        }
    }

    private class c extends DataSetObserver {
        c() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            if (j0.this.c()) {
                j0.this.a();
            }
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            j0.this.dismiss();
        }
    }

    private class d implements AbsListView.OnScrollListener {
        d() {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScroll(AbsListView absListView, int i2, int i3, int i4) {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScrollStateChanged(AbsListView absListView, int i2) {
            if (i2 != 1 || j0.this.w() || j0.this.R.getContentView() == null) {
                return;
            }
            j0 j0Var = j0.this;
            j0Var.N.removeCallbacks(j0Var.J);
            j0.this.J.run();
        }
    }

    private class e implements View.OnTouchListener {
        e() {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            PopupWindow popupWindow;
            int action = motionEvent.getAction();
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            if (action == 0 && (popupWindow = j0.this.R) != null && popupWindow.isShowing() && x >= 0 && x < j0.this.R.getWidth() && y >= 0 && y < j0.this.R.getHeight()) {
                j0 j0Var = j0.this;
                j0Var.N.postDelayed(j0Var.J, 250L);
                return false;
            }
            if (action != 1) {
                return false;
            }
            j0 j0Var2 = j0.this;
            j0Var2.N.removeCallbacks(j0Var2.J);
            return false;
        }
    }

    private class f implements Runnable {
        f() {
        }

        @Override // java.lang.Runnable
        public void run() {
            f0 f0Var = j0.this.p;
            if (f0Var == null || !b.g.l.r.x(f0Var) || j0.this.p.getCount() <= j0.this.p.getChildCount()) {
                return;
            }
            int childCount = j0.this.p.getChildCount();
            j0 j0Var = j0.this;
            if (childCount <= j0Var.B) {
                j0Var.R.setInputMethodMode(2);
                j0.this.a();
            }
        }
    }

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                S = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                U = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
        if (Build.VERSION.SDK_INT <= 23) {
            try {
                T = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", View.class, Integer.TYPE, Boolean.TYPE);
            } catch (NoSuchMethodException unused3) {
                Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
            }
        }
    }

    public j0(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public j0(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.q = -2;
        this.r = -2;
        this.u = 1002;
        this.y = 0;
        this.z = false;
        this.A = false;
        this.B = Integer.MAX_VALUE;
        this.D = 0;
        this.J = new f();
        this.K = new e();
        this.L = new d();
        this.M = new b();
        this.O = new Rect();
        this.n = context;
        this.N = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.a.j.d1, i2, i3);
        this.s = obtainStyledAttributes.getDimensionPixelOffset(b.a.j.e1, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(b.a.j.f1, 0);
        this.t = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.v = true;
        }
        obtainStyledAttributes.recycle();
        q qVar = new q(context, attributeSet, i2, i3);
        this.R = qVar;
        qVar.setInputMethodMode(1);
    }

    private void J(boolean z) {
        if (Build.VERSION.SDK_INT > 28) {
            this.R.setIsClippedToScreen(z);
            return;
        }
        Method method = S;
        if (method != null) {
            try {
                method.invoke(this.R, Boolean.valueOf(z));
            } catch (Exception unused) {
                Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:39:0x014a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private int q() {
        /*
            Method dump skipped, instructions count: 349
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.j0.q():int");
    }

    private int u(View view, int i2, boolean z) {
        if (Build.VERSION.SDK_INT > 23) {
            return this.R.getMaxAvailableHeight(view, i2, z);
        }
        Method method = T;
        if (method != null) {
            try {
                return ((Integer) method.invoke(this.R, view, Integer.valueOf(i2), Boolean.valueOf(z))).intValue();
            } catch (Exception unused) {
                Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
            }
        }
        return this.R.getMaxAvailableHeight(view, i2);
    }

    private void y() {
        View view = this.C;
        if (view != null) {
            ViewParent parent = view.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(this.C);
            }
        }
    }

    public void A(int i2) {
        this.R.setAnimationStyle(i2);
    }

    public void B(int i2) {
        Drawable background = this.R.getBackground();
        if (background == null) {
            M(i2);
            return;
        }
        background.getPadding(this.O);
        Rect rect = this.O;
        this.r = rect.left + rect.right + i2;
    }

    public void C(int i2) {
        this.y = i2;
    }

    public void D(Rect rect) {
        this.P = rect != null ? new Rect(rect) : null;
    }

    public void E(int i2) {
        this.R.setInputMethodMode(i2);
    }

    public void F(boolean z) {
        this.Q = z;
        this.R.setFocusable(z);
    }

    public void G(PopupWindow.OnDismissListener onDismissListener) {
        this.R.setOnDismissListener(onDismissListener);
    }

    public void H(AdapterView.OnItemClickListener onItemClickListener) {
        this.H = onItemClickListener;
    }

    public void I(boolean z) {
        this.x = true;
        this.w = z;
    }

    public void K(int i2) {
        this.D = i2;
    }

    public void L(int i2) {
        f0 f0Var = this.p;
        if (!c() || f0Var == null) {
            return;
        }
        f0Var.setListSelectionHidden(false);
        f0Var.setSelection(i2);
        if (f0Var.getChoiceMode() != 0) {
            f0Var.setItemChecked(i2, true);
        }
    }

    public void M(int i2) {
        this.r = i2;
    }

    @Override // androidx.appcompat.view.menu.p
    public void a() {
        int q = q();
        boolean w = w();
        androidx.core.widget.h.b(this.R, this.u);
        if (this.R.isShowing()) {
            if (b.g.l.r.x(t())) {
                int i2 = this.r;
                if (i2 == -1) {
                    i2 = -1;
                } else if (i2 == -2) {
                    i2 = t().getWidth();
                }
                int i3 = this.q;
                if (i3 == -1) {
                    if (!w) {
                        q = -1;
                    }
                    if (w) {
                        this.R.setWidth(this.r == -1 ? -1 : 0);
                        this.R.setHeight(0);
                    } else {
                        this.R.setWidth(this.r == -1 ? -1 : 0);
                        this.R.setHeight(-1);
                    }
                } else if (i3 != -2) {
                    q = i3;
                }
                this.R.setOutsideTouchable((this.A || this.z) ? false : true);
                this.R.update(t(), this.s, this.t, i2 < 0 ? -1 : i2, q < 0 ? -1 : q);
                return;
            }
            return;
        }
        int i4 = this.r;
        if (i4 == -1) {
            i4 = -1;
        } else if (i4 == -2) {
            i4 = t().getWidth();
        }
        int i5 = this.q;
        if (i5 == -1) {
            q = -1;
        } else if (i5 != -2) {
            q = i5;
        }
        this.R.setWidth(i4);
        this.R.setHeight(q);
        J(true);
        this.R.setOutsideTouchable((this.A || this.z) ? false : true);
        this.R.setTouchInterceptor(this.K);
        if (this.x) {
            androidx.core.widget.h.a(this.R, this.w);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = U;
            if (method != null) {
                try {
                    method.invoke(this.R, this.P);
                } catch (Exception e2) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e2);
                }
            }
        } else {
            this.R.setEpicenterBounds(this.P);
        }
        androidx.core.widget.h.c(this.R, t(), this.s, this.t, this.y);
        this.p.setSelection(-1);
        if (!this.Q || this.p.isInTouchMode()) {
            r();
        }
        if (this.Q) {
            return;
        }
        this.N.post(this.M);
    }

    @Override // androidx.appcompat.view.menu.p
    public boolean c() {
        return this.R.isShowing();
    }

    @Override // androidx.appcompat.view.menu.p
    public void dismiss() {
        this.R.dismiss();
        y();
        this.R.setContentView(null);
        this.p = null;
        this.N.removeCallbacks(this.J);
    }

    public void e(Drawable drawable) {
        this.R.setBackgroundDrawable(drawable);
    }

    public int f() {
        return this.s;
    }

    public Drawable g() {
        return this.R.getBackground();
    }

    @Override // androidx.appcompat.view.menu.p
    public ListView h() {
        return this.p;
    }

    public void j(int i2) {
        this.t = i2;
        this.v = true;
    }

    public void l(int i2) {
        this.s = i2;
    }

    public int n() {
        if (this.v) {
            return this.t;
        }
        return 0;
    }

    public void p(ListAdapter listAdapter) {
        DataSetObserver dataSetObserver = this.E;
        if (dataSetObserver == null) {
            this.E = new c();
        } else {
            ListAdapter listAdapter2 = this.o;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.o = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.E);
        }
        f0 f0Var = this.p;
        if (f0Var != null) {
            f0Var.setAdapter(this.o);
        }
    }

    public void r() {
        f0 f0Var = this.p;
        if (f0Var != null) {
            f0Var.setListSelectionHidden(true);
            f0Var.requestLayout();
        }
    }

    f0 s(Context context, boolean z) {
        return new f0(context, z);
    }

    public View t() {
        return this.F;
    }

    public int v() {
        return this.r;
    }

    public boolean w() {
        return this.R.getInputMethodMode() == 2;
    }

    public boolean x() {
        return this.Q;
    }

    public void z(View view) {
        this.F = view;
    }
}
