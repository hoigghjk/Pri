package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.TextView;
import b.g.e.e.f;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
class y {

    /* renamed from: a, reason: collision with root package name */
    private final TextView f351a;

    /* renamed from: b, reason: collision with root package name */
    private u0 f352b;

    /* renamed from: c, reason: collision with root package name */
    private u0 f353c;

    /* renamed from: d, reason: collision with root package name */
    private u0 f354d;

    /* renamed from: e, reason: collision with root package name */
    private u0 f355e;

    /* renamed from: f, reason: collision with root package name */
    private u0 f356f;

    /* renamed from: g, reason: collision with root package name */
    private u0 f357g;

    /* renamed from: h, reason: collision with root package name */
    private u0 f358h;

    /* renamed from: i, reason: collision with root package name */
    private final a0 f359i;

    /* renamed from: j, reason: collision with root package name */
    private int f360j = 0;

    /* renamed from: k, reason: collision with root package name */
    private int f361k = -1;
    private Typeface l;
    private boolean m;

    class a extends f.c {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ int f362a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ int f363b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ WeakReference f364c;

        a(int i2, int i3, WeakReference weakReference) {
            this.f362a = i2;
            this.f363b = i3;
            this.f364c = weakReference;
        }

        @Override // b.g.e.e.f.c
        public void d(int i2) {
        }

        @Override // b.g.e.e.f.c
        public void e(Typeface typeface) {
            int i2;
            if (Build.VERSION.SDK_INT >= 28 && (i2 = this.f362a) != -1) {
                typeface = Typeface.create(typeface, i2, (this.f363b & 2) != 0);
            }
            y.this.n(this.f364c, typeface);
        }
    }

    y(TextView textView) {
        this.f351a = textView;
        this.f359i = new a0(textView);
    }

    private void A(int i2, float f2) {
        this.f359i.y(i2, f2);
    }

    private void B(Context context, w0 w0Var) {
        String n;
        Typeface create;
        Typeface typeface;
        this.f360j = w0Var.j(b.a.j.x2, this.f360j);
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 28) {
            int j2 = w0Var.j(b.a.j.C2, -1);
            this.f361k = j2;
            if (j2 != -1) {
                this.f360j = (this.f360j & 2) | 0;
            }
        }
        int i3 = b.a.j.B2;
        if (!w0Var.r(i3) && !w0Var.r(b.a.j.D2)) {
            int i4 = b.a.j.w2;
            if (w0Var.r(i4)) {
                this.m = false;
                int j3 = w0Var.j(i4, 1);
                if (j3 == 1) {
                    typeface = Typeface.SANS_SERIF;
                } else if (j3 == 2) {
                    typeface = Typeface.SERIF;
                } else if (j3 != 3) {
                    return;
                } else {
                    typeface = Typeface.MONOSPACE;
                }
                this.l = typeface;
                return;
            }
            return;
        }
        this.l = null;
        int i5 = b.a.j.D2;
        if (w0Var.r(i5)) {
            i3 = i5;
        }
        int i6 = this.f361k;
        int i7 = this.f360j;
        if (!context.isRestricted()) {
            try {
                Typeface i8 = w0Var.i(i3, this.f360j, new a(i6, i7, new WeakReference(this.f351a)));
                if (i8 != null) {
                    if (i2 >= 28 && this.f361k != -1) {
                        i8 = Typeface.create(Typeface.create(i8, 0), this.f361k, (this.f360j & 2) != 0);
                    }
                    this.l = i8;
                }
                this.m = this.l == null;
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            }
        }
        if (this.l != null || (n = w0Var.n(i3)) == null) {
            return;
        }
        if (Build.VERSION.SDK_INT < 28 || this.f361k == -1) {
            create = Typeface.create(n, this.f360j);
        } else {
            create = Typeface.create(Typeface.create(n, 0), this.f361k, (this.f360j & 2) != 0);
        }
        this.l = create;
    }

    private void a(Drawable drawable, u0 u0Var) {
        if (drawable == null || u0Var == null) {
            return;
        }
        j.i(drawable, u0Var, this.f351a.getDrawableState());
    }

    private static u0 d(Context context, j jVar, int i2) {
        ColorStateList f2 = jVar.f(context, i2);
        if (f2 == null) {
            return null;
        }
        u0 u0Var = new u0();
        u0Var.f324d = true;
        u0Var.f321a = f2;
        return u0Var;
    }

    private void x(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4, Drawable drawable5, Drawable drawable6) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 17 && (drawable5 != null || drawable6 != null)) {
            Drawable[] compoundDrawablesRelative = this.f351a.getCompoundDrawablesRelative();
            TextView textView = this.f351a;
            if (drawable5 == null) {
                drawable5 = compoundDrawablesRelative[0];
            }
            if (drawable2 == null) {
                drawable2 = compoundDrawablesRelative[1];
            }
            if (drawable6 == null) {
                drawable6 = compoundDrawablesRelative[2];
            }
            if (drawable4 == null) {
                drawable4 = compoundDrawablesRelative[3];
            }
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable5, drawable2, drawable6, drawable4);
            return;
        }
        if (drawable == null && drawable2 == null && drawable3 == null && drawable4 == null) {
            return;
        }
        if (i2 >= 17) {
            Drawable[] compoundDrawablesRelative2 = this.f351a.getCompoundDrawablesRelative();
            if (compoundDrawablesRelative2[0] != null || compoundDrawablesRelative2[2] != null) {
                TextView textView2 = this.f351a;
                Drawable drawable7 = compoundDrawablesRelative2[0];
                if (drawable2 == null) {
                    drawable2 = compoundDrawablesRelative2[1];
                }
                Drawable drawable8 = compoundDrawablesRelative2[2];
                if (drawable4 == null) {
                    drawable4 = compoundDrawablesRelative2[3];
                }
                textView2.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable7, drawable2, drawable8, drawable4);
                return;
            }
        }
        Drawable[] compoundDrawables = this.f351a.getCompoundDrawables();
        TextView textView3 = this.f351a;
        if (drawable == null) {
            drawable = compoundDrawables[0];
        }
        if (drawable2 == null) {
            drawable2 = compoundDrawables[1];
        }
        if (drawable3 == null) {
            drawable3 = compoundDrawables[2];
        }
        if (drawable4 == null) {
            drawable4 = compoundDrawables[3];
        }
        textView3.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
    }

    private void y() {
        u0 u0Var = this.f358h;
        this.f352b = u0Var;
        this.f353c = u0Var;
        this.f354d = u0Var;
        this.f355e = u0Var;
        this.f356f = u0Var;
        this.f357g = u0Var;
    }

    void b() {
        if (this.f352b != null || this.f353c != null || this.f354d != null || this.f355e != null) {
            Drawable[] compoundDrawables = this.f351a.getCompoundDrawables();
            a(compoundDrawables[0], this.f352b);
            a(compoundDrawables[1], this.f353c);
            a(compoundDrawables[2], this.f354d);
            a(compoundDrawables[3], this.f355e);
        }
        if (Build.VERSION.SDK_INT >= 17) {
            if (this.f356f == null && this.f357g == null) {
                return;
            }
            Drawable[] compoundDrawablesRelative = this.f351a.getCompoundDrawablesRelative();
            a(compoundDrawablesRelative[0], this.f356f);
            a(compoundDrawablesRelative[2], this.f357g);
        }
    }

    void c() {
        this.f359i.b();
    }

    int e() {
        return this.f359i.j();
    }

    int f() {
        return this.f359i.k();
    }

    int g() {
        return this.f359i.l();
    }

    int[] h() {
        return this.f359i.m();
    }

    int i() {
        return this.f359i.n();
    }

    ColorStateList j() {
        u0 u0Var = this.f358h;
        if (u0Var != null) {
            return u0Var.f321a;
        }
        return null;
    }

    PorterDuff.Mode k() {
        u0 u0Var = this.f358h;
        if (u0Var != null) {
            return u0Var.f322b;
        }
        return null;
    }

    boolean l() {
        return this.f359i.s();
    }

    /* JADX WARN: Removed duplicated region for block: B:104:0x021a  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x022b  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x0268  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x0277  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x0286  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x0295  */
    /* JADX WARN: Removed duplicated region for block: B:126:0x02a4  */
    /* JADX WARN: Removed duplicated region for block: B:129:0x02b3  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x02cd  */
    /* JADX WARN: Removed duplicated region for block: B:135:0x02de  */
    /* JADX WARN: Removed duplicated region for block: B:138:0x0306  */
    /* JADX WARN: Removed duplicated region for block: B:140:0x030d  */
    /* JADX WARN: Removed duplicated region for block: B:142:0x0314  */
    /* JADX WARN: Removed duplicated region for block: B:145:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:146:0x02ee  */
    /* JADX WARN: Removed duplicated region for block: B:147:0x02b9  */
    /* JADX WARN: Removed duplicated region for block: B:148:0x02aa  */
    /* JADX WARN: Removed duplicated region for block: B:149:0x029b  */
    /* JADX WARN: Removed duplicated region for block: B:150:0x028c  */
    /* JADX WARN: Removed duplicated region for block: B:151:0x027d  */
    /* JADX WARN: Removed duplicated region for block: B:152:0x026e  */
    /* JADX WARN: Removed duplicated region for block: B:157:0x0109  */
    /* JADX WARN: Removed duplicated region for block: B:161:0x00f9  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00d0  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x010c  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0146  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0172  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x017a  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x018d  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x01b0  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x01b7  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x01be  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x01c5 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:89:0x01ce  */
    /* JADX WARN: Removed duplicated region for block: B:94:0x01e2  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x01e9  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    void m(android.util.AttributeSet r24, int r25) {
        /*
            Method dump skipped, instructions count: 794
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.y.m(android.util.AttributeSet, int):void");
    }

    void n(WeakReference<TextView> weakReference, Typeface typeface) {
        if (this.m) {
            this.l = typeface;
            TextView textView = weakReference.get();
            if (textView != null) {
                textView.setTypeface(typeface, this.f360j);
            }
        }
    }

    void o(boolean z, int i2, int i3, int i4, int i5) {
        if (androidx.core.widget.b.f519a) {
            return;
        }
        c();
    }

    void p() {
        b();
    }

    void q(Context context, int i2) {
        String n;
        ColorStateList c2;
        w0 s = w0.s(context, i2, b.a.j.u2);
        int i3 = b.a.j.F2;
        if (s.r(i3)) {
            r(s.a(i3, false));
        }
        int i4 = Build.VERSION.SDK_INT;
        if (i4 < 23) {
            int i5 = b.a.j.y2;
            if (s.r(i5) && (c2 = s.c(i5)) != null) {
                this.f351a.setTextColor(c2);
            }
        }
        int i6 = b.a.j.v2;
        if (s.r(i6) && s.e(i6, -1) == 0) {
            this.f351a.setTextSize(0, 0.0f);
        }
        B(context, s);
        if (i4 >= 26) {
            int i7 = b.a.j.E2;
            if (s.r(i7) && (n = s.n(i7)) != null) {
                this.f351a.setFontVariationSettings(n);
            }
        }
        s.v();
        Typeface typeface = this.l;
        if (typeface != null) {
            this.f351a.setTypeface(typeface, this.f360j);
        }
    }

    void r(boolean z) {
        this.f351a.setAllCaps(z);
    }

    void s(int i2, int i3, int i4, int i5) {
        this.f359i.u(i2, i3, i4, i5);
    }

    void t(int[] iArr, int i2) {
        this.f359i.v(iArr, i2);
    }

    void u(int i2) {
        this.f359i.w(i2);
    }

    void v(ColorStateList colorStateList) {
        if (this.f358h == null) {
            this.f358h = new u0();
        }
        u0 u0Var = this.f358h;
        u0Var.f321a = colorStateList;
        u0Var.f324d = colorStateList != null;
        y();
    }

    void w(PorterDuff.Mode mode) {
        if (this.f358h == null) {
            this.f358h = new u0();
        }
        u0 u0Var = this.f358h;
        u0Var.f322b = mode;
        u0Var.f323c = mode != null;
        y();
    }

    void z(int i2, float f2) {
        if (androidx.core.widget.b.f519a || l()) {
            return;
        }
        A(i2, f2);
    }
}
