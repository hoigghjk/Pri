package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;

/* loaded from: classes.dex */
public class n {

    /* renamed from: a, reason: collision with root package name */
    private final ImageView f287a;

    /* renamed from: b, reason: collision with root package name */
    private u0 f288b;

    /* renamed from: c, reason: collision with root package name */
    private u0 f289c;

    /* renamed from: d, reason: collision with root package name */
    private u0 f290d;

    public n(ImageView imageView) {
        this.f287a = imageView;
    }

    private boolean a(Drawable drawable) {
        if (this.f290d == null) {
            this.f290d = new u0();
        }
        u0 u0Var = this.f290d;
        u0Var.a();
        ColorStateList a2 = androidx.core.widget.e.a(this.f287a);
        if (a2 != null) {
            u0Var.f324d = true;
            u0Var.f321a = a2;
        }
        PorterDuff.Mode b2 = androidx.core.widget.e.b(this.f287a);
        if (b2 != null) {
            u0Var.f323c = true;
            u0Var.f322b = b2;
        }
        if (!u0Var.f324d && !u0Var.f323c) {
            return false;
        }
        j.i(drawable, u0Var, this.f287a.getDrawableState());
        return true;
    }

    private boolean j() {
        int i2 = Build.VERSION.SDK_INT;
        return i2 > 21 ? this.f288b != null : i2 == 21;
    }

    void b() {
        Drawable drawable = this.f287a.getDrawable();
        if (drawable != null) {
            e0.b(drawable);
        }
        if (drawable != null) {
            if (j() && a(drawable)) {
                return;
            }
            u0 u0Var = this.f289c;
            if (u0Var != null) {
                j.i(drawable, u0Var, this.f287a.getDrawableState());
                return;
            }
            u0 u0Var2 = this.f288b;
            if (u0Var2 != null) {
                j.i(drawable, u0Var2, this.f287a.getDrawableState());
            }
        }
    }

    ColorStateList c() {
        u0 u0Var = this.f289c;
        if (u0Var != null) {
            return u0Var.f321a;
        }
        return null;
    }

    PorterDuff.Mode d() {
        u0 u0Var = this.f289c;
        if (u0Var != null) {
            return u0Var.f322b;
        }
        return null;
    }

    boolean e() {
        return Build.VERSION.SDK_INT < 21 || !(this.f287a.getBackground() instanceof RippleDrawable);
    }

    public void f(AttributeSet attributeSet, int i2) {
        int m;
        Context context = this.f287a.getContext();
        int[] iArr = b.a.j.M;
        w0 u = w0.u(context, attributeSet, iArr, i2, 0);
        ImageView imageView = this.f287a;
        b.g.l.r.J(imageView, imageView.getContext(), iArr, attributeSet, u.q(), i2, 0);
        try {
            Drawable drawable = this.f287a.getDrawable();
            if (drawable == null && (m = u.m(b.a.j.N, -1)) != -1 && (drawable = b.a.k.a.a.d(this.f287a.getContext(), m)) != null) {
                this.f287a.setImageDrawable(drawable);
            }
            if (drawable != null) {
                e0.b(drawable);
            }
            int i3 = b.a.j.O;
            if (u.r(i3)) {
                androidx.core.widget.e.c(this.f287a, u.c(i3));
            }
            int i4 = b.a.j.P;
            if (u.r(i4)) {
                androidx.core.widget.e.d(this.f287a, e0.d(u.j(i4, -1), null));
            }
        } finally {
            u.v();
        }
    }

    public void g(int i2) {
        if (i2 != 0) {
            Drawable d2 = b.a.k.a.a.d(this.f287a.getContext(), i2);
            if (d2 != null) {
                e0.b(d2);
            }
            this.f287a.setImageDrawable(d2);
        } else {
            this.f287a.setImageDrawable(null);
        }
        b();
    }

    void h(ColorStateList colorStateList) {
        if (this.f289c == null) {
            this.f289c = new u0();
        }
        u0 u0Var = this.f289c;
        u0Var.f321a = colorStateList;
        u0Var.f324d = true;
        b();
    }

    void i(PorterDuff.Mode mode) {
        if (this.f289c == null) {
            this.f289c = new u0();
        }
        u0 u0Var = this.f289c;
        u0Var.f322b = mode;
        u0Var.f323c = true;
        b();
    }
}
