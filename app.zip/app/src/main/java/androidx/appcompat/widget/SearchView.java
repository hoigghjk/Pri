package androidx.appcompat.widget;

import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public class SearchView extends i0 implements b.a.n.c {
    static final n D0;
    private final AdapterView.OnItemClickListener A0;
    private final AdapterView.OnItemSelectedListener B0;
    final SearchAutoComplete C;
    private TextWatcher C0;
    private final View D;
    private final View E;
    private final View F;
    final ImageView G;
    final ImageView H;
    final ImageView I;
    final ImageView J;
    private final View K;
    private p L;
    private Rect M;
    private Rect N;
    private int[] O;
    private int[] P;
    private final ImageView Q;
    private final Drawable R;
    private final int S;
    private final int T;
    private final Intent U;
    private final Intent V;
    private final CharSequence W;
    private l a0;
    private k b0;
    View.OnFocusChangeListener c0;
    private m d0;
    private View.OnClickListener e0;
    private boolean f0;
    private boolean g0;
    b.h.a.a h0;
    private boolean i0;
    private CharSequence j0;
    private boolean k0;
    private boolean l0;
    private int m0;
    private boolean n0;
    private CharSequence o0;
    private CharSequence p0;
    private boolean q0;
    private int r0;
    SearchableInfo s0;
    private Bundle t0;
    private final Runnable u0;
    private Runnable v0;
    private final WeakHashMap<String, Drawable.ConstantState> w0;
    private final View.OnClickListener x0;
    View.OnKeyListener y0;
    private final TextView.OnEditorActionListener z0;

    public static class SearchAutoComplete extends androidx.appcompat.widget.d {
        private int q;
        private SearchView r;
        private boolean s;
        final Runnable t;

        class a implements Runnable {
            a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                SearchAutoComplete.this.c();
            }
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, b.a.a.p);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet, int i2) {
            super(context, attributeSet, i2);
            this.t = new a();
            this.q = getThreshold();
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i2 = configuration.screenWidthDp;
            int i3 = configuration.screenHeightDp;
            if (i2 >= 960 && i3 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i2 < 600) {
                return (i2 < 640 || i3 < 480) ? 160 : 192;
            }
            return 192;
        }

        void a() {
            if (Build.VERSION.SDK_INT < 29) {
                SearchView.D0.c(this);
                return;
            }
            setInputMethodMode(1);
            if (enoughToFilter()) {
                showDropDown();
            }
        }

        boolean b() {
            return TextUtils.getTrimmedLength(getText()) == 0;
        }

        void c() {
            if (this.s) {
                ((InputMethodManager) getContext().getSystemService("input_method")).showSoftInput(this, 0);
                this.s = false;
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public boolean enoughToFilter() {
            return this.q <= 0 || super.enoughToFilter();
        }

        @Override // androidx.appcompat.widget.d, android.widget.TextView, android.view.View
        public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.s) {
                removeCallbacks(this.t);
                post(this.t);
            }
            return onCreateInputConnection;
        }

        @Override // android.view.View
        protected void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        protected void onFocusChanged(boolean z, int i2, Rect rect) {
            super.onFocusChanged(z, i2, rect);
            this.r.X();
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public boolean onKeyPreIme(int i2, KeyEvent keyEvent) {
            if (i2 == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                }
                if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.r.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i2, keyEvent);
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public void onWindowFocusChanged(boolean z) {
            super.onWindowFocusChanged(z);
            if (z && this.r.hasFocus() && getVisibility() == 0) {
                this.s = true;
                if (SearchView.K(getContext())) {
                    a();
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public void performCompletion() {
        }

        @Override // android.widget.AutoCompleteTextView
        protected void replaceText(CharSequence charSequence) {
        }

        void setImeVisibility(boolean z) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            if (!z) {
                this.s = false;
                removeCallbacks(this.t);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else {
                if (!inputMethodManager.isActive(this)) {
                    this.s = true;
                    return;
                }
                this.s = false;
                removeCallbacks(this.t);
                inputMethodManager.showSoftInput(this, 0);
            }
        }

        void setSearchView(SearchView searchView) {
            this.r = searchView;
        }

        @Override // android.widget.AutoCompleteTextView
        public void setThreshold(int i2) {
            super.setThreshold(i2);
            this.q = i2;
        }
    }

    class a implements TextWatcher {
        a() {
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            SearchView.this.W(charSequence);
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            SearchView.this.d0();
        }
    }

    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            b.h.a.a aVar = SearchView.this.h0;
            if (aVar instanceof q0) {
                aVar.a(null);
            }
        }
    }

    class d implements View.OnFocusChangeListener {
        d() {
        }

        @Override // android.view.View.OnFocusChangeListener
        public void onFocusChange(View view, boolean z) {
            SearchView searchView = SearchView.this;
            View.OnFocusChangeListener onFocusChangeListener = searchView.c0;
            if (onFocusChangeListener != null) {
                onFocusChangeListener.onFocusChange(searchView, z);
            }
        }
    }

    class e implements View.OnLayoutChangeListener {
        e() {
        }

        @Override // android.view.View.OnLayoutChangeListener
        public void onLayoutChange(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
            SearchView.this.z();
        }
    }

    class f implements View.OnClickListener {
        f() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            SearchView searchView = SearchView.this;
            if (view == searchView.G) {
                searchView.T();
                return;
            }
            if (view == searchView.I) {
                searchView.P();
                return;
            }
            if (view == searchView.H) {
                searchView.U();
            } else if (view == searchView.J) {
                searchView.Y();
            } else if (view == searchView.C) {
                searchView.F();
            }
        }
    }

    class g implements View.OnKeyListener {
        g() {
        }

        @Override // android.view.View.OnKeyListener
        public boolean onKey(View view, int i2, KeyEvent keyEvent) {
            SearchView searchView = SearchView.this;
            if (searchView.s0 == null) {
                return false;
            }
            if (searchView.C.isPopupShowing() && SearchView.this.C.getListSelection() != -1) {
                return SearchView.this.V(view, i2, keyEvent);
            }
            if (SearchView.this.C.b() || !keyEvent.hasNoModifiers() || keyEvent.getAction() != 1 || i2 != 66) {
                return false;
            }
            view.cancelLongPress();
            SearchView searchView2 = SearchView.this;
            searchView2.N(0, null, searchView2.C.getText().toString());
            return true;
        }
    }

    class h implements TextView.OnEditorActionListener {
        h() {
        }

        @Override // android.widget.TextView.OnEditorActionListener
        public boolean onEditorAction(TextView textView, int i2, KeyEvent keyEvent) {
            SearchView.this.U();
            return true;
        }
    }

    class i implements AdapterView.OnItemClickListener {
        i() {
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
            SearchView.this.Q(i2, 0, null);
        }
    }

    class j implements AdapterView.OnItemSelectedListener {
        j() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
            SearchView.this.R(i2);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public interface k {
        boolean onClose();
    }

    public interface l {
        boolean onQueryTextChange(String str);

        boolean onQueryTextSubmit(String str);
    }

    public interface m {
        boolean a(int i2);

        boolean b(int i2);
    }

    private static class n {

        /* renamed from: a, reason: collision with root package name */
        private Method f213a;

        /* renamed from: b, reason: collision with root package name */
        private Method f214b;

        /* renamed from: c, reason: collision with root package name */
        private Method f215c;

        n() {
            this.f213a = null;
            this.f214b = null;
            this.f215c = null;
            d();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
                this.f213a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
                this.f214b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", Boolean.TYPE);
                this.f215c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
        }

        private static void d() {
            if (Build.VERSION.SDK_INT >= 29) {
                throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
            }
        }

        void a(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.f214b;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, new Object[0]);
                } catch (Exception unused) {
                }
            }
        }

        void b(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.f213a;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, new Object[0]);
                } catch (Exception unused) {
                }
            }
        }

        void c(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.f215c;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        }
    }

    static class o extends b.i.a.a {
        public static final Parcelable.Creator<o> CREATOR = new a();
        boolean p;

        class a implements Parcelable.ClassLoaderCreator<o> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public o createFromParcel(Parcel parcel) {
                return new o(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public o createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new o(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: c, reason: merged with bridge method [inline-methods] */
            public o[] newArray(int i2) {
                return new o[i2];
            }
        }

        public o(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.p = ((Boolean) parcel.readValue(null)).booleanValue();
        }

        o(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "SearchView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " isIconified=" + this.p + "}";
        }

        @Override // b.i.a.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeValue(Boolean.valueOf(this.p));
        }
    }

    private static class p extends TouchDelegate {

        /* renamed from: a, reason: collision with root package name */
        private final View f216a;

        /* renamed from: b, reason: collision with root package name */
        private final Rect f217b;

        /* renamed from: c, reason: collision with root package name */
        private final Rect f218c;

        /* renamed from: d, reason: collision with root package name */
        private final Rect f219d;

        /* renamed from: e, reason: collision with root package name */
        private final int f220e;

        /* renamed from: f, reason: collision with root package name */
        private boolean f221f;

        public p(Rect rect, Rect rect2, View view) {
            super(rect, view);
            this.f220e = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
            this.f217b = new Rect();
            this.f219d = new Rect();
            this.f218c = new Rect();
            a(rect, rect2);
            this.f216a = view;
        }

        public void a(Rect rect, Rect rect2) {
            this.f217b.set(rect);
            this.f219d.set(rect);
            Rect rect3 = this.f219d;
            int i2 = this.f220e;
            rect3.inset(-i2, -i2);
            this.f218c.set(rect2);
        }

        @Override // android.view.TouchDelegate
        public boolean onTouchEvent(MotionEvent motionEvent) {
            boolean z;
            float f2;
            int i2;
            boolean z2;
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            int action = motionEvent.getAction();
            boolean z3 = true;
            if (action != 0) {
                if (action == 1 || action == 2) {
                    z2 = this.f221f;
                    if (z2 && !this.f219d.contains(x, y)) {
                        z3 = z2;
                        z = false;
                    }
                } else {
                    if (action == 3) {
                        z2 = this.f221f;
                        this.f221f = false;
                    }
                    z = true;
                    z3 = false;
                }
                z3 = z2;
                z = true;
            } else {
                if (this.f217b.contains(x, y)) {
                    this.f221f = true;
                    z = true;
                }
                z = true;
                z3 = false;
            }
            if (!z3) {
                return false;
            }
            if (!z || this.f218c.contains(x, y)) {
                Rect rect = this.f218c;
                f2 = x - rect.left;
                i2 = y - rect.top;
            } else {
                f2 = this.f216a.getWidth() / 2;
                i2 = this.f216a.getHeight() / 2;
            }
            motionEvent.setLocation(f2, i2);
            return this.f216a.dispatchTouchEvent(motionEvent);
        }
    }

    static {
        D0 = Build.VERSION.SDK_INT < 29 ? new n() : null;
    }

    public SearchView(Context context) {
        this(context, null);
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b.a.a.G);
    }

    public SearchView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.M = new Rect();
        this.N = new Rect();
        this.O = new int[2];
        this.P = new int[2];
        this.u0 = new b();
        this.v0 = new c();
        this.w0 = new WeakHashMap<>();
        f fVar = new f();
        this.x0 = fVar;
        this.y0 = new g();
        h hVar = new h();
        this.z0 = hVar;
        i iVar = new i();
        this.A0 = iVar;
        j jVar = new j();
        this.B0 = jVar;
        this.C0 = new a();
        w0 u = w0.u(context, attributeSet, b.a.j.W1, i2, 0);
        LayoutInflater.from(context).inflate(u.m(b.a.j.g2, b.a.g.r), (ViewGroup) this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(b.a.f.D);
        this.C = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.D = findViewById(b.a.f.z);
        View findViewById = findViewById(b.a.f.C);
        this.E = findViewById;
        View findViewById2 = findViewById(b.a.f.J);
        this.F = findViewById2;
        ImageView imageView = (ImageView) findViewById(b.a.f.x);
        this.G = imageView;
        ImageView imageView2 = (ImageView) findViewById(b.a.f.A);
        this.H = imageView2;
        ImageView imageView3 = (ImageView) findViewById(b.a.f.y);
        this.I = imageView3;
        ImageView imageView4 = (ImageView) findViewById(b.a.f.E);
        this.J = imageView4;
        ImageView imageView5 = (ImageView) findViewById(b.a.f.B);
        this.Q = imageView5;
        b.g.l.r.M(findViewById, u.f(b.a.j.h2));
        b.g.l.r.M(findViewById2, u.f(b.a.j.l2));
        int i3 = b.a.j.k2;
        imageView.setImageDrawable(u.f(i3));
        imageView2.setImageDrawable(u.f(b.a.j.e2));
        imageView3.setImageDrawable(u.f(b.a.j.b2));
        imageView4.setImageDrawable(u.f(b.a.j.n2));
        imageView5.setImageDrawable(u.f(i3));
        this.R = u.f(b.a.j.j2);
        y0.a(imageView, getResources().getString(b.a.h.l));
        this.S = u.m(b.a.j.m2, b.a.g.q);
        this.T = u.m(b.a.j.c2, 0);
        imageView.setOnClickListener(fVar);
        imageView3.setOnClickListener(fVar);
        imageView2.setOnClickListener(fVar);
        imageView4.setOnClickListener(fVar);
        searchAutoComplete.setOnClickListener(fVar);
        searchAutoComplete.addTextChangedListener(this.C0);
        searchAutoComplete.setOnEditorActionListener(hVar);
        searchAutoComplete.setOnItemClickListener(iVar);
        searchAutoComplete.setOnItemSelectedListener(jVar);
        searchAutoComplete.setOnKeyListener(this.y0);
        searchAutoComplete.setOnFocusChangeListener(new d());
        setIconifiedByDefault(u.a(b.a.j.f2, true));
        int e2 = u.e(b.a.j.Y1, -1);
        if (e2 != -1) {
            setMaxWidth(e2);
        }
        this.W = u.o(b.a.j.d2);
        this.j0 = u.o(b.a.j.i2);
        int j2 = u.j(b.a.j.a2, -1);
        if (j2 != -1) {
            setImeOptions(j2);
        }
        int j3 = u.j(b.a.j.Z1, -1);
        if (j3 != -1) {
            setInputType(j3);
        }
        setFocusable(u.a(b.a.j.X1, true));
        u.v();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.U = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.V = intent2;
        intent2.addFlags(268435456);
        View findViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.K = findViewById3;
        if (findViewById3 != null) {
            findViewById3.addOnLayoutChangeListener(new e());
        }
        i0(this.f0);
        e0();
    }

    private Intent A(String str, Uri uri, String str2, String str3, int i2, String str4) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.p0);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.t0;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        if (i2 != 0) {
            intent.putExtra("action_key", i2);
            intent.putExtra("action_msg", str4);
        }
        intent.setComponent(this.s0.getSearchActivity());
        return intent;
    }

    private Intent B(Cursor cursor, int i2, String str) {
        int i3;
        String o2;
        try {
            String o3 = q0.o(cursor, "suggest_intent_action");
            if (o3 == null) {
                o3 = this.s0.getSuggestIntentAction();
            }
            if (o3 == null) {
                o3 = "android.intent.action.SEARCH";
            }
            String str2 = o3;
            String o4 = q0.o(cursor, "suggest_intent_data");
            if (o4 == null) {
                o4 = this.s0.getSuggestIntentData();
            }
            if (o4 != null && (o2 = q0.o(cursor, "suggest_intent_data_id")) != null) {
                o4 = o4 + "/" + Uri.encode(o2);
            }
            return A(str2, o4 == null ? null : Uri.parse(o4), q0.o(cursor, "suggest_intent_extra_data"), q0.o(cursor, "suggest_intent_query"), i2, str);
        } catch (RuntimeException e2) {
            try {
                i3 = cursor.getPosition();
            } catch (RuntimeException unused) {
                i3 = -1;
            }
            Log.w("SearchView", "Search suggestions cursor at row " + i3 + " returned exception.", e2);
            return null;
        }
    }

    private Intent C(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1073741824);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.t0;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        int voiceMaxResults = searchableInfo.getVoiceMaxResults() != 0 ? searchableInfo.getVoiceMaxResults() : 1;
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", voiceMaxResults);
        intent3.putExtra("calling_package", searchActivity != null ? searchActivity.flattenToShortString() : null);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    private Intent D(Intent intent, SearchableInfo searchableInfo) {
        Intent intent2 = new Intent(intent);
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        intent2.putExtra("calling_package", searchActivity == null ? null : searchActivity.flattenToShortString());
        return intent2;
    }

    private void E() {
        this.C.dismissDropDown();
    }

    private void G(View view, Rect rect) {
        view.getLocationInWindow(this.O);
        getLocationInWindow(this.P);
        int[] iArr = this.O;
        int i2 = iArr[1];
        int[] iArr2 = this.P;
        int i3 = i2 - iArr2[1];
        int i4 = iArr[0] - iArr2[0];
        rect.set(i4, i3, view.getWidth() + i4, view.getHeight() + i3);
    }

    private CharSequence H(CharSequence charSequence) {
        if (!this.f0 || this.R == null) {
            return charSequence;
        }
        int textSize = (int) (this.C.getTextSize() * 1.25d);
        this.R.setBounds(0, 0, textSize, textSize);
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
        spannableStringBuilder.setSpan(new ImageSpan(this.R), 1, 2, 33);
        spannableStringBuilder.append(charSequence);
        return spannableStringBuilder;
    }

    private boolean I() {
        SearchableInfo searchableInfo = this.s0;
        if (searchableInfo == null || !searchableInfo.getVoiceSearchEnabled()) {
            return false;
        }
        Intent intent = null;
        if (this.s0.getVoiceSearchLaunchWebSearch()) {
            intent = this.U;
        } else if (this.s0.getVoiceSearchLaunchRecognizer()) {
            intent = this.V;
        }
        return (intent == null || getContext().getPackageManager().resolveActivity(intent, 65536) == null) ? false : true;
    }

    static boolean K(Context context) {
        return context.getResources().getConfiguration().orientation == 2;
    }

    private boolean L() {
        return (this.i0 || this.n0) && !J();
    }

    private void M(Intent intent) {
        if (intent == null) {
            return;
        }
        try {
            getContext().startActivity(intent);
        } catch (RuntimeException e2) {
            Log.e("SearchView", "Failed launch activity: " + intent, e2);
        }
    }

    private boolean O(int i2, int i3, String str) {
        Cursor b2 = this.h0.b();
        if (b2 == null || !b2.moveToPosition(i2)) {
            return false;
        }
        M(B(b2, i3, str));
        return true;
    }

    private void Z() {
        post(this.u0);
    }

    private void a0(int i2) {
        CharSequence c2;
        Editable text = this.C.getText();
        Cursor b2 = this.h0.b();
        if (b2 == null) {
            return;
        }
        if (!b2.moveToPosition(i2) || (c2 = this.h0.c(b2)) == null) {
            setQuery(text);
        } else {
            setQuery(c2);
        }
    }

    private void c0() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.C.getText());
        if (!z2 && (!this.f0 || this.q0)) {
            z = false;
        }
        this.I.setVisibility(z ? 0 : 8);
        Drawable drawable = this.I.getDrawable();
        if (drawable != null) {
            drawable.setState(z2 ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    private void e0() {
        CharSequence queryHint = getQueryHint();
        SearchAutoComplete searchAutoComplete = this.C;
        if (queryHint == null) {
            queryHint = "";
        }
        searchAutoComplete.setHint(H(queryHint));
    }

    private void f0() {
        this.C.setThreshold(this.s0.getSuggestThreshold());
        this.C.setImeOptions(this.s0.getImeOptions());
        int inputType = this.s0.getInputType();
        if ((inputType & 15) == 1) {
            inputType &= -65537;
            if (this.s0.getSuggestAuthority() != null) {
                inputType = inputType | 65536 | 524288;
            }
        }
        this.C.setInputType(inputType);
        b.h.a.a aVar = this.h0;
        if (aVar != null) {
            aVar.a(null);
        }
        if (this.s0.getSuggestAuthority() != null) {
            q0 q0Var = new q0(getContext(), this, this.s0, this.w0);
            this.h0 = q0Var;
            this.C.setAdapter(q0Var);
            ((q0) this.h0).x(this.k0 ? 2 : 1);
        }
    }

    private void g0() {
        this.F.setVisibility((L() && (this.H.getVisibility() == 0 || this.J.getVisibility() == 0)) ? 0 : 8);
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(b.a.d.f732g);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(b.a.d.f733h);
    }

    private void h0(boolean z) {
        this.H.setVisibility((this.i0 && L() && hasFocus() && (z || !this.n0)) ? 0 : 8);
    }

    private void i0(boolean z) {
        this.g0 = z;
        int i2 = z ? 0 : 8;
        boolean z2 = !TextUtils.isEmpty(this.C.getText());
        this.G.setVisibility(i2);
        h0(z2);
        this.D.setVisibility(z ? 8 : 0);
        this.Q.setVisibility((this.Q.getDrawable() == null || this.f0) ? 8 : 0);
        c0();
        j0(!z2);
        g0();
    }

    private void j0(boolean z) {
        int i2 = 8;
        if (this.n0 && !J() && z) {
            this.H.setVisibility(8);
            i2 = 0;
        }
        this.J.setVisibility(i2);
    }

    private void setQuery(CharSequence charSequence) {
        this.C.setText(charSequence);
        this.C.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    void F() {
        if (Build.VERSION.SDK_INT >= 29) {
            this.C.refreshAutoCompleteResults();
            return;
        }
        n nVar = D0;
        nVar.b(this.C);
        nVar.a(this.C);
    }

    public boolean J() {
        return this.g0;
    }

    void N(int i2, String str, String str2) {
        getContext().startActivity(A("android.intent.action.SEARCH", null, null, str2, i2, str));
    }

    void P() {
        if (!TextUtils.isEmpty(this.C.getText())) {
            this.C.setText("");
            this.C.requestFocus();
            this.C.setImeVisibility(true);
        } else if (this.f0) {
            k kVar = this.b0;
            if (kVar == null || !kVar.onClose()) {
                clearFocus();
                i0(true);
            }
        }
    }

    boolean Q(int i2, int i3, String str) {
        m mVar = this.d0;
        if (mVar != null && mVar.b(i2)) {
            return false;
        }
        O(i2, 0, null);
        this.C.setImeVisibility(false);
        E();
        return true;
    }

    boolean R(int i2) {
        m mVar = this.d0;
        if (mVar != null && mVar.a(i2)) {
            return false;
        }
        a0(i2);
        return true;
    }

    void S(CharSequence charSequence) {
        setQuery(charSequence);
    }

    void T() {
        i0(false);
        this.C.requestFocus();
        this.C.setImeVisibility(true);
        View.OnClickListener onClickListener = this.e0;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    void U() {
        Editable text = this.C.getText();
        if (text == null || TextUtils.getTrimmedLength(text) <= 0) {
            return;
        }
        l lVar = this.a0;
        if (lVar == null || !lVar.onQueryTextSubmit(text.toString())) {
            if (this.s0 != null) {
                N(0, null, text.toString());
            }
            this.C.setImeVisibility(false);
            E();
        }
    }

    boolean V(View view, int i2, KeyEvent keyEvent) {
        if (this.s0 != null && this.h0 != null && keyEvent.getAction() == 0 && keyEvent.hasNoModifiers()) {
            if (i2 == 66 || i2 == 84 || i2 == 61) {
                return Q(this.C.getListSelection(), 0, null);
            }
            if (i2 == 21 || i2 == 22) {
                this.C.setSelection(i2 == 21 ? 0 : this.C.length());
                this.C.setListSelection(0);
                this.C.clearListSelection();
                this.C.a();
                return true;
            }
            if (i2 != 19 || this.C.getListSelection() == 0) {
                return false;
            }
        }
        return false;
    }

    void W(CharSequence charSequence) {
        Editable text = this.C.getText();
        this.p0 = text;
        boolean z = !TextUtils.isEmpty(text);
        h0(z);
        j0(!z);
        c0();
        g0();
        if (this.a0 != null && !TextUtils.equals(charSequence, this.o0)) {
            this.a0.onQueryTextChange(charSequence.toString());
        }
        this.o0 = charSequence.toString();
    }

    void X() {
        i0(J());
        Z();
        if (this.C.hasFocus()) {
            F();
        }
    }

    void Y() {
        Intent C;
        SearchableInfo searchableInfo = this.s0;
        if (searchableInfo == null) {
            return;
        }
        try {
            if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
                C = D(this.U, searchableInfo);
            } else if (!searchableInfo.getVoiceSearchLaunchRecognizer()) {
                return;
            } else {
                C = C(this.V, searchableInfo);
            }
            getContext().startActivity(C);
        } catch (ActivityNotFoundException unused) {
            Log.w("SearchView", "Could not find voice search activity");
        }
    }

    public void b0(CharSequence charSequence, boolean z) {
        this.C.setText(charSequence);
        if (charSequence != null) {
            SearchAutoComplete searchAutoComplete = this.C;
            searchAutoComplete.setSelection(searchAutoComplete.length());
            this.p0 = charSequence;
        }
        if (!z || TextUtils.isEmpty(charSequence)) {
            return;
        }
        U();
    }

    @Override // b.a.n.c
    public void c() {
        if (this.q0) {
            return;
        }
        this.q0 = true;
        int imeOptions = this.C.getImeOptions();
        this.r0 = imeOptions;
        this.C.setImeOptions(imeOptions | 33554432);
        this.C.setText("");
        setIconified(false);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void clearFocus() {
        this.l0 = true;
        super.clearFocus();
        this.C.clearFocus();
        this.C.setImeVisibility(false);
        this.l0 = false;
    }

    @Override // b.a.n.c
    public void d() {
        b0("", false);
        clearFocus();
        i0(true);
        this.C.setImeOptions(this.r0);
        this.q0 = false;
    }

    void d0() {
        int[] iArr = this.C.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.E.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.F.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    public int getImeOptions() {
        return this.C.getImeOptions();
    }

    public int getInputType() {
        return this.C.getInputType();
    }

    public int getMaxWidth() {
        return this.m0;
    }

    public CharSequence getQuery() {
        return this.C.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.j0;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.s0;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.W : getContext().getText(this.s0.getHintId());
    }

    int getSuggestionCommitIconResId() {
        return this.T;
    }

    int getSuggestionRowLayout() {
        return this.S;
    }

    public b.h.a.a getSuggestionsAdapter() {
        return this.h0;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        removeCallbacks(this.u0);
        post(this.v0);
        super.onDetachedFromWindow();
    }

    @Override // androidx.appcompat.widget.i0, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        super.onLayout(z, i2, i3, i4, i5);
        if (z) {
            G(this.C, this.M);
            Rect rect = this.N;
            Rect rect2 = this.M;
            rect.set(rect2.left, 0, rect2.right, i5 - i3);
            p pVar = this.L;
            if (pVar != null) {
                pVar.a(this.N, this.M);
                return;
            }
            p pVar2 = new p(this.N, this.M, this.C);
            this.L = pVar2;
            setTouchDelegate(pVar2);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x001f, code lost:
    
        if (r0 <= 0) goto L23;
     */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0043  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x004b  */
    @Override // androidx.appcompat.widget.i0, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void onMeasure(int r4, int r5) {
        /*
            r3 = this;
            boolean r0 = r3.J()
            if (r0 == 0) goto La
            super.onMeasure(r4, r5)
            return
        La:
            int r0 = android.view.View.MeasureSpec.getMode(r4)
            int r4 = android.view.View.MeasureSpec.getSize(r4)
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            r2 = 1073741824(0x40000000, float:2.0)
            if (r0 == r1) goto L2c
            if (r0 == 0) goto L22
            if (r0 == r2) goto L1d
            goto L39
        L1d:
            int r0 = r3.m0
            if (r0 <= 0) goto L39
            goto L30
        L22:
            int r4 = r3.m0
            if (r4 <= 0) goto L27
            goto L39
        L27:
            int r4 = r3.getPreferredWidth()
            goto L39
        L2c:
            int r0 = r3.m0
            if (r0 <= 0) goto L31
        L30:
            goto L35
        L31:
            int r0 = r3.getPreferredWidth()
        L35:
            int r4 = java.lang.Math.min(r0, r4)
        L39:
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            if (r0 == r1) goto L4b
            if (r0 == 0) goto L46
            goto L53
        L46:
            int r5 = r3.getPreferredHeight()
            goto L53
        L4b:
            int r0 = r3.getPreferredHeight()
            int r5 = java.lang.Math.min(r0, r5)
        L53:
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r2)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r2)
            super.onMeasure(r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.onMeasure(int, int):void");
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof o)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        o oVar = (o) parcelable;
        super.onRestoreInstanceState(oVar.a());
        i0(oVar.p);
        requestLayout();
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        o oVar = new o(super.onSaveInstanceState());
        oVar.p = J();
        return oVar;
    }

    @Override // android.view.View
    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        Z();
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean requestFocus(int i2, Rect rect) {
        if (this.l0 || !isFocusable()) {
            return false;
        }
        if (J()) {
            return super.requestFocus(i2, rect);
        }
        boolean requestFocus = this.C.requestFocus(i2, rect);
        if (requestFocus) {
            i0(false);
        }
        return requestFocus;
    }

    public void setAppSearchData(Bundle bundle) {
        this.t0 = bundle;
    }

    public void setIconified(boolean z) {
        if (z) {
            P();
        } else {
            T();
        }
    }

    public void setIconifiedByDefault(boolean z) {
        if (this.f0 == z) {
            return;
        }
        this.f0 = z;
        i0(z);
        e0();
    }

    public void setImeOptions(int i2) {
        this.C.setImeOptions(i2);
    }

    public void setInputType(int i2) {
        this.C.setInputType(i2);
    }

    public void setMaxWidth(int i2) {
        this.m0 = i2;
        requestLayout();
    }

    public void setOnCloseListener(k kVar) {
        this.b0 = kVar;
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.c0 = onFocusChangeListener;
    }

    public void setOnQueryTextListener(l lVar) {
        this.a0 = lVar;
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.e0 = onClickListener;
    }

    public void setOnSuggestionListener(m mVar) {
        this.d0 = mVar;
    }

    public void setQueryHint(CharSequence charSequence) {
        this.j0 = charSequence;
        e0();
    }

    public void setQueryRefinementEnabled(boolean z) {
        this.k0 = z;
        b.h.a.a aVar = this.h0;
        if (aVar instanceof q0) {
            ((q0) aVar).x(z ? 2 : 1);
        }
    }

    public void setSearchableInfo(SearchableInfo searchableInfo) {
        this.s0 = searchableInfo;
        if (searchableInfo != null) {
            f0();
            e0();
        }
        boolean I = I();
        this.n0 = I;
        if (I) {
            this.C.setPrivateImeOptions("nm");
        }
        i0(J());
    }

    public void setSubmitButtonEnabled(boolean z) {
        this.i0 = z;
        i0(J());
    }

    public void setSuggestionsAdapter(b.h.a.a aVar) {
        this.h0 = aVar;
        this.C.setAdapter(aVar);
    }

    void z() {
        if (this.K.getWidth() > 1) {
            Resources resources = getContext().getResources();
            int paddingLeft = this.E.getPaddingLeft();
            Rect rect = new Rect();
            boolean b2 = c1.b(this);
            int dimensionPixelSize = this.f0 ? resources.getDimensionPixelSize(b.a.d.f730e) + resources.getDimensionPixelSize(b.a.d.f731f) : 0;
            this.C.getDropDownBackground().getPadding(rect);
            int i2 = rect.left;
            this.C.setDropDownHorizontalOffset(b2 ? -i2 : paddingLeft - (i2 + dimensionPixelSize));
            this.C.setDropDownWidth((((this.K.getWidth() + rect.left) + rect.right) + dimensionPixelSize) - paddingLeft);
        }
    }
}
