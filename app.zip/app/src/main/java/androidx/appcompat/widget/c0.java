package androidx.appcompat.widget;

import android.view.Menu;
import android.view.Window;
import androidx.appcompat.view.menu.m;

/* loaded from: classes.dex */
public interface c0 {
    void b(Menu menu, m.a aVar);

    boolean c();

    void d();

    boolean f();

    boolean g();

    boolean h();

    boolean i();

    void j(int i2);

    void k();

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
