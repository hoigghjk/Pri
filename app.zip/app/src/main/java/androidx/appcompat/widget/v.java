package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;

/* loaded from: classes.dex */
class v extends r {

    /* renamed from: d, reason: collision with root package name */
    private final SeekBar f325d;

    /* renamed from: e, reason: collision with root package name */
    private Drawable f326e;

    /* renamed from: f, reason: collision with root package name */
    private ColorStateList f327f;

    /* renamed from: g, reason: collision with root package name */
    private PorterDuff.Mode f328g;

    /* renamed from: h, reason: collision with root package name */
    private boolean f329h;

    /* renamed from: i, reason: collision with root package name */
    private boolean f330i;

    v(SeekBar seekBar) {
        super(seekBar);
        this.f327f = null;
        this.f328g = null;
        this.f329h = false;
        this.f330i = false;
        this.f325d = seekBar;
    }

    private void f() {
        Drawable drawable = this.f326e;
        if (drawable != null) {
            if (this.f329h || this.f330i) {
                Drawable p = androidx.core.graphics.drawable.a.p(drawable.mutate());
                this.f326e = p;
                if (this.f329h) {
                    androidx.core.graphics.drawable.a.n(p, this.f327f);
                }
                if (this.f330i) {
                    androidx.core.graphics.drawable.a.o(this.f326e, this.f328g);
                }
                if (this.f326e.isStateful()) {
                    this.f326e.setState(this.f325d.getDrawableState());
                }
            }
        }
    }

    @Override // androidx.appcompat.widget.r
    void c(AttributeSet attributeSet, int i2) {
        super.c(attributeSet, i2);
        Context context = this.f325d.getContext();
        int[] iArr = b.a.j.Q;
        w0 u = w0.u(context, attributeSet, iArr, i2, 0);
        SeekBar seekBar = this.f325d;
        b.g.l.r.J(seekBar, seekBar.getContext(), iArr, attributeSet, u.q(), i2, 0);
        Drawable g2 = u.g(b.a.j.R);
        if (g2 != null) {
            this.f325d.setThumb(g2);
        }
        j(u.f(b.a.j.S));
        int i3 = b.a.j.U;
        if (u.r(i3)) {
            this.f328g = e0.d(u.j(i3, -1), this.f328g);
            this.f330i = true;
        }
        int i4 = b.a.j.T;
        if (u.r(i4)) {
            this.f327f = u.c(i4);
            this.f329h = true;
        }
        u.v();
        f();
    }

    void g(Canvas canvas) {
        if (this.f326e != null) {
            int max = this.f325d.getMax();
            if (max > 1) {
                int intrinsicWidth = this.f326e.getIntrinsicWidth();
                int intrinsicHeight = this.f326e.getIntrinsicHeight();
                int i2 = intrinsicWidth >= 0 ? intrinsicWidth / 2 : 1;
                int i3 = intrinsicHeight >= 0 ? intrinsicHeight / 2 : 1;
                this.f326e.setBounds(-i2, -i3, i2, i3);
                float width = ((this.f325d.getWidth() - this.f325d.getPaddingLeft()) - this.f325d.getPaddingRight()) / max;
                int save = canvas.save();
                canvas.translate(this.f325d.getPaddingLeft(), this.f325d.getHeight() / 2);
                for (int i4 = 0; i4 <= max; i4++) {
                    this.f326e.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(save);
            }
        }
    }

    void h() {
        Drawable drawable = this.f326e;
        if (drawable != null && drawable.isStateful() && drawable.setState(this.f325d.getDrawableState())) {
            this.f325d.invalidateDrawable(drawable);
        }
    }

    void i() {
        Drawable drawable = this.f326e;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    void j(Drawable drawable) {
        Drawable drawable2 = this.f326e;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f326e = drawable;
        if (drawable != null) {
            drawable.setCallback(this.f325d);
            androidx.core.graphics.drawable.a.l(drawable, b.g.l.r.p(this.f325d));
            if (drawable.isStateful()) {
                drawable.setState(this.f325d.getDrawableState());
            }
            f();
        }
        this.f325d.invalidate();
    }
}
