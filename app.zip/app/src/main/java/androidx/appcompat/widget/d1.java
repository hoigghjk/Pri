package androidx.appcompat.widget;

/* loaded from: classes.dex */
public interface d1 {
    CharSequence a();
}
