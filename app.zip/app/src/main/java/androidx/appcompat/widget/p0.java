package androidx.appcompat.widget;

import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import androidx.appcompat.app.a;
import androidx.appcompat.widget.i0;

/* loaded from: classes.dex */
public class p0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
    Runnable n;
    private c o;
    i0 p;
    private Spinner q;
    private boolean r;
    int s;
    int t;
    private int u;
    private int v;

    class a implements Runnable {
        final /* synthetic */ View n;

        a(View view) {
            this.n = view;
        }

        @Override // java.lang.Runnable
        public void run() {
            p0.this.smoothScrollTo(this.n.getLeft() - ((p0.this.getWidth() - this.n.getWidth()) / 2), 0);
            p0.this.n = null;
        }
    }

    private class b extends BaseAdapter {
        b() {
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return p0.this.p.getChildCount();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i2) {
            return ((d) p0.this.p.getChildAt(i2)).b();
        }

        @Override // android.widget.Adapter
        public long getItemId(int i2) {
            return i2;
        }

        @Override // android.widget.Adapter
        public View getView(int i2, View view, ViewGroup viewGroup) {
            if (view == null) {
                return p0.this.c((a.c) getItem(i2), true);
            }
            ((d) view).a((a.c) getItem(i2));
            return view;
        }
    }

    private class c implements View.OnClickListener {
        c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ((d) view).b().e();
            int childCount = p0.this.p.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = p0.this.p.getChildAt(i2);
                childAt.setSelected(childAt == view);
            }
        }
    }

    private class d extends LinearLayout {
        private final int[] n;
        private a.c o;
        private TextView p;
        private ImageView q;
        private View r;

        /* JADX WARN: Illegal instructions before constructor call */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public d(android.content.Context r6, androidx.appcompat.app.a.c r7, boolean r8) {
            /*
                r4 = this;
                androidx.appcompat.widget.p0.this = r5
                int r5 = b.a.a.f709d
                r0 = 0
                r4.<init>(r6, r0, r5)
                r1 = 1
                int[] r1 = new int[r1]
                r2 = 16842964(0x10100d4, float:2.3694152E-38)
                r3 = 0
                r1[r3] = r2
                r4.n = r1
                r4.o = r7
                androidx.appcompat.widget.w0 r5 = androidx.appcompat.widget.w0.u(r6, r0, r1, r5, r3)
                boolean r6 = r5.r(r3)
                if (r6 == 0) goto L26
                android.graphics.drawable.Drawable r6 = r5.f(r3)
                r4.setBackgroundDrawable(r6)
            L26:
                r5.v()
                if (r8 == 0) goto L31
                r5 = 8388627(0x800013, float:1.175497E-38)
                r4.setGravity(r5)
            L31:
                r4.c()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.p0.d.<init>(androidx.appcompat.widget.p0, android.content.Context, androidx.appcompat.app.a$c, boolean):void");
        }

        public void a(a.c cVar) {
            this.o = cVar;
            c();
        }

        public a.c b() {
            return this.o;
        }

        public void c() {
            a.c cVar = this.o;
            View b2 = cVar.b();
            if (b2 != null) {
                ViewParent parent = b2.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(b2);
                    }
                    addView(b2);
                }
                this.r = b2;
                TextView textView = this.p;
                if (textView != null) {
                    textView.setVisibility(8);
                }
                ImageView imageView = this.q;
                if (imageView != null) {
                    imageView.setVisibility(8);
                    this.q.setImageDrawable(null);
                    return;
                }
                return;
            }
            View view = this.r;
            if (view != null) {
                removeView(view);
                this.r = null;
            }
            Drawable c2 = cVar.c();
            CharSequence d2 = cVar.d();
            if (c2 != null) {
                if (this.q == null) {
                    o oVar = new o(getContext());
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams.gravity = 16;
                    oVar.setLayoutParams(layoutParams);
                    addView(oVar, 0);
                    this.q = oVar;
                }
                this.q.setImageDrawable(c2);
                this.q.setVisibility(0);
            } else {
                ImageView imageView2 = this.q;
                if (imageView2 != null) {
                    imageView2.setVisibility(8);
                    this.q.setImageDrawable(null);
                }
            }
            boolean z = !TextUtils.isEmpty(d2);
            if (z) {
                if (this.p == null) {
                    z zVar = new z(getContext(), null, b.a.a.f710e);
                    zVar.setEllipsize(TextUtils.TruncateAt.END);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams2.gravity = 16;
                    zVar.setLayoutParams(layoutParams2);
                    addView(zVar);
                    this.p = zVar;
                }
                this.p.setText(d2);
                this.p.setVisibility(0);
            } else {
                TextView textView2 = this.p;
                if (textView2 != null) {
                    textView2.setVisibility(8);
                    this.p.setText((CharSequence) null);
                }
            }
            ImageView imageView3 = this.q;
            if (imageView3 != null) {
                imageView3.setContentDescription(cVar.a());
            }
            y0.a(this, z ? null : cVar.a());
        }

        @Override // android.view.View
        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.view.View
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onMeasure(int i2, int i3) {
            super.onMeasure(i2, i3);
            if (p0.this.s > 0) {
                int measuredWidth = getMeasuredWidth();
                int i4 = p0.this.s;
                if (measuredWidth > i4) {
                    super.onMeasure(View.MeasureSpec.makeMeasureSpec(i4, 1073741824), i3);
                }
            }
        }

        @Override // android.view.View
        public void setSelected(boolean z) {
            boolean z2 = isSelected() != z;
            super.setSelected(z);
            if (z2 && z) {
                sendAccessibilityEvent(4);
            }
        }
    }

    static {
        new DecelerateInterpolator();
    }

    private Spinner b() {
        w wVar = new w(getContext(), null, b.a.a.f713h);
        wVar.setLayoutParams(new i0.a(-2, -1));
        wVar.setOnItemSelectedListener(this);
        return wVar;
    }

    private boolean d() {
        Spinner spinner = this.q;
        return spinner != null && spinner.getParent() == this;
    }

    private void e() {
        if (d()) {
            return;
        }
        if (this.q == null) {
            this.q = b();
        }
        removeView(this.p);
        addView(this.q, new ViewGroup.LayoutParams(-2, -1));
        if (this.q.getAdapter() == null) {
            this.q.setAdapter((SpinnerAdapter) new b());
        }
        Runnable runnable = this.n;
        if (runnable != null) {
            removeCallbacks(runnable);
            this.n = null;
        }
        this.q.setSelection(this.v);
    }

    private boolean f() {
        if (!d()) {
            return false;
        }
        removeView(this.q);
        addView(this.p, new ViewGroup.LayoutParams(-2, -1));
        setTabSelected(this.q.getSelectedItemPosition());
        return false;
    }

    public void a(int i2) {
        View childAt = this.p.getChildAt(i2);
        Runnable runnable = this.n;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
        a aVar = new a(childAt);
        this.n = aVar;
        post(aVar);
    }

    d c(a.c cVar, boolean z) {
        d dVar = new d(this, getContext(), cVar, z);
        if (z) {
            dVar.setBackgroundDrawable(null);
            dVar.setLayoutParams(new AbsListView.LayoutParams(-1, this.u));
        } else {
            dVar.setFocusable(true);
            if (this.o == null) {
                this.o = new c();
            }
            dVar.setOnClickListener(this.o);
        }
        return dVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Runnable runnable = this.n;
        if (runnable != null) {
            post(runnable);
        }
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        b.a.n.a b2 = b.a.n.a.b(getContext());
        setContentHeight(b2.f());
        this.t = b2.e();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Runnable runnable = this.n;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
        ((d) view).b().e();
    }

    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        int i4;
        int mode = View.MeasureSpec.getMode(i2);
        boolean z = mode == 1073741824;
        setFillViewport(z);
        int childCount = this.p.getChildCount();
        if (childCount <= 1 || !(mode == 1073741824 || mode == Integer.MIN_VALUE)) {
            i4 = -1;
        } else {
            if (childCount > 2) {
                this.s = (int) (View.MeasureSpec.getSize(i2) * 0.4f);
            } else {
                this.s = View.MeasureSpec.getSize(i2) / 2;
            }
            i4 = Math.min(this.s, this.t);
        }
        this.s = i4;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(this.u, 1073741824);
        if (!z && this.r) {
            this.p.measure(0, makeMeasureSpec);
            if (this.p.getMeasuredWidth() > View.MeasureSpec.getSize(i2)) {
                e();
                int measuredWidth = getMeasuredWidth();
                super.onMeasure(i2, makeMeasureSpec);
                int measuredWidth2 = getMeasuredWidth();
                if (z || measuredWidth == measuredWidth2) {
                }
                setTabSelected(this.v);
                return;
            }
        }
        f();
        int measuredWidth3 = getMeasuredWidth();
        super.onMeasure(i2, makeMeasureSpec);
        int measuredWidth22 = getMeasuredWidth();
        if (z) {
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    public void setAllowCollapse(boolean z) {
        this.r = z;
    }

    public void setContentHeight(int i2) {
        this.u = i2;
        requestLayout();
    }

    public void setTabSelected(int i2) {
        this.v = i2;
        int childCount = this.p.getChildCount();
        int i3 = 0;
        while (i3 < childCount) {
            View childAt = this.p.getChildAt(i3);
            boolean z = i3 == i2;
            childAt.setSelected(z);
            if (z) {
                a(i2);
            }
            i3++;
        }
        Spinner spinner = this.q;
        if (spinner == null || i2 < 0) {
            return;
        }
        spinner.setSelection(i2);
    }
}
