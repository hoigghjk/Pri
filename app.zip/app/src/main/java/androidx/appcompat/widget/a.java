package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public abstract class a extends ViewGroup {
    protected final C0013a n;
    protected final Context o;
    protected ActionMenuView p;
    protected c q;
    protected int r;
    protected b.g.l.v s;
    private boolean t;
    private boolean u;

    /* renamed from: androidx.appcompat.widget.a$a, reason: collision with other inner class name */
    protected class C0013a implements b.g.l.w {

        /* renamed from: a, reason: collision with root package name */
        private boolean f224a = false;

        /* renamed from: b, reason: collision with root package name */
        int f225b;

        protected C0013a() {
        }

        @Override // b.g.l.w
        public void a(View view) {
            this.f224a = true;
        }

        @Override // b.g.l.w
        public void b(View view) {
            if (this.f224a) {
                return;
            }
            a aVar = a.this;
            aVar.s = null;
            a.super.setVisibility(this.f225b);
        }

        @Override // b.g.l.w
        public void c(View view) {
            a.super.setVisibility(0);
            this.f224a = false;
        }

        public C0013a d(b.g.l.v vVar, int i2) {
            a.this.s = vVar;
            this.f225b = i2;
            return this;
        }
    }

    a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    a(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.n = new C0013a();
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(b.a.a.f706a, typedValue, true) || typedValue.resourceId == 0) {
            this.o = context;
        } else {
            this.o = new ContextThemeWrapper(context, typedValue.resourceId);
        }
    }

    protected static int d(int i2, int i3, boolean z) {
        return z ? i2 - i3 : i2 + i3;
    }

    protected int c(View view, int i2, int i3, int i4) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i2, Integer.MIN_VALUE), i3);
        return Math.max(0, (i2 - view.getMeasuredWidth()) - i4);
    }

    protected int e(View view, int i2, int i3, int i4, boolean z) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i5 = i3 + ((i4 - measuredHeight) / 2);
        if (z) {
            view.layout(i2 - measuredWidth, i5, i2, measuredHeight + i5);
        } else {
            view.layout(i2, i5, i2 + measuredWidth, measuredHeight + i5);
        }
        return z ? -measuredWidth : measuredWidth;
    }

    public b.g.l.v f(int i2, long j2) {
        b.g.l.v vVar = this.s;
        if (vVar != null) {
            vVar.b();
        }
        if (i2 != 0) {
            b.g.l.v b2 = b.g.l.r.b(this);
            b2.a(0.0f);
            b2.d(j2);
            C0013a c0013a = this.n;
            c0013a.d(b2, i2);
            b2.f(c0013a);
            return b2;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        b.g.l.v b3 = b.g.l.r.b(this);
        b3.a(1.0f);
        b3.d(j2);
        C0013a c0013a2 = this.n;
        c0013a2.d(b3, i2);
        b3.f(c0013a2);
        return b3;
    }

    public int getAnimatedVisibility() {
        return this.s != null ? this.n.f225b : getVisibility();
    }

    public int getContentHeight() {
        return this.r;
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(null, b.a.j.f785a, b.a.a.f708c, 0);
        setContentHeight(obtainStyledAttributes.getLayoutDimension(b.a.j.f794j, 0));
        obtainStyledAttributes.recycle();
        c cVar = this.q;
        if (cVar != null) {
            cVar.F(configuration);
        }
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.u = false;
        }
        if (!this.u) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.u = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.u = false;
        }
        return true;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.t = false;
        }
        if (!this.t) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.t = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.t = false;
        }
        return true;
    }

    public abstract void setContentHeight(int i2);

    @Override // android.view.View
    public void setVisibility(int i2) {
        if (i2 != getVisibility()) {
            b.g.l.v vVar = this.s;
            if (vVar != null) {
                vVar.b();
            }
            super.setVisibility(i2);
        }
    }
}
