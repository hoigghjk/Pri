package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;

/* loaded from: classes.dex */
public interface d0 {
    Context a();

    void b(Menu menu, m.a aVar);

    boolean c();

    void collapseActionView();

    void d();

    void e(Drawable drawable);

    boolean f();

    boolean g();

    CharSequence getTitle();

    boolean h();

    boolean i();

    void j();

    void k(m.a aVar, g.a aVar2);

    void l(int i2);

    void m(p0 p0Var);

    ViewGroup n();

    void o(boolean z);

    int p();

    boolean q();

    void r(int i2);

    int s();

    void setIcon(int i2);

    void setIcon(Drawable drawable);

    void setTitle(CharSequence charSequence);

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);

    Menu t();

    void u(int i2);

    int v();

    b.g.l.v w(int i2, long j2);

    void x();

    void y();

    void z(boolean z);
}
