package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.view.menu.n;
import androidx.appcompat.widget.ActionMenuView;
import b.g.l.b;
import java.util.ArrayList;

/* loaded from: classes.dex */
class c extends androidx.appcompat.view.menu.b implements b.a {
    private int A;
    private int B;
    private int C;
    private boolean D;
    private boolean E;
    private boolean F;
    private boolean G;
    private int H;
    private final SparseBooleanArray I;
    e J;
    a K;
    RunnableC0014c L;
    private b M;
    final f N;
    int O;
    d v;
    private Drawable w;
    private boolean x;
    private boolean y;
    private boolean z;

    private class a extends androidx.appcompat.view.menu.l {
        public a(Context context, androidx.appcompat.view.menu.r rVar, View view) {
            super(context, rVar, view, false, b.a.a.l);
            if (!((androidx.appcompat.view.menu.i) rVar.getItem()).l()) {
                View view2 = c.this.v;
                f(view2 == null ? (View) ((androidx.appcompat.view.menu.b) c.this).u : view2);
            }
            j(c.this.N);
        }

        @Override // androidx.appcompat.view.menu.l
        protected void e() {
            c cVar = c.this;
            cVar.K = null;
            cVar.O = 0;
            super.e();
        }
    }

    private class b extends ActionMenuItemView.b {
        b() {
        }

        @Override // androidx.appcompat.view.menu.ActionMenuItemView.b
        public androidx.appcompat.view.menu.p a() {
            a aVar = c.this.K;
            if (aVar != null) {
                return aVar.c();
            }
            return null;
        }
    }

    /* renamed from: androidx.appcompat.widget.c$c, reason: collision with other inner class name */
    private class RunnableC0014c implements Runnable {
        private e n;

        public RunnableC0014c(e eVar) {
            this.n = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (((androidx.appcompat.view.menu.b) c.this).p != null) {
                ((androidx.appcompat.view.menu.b) c.this).p.d();
            }
            View view = (View) ((androidx.appcompat.view.menu.b) c.this).u;
            if (view != null && view.getWindowToken() != null && this.n.m()) {
                c.this.J = this.n;
            }
            c.this.L = null;
        }
    }

    private class d extends o implements ActionMenuView.a {

        class a extends h0 {
            a(View view, c cVar) {
                super(view);
            }

            @Override // androidx.appcompat.widget.h0
            public androidx.appcompat.view.menu.p b() {
                e eVar = c.this.J;
                if (eVar == null) {
                    return null;
                }
                return eVar.c();
            }

            @Override // androidx.appcompat.widget.h0
            public boolean c() {
                c.this.K();
                return true;
            }

            @Override // androidx.appcompat.widget.h0
            public boolean d() {
                c cVar = c.this;
                if (cVar.L != null) {
                    return false;
                }
                cVar.B();
                return true;
            }
        }

        public d(Context context) {
            super(context, null, b.a.a.f716k);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            y0.a(this, getContentDescription());
            setOnTouchListener(new a(this, c.this));
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean b() {
            return false;
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean c() {
            return false;
        }

        @Override // android.view.View
        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            c.this.K();
            return true;
        }

        @Override // android.widget.ImageView
        protected boolean setFrame(int i2, int i3, int i4, int i5) {
            boolean frame = super.setFrame(i2, i3, i4, i5);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (drawable != null && background != null) {
                int width = getWidth();
                int height = getHeight();
                int max = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                androidx.core.graphics.drawable.a.k(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
            }
            return frame;
        }
    }

    private class e extends androidx.appcompat.view.menu.l {
        public e(Context context, androidx.appcompat.view.menu.g gVar, View view, boolean z) {
            super(context, gVar, view, z, b.a.a.l);
            h(8388613);
            j(c.this.N);
        }

        @Override // androidx.appcompat.view.menu.l
        protected void e() {
            if (((androidx.appcompat.view.menu.b) c.this).p != null) {
                ((androidx.appcompat.view.menu.b) c.this).p.close();
            }
            c.this.J = null;
            super.e();
        }
    }

    private class f implements m.a {
        f() {
        }

        @Override // androidx.appcompat.view.menu.m.a
        public void b(androidx.appcompat.view.menu.g gVar, boolean z) {
            if (gVar instanceof androidx.appcompat.view.menu.r) {
                gVar.D().e(false);
            }
            m.a m = c.this.m();
            if (m != null) {
                m.b(gVar, z);
            }
        }

        @Override // androidx.appcompat.view.menu.m.a
        public boolean c(androidx.appcompat.view.menu.g gVar) {
            if (gVar == ((androidx.appcompat.view.menu.b) c.this).p) {
                return false;
            }
            c.this.O = ((androidx.appcompat.view.menu.r) gVar).getItem().getItemId();
            m.a m = c.this.m();
            if (m != null) {
                return m.c(gVar);
            }
            return false;
        }
    }

    public c(Context context) {
        super(context, b.a.g.f761c, b.a.g.f760b);
        this.I = new SparseBooleanArray();
        this.N = new f();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View z(MenuItem menuItem) {
        ViewGroup viewGroup = (ViewGroup) this.u;
        if (viewGroup == null) {
            return null;
        }
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            if ((childAt instanceof n.a) && ((n.a) childAt).getItemData() == menuItem) {
                return childAt;
            }
        }
        return null;
    }

    public Drawable A() {
        d dVar = this.v;
        if (dVar != null) {
            return dVar.getDrawable();
        }
        if (this.x) {
            return this.w;
        }
        return null;
    }

    public boolean B() {
        Object obj;
        RunnableC0014c runnableC0014c = this.L;
        if (runnableC0014c != null && (obj = this.u) != null) {
            ((View) obj).removeCallbacks(runnableC0014c);
            this.L = null;
            return true;
        }
        e eVar = this.J;
        if (eVar == null) {
            return false;
        }
        eVar.b();
        return true;
    }

    public boolean C() {
        a aVar = this.K;
        if (aVar == null) {
            return false;
        }
        aVar.b();
        return true;
    }

    public boolean D() {
        return this.L != null || E();
    }

    public boolean E() {
        e eVar = this.J;
        return eVar != null && eVar.d();
    }

    public void F(Configuration configuration) {
        if (!this.D) {
            this.C = b.a.n.a.b(this.o).d();
        }
        androidx.appcompat.view.menu.g gVar = this.p;
        if (gVar != null) {
            gVar.K(true);
        }
    }

    public void G(boolean z) {
        this.G = z;
    }

    public void H(ActionMenuView actionMenuView) {
        this.u = actionMenuView;
        actionMenuView.b(this.p);
    }

    public void I(Drawable drawable) {
        d dVar = this.v;
        if (dVar != null) {
            dVar.setImageDrawable(drawable);
        } else {
            this.x = true;
            this.w = drawable;
        }
    }

    public void J(boolean z) {
        this.y = z;
        this.z = true;
    }

    public boolean K() {
        androidx.appcompat.view.menu.g gVar;
        if (!this.y || E() || (gVar = this.p) == null || this.u == null || this.L != null || gVar.z().isEmpty()) {
            return false;
        }
        RunnableC0014c runnableC0014c = new RunnableC0014c(new e(this.o, this.p, this.v, true));
        this.L = runnableC0014c;
        ((View) this.u).post(runnableC0014c);
        return true;
    }

    @Override // androidx.appcompat.view.menu.b, androidx.appcompat.view.menu.m
    public void b(androidx.appcompat.view.menu.g gVar, boolean z) {
        y();
        super.b(gVar, z);
    }

    @Override // androidx.appcompat.view.menu.b
    public void c(androidx.appcompat.view.menu.i iVar, n.a aVar) {
        aVar.d(iVar, 0);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) aVar;
        actionMenuItemView.setItemInvoker((ActionMenuView) this.u);
        if (this.M == null) {
            this.M = new b();
        }
        actionMenuItemView.setPopupCallback(this.M);
    }

    @Override // androidx.appcompat.view.menu.b, androidx.appcompat.view.menu.m
    public void d(Context context, androidx.appcompat.view.menu.g gVar) {
        super.d(context, gVar);
        Resources resources = context.getResources();
        b.a.n.a b2 = b.a.n.a.b(context);
        if (!this.z) {
            this.y = b2.h();
        }
        if (!this.F) {
            this.A = b2.c();
        }
        if (!this.D) {
            this.C = b2.d();
        }
        int i2 = this.A;
        if (this.y) {
            if (this.v == null) {
                d dVar = new d(this.n);
                this.v = dVar;
                if (this.x) {
                    dVar.setImageDrawable(this.w);
                    this.w = null;
                    this.x = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.v.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i2 -= this.v.getMeasuredWidth();
        } else {
            this.v = null;
        }
        this.B = i2;
        this.H = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    @Override // androidx.appcompat.view.menu.b, androidx.appcompat.view.menu.m
    public boolean e(androidx.appcompat.view.menu.r rVar) {
        boolean z = false;
        if (!rVar.hasVisibleItems()) {
            return false;
        }
        androidx.appcompat.view.menu.r rVar2 = rVar;
        while (rVar2.e0() != this.p) {
            rVar2 = (androidx.appcompat.view.menu.r) rVar2.e0();
        }
        View z2 = z(rVar2.getItem());
        if (z2 == null) {
            return false;
        }
        rVar.getItem().getItemId();
        int size = rVar.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                break;
            }
            MenuItem item = rVar.getItem(i2);
            if (item.isVisible() && item.getIcon() != null) {
                z = true;
                break;
            }
            i2++;
        }
        a aVar = new a(this.o, rVar, z2);
        this.K = aVar;
        aVar.g(z);
        this.K.k();
        super.e(rVar);
        return true;
    }

    @Override // androidx.appcompat.view.menu.b, androidx.appcompat.view.menu.m
    public void f(boolean z) {
        super.f(z);
        ((View) this.u).requestLayout();
        androidx.appcompat.view.menu.g gVar = this.p;
        boolean z2 = false;
        if (gVar != null) {
            ArrayList<androidx.appcompat.view.menu.i> s = gVar.s();
            int size = s.size();
            for (int i2 = 0; i2 < size; i2++) {
                b.g.l.b b2 = s.get(i2).b();
                if (b2 != null) {
                    b2.i(this);
                }
            }
        }
        androidx.appcompat.view.menu.g gVar2 = this.p;
        ArrayList<androidx.appcompat.view.menu.i> z3 = gVar2 != null ? gVar2.z() : null;
        if (this.y && z3 != null) {
            int size2 = z3.size();
            if (size2 == 1) {
                z2 = !z3.get(0).isActionViewExpanded();
            } else if (size2 > 0) {
                z2 = true;
            }
        }
        d dVar = this.v;
        if (z2) {
            if (dVar == null) {
                this.v = new d(this.n);
            }
            ViewGroup viewGroup = (ViewGroup) this.v.getParent();
            if (viewGroup != this.u) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.v);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.u;
                actionMenuView.addView(this.v, actionMenuView.D());
            }
        } else if (dVar != null) {
            Object parent = dVar.getParent();
            Object obj = this.u;
            if (parent == obj) {
                ((ViewGroup) obj).removeView(this.v);
            }
        }
        ((ActionMenuView) this.u).setOverflowReserved(this.y);
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean g() {
        ArrayList<androidx.appcompat.view.menu.i> arrayList;
        int i2;
        int i3;
        int i4;
        int i5;
        c cVar = this;
        androidx.appcompat.view.menu.g gVar = cVar.p;
        View view = null;
        int i6 = 0;
        if (gVar != null) {
            arrayList = gVar.E();
            i2 = arrayList.size();
        } else {
            arrayList = null;
            i2 = 0;
        }
        int i7 = cVar.C;
        int i8 = cVar.B;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) cVar.u;
        boolean z = false;
        int i9 = 0;
        int i10 = 0;
        for (int i11 = 0; i11 < i2; i11++) {
            androidx.appcompat.view.menu.i iVar = arrayList.get(i11);
            if (iVar.o()) {
                i9++;
            } else if (iVar.n()) {
                i10++;
            } else {
                z = true;
            }
            if (cVar.G && iVar.isActionViewExpanded()) {
                i7 = 0;
            }
        }
        if (cVar.y && (z || i10 + i9 > i7)) {
            i7--;
        }
        int i12 = i7 - i9;
        SparseBooleanArray sparseBooleanArray = cVar.I;
        sparseBooleanArray.clear();
        if (cVar.E) {
            int i13 = cVar.H;
            i4 = i8 / i13;
            i3 = i13 + ((i8 % i13) / i4);
        } else {
            i3 = 0;
            i4 = 0;
        }
        int i14 = 0;
        int i15 = 0;
        while (i14 < i2) {
            androidx.appcompat.view.menu.i iVar2 = arrayList.get(i14);
            if (iVar2.o()) {
                View n = cVar.n(iVar2, view, viewGroup);
                if (cVar.E) {
                    i4 -= ActionMenuView.J(n, i3, i4, makeMeasureSpec, i6);
                } else {
                    n.measure(makeMeasureSpec, makeMeasureSpec);
                }
                int measuredWidth = n.getMeasuredWidth();
                i8 -= measuredWidth;
                if (i15 == 0) {
                    i15 = measuredWidth;
                }
                int groupId = iVar2.getGroupId();
                if (groupId != 0) {
                    sparseBooleanArray.put(groupId, true);
                }
                iVar2.u(true);
                i5 = i2;
            } else if (iVar2.n()) {
                int groupId2 = iVar2.getGroupId();
                boolean z2 = sparseBooleanArray.get(groupId2);
                boolean z3 = (i12 > 0 || z2) && i8 > 0 && (!cVar.E || i4 > 0);
                boolean z4 = z3;
                i5 = i2;
                if (z3) {
                    View n2 = cVar.n(iVar2, null, viewGroup);
                    if (cVar.E) {
                        int J = ActionMenuView.J(n2, i3, i4, makeMeasureSpec, 0);
                        i4 -= J;
                        if (J == 0) {
                            z4 = false;
                        }
                    } else {
                        n2.measure(makeMeasureSpec, makeMeasureSpec);
                    }
                    boolean z5 = z4;
                    int measuredWidth2 = n2.getMeasuredWidth();
                    i8 -= measuredWidth2;
                    if (i15 == 0) {
                        i15 = measuredWidth2;
                    }
                    z3 = z5 & (!cVar.E ? i8 + i15 <= 0 : i8 < 0);
                }
                if (z3 && groupId2 != 0) {
                    sparseBooleanArray.put(groupId2, true);
                } else if (z2) {
                    sparseBooleanArray.put(groupId2, false);
                    for (int i16 = 0; i16 < i14; i16++) {
                        androidx.appcompat.view.menu.i iVar3 = arrayList.get(i16);
                        if (iVar3.getGroupId() == groupId2) {
                            if (iVar3.l()) {
                                i12++;
                            }
                            iVar3.u(false);
                        }
                    }
                }
                if (z3) {
                    i12--;
                }
                iVar2.u(z3);
            } else {
                i5 = i2;
                iVar2.u(false);
                i14++;
                view = null;
                cVar = this;
                i2 = i5;
                i6 = 0;
            }
            i14++;
            view = null;
            cVar = this;
            i2 = i5;
            i6 = 0;
        }
        return true;
    }

    @Override // androidx.appcompat.view.menu.b
    public boolean l(ViewGroup viewGroup, int i2) {
        if (viewGroup.getChildAt(i2) == this.v) {
            return false;
        }
        return super.l(viewGroup, i2);
    }

    @Override // androidx.appcompat.view.menu.b
    public View n(androidx.appcompat.view.menu.i iVar, View view, ViewGroup viewGroup) {
        View actionView = iVar.getActionView();
        if (actionView == null || iVar.j()) {
            actionView = super.n(iVar, view, viewGroup);
        }
        actionView.setVisibility(iVar.isActionViewExpanded() ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.generateLayoutParams(layoutParams));
        }
        return actionView;
    }

    @Override // androidx.appcompat.view.menu.b
    public androidx.appcompat.view.menu.n o(ViewGroup viewGroup) {
        androidx.appcompat.view.menu.n nVar = this.u;
        androidx.appcompat.view.menu.n o = super.o(viewGroup);
        if (nVar != o) {
            ((ActionMenuView) o).setPresenter(this);
        }
        return o;
    }

    @Override // androidx.appcompat.view.menu.b
    public boolean q(int i2, androidx.appcompat.view.menu.i iVar) {
        return iVar.l();
    }

    public boolean y() {
        return B() | C();
    }
}
