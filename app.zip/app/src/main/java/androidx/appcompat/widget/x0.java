package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.Toolbar;

/* loaded from: classes.dex */
public class x0 implements d0 {

    /* renamed from: a, reason: collision with root package name */
    Toolbar f337a;

    /* renamed from: b, reason: collision with root package name */
    private int f338b;

    /* renamed from: c, reason: collision with root package name */
    private View f339c;

    /* renamed from: d, reason: collision with root package name */
    private View f340d;

    /* renamed from: e, reason: collision with root package name */
    private Drawable f341e;

    /* renamed from: f, reason: collision with root package name */
    private Drawable f342f;

    /* renamed from: g, reason: collision with root package name */
    private Drawable f343g;

    /* renamed from: h, reason: collision with root package name */
    private boolean f344h;

    /* renamed from: i, reason: collision with root package name */
    CharSequence f345i;

    /* renamed from: j, reason: collision with root package name */
    private CharSequence f346j;

    /* renamed from: k, reason: collision with root package name */
    private CharSequence f347k;
    Window.Callback l;
    boolean m;
    private c n;
    private int o;
    private int p;
    private Drawable q;

    class a implements View.OnClickListener {
        final androidx.appcompat.view.menu.a n;

        a() {
            this.n = new androidx.appcompat.view.menu.a(x0.this.f337a.getContext(), 0, R.id.home, 0, 0, x0.this.f345i);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            x0 x0Var = x0.this;
            Window.Callback callback = x0Var.l;
            if (callback == null || !x0Var.m) {
                return;
            }
            callback.onMenuItemSelected(0, this.n);
        }
    }

    class b extends b.g.l.x {

        /* renamed from: a, reason: collision with root package name */
        private boolean f348a = false;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ int f349b;

        b(int i2) {
            this.f349b = i2;
        }

        @Override // b.g.l.x, b.g.l.w
        public void a(View view) {
            this.f348a = true;
        }

        @Override // b.g.l.w
        public void b(View view) {
            if (this.f348a) {
                return;
            }
            x0.this.f337a.setVisibility(this.f349b);
        }

        @Override // b.g.l.x, b.g.l.w
        public void c(View view) {
            x0.this.f337a.setVisibility(0);
        }
    }

    public x0(Toolbar toolbar, boolean z) {
        this(toolbar, z, b.a.h.f770a, b.a.e.n);
    }

    public x0(Toolbar toolbar, boolean z, int i2, int i3) {
        Drawable drawable;
        this.o = 0;
        this.p = 0;
        this.f337a = toolbar;
        this.f345i = toolbar.getTitle();
        this.f346j = toolbar.getSubtitle();
        this.f344h = this.f345i != null;
        this.f343g = toolbar.getNavigationIcon();
        w0 u = w0.u(toolbar.getContext(), null, b.a.j.f785a, b.a.a.f708c, 0);
        this.q = u.f(b.a.j.l);
        if (z) {
            CharSequence o = u.o(b.a.j.r);
            if (!TextUtils.isEmpty(o)) {
                setTitle(o);
            }
            CharSequence o2 = u.o(b.a.j.p);
            if (!TextUtils.isEmpty(o2)) {
                H(o2);
            }
            Drawable f2 = u.f(b.a.j.n);
            if (f2 != null) {
                D(f2);
            }
            Drawable f3 = u.f(b.a.j.m);
            if (f3 != null) {
                setIcon(f3);
            }
            if (this.f343g == null && (drawable = this.q) != null) {
                G(drawable);
            }
            r(u.j(b.a.j.f792h, 0));
            int m = u.m(b.a.j.f791g, 0);
            if (m != 0) {
                B(LayoutInflater.from(this.f337a.getContext()).inflate(m, (ViewGroup) this.f337a, false));
                r(this.f338b | 16);
            }
            int l = u.l(b.a.j.f794j, 0);
            if (l > 0) {
                ViewGroup.LayoutParams layoutParams = this.f337a.getLayoutParams();
                layoutParams.height = l;
                this.f337a.setLayoutParams(layoutParams);
            }
            int d2 = u.d(b.a.j.f790f, -1);
            int d3 = u.d(b.a.j.f789e, -1);
            if (d2 >= 0 || d3 >= 0) {
                this.f337a.H(Math.max(d2, 0), Math.max(d3, 0));
            }
            int m2 = u.m(b.a.j.s, 0);
            if (m2 != 0) {
                Toolbar toolbar2 = this.f337a;
                toolbar2.L(toolbar2.getContext(), m2);
            }
            int m3 = u.m(b.a.j.q, 0);
            if (m3 != 0) {
                Toolbar toolbar3 = this.f337a;
                toolbar3.K(toolbar3.getContext(), m3);
            }
            int m4 = u.m(b.a.j.o, 0);
            if (m4 != 0) {
                this.f337a.setPopupTheme(m4);
            }
        } else {
            this.f338b = A();
        }
        u.v();
        C(i2);
        this.f347k = this.f337a.getNavigationContentDescription();
        this.f337a.setNavigationOnClickListener(new a());
    }

    private int A() {
        if (this.f337a.getNavigationIcon() == null) {
            return 11;
        }
        this.q = this.f337a.getNavigationIcon();
        return 15;
    }

    private void I(CharSequence charSequence) {
        this.f345i = charSequence;
        if ((this.f338b & 8) != 0) {
            this.f337a.setTitle(charSequence);
        }
    }

    private void J() {
        if ((this.f338b & 4) != 0) {
            if (TextUtils.isEmpty(this.f347k)) {
                this.f337a.setNavigationContentDescription(this.p);
            } else {
                this.f337a.setNavigationContentDescription(this.f347k);
            }
        }
    }

    private void K() {
        Toolbar toolbar;
        Drawable drawable;
        if ((this.f338b & 4) != 0) {
            toolbar = this.f337a;
            drawable = this.f343g;
            if (drawable == null) {
                drawable = this.q;
            }
        } else {
            toolbar = this.f337a;
            drawable = null;
        }
        toolbar.setNavigationIcon(drawable);
    }

    private void L() {
        Drawable drawable;
        int i2 = this.f338b;
        if ((i2 & 2) == 0) {
            drawable = null;
        } else if ((i2 & 1) == 0 || (drawable = this.f342f) == null) {
            drawable = this.f341e;
        }
        this.f337a.setLogo(drawable);
    }

    public void B(View view) {
        View view2 = this.f340d;
        if (view2 != null && (this.f338b & 16) != 0) {
            this.f337a.removeView(view2);
        }
        this.f340d = view;
        if (view == null || (this.f338b & 16) == 0) {
            return;
        }
        this.f337a.addView(view);
    }

    public void C(int i2) {
        if (i2 == this.p) {
            return;
        }
        this.p = i2;
        if (TextUtils.isEmpty(this.f337a.getNavigationContentDescription())) {
            E(this.p);
        }
    }

    public void D(Drawable drawable) {
        this.f342f = drawable;
        L();
    }

    public void E(int i2) {
        F(i2 == 0 ? null : a().getString(i2));
    }

    public void F(CharSequence charSequence) {
        this.f347k = charSequence;
        J();
    }

    public void G(Drawable drawable) {
        this.f343g = drawable;
        K();
    }

    public void H(CharSequence charSequence) {
        this.f346j = charSequence;
        if ((this.f338b & 8) != 0) {
            this.f337a.setSubtitle(charSequence);
        }
    }

    @Override // androidx.appcompat.widget.d0
    public Context a() {
        return this.f337a.getContext();
    }

    @Override // androidx.appcompat.widget.d0
    public void b(Menu menu, m.a aVar) {
        if (this.n == null) {
            c cVar = new c(this.f337a.getContext());
            this.n = cVar;
            cVar.p(b.a.f.f754g);
        }
        this.n.k(aVar);
        this.f337a.I((androidx.appcompat.view.menu.g) menu, this.n);
    }

    @Override // androidx.appcompat.widget.d0
    public boolean c() {
        return this.f337a.A();
    }

    @Override // androidx.appcompat.widget.d0
    public void collapseActionView() {
        this.f337a.e();
    }

    @Override // androidx.appcompat.widget.d0
    public void d() {
        this.m = true;
    }

    @Override // androidx.appcompat.widget.d0
    public void e(Drawable drawable) {
        b.g.l.r.M(this.f337a, drawable);
    }

    @Override // androidx.appcompat.widget.d0
    public boolean f() {
        return this.f337a.z();
    }

    @Override // androidx.appcompat.widget.d0
    public boolean g() {
        return this.f337a.w();
    }

    @Override // androidx.appcompat.widget.d0
    public CharSequence getTitle() {
        return this.f337a.getTitle();
    }

    @Override // androidx.appcompat.widget.d0
    public boolean h() {
        return this.f337a.O();
    }

    @Override // androidx.appcompat.widget.d0
    public boolean i() {
        return this.f337a.d();
    }

    @Override // androidx.appcompat.widget.d0
    public void j() {
        this.f337a.f();
    }

    @Override // androidx.appcompat.widget.d0
    public void k(m.a aVar, g.a aVar2) {
        this.f337a.J(aVar, aVar2);
    }

    @Override // androidx.appcompat.widget.d0
    public void l(int i2) {
        this.f337a.setVisibility(i2);
    }

    @Override // androidx.appcompat.widget.d0
    public void m(p0 p0Var) {
        View view = this.f339c;
        if (view != null) {
            ViewParent parent = view.getParent();
            Toolbar toolbar = this.f337a;
            if (parent == toolbar) {
                toolbar.removeView(this.f339c);
            }
        }
        this.f339c = p0Var;
        if (p0Var == null || this.o != 2) {
            return;
        }
        this.f337a.addView(p0Var, 0);
        Toolbar.e eVar = (Toolbar.e) this.f339c.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) eVar).width = -2;
        ((ViewGroup.MarginLayoutParams) eVar).height = -2;
        eVar.f61a = 8388691;
        p0Var.setAllowCollapse(true);
    }

    @Override // androidx.appcompat.widget.d0
    public ViewGroup n() {
        return this.f337a;
    }

    @Override // androidx.appcompat.widget.d0
    public void o(boolean z) {
    }

    @Override // androidx.appcompat.widget.d0
    public int p() {
        return this.f337a.getVisibility();
    }

    @Override // androidx.appcompat.widget.d0
    public boolean q() {
        return this.f337a.v();
    }

    @Override // androidx.appcompat.widget.d0
    public void r(int i2) {
        View view;
        CharSequence charSequence;
        Toolbar toolbar;
        int i3 = this.f338b ^ i2;
        this.f338b = i2;
        if (i3 != 0) {
            if ((i3 & 4) != 0) {
                if ((i2 & 4) != 0) {
                    J();
                }
                K();
            }
            if ((i3 & 3) != 0) {
                L();
            }
            if ((i3 & 8) != 0) {
                if ((i2 & 8) != 0) {
                    this.f337a.setTitle(this.f345i);
                    toolbar = this.f337a;
                    charSequence = this.f346j;
                } else {
                    charSequence = null;
                    this.f337a.setTitle((CharSequence) null);
                    toolbar = this.f337a;
                }
                toolbar.setSubtitle(charSequence);
            }
            if ((i3 & 16) == 0 || (view = this.f340d) == null) {
                return;
            }
            if ((i2 & 16) != 0) {
                this.f337a.addView(view);
            } else {
                this.f337a.removeView(view);
            }
        }
    }

    @Override // androidx.appcompat.widget.d0
    public int s() {
        return this.f338b;
    }

    @Override // androidx.appcompat.widget.d0
    public void setIcon(int i2) {
        setIcon(i2 != 0 ? b.a.k.a.a.d(a(), i2) : null);
    }

    @Override // androidx.appcompat.widget.d0
    public void setIcon(Drawable drawable) {
        this.f341e = drawable;
        L();
    }

    @Override // androidx.appcompat.widget.d0
    public void setTitle(CharSequence charSequence) {
        this.f344h = true;
        I(charSequence);
    }

    @Override // androidx.appcompat.widget.d0
    public void setWindowCallback(Window.Callback callback) {
        this.l = callback;
    }

    @Override // androidx.appcompat.widget.d0
    public void setWindowTitle(CharSequence charSequence) {
        if (this.f344h) {
            return;
        }
        I(charSequence);
    }

    @Override // androidx.appcompat.widget.d0
    public Menu t() {
        return this.f337a.getMenu();
    }

    @Override // androidx.appcompat.widget.d0
    public void u(int i2) {
        D(i2 != 0 ? b.a.k.a.a.d(a(), i2) : null);
    }

    @Override // androidx.appcompat.widget.d0
    public int v() {
        return this.o;
    }

    @Override // androidx.appcompat.widget.d0
    public b.g.l.v w(int i2, long j2) {
        b.g.l.v b2 = b.g.l.r.b(this.f337a);
        b2.a(i2 == 0 ? 1.0f : 0.0f);
        b2.d(j2);
        b2.f(new b(i2));
        return b2;
    }

    @Override // androidx.appcompat.widget.d0
    public void x() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // androidx.appcompat.widget.d0
    public void y() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // androidx.appcompat.widget.d0
    public void z(boolean z) {
        this.f337a.setCollapsible(z);
    }
}
