package androidx.appcompat.widget;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

/* loaded from: classes.dex */
class a1 {

    /* renamed from: a, reason: collision with root package name */
    private final Context f238a;

    /* renamed from: b, reason: collision with root package name */
    private final View f239b;

    /* renamed from: c, reason: collision with root package name */
    private final TextView f240c;

    /* renamed from: d, reason: collision with root package name */
    private final WindowManager.LayoutParams f241d;

    /* renamed from: e, reason: collision with root package name */
    private final Rect f242e;

    /* renamed from: f, reason: collision with root package name */
    private final int[] f243f;

    /* renamed from: g, reason: collision with root package name */
    private final int[] f244g;

    a1(Context context) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.f241d = layoutParams;
        this.f242e = new Rect();
        this.f243f = new int[2];
        this.f244g = new int[2];
        this.f238a = context;
        View inflate = LayoutInflater.from(context).inflate(b.a.g.s, (ViewGroup) null);
        this.f239b = inflate;
        this.f240c = (TextView) inflate.findViewById(b.a.f.s);
        layoutParams.setTitle(a1.class.getSimpleName());
        layoutParams.packageName = context.getPackageName();
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = b.a.i.f781a;
        layoutParams.flags = 24;
    }

    private void a(View view, int i2, int i3, boolean z, WindowManager.LayoutParams layoutParams) {
        int height;
        int i4;
        layoutParams.token = view.getApplicationWindowToken();
        int dimensionPixelOffset = this.f238a.getResources().getDimensionPixelOffset(b.a.d.f735j);
        if (view.getWidth() < dimensionPixelOffset) {
            i2 = view.getWidth() / 2;
        }
        if (view.getHeight() >= dimensionPixelOffset) {
            int dimensionPixelOffset2 = this.f238a.getResources().getDimensionPixelOffset(b.a.d.f734i);
            height = i3 + dimensionPixelOffset2;
            i4 = i3 - dimensionPixelOffset2;
        } else {
            height = view.getHeight();
            i4 = 0;
        }
        layoutParams.gravity = 49;
        int dimensionPixelOffset3 = this.f238a.getResources().getDimensionPixelOffset(z ? b.a.d.l : b.a.d.f736k);
        View b2 = b(view);
        if (b2 == null) {
            Log.e("TooltipPopup", "Cannot find app view");
            return;
        }
        b2.getWindowVisibleDisplayFrame(this.f242e);
        Rect rect = this.f242e;
        if (rect.left < 0 && rect.top < 0) {
            Resources resources = this.f238a.getResources();
            int identifier = resources.getIdentifier("status_bar_height", "dimen", "android");
            int dimensionPixelSize = identifier != 0 ? resources.getDimensionPixelSize(identifier) : 0;
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            this.f242e.set(0, dimensionPixelSize, displayMetrics.widthPixels, displayMetrics.heightPixels);
        }
        b2.getLocationOnScreen(this.f244g);
        view.getLocationOnScreen(this.f243f);
        int[] iArr = this.f243f;
        int i5 = iArr[0];
        int[] iArr2 = this.f244g;
        iArr[0] = i5 - iArr2[0];
        iArr[1] = iArr[1] - iArr2[1];
        layoutParams.x = (iArr[0] + i2) - (b2.getWidth() / 2);
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.f239b.measure(makeMeasureSpec, makeMeasureSpec);
        int measuredHeight = this.f239b.getMeasuredHeight();
        int[] iArr3 = this.f243f;
        int i6 = ((iArr3[1] + i4) - dimensionPixelOffset3) - measuredHeight;
        int i7 = iArr3[1] + height + dimensionPixelOffset3;
        if (!z ? measuredHeight + i7 <= this.f242e.height() : i6 < 0) {
            layoutParams.y = i6;
        } else {
            layoutParams.y = i7;
        }
    }

    private static View b(View view) {
        View rootView = view.getRootView();
        ViewGroup.LayoutParams layoutParams = rootView.getLayoutParams();
        if ((layoutParams instanceof WindowManager.LayoutParams) && ((WindowManager.LayoutParams) layoutParams).type == 2) {
            return rootView;
        }
        for (Context context = view.getContext(); context instanceof ContextWrapper; context = ((ContextWrapper) context).getBaseContext()) {
            if (context instanceof Activity) {
                return ((Activity) context).getWindow().getDecorView();
            }
        }
        return rootView;
    }

    void c() {
        if (d()) {
            ((WindowManager) this.f238a.getSystemService("window")).removeView(this.f239b);
        }
    }

    boolean d() {
        return this.f239b.getParent() != null;
    }

    void e(View view, int i2, int i3, boolean z, CharSequence charSequence) {
        if (d()) {
            c();
        }
        this.f240c.setText(charSequence);
        a(view, i2, i3, z, this.f241d);
        ((WindowManager) this.f238a.getSystemService("window")).addView(this.f239b, this.f241d);
    }
}
