package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.a;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.ActionMenuView;
import com.pichillilorenzo.flutter_inappwebview.R;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class Toolbar extends ViewGroup {
    int A;
    private int B;
    private int C;
    private int D;
    private int E;
    private int F;
    private o0 G;
    private int H;
    private int I;
    private int J;
    private CharSequence K;
    private CharSequence L;
    private ColorStateList M;
    private ColorStateList N;
    private boolean O;
    private boolean P;
    private final ArrayList<View> Q;
    private final ArrayList<View> R;
    private final int[] S;
    f T;
    private final ActionMenuView.e U;
    private x0 V;
    private androidx.appcompat.widget.c W;
    private d a0;
    private m.a b0;
    private g.a c0;
    private boolean d0;
    private final Runnable e0;
    private ActionMenuView n;
    private TextView o;
    private TextView p;
    private ImageButton q;
    private ImageView r;
    private Drawable s;
    private CharSequence t;
    ImageButton u;
    View v;
    private Context w;
    private int x;
    private int y;
    private int z;

    class a implements ActionMenuView.e {
        a() {
        }

        @Override // androidx.appcompat.widget.ActionMenuView.e
        public boolean onMenuItemClick(MenuItem menuItem) {
            f fVar = Toolbar.this.T;
            if (fVar != null) {
                return fVar.onMenuItemClick(menuItem);
            }
            return false;
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Toolbar.this.O();
        }
    }

    class c implements View.OnClickListener {
        c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Toolbar.this.e();
        }
    }

    private class d implements androidx.appcompat.view.menu.m {
        androidx.appcompat.view.menu.g n;
        androidx.appcompat.view.menu.i o;

        d() {
        }

        @Override // androidx.appcompat.view.menu.m
        public void b(androidx.appcompat.view.menu.g gVar, boolean z) {
        }

        @Override // androidx.appcompat.view.menu.m
        public void d(Context context, androidx.appcompat.view.menu.g gVar) {
            androidx.appcompat.view.menu.i iVar;
            androidx.appcompat.view.menu.g gVar2 = this.n;
            if (gVar2 != null && (iVar = this.o) != null) {
                gVar2.f(iVar);
            }
            this.n = gVar;
        }

        @Override // androidx.appcompat.view.menu.m
        public boolean e(androidx.appcompat.view.menu.r rVar) {
            return false;
        }

        @Override // androidx.appcompat.view.menu.m
        public void f(boolean z) {
            if (this.o != null) {
                androidx.appcompat.view.menu.g gVar = this.n;
                boolean z2 = false;
                if (gVar != null) {
                    int size = gVar.size();
                    int i2 = 0;
                    while (true) {
                        if (i2 >= size) {
                            break;
                        }
                        if (this.n.getItem(i2) == this.o) {
                            z2 = true;
                            break;
                        }
                        i2++;
                    }
                }
                if (z2) {
                    return;
                }
                i(this.n, this.o);
            }
        }

        @Override // androidx.appcompat.view.menu.m
        public boolean g() {
            return false;
        }

        @Override // androidx.appcompat.view.menu.m
        public boolean i(androidx.appcompat.view.menu.g gVar, androidx.appcompat.view.menu.i iVar) {
            KeyEvent.Callback callback = Toolbar.this.v;
            if (callback instanceof b.a.n.c) {
                ((b.a.n.c) callback).d();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.v);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.u);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.v = null;
            toolbar3.a();
            this.o = null;
            Toolbar.this.requestLayout();
            iVar.r(false);
            return true;
        }

        @Override // androidx.appcompat.view.menu.m
        public boolean j(androidx.appcompat.view.menu.g gVar, androidx.appcompat.view.menu.i iVar) {
            Toolbar.this.g();
            ViewParent parent = Toolbar.this.u.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.u);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.u);
            }
            Toolbar.this.v = iVar.getActionView();
            this.o = iVar;
            ViewParent parent2 = Toolbar.this.v.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.v);
                }
                e generateDefaultLayoutParams = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                generateDefaultLayoutParams.f61a = 8388611 | (toolbar4.A & R.styleable.AppCompatTheme_tooltipForegroundColor);
                generateDefaultLayoutParams.f223b = 2;
                toolbar4.v.setLayoutParams(generateDefaultLayoutParams);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.v);
            }
            Toolbar.this.G();
            Toolbar.this.requestLayout();
            iVar.r(true);
            KeyEvent.Callback callback = Toolbar.this.v;
            if (callback instanceof b.a.n.c) {
                ((b.a.n.c) callback).c();
            }
            return true;
        }
    }

    public static class e extends a.C0010a {

        /* renamed from: b, reason: collision with root package name */
        int f223b;

        public e(int i2, int i3) {
            super(i2, i3);
            this.f223b = 0;
            this.f61a = 8388627;
        }

        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f223b = 0;
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f223b = 0;
        }

        public e(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f223b = 0;
            a(marginLayoutParams);
        }

        public e(a.C0010a c0010a) {
            super(c0010a);
            this.f223b = 0;
        }

        public e(e eVar) {
            super((a.C0010a) eVar);
            this.f223b = 0;
            this.f223b = eVar.f223b;
        }

        void a(ViewGroup.MarginLayoutParams marginLayoutParams) {
            ((ViewGroup.MarginLayoutParams) this).leftMargin = marginLayoutParams.leftMargin;
            ((ViewGroup.MarginLayoutParams) this).topMargin = marginLayoutParams.topMargin;
            ((ViewGroup.MarginLayoutParams) this).rightMargin = marginLayoutParams.rightMargin;
            ((ViewGroup.MarginLayoutParams) this).bottomMargin = marginLayoutParams.bottomMargin;
        }
    }

    public interface f {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    public static class g extends b.i.a.a {
        public static final Parcelable.Creator<g> CREATOR = new a();
        int p;
        boolean q;

        class a implements Parcelable.ClassLoaderCreator<g> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a, reason: merged with bridge method [inline-methods] */
            public g createFromParcel(Parcel parcel) {
                return new g(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* renamed from: b, reason: merged with bridge method [inline-methods] */
            public g createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new g(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: c, reason: merged with bridge method [inline-methods] */
            public g[] newArray(int i2) {
                return new g[i2];
            }
        }

        public g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.p = parcel.readInt();
            this.q = parcel.readInt() != 0;
        }

        public g(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // b.i.a.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.p);
            parcel.writeInt(this.q ? 1 : 0);
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b.a.a.L);
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.J = 8388627;
        this.Q = new ArrayList<>();
        this.R = new ArrayList<>();
        this.S = new int[2];
        this.U = new a();
        this.e0 = new b();
        Context context2 = getContext();
        int[] iArr = b.a.j.H2;
        w0 u = w0.u(context2, attributeSet, iArr, i2, 0);
        b.g.l.r.J(this, context, iArr, attributeSet, u.q(), i2, 0);
        this.y = u.m(b.a.j.j3, 0);
        this.z = u.m(b.a.j.a3, 0);
        this.J = u.k(b.a.j.I2, this.J);
        this.A = u.k(b.a.j.J2, 48);
        int d2 = u.d(b.a.j.d3, 0);
        int i3 = b.a.j.i3;
        d2 = u.r(i3) ? u.d(i3, d2) : d2;
        this.F = d2;
        this.E = d2;
        this.D = d2;
        this.C = d2;
        int d3 = u.d(b.a.j.g3, -1);
        if (d3 >= 0) {
            this.C = d3;
        }
        int d4 = u.d(b.a.j.f3, -1);
        if (d4 >= 0) {
            this.D = d4;
        }
        int d5 = u.d(b.a.j.h3, -1);
        if (d5 >= 0) {
            this.E = d5;
        }
        int d6 = u.d(b.a.j.e3, -1);
        if (d6 >= 0) {
            this.F = d6;
        }
        this.B = u.e(b.a.j.U2, -1);
        int d7 = u.d(b.a.j.Q2, Integer.MIN_VALUE);
        int d8 = u.d(b.a.j.M2, Integer.MIN_VALUE);
        int e2 = u.e(b.a.j.O2, 0);
        int e3 = u.e(b.a.j.P2, 0);
        h();
        this.G.e(e2, e3);
        if (d7 != Integer.MIN_VALUE || d8 != Integer.MIN_VALUE) {
            this.G.g(d7, d8);
        }
        this.H = u.d(b.a.j.R2, Integer.MIN_VALUE);
        this.I = u.d(b.a.j.N2, Integer.MIN_VALUE);
        this.s = u.f(b.a.j.L2);
        this.t = u.o(b.a.j.K2);
        CharSequence o = u.o(b.a.j.c3);
        if (!TextUtils.isEmpty(o)) {
            setTitle(o);
        }
        CharSequence o2 = u.o(b.a.j.Z2);
        if (!TextUtils.isEmpty(o2)) {
            setSubtitle(o2);
        }
        this.w = getContext();
        setPopupTheme(u.m(b.a.j.Y2, 0));
        Drawable f2 = u.f(b.a.j.X2);
        if (f2 != null) {
            setNavigationIcon(f2);
        }
        CharSequence o3 = u.o(b.a.j.W2);
        if (!TextUtils.isEmpty(o3)) {
            setNavigationContentDescription(o3);
        }
        Drawable f3 = u.f(b.a.j.S2);
        if (f3 != null) {
            setLogo(f3);
        }
        CharSequence o4 = u.o(b.a.j.T2);
        if (!TextUtils.isEmpty(o4)) {
            setLogoDescription(o4);
        }
        int i4 = b.a.j.k3;
        if (u.r(i4)) {
            setTitleTextColor(u.c(i4));
        }
        int i5 = b.a.j.b3;
        if (u.r(i5)) {
            setSubtitleTextColor(u.c(i5));
        }
        int i6 = b.a.j.V2;
        if (u.r(i6)) {
            x(u.m(i6, 0));
        }
        u.v();
    }

    private int B(View view, int i2, int[] iArr, int i3) {
        e eVar = (e) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin - iArr[0];
        int max = i2 + Math.max(0, i4);
        iArr[0] = Math.max(0, -i4);
        int q = q(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, q, max + measuredWidth, view.getMeasuredHeight() + q);
        return max + measuredWidth + ((ViewGroup.MarginLayoutParams) eVar).rightMargin;
    }

    private int C(View view, int i2, int[] iArr, int i3) {
        e eVar = (e) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) eVar).rightMargin - iArr[1];
        int max = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int q = q(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, q, max, view.getMeasuredHeight() + q);
        return max - (measuredWidth + ((ViewGroup.MarginLayoutParams) eVar).leftMargin);
    }

    private int D(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i6) + Math.max(0, i7);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + max + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    private void E(View view, int i2, int i3, int i4, int i5, int i6) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i6 >= 0) {
            if (mode != 0) {
                i6 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i6);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    private void F() {
        removeCallbacks(this.e0);
        post(this.e0);
    }

    private boolean M() {
        if (!this.d0) {
            return false;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (N(childAt) && childAt.getMeasuredWidth() > 0 && childAt.getMeasuredHeight() > 0) {
                return false;
            }
        }
        return true;
    }

    private boolean N(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    private void b(List<View> list, int i2) {
        boolean z = b.g.l.r.p(this) == 1;
        int childCount = getChildCount();
        int a2 = b.g.l.d.a(i2, b.g.l.r.p(this));
        list.clear();
        if (!z) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.f223b == 0 && N(childAt) && p(eVar.f61a) == a2) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i4 = childCount - 1; i4 >= 0; i4--) {
            View childAt2 = getChildAt(i4);
            e eVar2 = (e) childAt2.getLayoutParams();
            if (eVar2.f223b == 0 && N(childAt2) && p(eVar2.f61a) == a2) {
                list.add(childAt2);
            }
        }
    }

    private void c(View view, boolean z) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        e generateDefaultLayoutParams = layoutParams == null ? generateDefaultLayoutParams() : !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (e) layoutParams;
        generateDefaultLayoutParams.f223b = 1;
        if (!z || this.v == null) {
            addView(view, generateDefaultLayoutParams);
        } else {
            view.setLayoutParams(generateDefaultLayoutParams);
            this.R.add(view);
        }
    }

    private MenuInflater getMenuInflater() {
        return new b.a.n.g(getContext());
    }

    private void h() {
        if (this.G == null) {
            this.G = new o0();
        }
    }

    private void i() {
        if (this.r == null) {
            this.r = new o(getContext());
        }
    }

    private void j() {
        k();
        if (this.n.L() == null) {
            androidx.appcompat.view.menu.g gVar = (androidx.appcompat.view.menu.g) this.n.getMenu();
            if (this.a0 == null) {
                this.a0 = new d();
            }
            this.n.setExpandedActionViewsExclusive(true);
            gVar.c(this.a0, this.w);
        }
    }

    private void k() {
        if (this.n == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext());
            this.n = actionMenuView;
            actionMenuView.setPopupTheme(this.x);
            this.n.setOnMenuItemClickListener(this.U);
            this.n.M(this.b0, this.c0);
            e generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f61a = 8388613 | (this.A & R.styleable.AppCompatTheme_tooltipForegroundColor);
            this.n.setLayoutParams(generateDefaultLayoutParams);
            c(this.n, false);
        }
    }

    private void l() {
        if (this.q == null) {
            this.q = new m(getContext(), null, b.a.a.K);
            e generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f61a = 8388611 | (this.A & R.styleable.AppCompatTheme_tooltipForegroundColor);
            this.q.setLayoutParams(generateDefaultLayoutParams);
        }
    }

    private int p(int i2) {
        int p = b.g.l.r.p(this);
        int a2 = b.g.l.d.a(i2, p) & 7;
        return (a2 == 1 || a2 == 3 || a2 == 5) ? a2 : p == 1 ? 5 : 3;
    }

    private int q(View view, int i2) {
        e eVar = (e) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i2 > 0 ? (measuredHeight - i2) / 2 : 0;
        int r = r(eVar.f61a);
        if (r == 48) {
            return getPaddingTop() - i3;
        }
        if (r == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) eVar).bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i4 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i5 = ((ViewGroup.MarginLayoutParams) eVar).topMargin;
        if (i4 < i5) {
            i4 = i5;
        } else {
            int i6 = (((height - paddingBottom) - measuredHeight) - i4) - paddingTop;
            int i7 = ((ViewGroup.MarginLayoutParams) eVar).bottomMargin;
            if (i6 < i7) {
                i4 = Math.max(0, i4 - (i7 - i6));
            }
        }
        return paddingTop + i4;
    }

    private int r(int i2) {
        int i3 = i2 & R.styleable.AppCompatTheme_tooltipForegroundColor;
        return (i3 == 16 || i3 == 48 || i3 == 80) ? i3 : this.J & R.styleable.AppCompatTheme_tooltipForegroundColor;
    }

    private int s(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return b.g.l.g.b(marginLayoutParams) + b.g.l.g.a(marginLayoutParams);
    }

    private int t(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    private int u(List<View> list, int[] iArr) {
        int i2 = iArr[0];
        int i3 = iArr[1];
        int size = list.size();
        int i4 = 0;
        int i5 = 0;
        while (i4 < size) {
            View view = list.get(i4);
            e eVar = (e) view.getLayoutParams();
            int i6 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin - i2;
            int i7 = ((ViewGroup.MarginLayoutParams) eVar).rightMargin - i3;
            int max = Math.max(0, i6);
            int max2 = Math.max(0, i7);
            int max3 = Math.max(0, -i6);
            int max4 = Math.max(0, -i7);
            i5 += max + view.getMeasuredWidth() + max2;
            i4++;
            i3 = max4;
            i2 = max3;
        }
        return i5;
    }

    private boolean y(View view) {
        return view.getParent() == this || this.R.contains(view);
    }

    public boolean A() {
        ActionMenuView actionMenuView = this.n;
        return actionMenuView != null && actionMenuView.H();
    }

    void G() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            if (((e) childAt.getLayoutParams()).f223b != 2 && childAt != this.n) {
                removeViewAt(childCount);
                this.R.add(childAt);
            }
        }
    }

    public void H(int i2, int i3) {
        h();
        this.G.g(i2, i3);
    }

    public void I(androidx.appcompat.view.menu.g gVar, androidx.appcompat.widget.c cVar) {
        if (gVar == null && this.n == null) {
            return;
        }
        k();
        androidx.appcompat.view.menu.g L = this.n.L();
        if (L == gVar) {
            return;
        }
        if (L != null) {
            L.O(this.W);
            L.O(this.a0);
        }
        if (this.a0 == null) {
            this.a0 = new d();
        }
        cVar.G(true);
        if (gVar != null) {
            gVar.c(cVar, this.w);
            gVar.c(this.a0, this.w);
        } else {
            cVar.d(this.w, null);
            this.a0.d(this.w, null);
            cVar.f(true);
            this.a0.f(true);
        }
        this.n.setPopupTheme(this.x);
        this.n.setPresenter(cVar);
        this.W = cVar;
    }

    public void J(m.a aVar, g.a aVar2) {
        this.b0 = aVar;
        this.c0 = aVar2;
        ActionMenuView actionMenuView = this.n;
        if (actionMenuView != null) {
            actionMenuView.M(aVar, aVar2);
        }
    }

    public void K(Context context, int i2) {
        this.z = i2;
        TextView textView = this.p;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    public void L(Context context, int i2) {
        this.y = i2;
        TextView textView = this.o;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    public boolean O() {
        ActionMenuView actionMenuView = this.n;
        return actionMenuView != null && actionMenuView.N();
    }

    void a() {
        for (int size = this.R.size() - 1; size >= 0; size--) {
            addView(this.R.get(size));
        }
        this.R.clear();
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof e);
    }

    public boolean d() {
        ActionMenuView actionMenuView;
        return getVisibility() == 0 && (actionMenuView = this.n) != null && actionMenuView.I();
    }

    public void e() {
        d dVar = this.a0;
        androidx.appcompat.view.menu.i iVar = dVar == null ? null : dVar.o;
        if (iVar != null) {
            iVar.collapseActionView();
        }
    }

    public void f() {
        ActionMenuView actionMenuView = this.n;
        if (actionMenuView != null) {
            actionMenuView.z();
        }
    }

    void g() {
        if (this.u == null) {
            m mVar = new m(getContext(), null, b.a.a.K);
            this.u = mVar;
            mVar.setImageDrawable(this.s);
            this.u.setContentDescription(this.t);
            e generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f61a = 8388611 | (this.A & R.styleable.AppCompatTheme_tooltipForegroundColor);
            generateDefaultLayoutParams.f223b = 2;
            this.u.setLayoutParams(generateDefaultLayoutParams);
            this.u.setOnClickListener(new c());
        }
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.u;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.u;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        o0 o0Var = this.G;
        if (o0Var != null) {
            return o0Var.a();
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.I;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        o0 o0Var = this.G;
        if (o0Var != null) {
            return o0Var.b();
        }
        return 0;
    }

    public int getContentInsetRight() {
        o0 o0Var = this.G;
        if (o0Var != null) {
            return o0Var.c();
        }
        return 0;
    }

    public int getContentInsetStart() {
        o0 o0Var = this.G;
        if (o0Var != null) {
            return o0Var.d();
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.H;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        androidx.appcompat.view.menu.g L;
        ActionMenuView actionMenuView = this.n;
        return actionMenuView != null && (L = actionMenuView.L()) != null && L.hasVisibleItems() ? Math.max(getContentInsetEnd(), Math.max(this.I, 0)) : getContentInsetEnd();
    }

    public int getCurrentContentInsetLeft() {
        return b.g.l.r.p(this) == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return b.g.l.r.p(this) == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.H, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.r;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.r;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        j();
        return this.n.getMenu();
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.q;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.q;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    androidx.appcompat.widget.c getOuterActionMenuPresenter() {
        return this.W;
    }

    public Drawable getOverflowIcon() {
        j();
        return this.n.getOverflowIcon();
    }

    Context getPopupContext() {
        return this.w;
    }

    public int getPopupTheme() {
        return this.x;
    }

    public CharSequence getSubtitle() {
        return this.L;
    }

    final TextView getSubtitleTextView() {
        return this.p;
    }

    public CharSequence getTitle() {
        return this.K;
    }

    public int getTitleMarginBottom() {
        return this.F;
    }

    public int getTitleMarginEnd() {
        return this.D;
    }

    public int getTitleMarginStart() {
        return this.C;
    }

    public int getTitleMarginTop() {
        return this.E;
    }

    final TextView getTitleTextView() {
        return this.o;
    }

    public d0 getWrapper() {
        if (this.V == null) {
            this.V = new x0(this, true);
        }
        return this.V;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* renamed from: m, reason: merged with bridge method [inline-methods] */
    public e generateDefaultLayoutParams() {
        return new e(-2, -2);
    }

    @Override // android.view.ViewGroup
    /* renamed from: n, reason: merged with bridge method [inline-methods] */
    public e generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* renamed from: o, reason: merged with bridge method [inline-methods] */
    public e generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e ? new e((e) layoutParams) : layoutParams instanceof a.C0010a ? new e((a.C0010a) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new e((ViewGroup.MarginLayoutParams) layoutParams) : new e(layoutParams);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.e0);
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.P = false;
        }
        if (!this.P) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.P = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.P = false;
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:112:0x019c  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x012d  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x0126  */
    /* JADX WARN: Removed duplicated region for block: B:119:0x0113  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x00f6  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0072  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00c2  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00dd  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00fb  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0299 A[LOOP:0: B:46:0x0297->B:47:0x0299, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x02bb A[LOOP:1: B:50:0x02b9->B:51:0x02bb, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x02e5  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x02f4 A[LOOP:2: B:59:0x02f2->B:60:0x02f4, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0123  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x012a  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x015e  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x01ad  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x021f  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void onLayout(boolean r20, int r21, int r22, int r23, int r24) {
        /*
            Method dump skipped, instructions count: 777
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        char c2;
        char c3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int[] iArr = this.S;
        if (c1.b(this)) {
            c2 = 1;
            c3 = 0;
        } else {
            c2 = 0;
            c3 = 1;
        }
        if (N(this.q)) {
            E(this.q, i2, 0, i3, 0, this.B);
            i4 = this.q.getMeasuredWidth() + s(this.q);
            i5 = Math.max(0, this.q.getMeasuredHeight() + t(this.q));
            i6 = View.combineMeasuredStates(0, this.q.getMeasuredState());
        } else {
            i4 = 0;
            i5 = 0;
            i6 = 0;
        }
        if (N(this.u)) {
            E(this.u, i2, 0, i3, 0, this.B);
            i4 = this.u.getMeasuredWidth() + s(this.u);
            i5 = Math.max(i5, this.u.getMeasuredHeight() + t(this.u));
            i6 = View.combineMeasuredStates(i6, this.u.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = 0 + Math.max(currentContentInsetStart, i4);
        iArr[c2] = Math.max(0, currentContentInsetStart - i4);
        if (N(this.n)) {
            E(this.n, i2, max, i3, 0, this.B);
            i7 = this.n.getMeasuredWidth() + s(this.n);
            i5 = Math.max(i5, this.n.getMeasuredHeight() + t(this.n));
            i6 = View.combineMeasuredStates(i6, this.n.getMeasuredState());
        } else {
            i7 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max2 = max + Math.max(currentContentInsetEnd, i7);
        iArr[c3] = Math.max(0, currentContentInsetEnd - i7);
        if (N(this.v)) {
            max2 += D(this.v, i2, max2, i3, 0, iArr);
            i5 = Math.max(i5, this.v.getMeasuredHeight() + t(this.v));
            i6 = View.combineMeasuredStates(i6, this.v.getMeasuredState());
        }
        if (N(this.r)) {
            max2 += D(this.r, i2, max2, i3, 0, iArr);
            i5 = Math.max(i5, this.r.getMeasuredHeight() + t(this.r));
            i6 = View.combineMeasuredStates(i6, this.r.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (((e) childAt.getLayoutParams()).f223b == 0 && N(childAt)) {
                max2 += D(childAt, i2, max2, i3, 0, iArr);
                i5 = Math.max(i5, childAt.getMeasuredHeight() + t(childAt));
                i6 = View.combineMeasuredStates(i6, childAt.getMeasuredState());
            }
        }
        int i12 = this.E + this.F;
        int i13 = this.C + this.D;
        if (N(this.o)) {
            D(this.o, i2, max2 + i13, i3, i12, iArr);
            int measuredWidth = this.o.getMeasuredWidth() + s(this.o);
            i10 = this.o.getMeasuredHeight() + t(this.o);
            i8 = View.combineMeasuredStates(i6, this.o.getMeasuredState());
            i9 = measuredWidth;
        } else {
            i8 = i6;
            i9 = 0;
            i10 = 0;
        }
        if (N(this.p)) {
            i9 = Math.max(i9, D(this.p, i2, max2 + i13, i3, i10 + i12, iArr));
            i10 += this.p.getMeasuredHeight() + t(this.p);
            i8 = View.combineMeasuredStates(i8, this.p.getMeasuredState());
        }
        int max3 = Math.max(i5, i10);
        setMeasuredDimension(View.resolveSizeAndState(Math.max(max2 + i9 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i2, (-16777216) & i8), M() ? 0 : View.resolveSizeAndState(Math.max(max3 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i3, i8 << 16));
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        g gVar = (g) parcelable;
        super.onRestoreInstanceState(gVar.a());
        ActionMenuView actionMenuView = this.n;
        androidx.appcompat.view.menu.g L = actionMenuView != null ? actionMenuView.L() : null;
        int i2 = gVar.p;
        if (i2 != 0 && this.a0 != null && L != null && (findItem = L.findItem(i2)) != null) {
            findItem.expandActionView();
        }
        if (gVar.q) {
            F();
        }
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i2) {
        if (Build.VERSION.SDK_INT >= 17) {
            super.onRtlPropertiesChanged(i2);
        }
        h();
        this.G.f(i2 == 1);
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        androidx.appcompat.view.menu.i iVar;
        g gVar = new g(super.onSaveInstanceState());
        d dVar = this.a0;
        if (dVar != null && (iVar = dVar.o) != null) {
            gVar.p = iVar.getItemId();
        }
        gVar.q = A();
        return gVar;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.O = false;
        }
        if (!this.O) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.O = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.O = false;
        }
        return true;
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        ImageButton imageButton = this.u;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(b.a.k.a.a.d(getContext(), i2));
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            this.u.setImageDrawable(drawable);
        } else {
            ImageButton imageButton = this.u;
            if (imageButton != null) {
                imageButton.setImageDrawable(this.s);
            }
        }
    }

    public void setCollapsible(boolean z) {
        this.d0 = z;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.I) {
            this.I = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.H) {
            this.H = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(b.a.k.a.a.d(getContext(), i2));
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            i();
            if (!y(this.r)) {
                c(this.r, true);
            }
        } else {
            ImageView imageView = this.r;
            if (imageView != null && y(imageView)) {
                removeView(this.r);
                this.R.remove(this.r);
            }
        }
        ImageView imageView2 = this.r;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            i();
        }
        ImageView imageView = this.r;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            l();
        }
        ImageButton imageButton = this.q;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(b.a.k.a.a.d(getContext(), i2));
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            l();
            if (!y(this.q)) {
                c(this.q, true);
            }
        } else {
            ImageButton imageButton = this.q;
            if (imageButton != null && y(imageButton)) {
                removeView(this.q);
                this.R.remove(this.q);
            }
        }
        ImageButton imageButton2 = this.q;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        l();
        this.q.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(f fVar) {
        this.T = fVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        j();
        this.n.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.x != i2) {
            this.x = i2;
            if (i2 == 0) {
                this.w = getContext();
            } else {
                this.w = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.p;
            if (textView != null && y(textView)) {
                removeView(this.p);
                this.R.remove(this.p);
            }
        } else {
            if (this.p == null) {
                Context context = getContext();
                z zVar = new z(context);
                this.p = zVar;
                zVar.setSingleLine();
                this.p.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.z;
                if (i2 != 0) {
                    this.p.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.N;
                if (colorStateList != null) {
                    this.p.setTextColor(colorStateList);
                }
            }
            if (!y(this.p)) {
                c(this.p, true);
            }
        }
        TextView textView2 = this.p;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.L = charSequence;
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.N = colorStateList;
        TextView textView = this.p;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.o;
            if (textView != null && y(textView)) {
                removeView(this.o);
                this.R.remove(this.o);
            }
        } else {
            if (this.o == null) {
                Context context = getContext();
                z zVar = new z(context);
                this.o = zVar;
                zVar.setSingleLine();
                this.o.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.y;
                if (i2 != 0) {
                    this.o.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.M;
                if (colorStateList != null) {
                    this.o.setTextColor(colorStateList);
                }
            }
            if (!y(this.o)) {
                c(this.o, true);
            }
        }
        TextView textView2 = this.o;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.K = charSequence;
    }

    public void setTitleMarginBottom(int i2) {
        this.F = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.D = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.C = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.E = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.M = colorStateList;
        TextView textView = this.o;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public boolean v() {
        d dVar = this.a0;
        return (dVar == null || dVar.o == null) ? false : true;
    }

    public boolean w() {
        ActionMenuView actionMenuView = this.n;
        return actionMenuView != null && actionMenuView.F();
    }

    public void x(int i2) {
        getMenuInflater().inflate(i2, getMenu());
    }

    public boolean z() {
        ActionMenuView actionMenuView = this.n;
        return actionMenuView != null && actionMenuView.G();
    }
}
