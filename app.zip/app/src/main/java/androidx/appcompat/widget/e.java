package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;

/* loaded from: classes.dex */
class e {

    /* renamed from: a, reason: collision with root package name */
    private final View f250a;

    /* renamed from: d, reason: collision with root package name */
    private u0 f253d;

    /* renamed from: e, reason: collision with root package name */
    private u0 f254e;

    /* renamed from: f, reason: collision with root package name */
    private u0 f255f;

    /* renamed from: c, reason: collision with root package name */
    private int f252c = -1;

    /* renamed from: b, reason: collision with root package name */
    private final j f251b = j.b();

    e(View view) {
        this.f250a = view;
    }

    private boolean a(Drawable drawable) {
        if (this.f255f == null) {
            this.f255f = new u0();
        }
        u0 u0Var = this.f255f;
        u0Var.a();
        ColorStateList l = b.g.l.r.l(this.f250a);
        if (l != null) {
            u0Var.f324d = true;
            u0Var.f321a = l;
        }
        PorterDuff.Mode m = b.g.l.r.m(this.f250a);
        if (m != null) {
            u0Var.f323c = true;
            u0Var.f322b = m;
        }
        if (!u0Var.f324d && !u0Var.f323c) {
            return false;
        }
        j.i(drawable, u0Var, this.f250a.getDrawableState());
        return true;
    }

    private boolean k() {
        int i2 = Build.VERSION.SDK_INT;
        return i2 > 21 ? this.f253d != null : i2 == 21;
    }

    void b() {
        Drawable background = this.f250a.getBackground();
        if (background != null) {
            if (k() && a(background)) {
                return;
            }
            u0 u0Var = this.f254e;
            if (u0Var != null) {
                j.i(background, u0Var, this.f250a.getDrawableState());
                return;
            }
            u0 u0Var2 = this.f253d;
            if (u0Var2 != null) {
                j.i(background, u0Var2, this.f250a.getDrawableState());
            }
        }
    }

    ColorStateList c() {
        u0 u0Var = this.f254e;
        if (u0Var != null) {
            return u0Var.f321a;
        }
        return null;
    }

    PorterDuff.Mode d() {
        u0 u0Var = this.f254e;
        if (u0Var != null) {
            return u0Var.f322b;
        }
        return null;
    }

    void e(AttributeSet attributeSet, int i2) {
        Context context = this.f250a.getContext();
        int[] iArr = b.a.j.o3;
        w0 u = w0.u(context, attributeSet, iArr, i2, 0);
        View view = this.f250a;
        b.g.l.r.J(view, view.getContext(), iArr, attributeSet, u.q(), i2, 0);
        try {
            int i3 = b.a.j.p3;
            if (u.r(i3)) {
                this.f252c = u.m(i3, -1);
                ColorStateList f2 = this.f251b.f(this.f250a.getContext(), this.f252c);
                if (f2 != null) {
                    h(f2);
                }
            }
            int i4 = b.a.j.q3;
            if (u.r(i4)) {
                b.g.l.r.N(this.f250a, u.c(i4));
            }
            int i5 = b.a.j.r3;
            if (u.r(i5)) {
                b.g.l.r.O(this.f250a, e0.d(u.j(i5, -1), null));
            }
        } finally {
            u.v();
        }
    }

    void f(Drawable drawable) {
        this.f252c = -1;
        h(null);
        b();
    }

    void g(int i2) {
        this.f252c = i2;
        j jVar = this.f251b;
        h(jVar != null ? jVar.f(this.f250a.getContext(), i2) : null);
        b();
    }

    void h(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f253d == null) {
                this.f253d = new u0();
            }
            u0 u0Var = this.f253d;
            u0Var.f321a = colorStateList;
            u0Var.f324d = true;
        } else {
            this.f253d = null;
        }
        b();
    }

    void i(ColorStateList colorStateList) {
        if (this.f254e == null) {
            this.f254e = new u0();
        }
        u0 u0Var = this.f254e;
        u0Var.f321a = colorStateList;
        u0Var.f324d = true;
        b();
    }

    void j(PorterDuff.Mode mode) {
        if (this.f254e == null) {
            this.f254e = new u0();
        }
        u0 u0Var = this.f254e;
        u0Var.f322b = mode;
        u0Var.f323c = true;
        b();
    }
}
