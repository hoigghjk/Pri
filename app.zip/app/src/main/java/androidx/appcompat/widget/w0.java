package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import b.g.e.e.f;

/* loaded from: classes.dex */
public class w0 {

    /* renamed from: a, reason: collision with root package name */
    private final Context f332a;

    /* renamed from: b, reason: collision with root package name */
    private final TypedArray f333b;

    /* renamed from: c, reason: collision with root package name */
    private TypedValue f334c;

    private w0(Context context, TypedArray typedArray) {
        this.f332a = context;
        this.f333b = typedArray;
    }

    public static w0 s(Context context, int i2, int[] iArr) {
        return new w0(context, context.obtainStyledAttributes(i2, iArr));
    }

    public static w0 t(Context context, AttributeSet attributeSet, int[] iArr) {
        return new w0(context, context.obtainStyledAttributes(attributeSet, iArr));
    }

    public static w0 u(Context context, AttributeSet attributeSet, int[] iArr, int i2, int i3) {
        return new w0(context, context.obtainStyledAttributes(attributeSet, iArr, i2, i3));
    }

    public boolean a(int i2, boolean z) {
        return this.f333b.getBoolean(i2, z);
    }

    public int b(int i2, int i3) {
        return this.f333b.getColor(i2, i3);
    }

    public ColorStateList c(int i2) {
        int resourceId;
        ColorStateList c2;
        return (!this.f333b.hasValue(i2) || (resourceId = this.f333b.getResourceId(i2, 0)) == 0 || (c2 = b.a.k.a.a.c(this.f332a, resourceId)) == null) ? this.f333b.getColorStateList(i2) : c2;
    }

    public int d(int i2, int i3) {
        return this.f333b.getDimensionPixelOffset(i2, i3);
    }

    public int e(int i2, int i3) {
        return this.f333b.getDimensionPixelSize(i2, i3);
    }

    public Drawable f(int i2) {
        int resourceId;
        return (!this.f333b.hasValue(i2) || (resourceId = this.f333b.getResourceId(i2, 0)) == 0) ? this.f333b.getDrawable(i2) : b.a.k.a.a.d(this.f332a, resourceId);
    }

    public Drawable g(int i2) {
        int resourceId;
        if (!this.f333b.hasValue(i2) || (resourceId = this.f333b.getResourceId(i2, 0)) == 0) {
            return null;
        }
        return j.b().d(this.f332a, resourceId, true);
    }

    public float h(int i2, float f2) {
        return this.f333b.getFloat(i2, f2);
    }

    public Typeface i(int i2, int i3, f.c cVar) {
        int resourceId = this.f333b.getResourceId(i2, 0);
        if (resourceId == 0) {
            return null;
        }
        if (this.f334c == null) {
            this.f334c = new TypedValue();
        }
        return b.g.e.e.f.e(this.f332a, resourceId, this.f334c, i3, cVar);
    }

    public int j(int i2, int i3) {
        return this.f333b.getInt(i2, i3);
    }

    public int k(int i2, int i3) {
        return this.f333b.getInteger(i2, i3);
    }

    public int l(int i2, int i3) {
        return this.f333b.getLayoutDimension(i2, i3);
    }

    public int m(int i2, int i3) {
        return this.f333b.getResourceId(i2, i3);
    }

    public String n(int i2) {
        return this.f333b.getString(i2);
    }

    public CharSequence o(int i2) {
        return this.f333b.getText(i2);
    }

    public CharSequence[] p(int i2) {
        return this.f333b.getTextArray(i2);
    }

    public TypedArray q() {
        return this.f333b;
    }

    public boolean r(int i2) {
        return this.f333b.hasValue(i2);
    }

    public void v() {
        this.f333b.recycle();
    }
}
