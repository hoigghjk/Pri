package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public final class m0 {

    /* renamed from: i, reason: collision with root package name */
    private static m0 f278i;

    /* renamed from: a, reason: collision with root package name */
    private WeakHashMap<Context, b.e.h<ColorStateList>> f280a;

    /* renamed from: b, reason: collision with root package name */
    private b.e.g<String, d> f281b;

    /* renamed from: c, reason: collision with root package name */
    private b.e.h<String> f282c;

    /* renamed from: d, reason: collision with root package name */
    private final WeakHashMap<Context, b.e.d<WeakReference<Drawable.ConstantState>>> f283d = new WeakHashMap<>(0);

    /* renamed from: e, reason: collision with root package name */
    private TypedValue f284e;

    /* renamed from: f, reason: collision with root package name */
    private boolean f285f;

    /* renamed from: g, reason: collision with root package name */
    private e f286g;

    /* renamed from: h, reason: collision with root package name */
    private static final PorterDuff.Mode f277h = PorterDuff.Mode.SRC_IN;

    /* renamed from: j, reason: collision with root package name */
    private static final c f279j = new c(6);

    static class a implements d {
        a() {
        }

        @Override // androidx.appcompat.widget.m0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return b.a.l.a.a.m(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e2) {
                Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", e2);
                return null;
            }
        }
    }

    private static class b implements d {
        b() {
        }

        @Override // androidx.appcompat.widget.m0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return b.q.a.a.c.a(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e2) {
                Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", e2);
                return null;
            }
        }
    }

    private static class c extends b.e.e<Integer, PorterDuffColorFilter> {
        public c(int i2) {
            super(i2);
        }

        private static int j(int i2, PorterDuff.Mode mode) {
            return ((i2 + 31) * 31) + mode.hashCode();
        }

        PorterDuffColorFilter k(int i2, PorterDuff.Mode mode) {
            return c(Integer.valueOf(j(i2, mode)));
        }

        PorterDuffColorFilter l(int i2, PorterDuff.Mode mode, PorterDuffColorFilter porterDuffColorFilter) {
            return d(Integer.valueOf(j(i2, mode)), porterDuffColorFilter);
        }
    }

    private interface d {
        Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme);
    }

    interface e {
        boolean a(Context context, int i2, Drawable drawable);

        PorterDuff.Mode b(int i2);

        Drawable c(m0 m0Var, Context context, int i2);

        ColorStateList d(Context context, int i2);

        boolean e(Context context, int i2, Drawable drawable);
    }

    private static class f implements d {
        f() {
        }

        @Override // androidx.appcompat.widget.m0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return b.q.a.a.i.c(context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e2) {
                Log.e("VdcInflateDelegate", "Exception while inflating <vector>", e2);
                return null;
            }
        }
    }

    private void a(String str, d dVar) {
        if (this.f281b == null) {
            this.f281b = new b.e.g<>();
        }
        this.f281b.put(str, dVar);
    }

    private synchronized boolean b(Context context, long j2, Drawable drawable) {
        boolean z;
        Drawable.ConstantState constantState = drawable.getConstantState();
        if (constantState != null) {
            b.e.d<WeakReference<Drawable.ConstantState>> dVar = this.f283d.get(context);
            if (dVar == null) {
                dVar = new b.e.d<>();
                this.f283d.put(context, dVar);
            }
            dVar.i(j2, new WeakReference<>(constantState));
            z = true;
        } else {
            z = false;
        }
        return z;
    }

    private void c(Context context, int i2, ColorStateList colorStateList) {
        if (this.f280a == null) {
            this.f280a = new WeakHashMap<>();
        }
        b.e.h<ColorStateList> hVar = this.f280a.get(context);
        if (hVar == null) {
            hVar = new b.e.h<>();
            this.f280a.put(context, hVar);
        }
        hVar.a(i2, colorStateList);
    }

    private void d(Context context) {
        if (this.f285f) {
            return;
        }
        this.f285f = true;
        Drawable j2 = j(context, b.a.m.a.f819a);
        if (j2 == null || !q(j2)) {
            this.f285f = false;
            throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
        }
    }

    private static long e(TypedValue typedValue) {
        return (typedValue.assetCookie << 32) | typedValue.data;
    }

    private Drawable f(Context context, int i2) {
        if (this.f284e == null) {
            this.f284e = new TypedValue();
        }
        TypedValue typedValue = this.f284e;
        context.getResources().getValue(i2, typedValue, true);
        long e2 = e(typedValue);
        Drawable i3 = i(context, e2);
        if (i3 != null) {
            return i3;
        }
        e eVar = this.f286g;
        Drawable c2 = eVar == null ? null : eVar.c(this, context, i2);
        if (c2 != null) {
            c2.setChangingConfigurations(typedValue.changingConfigurations);
            b(context, e2, c2);
        }
        return c2;
    }

    private static PorterDuffColorFilter g(ColorStateList colorStateList, PorterDuff.Mode mode, int[] iArr) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return l(colorStateList.getColorForState(iArr, 0), mode);
    }

    public static synchronized m0 h() {
        m0 m0Var;
        synchronized (m0.class) {
            if (f278i == null) {
                m0 m0Var2 = new m0();
                f278i = m0Var2;
                p(m0Var2);
            }
            m0Var = f278i;
        }
        return m0Var;
    }

    private synchronized Drawable i(Context context, long j2) {
        b.e.d<WeakReference<Drawable.ConstantState>> dVar = this.f283d.get(context);
        if (dVar == null) {
            return null;
        }
        WeakReference<Drawable.ConstantState> f2 = dVar.f(j2);
        if (f2 != null) {
            Drawable.ConstantState constantState = f2.get();
            if (constantState != null) {
                return constantState.newDrawable(context.getResources());
            }
            dVar.j(j2);
        }
        return null;
    }

    public static synchronized PorterDuffColorFilter l(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter k2;
        synchronized (m0.class) {
            c cVar = f279j;
            k2 = cVar.k(i2, mode);
            if (k2 == null) {
                k2 = new PorterDuffColorFilter(i2, mode);
                cVar.l(i2, mode, k2);
            }
        }
        return k2;
    }

    private ColorStateList n(Context context, int i2) {
        b.e.h<ColorStateList> hVar;
        WeakHashMap<Context, b.e.h<ColorStateList>> weakHashMap = this.f280a;
        if (weakHashMap == null || (hVar = weakHashMap.get(context)) == null) {
            return null;
        }
        return hVar.f(i2);
    }

    private static void p(m0 m0Var) {
        if (Build.VERSION.SDK_INT < 24) {
            m0Var.a("vector", new f());
            m0Var.a("animated-vector", new b());
            m0Var.a("animated-selector", new a());
        }
    }

    private static boolean q(Drawable drawable) {
        return (drawable instanceof b.q.a.a.i) || "android.graphics.drawable.VectorDrawable".equals(drawable.getClass().getName());
    }

    private Drawable r(Context context, int i2) {
        int next;
        b.e.g<String, d> gVar = this.f281b;
        if (gVar == null || gVar.isEmpty()) {
            return null;
        }
        b.e.h<String> hVar = this.f282c;
        if (hVar != null) {
            String f2 = hVar.f(i2);
            if ("appcompat_skip_skip".equals(f2) || (f2 != null && this.f281b.get(f2) == null)) {
                return null;
            }
        } else {
            this.f282c = new b.e.h<>();
        }
        if (this.f284e == null) {
            this.f284e = new TypedValue();
        }
        TypedValue typedValue = this.f284e;
        Resources resources = context.getResources();
        resources.getValue(i2, typedValue, true);
        long e2 = e(typedValue);
        Drawable i3 = i(context, e2);
        if (i3 != null) {
            return i3;
        }
        CharSequence charSequence = typedValue.string;
        if (charSequence != null && charSequence.toString().endsWith(".xml")) {
            try {
                XmlResourceParser xml = resources.getXml(i2);
                AttributeSet asAttributeSet = Xml.asAttributeSet(xml);
                do {
                    next = xml.next();
                    if (next == 2) {
                        break;
                    }
                } while (next != 1);
                if (next != 2) {
                    throw new XmlPullParserException("No start tag found");
                }
                String name = xml.getName();
                this.f282c.a(i2, name);
                d dVar = this.f281b.get(name);
                if (dVar != null) {
                    i3 = dVar.a(context, xml, asAttributeSet, context.getTheme());
                }
                if (i3 != null) {
                    i3.setChangingConfigurations(typedValue.changingConfigurations);
                    b(context, e2, i3);
                }
            } catch (Exception e3) {
                Log.e("ResourceManagerInternal", "Exception while inflating drawable", e3);
            }
        }
        if (i3 == null) {
            this.f282c.a(i2, "appcompat_skip_skip");
        }
        return i3;
    }

    private Drawable v(Context context, int i2, boolean z, Drawable drawable) {
        ColorStateList m = m(context, i2);
        if (m == null) {
            e eVar = this.f286g;
            if ((eVar == null || !eVar.e(context, i2, drawable)) && !x(context, i2, drawable) && z) {
                return null;
            }
            return drawable;
        }
        if (e0.a(drawable)) {
            drawable = drawable.mutate();
        }
        Drawable p = androidx.core.graphics.drawable.a.p(drawable);
        androidx.core.graphics.drawable.a.n(p, m);
        PorterDuff.Mode o = o(i2);
        if (o == null) {
            return p;
        }
        androidx.core.graphics.drawable.a.o(p, o);
        return p;
    }

    static void w(Drawable drawable, u0 u0Var, int[] iArr) {
        if (e0.a(drawable) && drawable.mutate() != drawable) {
            Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
            return;
        }
        boolean z = u0Var.f324d;
        if (z || u0Var.f323c) {
            drawable.setColorFilter(g(z ? u0Var.f321a : null, u0Var.f323c ? u0Var.f322b : f277h, iArr));
        } else {
            drawable.clearColorFilter();
        }
        if (Build.VERSION.SDK_INT <= 23) {
            drawable.invalidateSelf();
        }
    }

    public synchronized Drawable j(Context context, int i2) {
        return k(context, i2, false);
    }

    synchronized Drawable k(Context context, int i2, boolean z) {
        Drawable r;
        d(context);
        r = r(context, i2);
        if (r == null) {
            r = f(context, i2);
        }
        if (r == null) {
            r = b.g.e.a.f(context, i2);
        }
        if (r != null) {
            r = v(context, i2, z, r);
        }
        if (r != null) {
            e0.b(r);
        }
        return r;
    }

    synchronized ColorStateList m(Context context, int i2) {
        ColorStateList n;
        n = n(context, i2);
        if (n == null) {
            e eVar = this.f286g;
            n = eVar == null ? null : eVar.d(context, i2);
            if (n != null) {
                c(context, i2, n);
            }
        }
        return n;
    }

    PorterDuff.Mode o(int i2) {
        e eVar = this.f286g;
        if (eVar == null) {
            return null;
        }
        return eVar.b(i2);
    }

    public synchronized void s(Context context) {
        b.e.d<WeakReference<Drawable.ConstantState>> dVar = this.f283d.get(context);
        if (dVar != null) {
            dVar.c();
        }
    }

    synchronized Drawable t(Context context, b1 b1Var, int i2) {
        Drawable r = r(context, i2);
        if (r == null) {
            r = b1Var.c(i2);
        }
        if (r == null) {
            return null;
        }
        return v(context, i2, false, r);
    }

    public synchronized void u(e eVar) {
        this.f286g = eVar;
    }

    boolean x(Context context, int i2, Drawable drawable) {
        e eVar = this.f286g;
        return eVar != null && eVar.a(context, i2, drawable);
    }
}
