package androidx.appcompat.widget;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.appcompat.view.menu.m;
import b.g.l.z;

/* loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements c0, b.g.l.m, b.g.l.k, b.g.l.l {
    static final int[] S = {b.a.a.f707b, R.attr.windowContentOverlay};
    private final Rect A;
    private final Rect B;
    private final Rect C;
    private final Rect D;
    private final Rect E;
    private final Rect F;
    private final Rect G;
    private b.g.l.z H;
    private b.g.l.z I;
    private b.g.l.z J;
    private b.g.l.z K;
    private d L;
    private OverScroller M;
    ViewPropertyAnimator N;
    final AnimatorListenerAdapter O;
    private final Runnable P;
    private final Runnable Q;
    private final b.g.l.n R;
    private int n;
    private int o;
    private ContentFrameLayout p;
    ActionBarContainer q;
    private d0 r;
    private Drawable s;
    private boolean t;
    private boolean u;
    private boolean v;
    private boolean w;
    boolean x;
    private int y;
    private int z;

    class a extends AnimatorListenerAdapter {
        a() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.N = null;
            actionBarOverlayLayout.x = false;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.N = null;
            actionBarOverlayLayout.x = false;
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.o();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.N = actionBarOverlayLayout.q.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.O);
        }
    }

    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.o();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.N = actionBarOverlayLayout.q.animate().translationY(-ActionBarOverlayLayout.this.q.getHeight()).setListener(ActionBarOverlayLayout.this.O);
        }
    }

    public interface d {
        void a();

        void b();

        void c(int i2);

        void d();

        void e(boolean z);

        void f();
    }

    public static class e extends ViewGroup.MarginLayoutParams {
        public e(int i2, int i3) {
            super(i2, i3);
        }

        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.o = 0;
        this.A = new Rect();
        this.B = new Rect();
        this.C = new Rect();
        this.D = new Rect();
        this.E = new Rect();
        this.F = new Rect();
        this.G = new Rect();
        b.g.l.z zVar = b.g.l.z.f1273b;
        this.H = zVar;
        this.I = zVar;
        this.J = zVar;
        this.K = zVar;
        this.O = new a();
        this.P = new b();
        this.Q = new c();
        p(context);
        this.R = new b.g.l.n(this);
    }

    private void a() {
        o();
        this.Q.run();
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0021  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x002c  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0016  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private boolean e(android.view.View r3, android.graphics.Rect r4, boolean r5, boolean r6, boolean r7, boolean r8) {
        /*
            r2 = this;
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.ActionBarOverlayLayout$e r3 = (androidx.appcompat.widget.ActionBarOverlayLayout.e) r3
            r0 = 1
            if (r5 == 0) goto L13
            int r5 = r3.leftMargin
            int r1 = r4.left
            if (r5 == r1) goto L13
            r3.leftMargin = r1
            r5 = 1
            goto L14
        L13:
            r5 = 0
        L14:
            if (r6 == 0) goto L1f
            int r6 = r3.topMargin
            int r1 = r4.top
            if (r6 == r1) goto L1f
            r3.topMargin = r1
            r5 = 1
        L1f:
            if (r8 == 0) goto L2a
            int r6 = r3.rightMargin
            int r8 = r4.right
            if (r6 == r8) goto L2a
            r3.rightMargin = r8
            r5 = 1
        L2a:
            if (r7 == 0) goto L35
            int r6 = r3.bottomMargin
            int r4 = r4.bottom
            if (r6 == r4) goto L35
            r3.bottomMargin = r4
            goto L36
        L35:
            r0 = r5
        L36:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.e(android.view.View, android.graphics.Rect, boolean, boolean, boolean, boolean):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    private d0 n(View view) {
        if (view instanceof d0) {
            return (d0) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        throw new IllegalStateException("Can't make a decor toolbar out of " + view.getClass().getSimpleName());
    }

    private void p(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(S);
        this.n = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.s = drawable;
        setWillNotDraw(drawable == null);
        obtainStyledAttributes.recycle();
        this.t = context.getApplicationInfo().targetSdkVersion < 19;
        this.M = new OverScroller(context);
    }

    private void r() {
        o();
        postDelayed(this.Q, 600L);
    }

    private void s() {
        o();
        postDelayed(this.P, 600L);
    }

    private void u() {
        o();
        this.P.run();
    }

    private boolean v(float f2) {
        this.M.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        return this.M.getFinalY() > this.q.getHeight();
    }

    @Override // androidx.appcompat.widget.c0
    public void b(Menu menu, m.a aVar) {
        t();
        this.r.b(menu, aVar);
    }

    @Override // androidx.appcompat.widget.c0
    public boolean c() {
        t();
        return this.r.c();
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e;
    }

    @Override // androidx.appcompat.widget.c0
    public void d() {
        t();
        this.r.d();
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.s == null || this.t) {
            return;
        }
        int bottom = this.q.getVisibility() == 0 ? (int) (this.q.getBottom() + this.q.getTranslationY() + 0.5f) : 0;
        this.s.setBounds(0, bottom, getWidth(), this.s.getIntrinsicHeight() + bottom);
        this.s.draw(canvas);
    }

    @Override // androidx.appcompat.widget.c0
    public boolean f() {
        t();
        return this.r.f();
    }

    @Override // android.view.View
    protected boolean fitSystemWindows(Rect rect) {
        if (Build.VERSION.SDK_INT >= 21) {
            return super.fitSystemWindows(rect);
        }
        t();
        boolean e2 = e(this.q, rect, true, true, false, true);
        this.D.set(rect);
        c1.a(this, this.D, this.A);
        if (!this.E.equals(this.D)) {
            this.E.set(this.D);
            e2 = true;
        }
        if (!this.B.equals(this.A)) {
            this.B.set(this.A);
            e2 = true;
        }
        if (e2) {
            requestLayout();
        }
        return true;
    }

    @Override // androidx.appcompat.widget.c0
    public boolean g() {
        t();
        return this.r.g();
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new e(layoutParams);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.q;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.R.a();
    }

    public CharSequence getTitle() {
        t();
        return this.r.getTitle();
    }

    @Override // androidx.appcompat.widget.c0
    public boolean h() {
        t();
        return this.r.h();
    }

    @Override // androidx.appcompat.widget.c0
    public boolean i() {
        t();
        return this.r.i();
    }

    @Override // androidx.appcompat.widget.c0
    public void j(int i2) {
        t();
        if (i2 == 2) {
            this.r.x();
        } else if (i2 == 5) {
            this.r.y();
        } else {
            if (i2 != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    @Override // androidx.appcompat.widget.c0
    public void k() {
        t();
        this.r.j();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* renamed from: l, reason: merged with bridge method [inline-methods] */
    public e generateDefaultLayoutParams() {
        return new e(-1, -1);
    }

    @Override // android.view.ViewGroup
    /* renamed from: m, reason: merged with bridge method [inline-methods] */
    public e generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    void o() {
        removeCallbacks(this.P);
        removeCallbacks(this.Q);
        ViewPropertyAnimator viewPropertyAnimator = this.N;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    @Override // android.view.View
    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        t();
        b.g.l.z t = b.g.l.z.t(windowInsets);
        boolean e2 = e(this.q, new Rect(t.i(), t.k(), t.j(), t.h()), true, true, false, true);
        b.g.l.r.d(this, t, this.A);
        Rect rect = this.A;
        b.g.l.z l = t.l(rect.left, rect.top, rect.right, rect.bottom);
        this.H = l;
        boolean z = true;
        if (!this.I.equals(l)) {
            this.I = this.H;
            e2 = true;
        }
        if (this.B.equals(this.A)) {
            z = e2;
        } else {
            this.B.set(this.A);
        }
        if (z) {
            requestLayout();
        }
        return t.a().c().b().s();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        p(getContext());
        b.g.l.r.I(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        o();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z, int i2, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin + paddingLeft;
                int i8 = ((ViewGroup.MarginLayoutParams) eVar).topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        int measuredHeight;
        b.g.l.z a2;
        t();
        measureChildWithMargins(this.q, i2, 0, i3, 0);
        e eVar = (e) this.q.getLayoutParams();
        int max = Math.max(0, this.q.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin + ((ViewGroup.MarginLayoutParams) eVar).rightMargin);
        int max2 = Math.max(0, this.q.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar).topMargin + ((ViewGroup.MarginLayoutParams) eVar).bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.q.getMeasuredState());
        boolean z = (b.g.l.r.u(this) & 256) != 0;
        if (z) {
            measuredHeight = this.n;
            if (this.v && this.q.getTabContainer() != null) {
                measuredHeight += this.n;
            }
        } else {
            measuredHeight = this.q.getVisibility() != 8 ? this.q.getMeasuredHeight() : 0;
        }
        this.C.set(this.A);
        int i4 = Build.VERSION.SDK_INT;
        if (i4 >= 21) {
            this.J = this.H;
        } else {
            this.F.set(this.D);
        }
        if (!this.u && !z) {
            Rect rect = this.C;
            rect.top += measuredHeight;
            rect.bottom += 0;
            if (i4 >= 21) {
                a2 = this.J.l(0, measuredHeight, 0, 0);
                this.J = a2;
            }
        } else if (i4 >= 21) {
            b.g.f.b b2 = b.g.f.b.b(this.J.i(), this.J.k() + measuredHeight, this.J.j(), this.J.h() + 0);
            z.b bVar = new z.b(this.J);
            bVar.c(b2);
            a2 = bVar.a();
            this.J = a2;
        } else {
            Rect rect2 = this.F;
            rect2.top += measuredHeight;
            rect2.bottom += 0;
        }
        e(this.p, this.C, true, true, true, true);
        if (i4 >= 21 && !this.K.equals(this.J)) {
            b.g.l.z zVar = this.J;
            this.K = zVar;
            b.g.l.r.e(this.p, zVar);
        } else if (i4 < 21 && !this.G.equals(this.F)) {
            this.G.set(this.F);
            this.p.a(this.F);
        }
        measureChildWithMargins(this.p, i2, 0, i3, 0);
        e eVar2 = (e) this.p.getLayoutParams();
        int max3 = Math.max(max, this.p.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar2).leftMargin + ((ViewGroup.MarginLayoutParams) eVar2).rightMargin);
        int max4 = Math.max(max2, this.p.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar2).topMargin + ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.p.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(max3 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i2, combineMeasuredStates2), View.resolveSizeAndState(Math.max(max4 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i3, combineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent, b.g.l.m
    public boolean onNestedFling(View view, float f2, float f3, boolean z) {
        if (!this.w || !z) {
            return false;
        }
        if (v(f3)) {
            a();
        } else {
            u();
        }
        this.x = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent, b.g.l.m
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent, b.g.l.m
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
    }

    @Override // b.g.l.k
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr, int i4) {
        if (i4 == 0) {
            onNestedPreScroll(view, i2, i3, iArr);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent, b.g.l.m
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        int i6 = this.y + i3;
        this.y = i6;
        setActionBarHideOffset(i6);
    }

    @Override // b.g.l.k
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(view, i2, i3, i4, i5);
        }
    }

    @Override // b.g.l.l
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        onNestedScroll(view, i2, i3, i4, i5, i6);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent, b.g.l.m
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        this.R.b(view, view2, i2);
        this.y = getActionBarHideOffset();
        o();
        d dVar = this.L;
        if (dVar != null) {
            dVar.b();
        }
    }

    @Override // b.g.l.k
    public void onNestedScrollAccepted(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent, b.g.l.m
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        if ((i2 & 2) == 0 || this.q.getVisibility() != 0) {
            return false;
        }
        return this.w;
    }

    @Override // b.g.l.k
    public boolean onStartNestedScroll(View view, View view2, int i2, int i3) {
        return i3 == 0 && onStartNestedScroll(view, view2, i2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent, b.g.l.m
    public void onStopNestedScroll(View view) {
        if (this.w && !this.x) {
            if (this.y <= this.q.getHeight()) {
                s();
            } else {
                r();
            }
        }
        d dVar = this.L;
        if (dVar != null) {
            dVar.d();
        }
    }

    @Override // b.g.l.k
    public void onStopNestedScroll(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.View
    public void onWindowSystemUiVisibilityChanged(int i2) {
        if (Build.VERSION.SDK_INT >= 16) {
            super.onWindowSystemUiVisibilityChanged(i2);
        }
        t();
        int i3 = this.z ^ i2;
        this.z = i2;
        boolean z = (i2 & 4) == 0;
        boolean z2 = (i2 & 256) != 0;
        d dVar = this.L;
        if (dVar != null) {
            dVar.e(!z2);
            if (z || !z2) {
                this.L.a();
            } else {
                this.L.f();
            }
        }
        if ((i3 & 256) == 0 || this.L == null) {
            return;
        }
        b.g.l.r.I(this);
    }

    @Override // android.view.View
    protected void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
        this.o = i2;
        d dVar = this.L;
        if (dVar != null) {
            dVar.c(i2);
        }
    }

    public boolean q() {
        return this.u;
    }

    public void setActionBarHideOffset(int i2) {
        o();
        this.q.setTranslationY(-Math.max(0, Math.min(i2, this.q.getHeight())));
    }

    public void setActionBarVisibilityCallback(d dVar) {
        this.L = dVar;
        if (getWindowToken() != null) {
            this.L.c(this.o);
            int i2 = this.z;
            if (i2 != 0) {
                onWindowSystemUiVisibilityChanged(i2);
                b.g.l.r.I(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z) {
        this.v = z;
    }

    public void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.w) {
            this.w = z;
            if (z) {
                return;
            }
            o();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i2) {
        t();
        this.r.setIcon(i2);
    }

    public void setIcon(Drawable drawable) {
        t();
        this.r.setIcon(drawable);
    }

    public void setLogo(int i2) {
        t();
        this.r.u(i2);
    }

    public void setOverlayMode(boolean z) {
        this.u = z;
        this.t = z && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z) {
    }

    public void setUiOptions(int i2) {
    }

    @Override // androidx.appcompat.widget.c0
    public void setWindowCallback(Window.Callback callback) {
        t();
        this.r.setWindowCallback(callback);
    }

    @Override // androidx.appcompat.widget.c0
    public void setWindowTitle(CharSequence charSequence) {
        t();
        this.r.setWindowTitle(charSequence);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    void t() {
        if (this.p == null) {
            this.p = (ContentFrameLayout) findViewById(b.a.f.f749b);
            this.q = (ActionBarContainer) findViewById(b.a.f.f750c);
            this.r = n(findViewById(b.a.f.f748a));
        }
    }
}
