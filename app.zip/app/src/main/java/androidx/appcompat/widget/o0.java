package androidx.appcompat.widget;

/* loaded from: classes.dex */
class o0 {

    /* renamed from: a, reason: collision with root package name */
    private int f292a = 0;

    /* renamed from: b, reason: collision with root package name */
    private int f293b = 0;

    /* renamed from: c, reason: collision with root package name */
    private int f294c = Integer.MIN_VALUE;

    /* renamed from: d, reason: collision with root package name */
    private int f295d = Integer.MIN_VALUE;

    /* renamed from: e, reason: collision with root package name */
    private int f296e = 0;

    /* renamed from: f, reason: collision with root package name */
    private int f297f = 0;

    /* renamed from: g, reason: collision with root package name */
    private boolean f298g = false;

    /* renamed from: h, reason: collision with root package name */
    private boolean f299h = false;

    o0() {
    }

    public int a() {
        return this.f298g ? this.f292a : this.f293b;
    }

    public int b() {
        return this.f292a;
    }

    public int c() {
        return this.f293b;
    }

    public int d() {
        return this.f298g ? this.f293b : this.f292a;
    }

    public void e(int i2, int i3) {
        this.f299h = false;
        if (i2 != Integer.MIN_VALUE) {
            this.f296e = i2;
            this.f292a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.f297f = i3;
            this.f293b = i3;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x001a, code lost:
    
        if (r2 != Integer.MIN_VALUE) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0028, code lost:
    
        if (r2 != Integer.MIN_VALUE) goto L25;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void f(boolean r2) {
        /*
            r1 = this;
            boolean r0 = r1.f298g
            if (r2 != r0) goto L5
            return
        L5:
            r1.f298g = r2
            boolean r0 = r1.f299h
            if (r0 == 0) goto L2b
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r2 == 0) goto L1d
            int r2 = r1.f295d
            if (r2 == r0) goto L14
            goto L16
        L14:
            int r2 = r1.f296e
        L16:
            r1.f292a = r2
            int r2 = r1.f294c
            if (r2 == r0) goto L2f
            goto L31
        L1d:
            int r2 = r1.f294c
            if (r2 == r0) goto L22
            goto L24
        L22:
            int r2 = r1.f296e
        L24:
            r1.f292a = r2
            int r2 = r1.f295d
            if (r2 == r0) goto L2f
            goto L31
        L2b:
            int r2 = r1.f296e
            r1.f292a = r2
        L2f:
            int r2 = r1.f297f
        L31:
            r1.f293b = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.o0.f(boolean):void");
    }

    public void g(int i2, int i3) {
        this.f294c = i2;
        this.f295d = i3;
        this.f299h = true;
        if (this.f298g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f292a = i3;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.f293b = i2;
                return;
            }
            return;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f292a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.f293b = i3;
        }
    }
}
