package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import androidx.appcompat.widget.m0;

/* loaded from: classes.dex */
public final class j {

    /* renamed from: b, reason: collision with root package name */
    private static final PorterDuff.Mode f266b = PorterDuff.Mode.SRC_IN;

    /* renamed from: c, reason: collision with root package name */
    private static j f267c;

    /* renamed from: a, reason: collision with root package name */
    private m0 f268a;

    class a implements m0.e {

        /* renamed from: a, reason: collision with root package name */
        private final int[] f269a = {b.a.e.S, b.a.e.Q, b.a.e.f737a};

        /* renamed from: b, reason: collision with root package name */
        private final int[] f270b = {b.a.e.o, b.a.e.B, b.a.e.t, b.a.e.p, b.a.e.q, b.a.e.s, b.a.e.r};

        /* renamed from: c, reason: collision with root package name */
        private final int[] f271c = {b.a.e.P, b.a.e.R, b.a.e.f747k, b.a.e.I, b.a.e.J, b.a.e.L, b.a.e.N, b.a.e.K, b.a.e.M, b.a.e.O};

        /* renamed from: d, reason: collision with root package name */
        private final int[] f272d = {b.a.e.w, b.a.e.f745i, b.a.e.v};

        /* renamed from: e, reason: collision with root package name */
        private final int[] f273e = {b.a.e.H, b.a.e.T};

        /* renamed from: f, reason: collision with root package name */
        private final int[] f274f = {b.a.e.f739c, b.a.e.f743g, b.a.e.f740d, b.a.e.f744h};

        a() {
        }

        private boolean f(int[] iArr, int i2) {
            for (int i3 : iArr) {
                if (i3 == i2) {
                    return true;
                }
            }
            return false;
        }

        private ColorStateList g(Context context) {
            return h(context, 0);
        }

        private ColorStateList h(Context context, int i2) {
            int c2 = r0.c(context, b.a.a.v);
            return new ColorStateList(new int[][]{r0.f311b, r0.f313d, r0.f312c, r0.f315f}, new int[]{r0.b(context, b.a.a.t), b.g.f.a.b(c2, i2), b.g.f.a.b(c2, i2), i2});
        }

        private ColorStateList i(Context context) {
            return h(context, r0.c(context, b.a.a.s));
        }

        private ColorStateList j(Context context) {
            return h(context, r0.c(context, b.a.a.t));
        }

        private ColorStateList k(Context context) {
            int[][] iArr = new int[3][];
            int[] iArr2 = new int[3];
            int i2 = b.a.a.x;
            ColorStateList e2 = r0.e(context, i2);
            if (e2 == null || !e2.isStateful()) {
                iArr[0] = r0.f311b;
                iArr2[0] = r0.b(context, i2);
                iArr[1] = r0.f314e;
                iArr2[1] = r0.c(context, b.a.a.u);
                iArr[2] = r0.f315f;
                iArr2[2] = r0.c(context, i2);
            } else {
                iArr[0] = r0.f311b;
                iArr2[0] = e2.getColorForState(iArr[0], 0);
                iArr[1] = r0.f314e;
                iArr2[1] = r0.c(context, b.a.a.u);
                iArr[2] = r0.f315f;
                iArr2[2] = e2.getDefaultColor();
            }
            return new ColorStateList(iArr, iArr2);
        }

        private void l(Drawable drawable, int i2, PorterDuff.Mode mode) {
            if (e0.a(drawable)) {
                drawable = drawable.mutate();
            }
            if (mode == null) {
                mode = j.f266b;
            }
            drawable.setColorFilter(j.e(i2, mode));
        }

        /* JADX WARN: Removed duplicated region for block: B:15:0x0061 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:7:0x0046  */
        @Override // androidx.appcompat.widget.m0.e
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public boolean a(android.content.Context r7, int r8, android.graphics.drawable.Drawable r9) {
            /*
                r6 = this;
                android.graphics.PorterDuff$Mode r0 = androidx.appcompat.widget.j.a()
                int[] r1 = r6.f269a
                boolean r1 = r6.f(r1, r8)
                r2 = 16842801(0x1010031, float:2.3693695E-38)
                r3 = -1
                r4 = 0
                r5 = 1
                if (r1 == 0) goto L17
                int r2 = b.a.a.w
            L14:
                r8 = -1
            L15:
                r1 = 1
                goto L44
            L17:
                int[] r1 = r6.f271c
                boolean r1 = r6.f(r1, r8)
                if (r1 == 0) goto L22
                int r2 = b.a.a.u
                goto L14
            L22:
                int[] r1 = r6.f272d
                boolean r1 = r6.f(r1, r8)
                if (r1 == 0) goto L2d
                android.graphics.PorterDuff$Mode r0 = android.graphics.PorterDuff.Mode.MULTIPLY
                goto L14
            L2d:
                int r1 = b.a.e.u
                if (r8 != r1) goto L3c
                r2 = 16842800(0x1010030, float:2.3693693E-38)
                r8 = 1109603123(0x42233333, float:40.8)
                int r8 = java.lang.Math.round(r8)
                goto L15
            L3c:
                int r1 = b.a.e.l
                if (r8 != r1) goto L41
                goto L14
            L41:
                r8 = -1
                r1 = 0
                r2 = 0
            L44:
                if (r1 == 0) goto L61
                boolean r1 = androidx.appcompat.widget.e0.a(r9)
                if (r1 == 0) goto L50
                android.graphics.drawable.Drawable r9 = r9.mutate()
            L50:
                int r7 = androidx.appcompat.widget.r0.c(r7, r2)
                android.graphics.PorterDuffColorFilter r7 = androidx.appcompat.widget.j.e(r7, r0)
                r9.setColorFilter(r7)
                if (r8 == r3) goto L60
                r9.setAlpha(r8)
            L60:
                return r5
            L61:
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.j.a.a(android.content.Context, int, android.graphics.drawable.Drawable):boolean");
        }

        @Override // androidx.appcompat.widget.m0.e
        public PorterDuff.Mode b(int i2) {
            if (i2 == b.a.e.F) {
                return PorterDuff.Mode.MULTIPLY;
            }
            return null;
        }

        @Override // androidx.appcompat.widget.m0.e
        public Drawable c(m0 m0Var, Context context, int i2) {
            if (i2 == b.a.e.f746j) {
                return new LayerDrawable(new Drawable[]{m0Var.j(context, b.a.e.f745i), m0Var.j(context, b.a.e.f747k)});
            }
            return null;
        }

        @Override // androidx.appcompat.widget.m0.e
        public ColorStateList d(Context context, int i2) {
            if (i2 == b.a.e.m) {
                return b.a.k.a.a.c(context, b.a.c.f722e);
            }
            if (i2 == b.a.e.G) {
                return b.a.k.a.a.c(context, b.a.c.f725h);
            }
            if (i2 == b.a.e.F) {
                return k(context);
            }
            if (i2 == b.a.e.f742f) {
                return j(context);
            }
            if (i2 == b.a.e.f738b) {
                return g(context);
            }
            if (i2 == b.a.e.f741e) {
                return i(context);
            }
            if (i2 == b.a.e.D || i2 == b.a.e.E) {
                return b.a.k.a.a.c(context, b.a.c.f724g);
            }
            if (f(this.f270b, i2)) {
                return r0.e(context, b.a.a.w);
            }
            if (f(this.f273e, i2)) {
                return b.a.k.a.a.c(context, b.a.c.f721d);
            }
            if (f(this.f274f, i2)) {
                return b.a.k.a.a.c(context, b.a.c.f720c);
            }
            if (i2 == b.a.e.A) {
                return b.a.k.a.a.c(context, b.a.c.f723f);
            }
            return null;
        }

        @Override // androidx.appcompat.widget.m0.e
        public boolean e(Context context, int i2, Drawable drawable) {
            Drawable findDrawableByLayerId;
            int c2;
            if (i2 == b.a.e.C) {
                LayerDrawable layerDrawable = (LayerDrawable) drawable;
                Drawable findDrawableByLayerId2 = layerDrawable.findDrawableByLayerId(R.id.background);
                int i3 = b.a.a.w;
                l(findDrawableByLayerId2, r0.c(context, i3), j.f266b);
                l(layerDrawable.findDrawableByLayerId(R.id.secondaryProgress), r0.c(context, i3), j.f266b);
                findDrawableByLayerId = layerDrawable.findDrawableByLayerId(R.id.progress);
                c2 = r0.c(context, b.a.a.u);
            } else {
                if (i2 != b.a.e.y && i2 != b.a.e.x && i2 != b.a.e.z) {
                    return false;
                }
                LayerDrawable layerDrawable2 = (LayerDrawable) drawable;
                l(layerDrawable2.findDrawableByLayerId(R.id.background), r0.b(context, b.a.a.w), j.f266b);
                Drawable findDrawableByLayerId3 = layerDrawable2.findDrawableByLayerId(R.id.secondaryProgress);
                int i4 = b.a.a.u;
                l(findDrawableByLayerId3, r0.c(context, i4), j.f266b);
                findDrawableByLayerId = layerDrawable2.findDrawableByLayerId(R.id.progress);
                c2 = r0.c(context, i4);
            }
            l(findDrawableByLayerId, c2, j.f266b);
            return true;
        }
    }

    public static synchronized j b() {
        j jVar;
        synchronized (j.class) {
            if (f267c == null) {
                h();
            }
            jVar = f267c;
        }
        return jVar;
    }

    public static synchronized PorterDuffColorFilter e(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter l;
        synchronized (j.class) {
            l = m0.l(i2, mode);
        }
        return l;
    }

    public static synchronized void h() {
        synchronized (j.class) {
            if (f267c == null) {
                j jVar = new j();
                f267c = jVar;
                jVar.f268a = m0.h();
                f267c.f268a.u(new a());
            }
        }
    }

    static void i(Drawable drawable, u0 u0Var, int[] iArr) {
        m0.w(drawable, u0Var, iArr);
    }

    public synchronized Drawable c(Context context, int i2) {
        return this.f268a.j(context, i2);
    }

    synchronized Drawable d(Context context, int i2, boolean z) {
        return this.f268a.k(context, i2, z);
    }

    synchronized ColorStateList f(Context context, int i2) {
        return this.f268a.m(context, i2);
    }

    public synchronized void g(Context context) {
        this.f268a.s(context);
    }
}
