package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import b.a.n.b;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: androidx.appcompat.app.a$a, reason: collision with other inner class name */
    public static class C0010a extends ViewGroup.MarginLayoutParams {

        /* renamed from: a, reason: collision with root package name */
        public int f61a;

        public C0010a(int i2, int i3) {
            super(i2, i3);
            this.f61a = 0;
            this.f61a = 8388627;
        }

        public C0010a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f61a = 0;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.a.j.t);
            this.f61a = obtainStyledAttributes.getInt(b.a.j.u, 0);
            obtainStyledAttributes.recycle();
        }

        public C0010a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f61a = 0;
        }

        public C0010a(C0010a c0010a) {
            super((ViewGroup.MarginLayoutParams) c0010a);
            this.f61a = 0;
            this.f61a = c0010a.f61a;
        }
    }

    public interface b {
        void a(boolean z);
    }

    @Deprecated
    public static abstract class c {
        public abstract CharSequence a();

        public abstract View b();

        public abstract Drawable c();

        public abstract CharSequence d();

        public abstract void e();
    }

    public b.a.n.b A(b.a aVar) {
        return null;
    }

    public boolean g() {
        return false;
    }

    public abstract boolean h();

    public abstract void i(boolean z);

    public abstract int j();

    public abstract Context k();

    public abstract void l();

    public boolean m() {
        return false;
    }

    public abstract boolean n();

    public void o(Configuration configuration) {
    }

    void p() {
    }

    public abstract boolean q(int i2, KeyEvent keyEvent);

    public boolean r(KeyEvent keyEvent) {
        return false;
    }

    public boolean s() {
        return false;
    }

    public abstract void t(Drawable drawable);

    public abstract void u(boolean z);

    public abstract void v(boolean z);

    public abstract void w(boolean z);

    public abstract void x(CharSequence charSequence);

    public abstract void y(CharSequence charSequence);

    public abstract void z();
}
