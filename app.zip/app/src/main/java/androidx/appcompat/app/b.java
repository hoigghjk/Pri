package androidx.appcompat.app;

/* loaded from: classes.dex */
public interface b {
}
