package androidx.appcompat.app;

import b.a.n.b;

/* loaded from: classes.dex */
public interface e {
    void onSupportActionModeFinished(b.a.n.b bVar);

    void onSupportActionModeStarted(b.a.n.b bVar);

    b.a.n.b onWindowStartingSupportActionMode(b.a aVar);
}
