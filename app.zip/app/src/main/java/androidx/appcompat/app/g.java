package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.b1;
import androidx.appcompat.widget.c0;
import androidx.appcompat.widget.c1;
import androidx.appcompat.widget.g0;
import androidx.appcompat.widget.w0;
import androidx.lifecycle.d;
import b.a.n.b;
import b.a.n.f;
import b.g.e.e.f;
import b.g.l.e;
import b.g.l.v;
import b.g.l.x;
import b.g.l.z;
import com.pichillilorenzo.flutter_inappwebview.R;
import java.lang.Thread;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

/* loaded from: classes.dex */
class g extends androidx.appcompat.app.f implements g.a, LayoutInflater.Factory2 {
    private static final b.e.g<String, Integer> n0 = new b.e.g<>();
    private static final boolean o0;
    private static final int[] p0;
    private static final boolean q0;
    private static final boolean r0;
    private static boolean s0;
    private u A;
    b.a.n.b B;
    ActionBarContextView C;
    PopupWindow D;
    Runnable E;
    v F;
    private boolean G;
    private boolean H;
    ViewGroup I;
    private TextView J;
    private View K;
    private boolean L;
    private boolean M;
    boolean N;
    boolean O;
    boolean P;
    boolean Q;
    boolean R;
    private boolean S;
    private t[] T;
    private t U;
    private boolean V;
    private boolean W;
    private boolean X;
    private boolean Y;
    boolean Z;
    private int a0;
    private int b0;
    private boolean c0;
    private boolean d0;
    private m e0;
    private m f0;
    boolean g0;
    int h0;
    private final Runnable i0;
    private boolean j0;
    private Rect k0;
    private Rect l0;
    private androidx.appcompat.app.i m0;
    final Object q;
    final Context r;
    Window s;
    private k t;
    final androidx.appcompat.app.e u;
    androidx.appcompat.app.a v;
    MenuInflater w;
    private CharSequence x;
    private c0 y;
    private i z;

    class a implements Thread.UncaughtExceptionHandler {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ Thread.UncaughtExceptionHandler f64a;

        a(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
            this.f64a = uncaughtExceptionHandler;
        }

        private boolean a(Throwable th) {
            String message;
            if (!(th instanceof Resources.NotFoundException) || (message = th.getMessage()) == null) {
                return false;
            }
            return message.contains("drawable") || message.contains("Drawable");
        }

        @Override // java.lang.Thread.UncaughtExceptionHandler
        public void uncaughtException(Thread thread, Throwable th) {
            if (!a(th)) {
                this.f64a.uncaughtException(thread, th);
                return;
            }
            Resources.NotFoundException notFoundException = new Resources.NotFoundException(th.getMessage() + ". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.");
            notFoundException.initCause(th.getCause());
            notFoundException.setStackTrace(th.getStackTrace());
            this.f64a.uncaughtException(thread, notFoundException);
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            g gVar = g.this;
            if ((gVar.h0 & 1) != 0) {
                gVar.X(0);
            }
            g gVar2 = g.this;
            if ((gVar2.h0 & 4096) != 0) {
                gVar2.X(R.styleable.AppCompatTheme_textColorAlertDialogListItem);
            }
            g gVar3 = g.this;
            gVar3.g0 = false;
            gVar3.h0 = 0;
        }
    }

    class c implements b.g.l.o {
        c() {
        }

        @Override // b.g.l.o
        public z a(View view, z zVar) {
            int k2 = zVar.k();
            int N0 = g.this.N0(zVar, null);
            if (k2 != N0) {
                zVar = zVar.n(zVar.i(), N0, zVar.j(), zVar.h());
            }
            return b.g.l.r.D(view, zVar);
        }
    }

    class d implements g0.a {
        d() {
        }

        @Override // androidx.appcompat.widget.g0.a
        public void a(Rect rect) {
            rect.top = g.this.N0(null, rect);
        }
    }

    class e implements ContentFrameLayout.a {
        e() {
        }

        @Override // androidx.appcompat.widget.ContentFrameLayout.a
        public void a() {
        }

        @Override // androidx.appcompat.widget.ContentFrameLayout.a
        public void onDetachedFromWindow() {
            g.this.V();
        }
    }

    class f implements Runnable {

        class a extends x {
            a() {
            }

            @Override // b.g.l.w
            public void b(View view) {
                g.this.C.setAlpha(1.0f);
                g.this.F.f(null);
                g.this.F = null;
            }

            @Override // b.g.l.x, b.g.l.w
            public void c(View view) {
                g.this.C.setVisibility(0);
            }
        }

        f() {
        }

        @Override // java.lang.Runnable
        public void run() {
            g gVar = g.this;
            gVar.D.showAtLocation(gVar.C, 55, 0, 0);
            g.this.Y();
            if (!g.this.G0()) {
                g.this.C.setAlpha(1.0f);
                g.this.C.setVisibility(0);
                return;
            }
            g.this.C.setAlpha(0.0f);
            g gVar2 = g.this;
            v b2 = b.g.l.r.b(gVar2.C);
            b2.a(1.0f);
            gVar2.F = b2;
            g.this.F.f(new a());
        }
    }

    /* renamed from: androidx.appcompat.app.g$g, reason: collision with other inner class name */
    class C0011g extends x {
        C0011g() {
        }

        @Override // b.g.l.w
        public void b(View view) {
            g.this.C.setAlpha(1.0f);
            g.this.F.f(null);
            g.this.F = null;
        }

        @Override // b.g.l.x, b.g.l.w
        public void c(View view) {
            g.this.C.setVisibility(0);
            g.this.C.sendAccessibilityEvent(32);
            if (g.this.C.getParent() instanceof View) {
                b.g.l.r.I((View) g.this.C.getParent());
            }
        }
    }

    private class h implements androidx.appcompat.app.b {
        h(g gVar) {
        }
    }

    private final class i implements m.a {
        i() {
        }

        @Override // androidx.appcompat.view.menu.m.a
        public void b(androidx.appcompat.view.menu.g gVar, boolean z) {
            g.this.O(gVar);
        }

        @Override // androidx.appcompat.view.menu.m.a
        public boolean c(androidx.appcompat.view.menu.g gVar) {
            Window.Callback i0 = g.this.i0();
            if (i0 == null) {
                return true;
            }
            i0.onMenuOpened(R.styleable.AppCompatTheme_textColorAlertDialogListItem, gVar);
            return true;
        }
    }

    class j implements b.a {

        /* renamed from: a, reason: collision with root package name */
        private b.a f70a;

        class a extends x {
            a() {
            }

            @Override // b.g.l.w
            public void b(View view) {
                g.this.C.setVisibility(8);
                g gVar = g.this;
                PopupWindow popupWindow = gVar.D;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (gVar.C.getParent() instanceof View) {
                    b.g.l.r.I((View) g.this.C.getParent());
                }
                g.this.C.removeAllViews();
                g.this.F.f(null);
                g gVar2 = g.this;
                gVar2.F = null;
                b.g.l.r.I(gVar2.I);
            }
        }

        public j(b.a aVar) {
            this.f70a = aVar;
        }

        @Override // b.a.n.b.a
        public boolean a(b.a.n.b bVar, Menu menu) {
            b.g.l.r.I(g.this.I);
            return this.f70a.a(bVar, menu);
        }

        @Override // b.a.n.b.a
        public void b(b.a.n.b bVar) {
            this.f70a.b(bVar);
            g gVar = g.this;
            if (gVar.D != null) {
                gVar.s.getDecorView().removeCallbacks(g.this.E);
            }
            g gVar2 = g.this;
            if (gVar2.C != null) {
                gVar2.Y();
                g gVar3 = g.this;
                v b2 = b.g.l.r.b(gVar3.C);
                b2.a(0.0f);
                gVar3.F = b2;
                g.this.F.f(new a());
            }
            g gVar4 = g.this;
            androidx.appcompat.app.e eVar = gVar4.u;
            if (eVar != null) {
                eVar.onSupportActionModeFinished(gVar4.B);
            }
            g gVar5 = g.this;
            gVar5.B = null;
            b.g.l.r.I(gVar5.I);
        }

        @Override // b.a.n.b.a
        public boolean c(b.a.n.b bVar, MenuItem menuItem) {
            return this.f70a.c(bVar, menuItem);
        }

        @Override // b.a.n.b.a
        public boolean d(b.a.n.b bVar, Menu menu) {
            return this.f70a.d(bVar, menu);
        }
    }

    class k extends b.a.n.i {
        k(Window.Callback callback) {
            super(callback);
        }

        final ActionMode b(ActionMode.Callback callback) {
            f.a aVar = new f.a(g.this.r, callback);
            b.a.n.b H = g.this.H(aVar);
            if (H != null) {
                return aVar.e(H);
            }
            return null;
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return g.this.W(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
            return super.dispatchKeyShortcutEvent(keyEvent) || g.this.u0(keyEvent.getKeyCode(), keyEvent);
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public void onContentChanged() {
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public boolean onCreatePanelMenu(int i2, Menu menu) {
            if (i2 != 0 || (menu instanceof androidx.appcompat.view.menu.g)) {
                return super.onCreatePanelMenu(i2, menu);
            }
            return false;
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public boolean onMenuOpened(int i2, Menu menu) {
            super.onMenuOpened(i2, menu);
            g.this.x0(i2);
            return true;
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public void onPanelClosed(int i2, Menu menu) {
            super.onPanelClosed(i2, menu);
            g.this.y0(i2);
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public boolean onPreparePanel(int i2, View view, Menu menu) {
            androidx.appcompat.view.menu.g gVar = menu instanceof androidx.appcompat.view.menu.g ? (androidx.appcompat.view.menu.g) menu : null;
            if (i2 == 0 && gVar == null) {
                return false;
            }
            if (gVar != null) {
                gVar.a0(true);
            }
            boolean onPreparePanel = super.onPreparePanel(i2, view, menu);
            if (gVar != null) {
                gVar.a0(false);
            }
            return onPreparePanel;
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> list, Menu menu, int i2) {
            androidx.appcompat.view.menu.g gVar;
            t g0 = g.this.g0(0, true);
            if (g0 == null || (gVar = g0.f89j) == null) {
                super.onProvideKeyboardShortcuts(list, menu, i2);
            } else {
                super.onProvideKeyboardShortcuts(list, gVar, i2);
            }
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
            if (Build.VERSION.SDK_INT >= 23) {
                return null;
            }
            return g.this.p0() ? b(callback) : super.onWindowStartingActionMode(callback);
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i2) {
            return (g.this.p0() && i2 == 0) ? b(callback) : super.onWindowStartingActionMode(callback, i2);
        }
    }

    private class l extends m {

        /* renamed from: c, reason: collision with root package name */
        private final PowerManager f73c;

        l(Context context) {
            super();
            this.f73c = (PowerManager) context.getApplicationContext().getSystemService("power");
        }

        @Override // androidx.appcompat.app.g.m
        IntentFilter b() {
            if (Build.VERSION.SDK_INT < 21) {
                return null;
            }
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
            return intentFilter;
        }

        @Override // androidx.appcompat.app.g.m
        public int c() {
            return (Build.VERSION.SDK_INT < 21 || !this.f73c.isPowerSaveMode()) ? 1 : 2;
        }

        @Override // androidx.appcompat.app.g.m
        public void d() {
            g.this.I();
        }
    }

    abstract class m {

        /* renamed from: a, reason: collision with root package name */
        private BroadcastReceiver f75a;

        class a extends BroadcastReceiver {
            a() {
            }

            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                m.this.d();
            }
        }

        m() {
        }

        void a() {
            BroadcastReceiver broadcastReceiver = this.f75a;
            if (broadcastReceiver != null) {
                try {
                    g.this.r.unregisterReceiver(broadcastReceiver);
                } catch (IllegalArgumentException unused) {
                }
                this.f75a = null;
            }
        }

        abstract IntentFilter b();

        abstract int c();

        abstract void d();

        void e() {
            a();
            IntentFilter b2 = b();
            if (b2 == null || b2.countActions() == 0) {
                return;
            }
            if (this.f75a == null) {
                this.f75a = new a();
            }
            g.this.r.registerReceiver(this.f75a, b2);
        }
    }

    private class n extends m {

        /* renamed from: c, reason: collision with root package name */
        private final androidx.appcompat.app.m f78c;

        n(androidx.appcompat.app.m mVar) {
            super();
            this.f78c = mVar;
        }

        @Override // androidx.appcompat.app.g.m
        IntentFilter b() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.TIME_SET");
            intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
            intentFilter.addAction("android.intent.action.TIME_TICK");
            return intentFilter;
        }

        @Override // androidx.appcompat.app.g.m
        public int c() {
            return this.f78c.d() ? 2 : 1;
        }

        @Override // androidx.appcompat.app.g.m
        public void d() {
            g.this.I();
        }
    }

    static class o {
        static void a(Configuration configuration, Configuration configuration2, Configuration configuration3) {
            int i2 = configuration.densityDpi;
            int i3 = configuration2.densityDpi;
            if (i2 != i3) {
                configuration3.densityDpi = i3;
            }
        }
    }

    static class p {
        static void a(Configuration configuration, Configuration configuration2, Configuration configuration3) {
            LocaleList locales = configuration.getLocales();
            LocaleList locales2 = configuration2.getLocales();
            if (locales.equals(locales2)) {
                return;
            }
            configuration3.setLocales(locales2);
            configuration3.locale = configuration2.locale;
        }
    }

    static class q {
        static void a(Configuration configuration, Configuration configuration2, Configuration configuration3) {
            int i2 = configuration.colorMode & 3;
            int i3 = configuration2.colorMode;
            if (i2 != (i3 & 3)) {
                configuration3.colorMode |= i3 & 3;
            }
            int i4 = configuration.colorMode & 12;
            int i5 = configuration2.colorMode;
            if (i4 != (i5 & 12)) {
                configuration3.colorMode |= i5 & 12;
            }
        }
    }

    private static class r {
        static void a(ContextThemeWrapper contextThemeWrapper, Configuration configuration) {
            contextThemeWrapper.applyOverrideConfiguration(configuration);
        }
    }

    private class s extends ContentFrameLayout {
        public s(Context context) {
            super(context);
        }

        private boolean c(int i2, int i3) {
            return i2 < -5 || i3 < -5 || i2 > getWidth() + 5 || i3 > getHeight() + 5;
        }

        @Override // android.view.ViewGroup, android.view.View
        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return g.this.W(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        @Override // android.view.ViewGroup
        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (motionEvent.getAction() != 0 || !c((int) motionEvent.getX(), (int) motionEvent.getY())) {
                return super.onInterceptTouchEvent(motionEvent);
            }
            g.this.Q(0);
            return true;
        }

        @Override // android.view.View
        public void setBackgroundResource(int i2) {
            setBackgroundDrawable(b.a.k.a.a.d(getContext(), i2));
        }
    }

    protected static final class t {

        /* renamed from: a, reason: collision with root package name */
        int f80a;

        /* renamed from: b, reason: collision with root package name */
        int f81b;

        /* renamed from: c, reason: collision with root package name */
        int f82c;

        /* renamed from: d, reason: collision with root package name */
        int f83d;

        /* renamed from: e, reason: collision with root package name */
        int f84e;

        /* renamed from: f, reason: collision with root package name */
        int f85f;

        /* renamed from: g, reason: collision with root package name */
        ViewGroup f86g;

        /* renamed from: h, reason: collision with root package name */
        View f87h;

        /* renamed from: i, reason: collision with root package name */
        View f88i;

        /* renamed from: j, reason: collision with root package name */
        androidx.appcompat.view.menu.g f89j;

        /* renamed from: k, reason: collision with root package name */
        androidx.appcompat.view.menu.e f90k;
        Context l;
        boolean m;
        boolean n;
        boolean o;
        public boolean p;
        boolean q = false;
        boolean r;
        Bundle s;

        t(int i2) {
            this.f80a = i2;
        }

        androidx.appcompat.view.menu.n a(m.a aVar) {
            if (this.f89j == null) {
                return null;
            }
            if (this.f90k == null) {
                androidx.appcompat.view.menu.e eVar = new androidx.appcompat.view.menu.e(this.l, b.a.g.f768j);
                this.f90k = eVar;
                eVar.k(aVar);
                this.f89j.b(this.f90k);
            }
            return this.f90k.c(this.f86g);
        }

        public boolean b() {
            if (this.f87h == null) {
                return false;
            }
            return this.f88i != null || this.f90k.a().getCount() > 0;
        }

        void c(androidx.appcompat.view.menu.g gVar) {
            androidx.appcompat.view.menu.e eVar;
            androidx.appcompat.view.menu.g gVar2 = this.f89j;
            if (gVar == gVar2) {
                return;
            }
            if (gVar2 != null) {
                gVar2.O(this.f90k);
            }
            this.f89j = gVar;
            if (gVar == null || (eVar = this.f90k) == null) {
                return;
            }
            gVar.b(eVar);
        }

        void d(Context context) {
            TypedValue typedValue = new TypedValue();
            Resources.Theme newTheme = context.getResources().newTheme();
            newTheme.setTo(context.getTheme());
            newTheme.resolveAttribute(b.a.a.f706a, typedValue, true);
            int i2 = typedValue.resourceId;
            if (i2 != 0) {
                newTheme.applyStyle(i2, true);
            }
            newTheme.resolveAttribute(b.a.a.D, typedValue, true);
            int i3 = typedValue.resourceId;
            if (i3 == 0) {
                i3 = b.a.i.f782b;
            }
            newTheme.applyStyle(i3, true);
            b.a.n.d dVar = new b.a.n.d(context, 0);
            dVar.getTheme().setTo(newTheme);
            this.l = dVar;
            TypedArray obtainStyledAttributes = dVar.obtainStyledAttributes(b.a.j.u0);
            this.f81b = obtainStyledAttributes.getResourceId(b.a.j.x0, 0);
            this.f85f = obtainStyledAttributes.getResourceId(b.a.j.w0, 0);
            obtainStyledAttributes.recycle();
        }
    }

    private final class u implements m.a {
        u() {
        }

        @Override // androidx.appcompat.view.menu.m.a
        public void b(androidx.appcompat.view.menu.g gVar, boolean z) {
            androidx.appcompat.view.menu.g D = gVar.D();
            boolean z2 = D != gVar;
            g gVar2 = g.this;
            if (z2) {
                gVar = D;
            }
            t b0 = gVar2.b0(gVar);
            if (b0 != null) {
                if (!z2) {
                    g.this.R(b0, z);
                } else {
                    g.this.N(b0.f80a, b0, D);
                    g.this.R(b0, true);
                }
            }
        }

        @Override // androidx.appcompat.view.menu.m.a
        public boolean c(androidx.appcompat.view.menu.g gVar) {
            Window.Callback i0;
            if (gVar != gVar.D()) {
                return true;
            }
            g gVar2 = g.this;
            if (!gVar2.N || (i0 = gVar2.i0()) == null || g.this.Z) {
                return true;
            }
            i0.onMenuOpened(R.styleable.AppCompatTheme_textColorAlertDialogListItem, gVar);
            return true;
        }
    }

    static {
        int i2 = Build.VERSION.SDK_INT;
        boolean z = i2 < 21;
        o0 = z;
        p0 = new int[]{android.R.attr.windowBackground};
        q0 = !"robolectric".equals(Build.FINGERPRINT);
        r0 = i2 >= 17;
        if (!z || s0) {
            return;
        }
        Thread.setDefaultUncaughtExceptionHandler(new a(Thread.getDefaultUncaughtExceptionHandler()));
        s0 = true;
    }

    g(Activity activity, androidx.appcompat.app.e eVar) {
        this(activity, null, eVar, activity);
    }

    g(Dialog dialog, androidx.appcompat.app.e eVar) {
        this(dialog.getContext(), dialog.getWindow(), eVar, dialog);
    }

    private g(Context context, Window window, androidx.appcompat.app.e eVar, Object obj) {
        b.e.g<String, Integer> gVar;
        Integer num;
        androidx.appcompat.app.d K0;
        this.F = null;
        this.G = true;
        this.a0 = -100;
        this.i0 = new b();
        this.r = context;
        this.u = eVar;
        this.q = obj;
        if ((obj instanceof Dialog) && (K0 = K0()) != null) {
            this.a0 = K0.getDelegate().l();
        }
        if (this.a0 == -100 && (num = (gVar = n0).get(obj.getClass().getName())) != null) {
            this.a0 = num.intValue();
            gVar.remove(obj.getClass().getName());
        }
        if (window != null) {
            L(window);
        }
        androidx.appcompat.widget.j.h();
    }

    private void A0(t tVar, KeyEvent keyEvent) {
        int i2;
        ViewGroup.LayoutParams layoutParams;
        if (tVar.o || this.Z) {
            return;
        }
        if (tVar.f80a == 0) {
            if ((this.r.getResources().getConfiguration().screenLayout & 15) == 4) {
                return;
            }
        }
        Window.Callback i0 = i0();
        if (i0 != null && !i0.onMenuOpened(tVar.f80a, tVar.f89j)) {
            R(tVar, true);
            return;
        }
        WindowManager windowManager = (WindowManager) this.r.getSystemService("window");
        if (windowManager != null && D0(tVar, keyEvent)) {
            ViewGroup viewGroup = tVar.f86g;
            if (viewGroup == null || tVar.q) {
                if (viewGroup == null) {
                    if (!l0(tVar) || tVar.f86g == null) {
                        return;
                    }
                } else if (tVar.q && viewGroup.getChildCount() > 0) {
                    tVar.f86g.removeAllViews();
                }
                if (!k0(tVar) || !tVar.b()) {
                    tVar.q = true;
                    return;
                }
                ViewGroup.LayoutParams layoutParams2 = tVar.f87h.getLayoutParams();
                if (layoutParams2 == null) {
                    layoutParams2 = new ViewGroup.LayoutParams(-2, -2);
                }
                tVar.f86g.setBackgroundResource(tVar.f81b);
                ViewParent parent = tVar.f87h.getParent();
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(tVar.f87h);
                }
                tVar.f86g.addView(tVar.f87h, layoutParams2);
                if (!tVar.f87h.hasFocus()) {
                    tVar.f87h.requestFocus();
                }
            } else {
                View view = tVar.f88i;
                if (view != null && (layoutParams = view.getLayoutParams()) != null && layoutParams.width == -1) {
                    i2 = -1;
                    tVar.n = false;
                    WindowManager.LayoutParams layoutParams3 = new WindowManager.LayoutParams(i2, -2, tVar.f83d, tVar.f84e, 1002, 8519680, -3);
                    layoutParams3.gravity = tVar.f82c;
                    layoutParams3.windowAnimations = tVar.f85f;
                    windowManager.addView(tVar.f86g, layoutParams3);
                    tVar.o = true;
                }
            }
            i2 = -2;
            tVar.n = false;
            WindowManager.LayoutParams layoutParams32 = new WindowManager.LayoutParams(i2, -2, tVar.f83d, tVar.f84e, 1002, 8519680, -3);
            layoutParams32.gravity = tVar.f82c;
            layoutParams32.windowAnimations = tVar.f85f;
            windowManager.addView(tVar.f86g, layoutParams32);
            tVar.o = true;
        }
    }

    private boolean C0(t tVar, int i2, KeyEvent keyEvent, int i3) {
        androidx.appcompat.view.menu.g gVar;
        boolean z = false;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((tVar.m || D0(tVar, keyEvent)) && (gVar = tVar.f89j) != null) {
            z = gVar.performShortcut(i2, keyEvent, i3);
        }
        if (z && (i3 & 1) == 0 && this.y == null) {
            R(tVar, true);
        }
        return z;
    }

    private boolean D0(t tVar, KeyEvent keyEvent) {
        c0 c0Var;
        c0 c0Var2;
        c0 c0Var3;
        c0 c0Var4;
        if (this.Z) {
            return false;
        }
        if (tVar.m) {
            return true;
        }
        t tVar2 = this.U;
        if (tVar2 != null && tVar2 != tVar) {
            R(tVar2, false);
        }
        Window.Callback i0 = i0();
        if (i0 != null) {
            tVar.f88i = i0.onCreatePanelView(tVar.f80a);
        }
        int i2 = tVar.f80a;
        boolean z = i2 == 0 || i2 == 108;
        if (z && (c0Var4 = this.y) != null) {
            c0Var4.d();
        }
        if (tVar.f88i == null && (!z || !(B0() instanceof androidx.appcompat.app.k))) {
            androidx.appcompat.view.menu.g gVar = tVar.f89j;
            if (gVar == null || tVar.r) {
                if (gVar == null && (!m0(tVar) || tVar.f89j == null)) {
                    return false;
                }
                if (z && (c0Var2 = this.y) != null) {
                    if (this.z == null) {
                        this.z = new i();
                    }
                    c0Var2.b(tVar.f89j, this.z);
                }
                tVar.f89j.d0();
                if (!i0.onCreatePanelMenu(tVar.f80a, tVar.f89j)) {
                    tVar.c(null);
                    if (z && (c0Var = this.y) != null) {
                        c0Var.b(null, this.z);
                    }
                    return false;
                }
                tVar.r = false;
            }
            tVar.f89j.d0();
            Bundle bundle = tVar.s;
            if (bundle != null) {
                tVar.f89j.P(bundle);
                tVar.s = null;
            }
            if (!i0.onPreparePanel(0, tVar.f88i, tVar.f89j)) {
                if (z && (c0Var3 = this.y) != null) {
                    c0Var3.b(null, this.z);
                }
                tVar.f89j.c0();
                return false;
            }
            boolean z2 = KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1;
            tVar.p = z2;
            tVar.f89j.setQwertyMode(z2);
            tVar.f89j.c0();
        }
        tVar.m = true;
        tVar.n = false;
        this.U = tVar;
        return true;
    }

    private void E0(boolean z) {
        c0 c0Var = this.y;
        if (c0Var == null || !c0Var.i() || (ViewConfiguration.get(this.r).hasPermanentMenuKey() && !this.y.f())) {
            t g0 = g0(0, true);
            g0.q = true;
            R(g0, false);
            A0(g0, null);
            return;
        }
        Window.Callback i0 = i0();
        if (this.y.c() && z) {
            this.y.g();
            if (this.Z) {
                return;
            }
            i0.onPanelClosed(R.styleable.AppCompatTheme_textColorAlertDialogListItem, g0(0, true).f89j);
            return;
        }
        if (i0 == null || this.Z) {
            return;
        }
        if (this.g0 && (this.h0 & 1) != 0) {
            this.s.getDecorView().removeCallbacks(this.i0);
            this.i0.run();
        }
        t g02 = g0(0, true);
        androidx.appcompat.view.menu.g gVar = g02.f89j;
        if (gVar == null || g02.r || !i0.onPreparePanel(0, g02.f88i, gVar)) {
            return;
        }
        i0.onMenuOpened(R.styleable.AppCompatTheme_textColorAlertDialogListItem, g02.f89j);
        this.y.h();
    }

    private int F0(int i2) {
        if (i2 == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            return R.styleable.AppCompatTheme_textColorAlertDialogListItem;
        }
        if (i2 != 9) {
            return i2;
        }
        Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
        return R.styleable.AppCompatTheme_textColorSearchUrl;
    }

    private boolean H0(ViewParent viewParent) {
        if (viewParent == null) {
            return false;
        }
        View decorView = this.s.getDecorView();
        while (viewParent != null) {
            if (viewParent == decorView || !(viewParent instanceof View) || b.g.l.r.x((View) viewParent)) {
                return false;
            }
            viewParent = viewParent.getParent();
        }
        return true;
    }

    private boolean J(boolean z) {
        if (this.Z) {
            return false;
        }
        int M = M();
        boolean L0 = L0(q0(this.r, M), z);
        if (M == 0) {
            f0(this.r).e();
        } else {
            m mVar = this.e0;
            if (mVar != null) {
                mVar.a();
            }
        }
        if (M == 3) {
            e0(this.r).e();
        } else {
            m mVar2 = this.f0;
            if (mVar2 != null) {
                mVar2.a();
            }
        }
        return L0;
    }

    private void J0() {
        if (this.H) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    private void K() {
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) this.I.findViewById(android.R.id.content);
        View decorView = this.s.getDecorView();
        contentFrameLayout.b(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        TypedArray obtainStyledAttributes = this.r.obtainStyledAttributes(b.a.j.u0);
        obtainStyledAttributes.getValue(b.a.j.G0, contentFrameLayout.getMinWidthMajor());
        obtainStyledAttributes.getValue(b.a.j.H0, contentFrameLayout.getMinWidthMinor());
        int i2 = b.a.j.E0;
        if (obtainStyledAttributes.hasValue(i2)) {
            obtainStyledAttributes.getValue(i2, contentFrameLayout.getFixedWidthMajor());
        }
        int i3 = b.a.j.F0;
        if (obtainStyledAttributes.hasValue(i3)) {
            obtainStyledAttributes.getValue(i3, contentFrameLayout.getFixedWidthMinor());
        }
        int i4 = b.a.j.C0;
        if (obtainStyledAttributes.hasValue(i4)) {
            obtainStyledAttributes.getValue(i4, contentFrameLayout.getFixedHeightMajor());
        }
        int i5 = b.a.j.D0;
        if (obtainStyledAttributes.hasValue(i5)) {
            obtainStyledAttributes.getValue(i5, contentFrameLayout.getFixedHeightMinor());
        }
        obtainStyledAttributes.recycle();
        contentFrameLayout.requestLayout();
    }

    private androidx.appcompat.app.d K0() {
        for (Context context = this.r; context != null; context = ((ContextWrapper) context).getBaseContext()) {
            if (context instanceof androidx.appcompat.app.d) {
                return (androidx.appcompat.app.d) context;
            }
            if (!(context instanceof ContextWrapper)) {
                break;
            }
        }
        return null;
    }

    private void L(Window window) {
        if (this.s != null) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        Window.Callback callback = window.getCallback();
        if (callback instanceof k) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        k kVar = new k(callback);
        this.t = kVar;
        window.setCallback(kVar);
        w0 t2 = w0.t(this.r, null, p0);
        Drawable g2 = t2.g(0);
        if (g2 != null) {
            window.setBackgroundDrawable(g2);
        }
        t2.v();
        this.s = window;
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0053  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private boolean L0(int r7, boolean r8) {
        /*
            r6 = this;
            android.content.Context r0 = r6.r
            r1 = 0
            android.content.res.Configuration r0 = r6.S(r0, r7, r1)
            boolean r2 = r6.o0()
            android.content.Context r3 = r6.r
            android.content.res.Resources r3 = r3.getResources()
            android.content.res.Configuration r3 = r3.getConfiguration()
            int r3 = r3.uiMode
            r3 = r3 & 48
            int r0 = r0.uiMode
            r0 = r0 & 48
            r4 = 1
            if (r3 == r0) goto L47
            if (r8 == 0) goto L47
            if (r2 != 0) goto L47
            boolean r8 = r6.W
            if (r8 == 0) goto L47
            boolean r8 = androidx.appcompat.app.g.q0
            if (r8 != 0) goto L30
            boolean r8 = r6.X
            if (r8 == 0) goto L47
        L30:
            java.lang.Object r8 = r6.q
            boolean r5 = r8 instanceof android.app.Activity
            if (r5 == 0) goto L47
            android.app.Activity r8 = (android.app.Activity) r8
            boolean r8 = r8.isChild()
            if (r8 != 0) goto L47
            java.lang.Object r8 = r6.q
            android.app.Activity r8 = (android.app.Activity) r8
            androidx.core.app.a.p(r8)
            r8 = 1
            goto L48
        L47:
            r8 = 0
        L48:
            if (r8 != 0) goto L50
            if (r3 == r0) goto L50
            r6.M0(r0, r2, r1)
            goto L51
        L50:
            r4 = r8
        L51:
            if (r4 == 0) goto L5e
            java.lang.Object r8 = r6.q
            boolean r0 = r8 instanceof androidx.appcompat.app.d
            if (r0 == 0) goto L5e
            androidx.appcompat.app.d r8 = (androidx.appcompat.app.d) r8
            r8.onNightModeChanged(r7)
        L5e:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.g.L0(int, boolean):boolean");
    }

    private int M() {
        int i2 = this.a0;
        return i2 != -100 ? i2 : androidx.appcompat.app.f.j();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void M0(int i2, boolean z, Configuration configuration) {
        Resources resources = this.r.getResources();
        Configuration configuration2 = new Configuration(resources.getConfiguration());
        if (configuration != null) {
            configuration2.updateFrom(configuration);
        }
        configuration2.uiMode = i2 | (resources.getConfiguration().uiMode & (-49));
        resources.updateConfiguration(configuration2, null);
        int i3 = Build.VERSION.SDK_INT;
        if (i3 < 26) {
            androidx.appcompat.app.j.a(resources);
        }
        int i4 = this.b0;
        if (i4 != 0) {
            this.r.setTheme(i4);
            if (i3 >= 23) {
                this.r.getTheme().applyStyle(this.b0, true);
            }
        }
        if (z) {
            Object obj = this.q;
            if (obj instanceof Activity) {
                Activity activity = (Activity) obj;
                if (activity instanceof androidx.lifecycle.g) {
                    if (!((androidx.lifecycle.g) activity).getLifecycle().b().c(d.b.STARTED)) {
                        return;
                    }
                } else if (!this.Y) {
                    return;
                }
                activity.onConfigurationChanged(configuration2);
            }
        }
    }

    private void O0(View view) {
        Context context;
        int i2;
        if ((b.g.l.r.u(view) & 8192) != 0) {
            context = this.r;
            i2 = b.a.c.f719b;
        } else {
            context = this.r;
            i2 = b.a.c.f718a;
        }
        view.setBackgroundColor(b.g.e.a.d(context, i2));
    }

    private void P() {
        m mVar = this.e0;
        if (mVar != null) {
            mVar.a();
        }
        m mVar2 = this.f0;
        if (mVar2 != null) {
            mVar2.a();
        }
    }

    private Configuration S(Context context, int i2, Configuration configuration) {
        int i3 = i2 != 1 ? i2 != 2 ? context.getApplicationContext().getResources().getConfiguration().uiMode & 48 : 32 : 16;
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i3 | (configuration2.uiMode & (-49));
        return configuration2;
    }

    private ViewGroup T() {
        ViewGroup viewGroup;
        TypedArray obtainStyledAttributes = this.r.obtainStyledAttributes(b.a.j.u0);
        int i2 = b.a.j.z0;
        if (!obtainStyledAttributes.hasValue(i2)) {
            obtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
        if (obtainStyledAttributes.getBoolean(b.a.j.I0, false)) {
            A(1);
        } else if (obtainStyledAttributes.getBoolean(i2, false)) {
            A(R.styleable.AppCompatTheme_textColorAlertDialogListItem);
        }
        if (obtainStyledAttributes.getBoolean(b.a.j.A0, false)) {
            A(R.styleable.AppCompatTheme_textColorSearchUrl);
        }
        if (obtainStyledAttributes.getBoolean(b.a.j.B0, false)) {
            A(10);
        }
        this.Q = obtainStyledAttributes.getBoolean(b.a.j.v0, false);
        obtainStyledAttributes.recycle();
        a0();
        this.s.getDecorView();
        LayoutInflater from = LayoutInflater.from(this.r);
        if (this.R) {
            viewGroup = (ViewGroup) from.inflate(this.P ? b.a.g.o : b.a.g.n, (ViewGroup) null);
        } else if (this.Q) {
            viewGroup = (ViewGroup) from.inflate(b.a.g.f764f, (ViewGroup) null);
            this.O = false;
            this.N = false;
        } else if (this.N) {
            TypedValue typedValue = new TypedValue();
            this.r.getTheme().resolveAttribute(b.a.a.f711f, typedValue, true);
            viewGroup = (ViewGroup) LayoutInflater.from(typedValue.resourceId != 0 ? new b.a.n.d(this.r, typedValue.resourceId) : this.r).inflate(b.a.g.p, (ViewGroup) null);
            c0 c0Var = (c0) viewGroup.findViewById(b.a.f.p);
            this.y = c0Var;
            c0Var.setWindowCallback(i0());
            if (this.O) {
                this.y.j(R.styleable.AppCompatTheme_textColorSearchUrl);
            }
            if (this.L) {
                this.y.j(2);
            }
            if (this.M) {
                this.y.j(5);
            }
        } else {
            viewGroup = null;
        }
        if (viewGroup == null) {
            throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.N + ", windowActionBarOverlay: " + this.O + ", android:windowIsFloating: " + this.Q + ", windowActionModeOverlay: " + this.P + ", windowNoTitle: " + this.R + " }");
        }
        if (Build.VERSION.SDK_INT >= 21) {
            b.g.l.r.R(viewGroup, new c());
        } else if (viewGroup instanceof g0) {
            ((g0) viewGroup).setOnFitSystemWindowsListener(new d());
        }
        if (this.y == null) {
            this.J = (TextView) viewGroup.findViewById(b.a.f.M);
        }
        c1.c(viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(b.a.f.f749b);
        ViewGroup viewGroup2 = (ViewGroup) this.s.findViewById(android.R.id.content);
        if (viewGroup2 != null) {
            while (viewGroup2.getChildCount() > 0) {
                View childAt = viewGroup2.getChildAt(0);
                viewGroup2.removeViewAt(0);
                contentFrameLayout.addView(childAt);
            }
            viewGroup2.setId(-1);
            contentFrameLayout.setId(android.R.id.content);
            if (viewGroup2 instanceof FrameLayout) {
                ((FrameLayout) viewGroup2).setForeground(null);
            }
        }
        this.s.setContentView(viewGroup);
        contentFrameLayout.setAttachListener(new e());
        return viewGroup;
    }

    private void Z() {
        if (this.H) {
            return;
        }
        this.I = T();
        CharSequence h0 = h0();
        if (!TextUtils.isEmpty(h0)) {
            c0 c0Var = this.y;
            if (c0Var != null) {
                c0Var.setWindowTitle(h0);
            } else if (B0() != null) {
                B0().y(h0);
            } else {
                TextView textView = this.J;
                if (textView != null) {
                    textView.setText(h0);
                }
            }
        }
        K();
        z0(this.I);
        this.H = true;
        t g0 = g0(0, false);
        if (this.Z) {
            return;
        }
        if (g0 == null || g0.f89j == null) {
            n0(R.styleable.AppCompatTheme_textColorAlertDialogListItem);
        }
    }

    private void a0() {
        if (this.s == null) {
            Object obj = this.q;
            if (obj instanceof Activity) {
                L(((Activity) obj).getWindow());
            }
        }
        if (this.s == null) {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    private static Configuration c0(Configuration configuration, Configuration configuration2) {
        Configuration configuration3 = new Configuration();
        configuration3.fontScale = 0.0f;
        if (configuration2 != null && configuration.diff(configuration2) != 0) {
            float f2 = configuration.fontScale;
            float f3 = configuration2.fontScale;
            if (f2 != f3) {
                configuration3.fontScale = f3;
            }
            int i2 = configuration.mcc;
            int i3 = configuration2.mcc;
            if (i2 != i3) {
                configuration3.mcc = i3;
            }
            int i4 = configuration.mnc;
            int i5 = configuration2.mnc;
            if (i4 != i5) {
                configuration3.mnc = i5;
            }
            int i6 = Build.VERSION.SDK_INT;
            if (i6 >= 24) {
                p.a(configuration, configuration2, configuration3);
            } else if (!b.g.k.d.a(configuration.locale, configuration2.locale)) {
                configuration3.locale = configuration2.locale;
            }
            int i7 = configuration.touchscreen;
            int i8 = configuration2.touchscreen;
            if (i7 != i8) {
                configuration3.touchscreen = i8;
            }
            int i9 = configuration.keyboard;
            int i10 = configuration2.keyboard;
            if (i9 != i10) {
                configuration3.keyboard = i10;
            }
            int i11 = configuration.keyboardHidden;
            int i12 = configuration2.keyboardHidden;
            if (i11 != i12) {
                configuration3.keyboardHidden = i12;
            }
            int i13 = configuration.navigation;
            int i14 = configuration2.navigation;
            if (i13 != i14) {
                configuration3.navigation = i14;
            }
            int i15 = configuration.navigationHidden;
            int i16 = configuration2.navigationHidden;
            if (i15 != i16) {
                configuration3.navigationHidden = i16;
            }
            int i17 = configuration.orientation;
            int i18 = configuration2.orientation;
            if (i17 != i18) {
                configuration3.orientation = i18;
            }
            int i19 = configuration.screenLayout & 15;
            int i20 = configuration2.screenLayout;
            if (i19 != (i20 & 15)) {
                configuration3.screenLayout |= i20 & 15;
            }
            int i21 = configuration.screenLayout & 192;
            int i22 = configuration2.screenLayout;
            if (i21 != (i22 & 192)) {
                configuration3.screenLayout |= i22 & 192;
            }
            int i23 = configuration.screenLayout & 48;
            int i24 = configuration2.screenLayout;
            if (i23 != (i24 & 48)) {
                configuration3.screenLayout |= i24 & 48;
            }
            int i25 = configuration.screenLayout & 768;
            int i26 = configuration2.screenLayout;
            if (i25 != (i26 & 768)) {
                configuration3.screenLayout |= i26 & 768;
            }
            if (i6 >= 26) {
                q.a(configuration, configuration2, configuration3);
            }
            int i27 = configuration.uiMode & 15;
            int i28 = configuration2.uiMode;
            if (i27 != (i28 & 15)) {
                configuration3.uiMode |= i28 & 15;
            }
            int i29 = configuration.uiMode & 48;
            int i30 = configuration2.uiMode;
            if (i29 != (i30 & 48)) {
                configuration3.uiMode |= i30 & 48;
            }
            int i31 = configuration.screenWidthDp;
            int i32 = configuration2.screenWidthDp;
            if (i31 != i32) {
                configuration3.screenWidthDp = i32;
            }
            int i33 = configuration.screenHeightDp;
            int i34 = configuration2.screenHeightDp;
            if (i33 != i34) {
                configuration3.screenHeightDp = i34;
            }
            int i35 = configuration.smallestScreenWidthDp;
            int i36 = configuration2.smallestScreenWidthDp;
            if (i35 != i36) {
                configuration3.smallestScreenWidthDp = i36;
            }
            if (i6 >= 17) {
                o.a(configuration, configuration2, configuration3);
            }
        }
        return configuration3;
    }

    private m e0(Context context) {
        if (this.f0 == null) {
            this.f0 = new l(context);
        }
        return this.f0;
    }

    private m f0(Context context) {
        if (this.e0 == null) {
            this.e0 = new n(androidx.appcompat.app.m.a(context));
        }
        return this.e0;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0032  */
    /* JADX WARN: Removed duplicated region for block: B:14:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void j0() {
        /*
            r3 = this;
            r3.Z()
            boolean r0 = r3.N
            if (r0 == 0) goto L37
            androidx.appcompat.app.a r0 = r3.v
            if (r0 == 0) goto Lc
            goto L37
        Lc:
            java.lang.Object r0 = r3.q
            boolean r1 = r0 instanceof android.app.Activity
            if (r1 == 0) goto L20
            androidx.appcompat.app.n r0 = new androidx.appcompat.app.n
            java.lang.Object r1 = r3.q
            android.app.Activity r1 = (android.app.Activity) r1
            boolean r2 = r3.O
            r0.<init>(r1, r2)
        L1d:
            r3.v = r0
            goto L2e
        L20:
            boolean r0 = r0 instanceof android.app.Dialog
            if (r0 == 0) goto L2e
            androidx.appcompat.app.n r0 = new androidx.appcompat.app.n
            java.lang.Object r1 = r3.q
            android.app.Dialog r1 = (android.app.Dialog) r1
            r0.<init>(r1)
            goto L1d
        L2e:
            androidx.appcompat.app.a r0 = r3.v
            if (r0 == 0) goto L37
            boolean r1 = r3.j0
            r0.u(r1)
        L37:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.g.j0():void");
    }

    private boolean k0(t tVar) {
        View view = tVar.f88i;
        if (view != null) {
            tVar.f87h = view;
            return true;
        }
        if (tVar.f89j == null) {
            return false;
        }
        if (this.A == null) {
            this.A = new u();
        }
        View view2 = (View) tVar.a(this.A);
        tVar.f87h = view2;
        return view2 != null;
    }

    private boolean l0(t tVar) {
        tVar.d(d0());
        tVar.f86g = new s(tVar.l);
        tVar.f82c = 81;
        return true;
    }

    private boolean m0(t tVar) {
        Context context = this.r;
        int i2 = tVar.f80a;
        if ((i2 == 0 || i2 == 108) && this.y != null) {
            TypedValue typedValue = new TypedValue();
            Resources.Theme theme = context.getTheme();
            theme.resolveAttribute(b.a.a.f711f, typedValue, true);
            Resources.Theme theme2 = null;
            if (typedValue.resourceId != 0) {
                theme2 = context.getResources().newTheme();
                theme2.setTo(theme);
                theme2.applyStyle(typedValue.resourceId, true);
                theme2.resolveAttribute(b.a.a.f712g, typedValue, true);
            } else {
                theme.resolveAttribute(b.a.a.f712g, typedValue, true);
            }
            if (typedValue.resourceId != 0) {
                if (theme2 == null) {
                    theme2 = context.getResources().newTheme();
                    theme2.setTo(theme);
                }
                theme2.applyStyle(typedValue.resourceId, true);
            }
            if (theme2 != null) {
                b.a.n.d dVar = new b.a.n.d(context, 0);
                dVar.getTheme().setTo(theme2);
                context = dVar;
            }
        }
        androidx.appcompat.view.menu.g gVar = new androidx.appcompat.view.menu.g(context);
        gVar.R(this);
        tVar.c(gVar);
        return true;
    }

    private void n0(int i2) {
        this.h0 = (1 << i2) | this.h0;
        if (this.g0) {
            return;
        }
        b.g.l.r.G(this.s.getDecorView(), this.i0);
        this.g0 = true;
    }

    private boolean o0() {
        if (!this.d0 && (this.q instanceof Activity)) {
            PackageManager packageManager = this.r.getPackageManager();
            if (packageManager == null) {
                return false;
            }
            try {
                int i2 = Build.VERSION.SDK_INT;
                ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(this.r, this.q.getClass()), i2 >= 29 ? 269221888 : i2 >= 24 ? 786432 : 0);
                this.c0 = (activityInfo == null || (activityInfo.configChanges & 512) == 0) ? false : true;
            } catch (PackageManager.NameNotFoundException e2) {
                Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", e2);
                this.c0 = false;
            }
        }
        this.d0 = true;
        return this.c0;
    }

    private boolean t0(int i2, KeyEvent keyEvent) {
        if (keyEvent.getRepeatCount() != 0) {
            return false;
        }
        t g0 = g0(i2, true);
        if (g0.o) {
            return false;
        }
        return D0(g0, keyEvent);
    }

    private boolean w0(int i2, KeyEvent keyEvent) {
        boolean z;
        c0 c0Var;
        if (this.B != null) {
            return false;
        }
        boolean z2 = true;
        t g0 = g0(i2, true);
        if (i2 != 0 || (c0Var = this.y) == null || !c0Var.i() || ViewConfiguration.get(this.r).hasPermanentMenuKey()) {
            boolean z3 = g0.o;
            if (z3 || g0.n) {
                R(g0, true);
                z2 = z3;
            } else {
                if (g0.m) {
                    if (g0.r) {
                        g0.m = false;
                        z = D0(g0, keyEvent);
                    } else {
                        z = true;
                    }
                    if (z) {
                        A0(g0, keyEvent);
                    }
                }
                z2 = false;
            }
        } else if (this.y.c()) {
            z2 = this.y.g();
        } else {
            if (!this.Z && D0(g0, keyEvent)) {
                z2 = this.y.h();
            }
            z2 = false;
        }
        if (z2) {
            AudioManager audioManager = (AudioManager) this.r.getApplicationContext().getSystemService("audio");
            if (audioManager != null) {
                audioManager.playSoundEffect(0);
            } else {
                Log.w("AppCompatDelegate", "Couldn't get audio manager");
            }
        }
        return z2;
    }

    @Override // androidx.appcompat.app.f
    public boolean A(int i2) {
        int F0 = F0(i2);
        if (this.R && F0 == 108) {
            return false;
        }
        if (this.N && F0 == 1) {
            this.N = false;
        }
        if (F0 == 1) {
            J0();
            this.R = true;
            return true;
        }
        if (F0 == 2) {
            J0();
            this.L = true;
            return true;
        }
        if (F0 == 5) {
            J0();
            this.M = true;
            return true;
        }
        if (F0 == 10) {
            J0();
            this.P = true;
            return true;
        }
        if (F0 == 108) {
            J0();
            this.N = true;
            return true;
        }
        if (F0 != 109) {
            return this.s.requestFeature(F0);
        }
        J0();
        this.O = true;
        return true;
    }

    @Override // androidx.appcompat.app.f
    public void B(int i2) {
        Z();
        ViewGroup viewGroup = (ViewGroup) this.I.findViewById(android.R.id.content);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.r).inflate(i2, viewGroup);
        this.t.a().onContentChanged();
    }

    final androidx.appcompat.app.a B0() {
        return this.v;
    }

    @Override // androidx.appcompat.app.f
    public void C(View view) {
        Z();
        ViewGroup viewGroup = (ViewGroup) this.I.findViewById(android.R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.t.a().onContentChanged();
    }

    @Override // androidx.appcompat.app.f
    public void D(View view, ViewGroup.LayoutParams layoutParams) {
        Z();
        ViewGroup viewGroup = (ViewGroup) this.I.findViewById(android.R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.t.a().onContentChanged();
    }

    @Override // androidx.appcompat.app.f
    public void E(Toolbar toolbar) {
        Window window;
        Window.Callback callback;
        if (this.q instanceof Activity) {
            androidx.appcompat.app.a n2 = n();
            if (n2 instanceof androidx.appcompat.app.n) {
                throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
            }
            this.w = null;
            if (n2 != null) {
                n2.p();
            }
            if (toolbar != null) {
                androidx.appcompat.app.k kVar = new androidx.appcompat.app.k(toolbar, h0(), this.t);
                this.v = kVar;
                window = this.s;
                callback = kVar.C();
            } else {
                this.v = null;
                window = this.s;
                callback = this.t;
            }
            window.setCallback(callback);
            p();
        }
    }

    @Override // androidx.appcompat.app.f
    public void F(int i2) {
        this.b0 = i2;
    }

    @Override // androidx.appcompat.app.f
    public final void G(CharSequence charSequence) {
        this.x = charSequence;
        c0 c0Var = this.y;
        if (c0Var != null) {
            c0Var.setWindowTitle(charSequence);
            return;
        }
        if (B0() != null) {
            B0().y(charSequence);
            return;
        }
        TextView textView = this.J;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    final boolean G0() {
        ViewGroup viewGroup;
        return this.H && (viewGroup = this.I) != null && b.g.l.r.y(viewGroup);
    }

    @Override // androidx.appcompat.app.f
    public b.a.n.b H(b.a aVar) {
        androidx.appcompat.app.e eVar;
        if (aVar == null) {
            throw new IllegalArgumentException("ActionMode callback can not be null.");
        }
        b.a.n.b bVar = this.B;
        if (bVar != null) {
            bVar.c();
        }
        j jVar = new j(aVar);
        androidx.appcompat.app.a n2 = n();
        if (n2 != null) {
            b.a.n.b A = n2.A(jVar);
            this.B = A;
            if (A != null && (eVar = this.u) != null) {
                eVar.onSupportActionModeStarted(A);
            }
        }
        if (this.B == null) {
            this.B = I0(jVar);
        }
        return this.B;
    }

    public boolean I() {
        return J(true);
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0025  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0029  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    b.a.n.b I0(b.a.n.b.a r8) {
        /*
            Method dump skipped, instructions count: 367
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.g.I0(b.a.n.b$a):b.a.n.b");
    }

    void N(int i2, t tVar, Menu menu) {
        if (menu == null) {
            if (tVar == null && i2 >= 0) {
                t[] tVarArr = this.T;
                if (i2 < tVarArr.length) {
                    tVar = tVarArr[i2];
                }
            }
            if (tVar != null) {
                menu = tVar.f89j;
            }
        }
        if ((tVar == null || tVar.o) && !this.Z) {
            this.t.a().onPanelClosed(i2, menu);
        }
    }

    final int N0(z zVar, Rect rect) {
        boolean z;
        boolean z2;
        int k2 = zVar != null ? zVar.k() : rect != null ? rect.top : 0;
        ActionBarContextView actionBarContextView = this.C;
        if (actionBarContextView == null || !(actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            z = false;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.C.getLayoutParams();
            if (this.C.isShown()) {
                if (this.k0 == null) {
                    this.k0 = new Rect();
                    this.l0 = new Rect();
                }
                Rect rect2 = this.k0;
                Rect rect3 = this.l0;
                if (zVar == null) {
                    rect2.set(rect);
                } else {
                    rect2.set(zVar.i(), zVar.k(), zVar.j(), zVar.h());
                }
                c1.a(this.I, rect2, rect3);
                int i2 = rect2.top;
                int i3 = rect2.left;
                int i4 = rect2.right;
                z r2 = b.g.l.r.r(this.I);
                int i5 = r2 == null ? 0 : r2.i();
                int j2 = r2 == null ? 0 : r2.j();
                if (marginLayoutParams.topMargin == i2 && marginLayoutParams.leftMargin == i3 && marginLayoutParams.rightMargin == i4) {
                    z2 = false;
                } else {
                    marginLayoutParams.topMargin = i2;
                    marginLayoutParams.leftMargin = i3;
                    marginLayoutParams.rightMargin = i4;
                    z2 = true;
                }
                if (i2 <= 0 || this.K != null) {
                    View view = this.K;
                    if (view != null) {
                        ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
                        int i6 = marginLayoutParams2.height;
                        int i7 = marginLayoutParams.topMargin;
                        if (i6 != i7 || marginLayoutParams2.leftMargin != i5 || marginLayoutParams2.rightMargin != j2) {
                            marginLayoutParams2.height = i7;
                            marginLayoutParams2.leftMargin = i5;
                            marginLayoutParams2.rightMargin = j2;
                            this.K.setLayoutParams(marginLayoutParams2);
                        }
                    }
                } else {
                    View view2 = new View(this.r);
                    this.K = view2;
                    view2.setVisibility(8);
                    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
                    layoutParams.leftMargin = i5;
                    layoutParams.rightMargin = j2;
                    this.I.addView(this.K, -1, layoutParams);
                }
                View view3 = this.K;
                r5 = view3 != null;
                if (r5 && view3.getVisibility() != 0) {
                    O0(this.K);
                }
                if (!this.P && r5) {
                    k2 = 0;
                }
                z = r5;
                r5 = z2;
            } else if (marginLayoutParams.topMargin != 0) {
                marginLayoutParams.topMargin = 0;
                z = false;
            } else {
                z = false;
                r5 = false;
            }
            if (r5) {
                this.C.setLayoutParams(marginLayoutParams);
            }
        }
        View view4 = this.K;
        if (view4 != null) {
            view4.setVisibility(z ? 0 : 8);
        }
        return k2;
    }

    void O(androidx.appcompat.view.menu.g gVar) {
        if (this.S) {
            return;
        }
        this.S = true;
        this.y.k();
        Window.Callback i0 = i0();
        if (i0 != null && !this.Z) {
            i0.onPanelClosed(R.styleable.AppCompatTheme_textColorAlertDialogListItem, gVar);
        }
        this.S = false;
    }

    void Q(int i2) {
        R(g0(i2, true), true);
    }

    void R(t tVar, boolean z) {
        ViewGroup viewGroup;
        c0 c0Var;
        if (z && tVar.f80a == 0 && (c0Var = this.y) != null && c0Var.c()) {
            O(tVar.f89j);
            return;
        }
        WindowManager windowManager = (WindowManager) this.r.getSystemService("window");
        if (windowManager != null && tVar.o && (viewGroup = tVar.f86g) != null) {
            windowManager.removeView(viewGroup);
            if (z) {
                N(tVar.f80a, tVar, null);
            }
        }
        tVar.m = false;
        tVar.n = false;
        tVar.o = false;
        tVar.f87h = null;
        tVar.q = true;
        if (this.U == tVar) {
            this.U = null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public View U(View view, String str, Context context, AttributeSet attributeSet) {
        boolean z;
        androidx.appcompat.app.i iVar;
        boolean z2 = false;
        if (this.m0 == null) {
            String string = this.r.obtainStyledAttributes(b.a.j.u0).getString(b.a.j.y0);
            if (string == null) {
                iVar = new androidx.appcompat.app.i();
            } else {
                try {
                    this.m0 = (androidx.appcompat.app.i) Class.forName(string).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                } catch (Throwable th) {
                    Log.i("AppCompatDelegate", "Failed to instantiate custom view inflater " + string + ". Falling back to default.", th);
                    iVar = new androidx.appcompat.app.i();
                }
            }
            this.m0 = iVar;
        }
        boolean z3 = o0;
        if (z3) {
            if (!(attributeSet instanceof XmlPullParser)) {
                z2 = H0((ViewParent) view);
            } else if (((XmlPullParser) attributeSet).getDepth() > 1) {
                z2 = true;
            }
            z = z2;
        } else {
            z = false;
        }
        return this.m0.q(view, str, context, attributeSet, z, z3, true, b1.b());
    }

    void V() {
        androidx.appcompat.view.menu.g gVar;
        c0 c0Var = this.y;
        if (c0Var != null) {
            c0Var.k();
        }
        if (this.D != null) {
            this.s.getDecorView().removeCallbacks(this.E);
            if (this.D.isShowing()) {
                try {
                    this.D.dismiss();
                } catch (IllegalArgumentException unused) {
                }
            }
            this.D = null;
        }
        Y();
        t g0 = g0(0, false);
        if (g0 == null || (gVar = g0.f89j) == null) {
            return;
        }
        gVar.close();
    }

    boolean W(KeyEvent keyEvent) {
        View decorView;
        Object obj = this.q;
        if (((obj instanceof e.a) || (obj instanceof androidx.appcompat.app.h)) && (decorView = this.s.getDecorView()) != null && b.g.l.e.d(decorView, keyEvent)) {
            return true;
        }
        if (keyEvent.getKeyCode() == 82 && this.t.a().dispatchKeyEvent(keyEvent)) {
            return true;
        }
        int keyCode = keyEvent.getKeyCode();
        return keyEvent.getAction() == 0 ? s0(keyCode, keyEvent) : v0(keyCode, keyEvent);
    }

    void X(int i2) {
        t g0;
        t g02 = g0(i2, true);
        if (g02.f89j != null) {
            Bundle bundle = new Bundle();
            g02.f89j.Q(bundle);
            if (bundle.size() > 0) {
                g02.s = bundle;
            }
            g02.f89j.d0();
            g02.f89j.clear();
        }
        g02.r = true;
        g02.q = true;
        if ((i2 != 108 && i2 != 0) || this.y == null || (g0 = g0(0, false)) == null) {
            return;
        }
        g0.m = false;
        D0(g0, null);
    }

    void Y() {
        v vVar = this.F;
        if (vVar != null) {
            vVar.b();
        }
    }

    @Override // androidx.appcompat.view.menu.g.a
    public boolean a(androidx.appcompat.view.menu.g gVar, MenuItem menuItem) {
        t b0;
        Window.Callback i0 = i0();
        if (i0 == null || this.Z || (b0 = b0(gVar.D())) == null) {
            return false;
        }
        return i0.onMenuItemSelected(b0.f80a, menuItem);
    }

    @Override // androidx.appcompat.view.menu.g.a
    public void b(androidx.appcompat.view.menu.g gVar) {
        E0(true);
    }

    t b0(Menu menu) {
        t[] tVarArr = this.T;
        int length = tVarArr != null ? tVarArr.length : 0;
        for (int i2 = 0; i2 < length; i2++) {
            t tVar = tVarArr[i2];
            if (tVar != null && tVar.f89j == menu) {
                return tVar;
            }
        }
        return null;
    }

    @Override // androidx.appcompat.app.f
    public void d(View view, ViewGroup.LayoutParams layoutParams) {
        Z();
        ((ViewGroup) this.I.findViewById(android.R.id.content)).addView(view, layoutParams);
        this.t.a().onContentChanged();
    }

    final Context d0() {
        androidx.appcompat.app.a n2 = n();
        Context k2 = n2 != null ? n2.k() : null;
        return k2 == null ? this.r : k2;
    }

    @Override // androidx.appcompat.app.f
    public Context f(Context context) {
        this.W = true;
        int q02 = q0(context, M());
        if (r0 && (context instanceof ContextThemeWrapper)) {
            try {
                r.a((ContextThemeWrapper) context, S(context, q02, null));
                return context;
            } catch (IllegalStateException unused) {
            }
        }
        if (context instanceof b.a.n.d) {
            try {
                ((b.a.n.d) context).a(S(context, q02, null));
                return context;
            } catch (IllegalStateException unused2) {
            }
        }
        if (!q0) {
            super.f(context);
            return context;
        }
        try {
            Configuration configuration = context.getPackageManager().getResourcesForApplication(context.getApplicationInfo()).getConfiguration();
            Configuration configuration2 = context.getResources().getConfiguration();
            Configuration S = S(context, q02, configuration.equals(configuration2) ? null : c0(configuration, configuration2));
            b.a.n.d dVar = new b.a.n.d(context, b.a.i.f783c);
            dVar.a(S);
            boolean z = false;
            try {
                z = context.getTheme() != null;
            } catch (NullPointerException unused3) {
            }
            if (z) {
                f.d.a(dVar.getTheme());
            }
            super.f(dVar);
            return dVar;
        } catch (PackageManager.NameNotFoundException e2) {
            throw new RuntimeException("Application failed to obtain resources from itself", e2);
        }
    }

    protected t g0(int i2, boolean z) {
        t[] tVarArr = this.T;
        if (tVarArr == null || tVarArr.length <= i2) {
            t[] tVarArr2 = new t[i2 + 1];
            if (tVarArr != null) {
                System.arraycopy(tVarArr, 0, tVarArr2, 0, tVarArr.length);
            }
            this.T = tVarArr2;
            tVarArr = tVarArr2;
        }
        t tVar = tVarArr[i2];
        if (tVar != null) {
            return tVar;
        }
        t tVar2 = new t(i2);
        tVarArr[i2] = tVar2;
        return tVar2;
    }

    final CharSequence h0() {
        Object obj = this.q;
        return obj instanceof Activity ? ((Activity) obj).getTitle() : this.x;
    }

    @Override // androidx.appcompat.app.f
    public <T extends View> T i(int i2) {
        Z();
        return (T) this.s.findViewById(i2);
    }

    final Window.Callback i0() {
        return this.s.getCallback();
    }

    @Override // androidx.appcompat.app.f
    public final androidx.appcompat.app.b k() {
        return new h(this);
    }

    @Override // androidx.appcompat.app.f
    public int l() {
        return this.a0;
    }

    @Override // androidx.appcompat.app.f
    public MenuInflater m() {
        if (this.w == null) {
            j0();
            androidx.appcompat.app.a aVar = this.v;
            this.w = new b.a.n.g(aVar != null ? aVar.k() : this.r);
        }
        return this.w;
    }

    @Override // androidx.appcompat.app.f
    public androidx.appcompat.app.a n() {
        j0();
        return this.v;
    }

    @Override // androidx.appcompat.app.f
    public void o() {
        LayoutInflater from = LayoutInflater.from(this.r);
        if (from.getFactory() == null) {
            b.g.l.f.b(from, this);
        } else {
            if (from.getFactory2() instanceof g) {
                return;
            }
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    @Override // android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return U(view, str, context, attributeSet);
    }

    @Override // android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    @Override // androidx.appcompat.app.f
    public void p() {
        androidx.appcompat.app.a n2 = n();
        if (n2 == null || !n2.m()) {
            n0(0);
        }
    }

    public boolean p0() {
        return this.G;
    }

    @Override // androidx.appcompat.app.f
    public void q(Configuration configuration) {
        androidx.appcompat.app.a n2;
        if (this.N && this.H && (n2 = n()) != null) {
            n2.o(configuration);
        }
        androidx.appcompat.widget.j.b().g(this.r);
        J(false);
    }

    int q0(Context context, int i2) {
        m f0;
        if (i2 == -100) {
            return -1;
        }
        if (i2 != -1) {
            if (i2 != 0) {
                if (i2 != 1 && i2 != 2) {
                    if (i2 != 3) {
                        throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
                    }
                    f0 = e0(context);
                }
            } else {
                if (Build.VERSION.SDK_INT >= 23 && ((UiModeManager) context.getApplicationContext().getSystemService(UiModeManager.class)).getNightMode() == 0) {
                    return -1;
                }
                f0 = f0(context);
            }
            return f0.c();
        }
        return i2;
    }

    @Override // androidx.appcompat.app.f
    public void r(Bundle bundle) {
        this.W = true;
        J(false);
        a0();
        Object obj = this.q;
        if (obj instanceof Activity) {
            String str = null;
            try {
                str = androidx.core.app.g.c((Activity) obj);
            } catch (IllegalArgumentException unused) {
            }
            if (str != null) {
                androidx.appcompat.app.a B0 = B0();
                if (B0 == null) {
                    this.j0 = true;
                } else {
                    B0.u(true);
                }
            }
            androidx.appcompat.app.f.c(this);
        }
        this.X = true;
    }

    boolean r0() {
        b.a.n.b bVar = this.B;
        if (bVar != null) {
            bVar.c();
            return true;
        }
        androidx.appcompat.app.a n2 = n();
        return n2 != null && n2.h();
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x005b  */
    @Override // androidx.appcompat.app.f
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void s() {
        /*
            r3 = this;
            java.lang.Object r0 = r3.q
            boolean r0 = r0 instanceof android.app.Activity
            if (r0 == 0) goto L9
            androidx.appcompat.app.f.y(r3)
        L9:
            boolean r0 = r3.g0
            if (r0 == 0) goto L18
            android.view.Window r0 = r3.s
            android.view.View r0 = r0.getDecorView()
            java.lang.Runnable r1 = r3.i0
            r0.removeCallbacks(r1)
        L18:
            r0 = 0
            r3.Y = r0
            r0 = 1
            r3.Z = r0
            int r0 = r3.a0
            r1 = -100
            if (r0 == r1) goto L48
            java.lang.Object r0 = r3.q
            boolean r1 = r0 instanceof android.app.Activity
            if (r1 == 0) goto L48
            android.app.Activity r0 = (android.app.Activity) r0
            boolean r0 = r0.isChangingConfigurations()
            if (r0 == 0) goto L48
            b.e.g<java.lang.String, java.lang.Integer> r0 = androidx.appcompat.app.g.n0
            java.lang.Object r1 = r3.q
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            int r2 = r3.a0
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r0.put(r1, r2)
            goto L57
        L48:
            b.e.g<java.lang.String, java.lang.Integer> r0 = androidx.appcompat.app.g.n0
            java.lang.Object r1 = r3.q
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            r0.remove(r1)
        L57:
            androidx.appcompat.app.a r0 = r3.v
            if (r0 == 0) goto L5e
            r0.p()
        L5e:
            r3.P()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.g.s():void");
    }

    boolean s0(int i2, KeyEvent keyEvent) {
        if (i2 == 4) {
            this.V = (keyEvent.getFlags() & 128) != 0;
        } else if (i2 == 82) {
            t0(0, keyEvent);
            return true;
        }
        return false;
    }

    @Override // androidx.appcompat.app.f
    public void t(Bundle bundle) {
        Z();
    }

    @Override // androidx.appcompat.app.f
    public void u() {
        androidx.appcompat.app.a n2 = n();
        if (n2 != null) {
            n2.w(true);
        }
    }

    boolean u0(int i2, KeyEvent keyEvent) {
        androidx.appcompat.app.a n2 = n();
        if (n2 != null && n2.q(i2, keyEvent)) {
            return true;
        }
        t tVar = this.U;
        if (tVar != null && C0(tVar, keyEvent.getKeyCode(), keyEvent, 1)) {
            t tVar2 = this.U;
            if (tVar2 != null) {
                tVar2.n = true;
            }
            return true;
        }
        if (this.U == null) {
            t g0 = g0(0, true);
            D0(g0, keyEvent);
            boolean C0 = C0(g0, keyEvent.getKeyCode(), keyEvent, 1);
            g0.m = false;
            if (C0) {
                return true;
            }
        }
        return false;
    }

    @Override // androidx.appcompat.app.f
    public void v(Bundle bundle) {
    }

    boolean v0(int i2, KeyEvent keyEvent) {
        if (i2 == 4) {
            boolean z = this.V;
            this.V = false;
            t g0 = g0(0, false);
            if (g0 != null && g0.o) {
                if (!z) {
                    R(g0, true);
                }
                return true;
            }
            if (r0()) {
                return true;
            }
        } else if (i2 == 82) {
            w0(0, keyEvent);
            return true;
        }
        return false;
    }

    @Override // androidx.appcompat.app.f
    public void w() {
        this.Y = true;
        I();
    }

    @Override // androidx.appcompat.app.f
    public void x() {
        this.Y = false;
        androidx.appcompat.app.a n2 = n();
        if (n2 != null) {
            n2.w(false);
        }
    }

    void x0(int i2) {
        androidx.appcompat.app.a n2;
        if (i2 != 108 || (n2 = n()) == null) {
            return;
        }
        n2.i(true);
    }

    void y0(int i2) {
        if (i2 == 108) {
            androidx.appcompat.app.a n2 = n();
            if (n2 != null) {
                n2.i(false);
                return;
            }
            return;
        }
        if (i2 == 0) {
            t g0 = g0(i2, true);
            if (g0.o) {
                R(g0, false);
            }
        }
    }

    void z0(ViewGroup viewGroup) {
    }
}
