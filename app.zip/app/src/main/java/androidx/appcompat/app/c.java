package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AlertController;

/* loaded from: classes.dex */
public class c extends h implements DialogInterface {
    final AlertController p;

    public static class a {

        /* renamed from: a, reason: collision with root package name */
        private final AlertController.f f62a;

        /* renamed from: b, reason: collision with root package name */
        private final int f63b;

        public a(Context context) {
            this(context, c.f(context, 0));
        }

        public a(Context context, int i2) {
            this.f62a = new AlertController.f(new ContextThemeWrapper(context, c.f(context, i2)));
            this.f63b = i2;
        }

        public c a() {
            c cVar = new c(this.f62a.f49a, this.f63b);
            this.f62a.a(cVar.p);
            cVar.setCancelable(this.f62a.r);
            if (this.f62a.r) {
                cVar.setCanceledOnTouchOutside(true);
            }
            cVar.setOnCancelListener(this.f62a.s);
            cVar.setOnDismissListener(this.f62a.t);
            DialogInterface.OnKeyListener onKeyListener = this.f62a.u;
            if (onKeyListener != null) {
                cVar.setOnKeyListener(onKeyListener);
            }
            return cVar;
        }

        public Context b() {
            return this.f62a.f49a;
        }

        public a c(ListAdapter listAdapter, DialogInterface.OnClickListener onClickListener) {
            AlertController.f fVar = this.f62a;
            fVar.w = listAdapter;
            fVar.x = onClickListener;
            return this;
        }

        public a d(View view) {
            this.f62a.f55g = view;
            return this;
        }

        public a e(Drawable drawable) {
            this.f62a.f52d = drawable;
            return this;
        }

        public a f(CharSequence charSequence) {
            this.f62a.f56h = charSequence;
            return this;
        }

        public a g(int i2, DialogInterface.OnClickListener onClickListener) {
            AlertController.f fVar = this.f62a;
            fVar.l = fVar.f49a.getText(i2);
            this.f62a.n = onClickListener;
            return this;
        }

        public a h(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
            AlertController.f fVar = this.f62a;
            fVar.l = charSequence;
            fVar.n = onClickListener;
            return this;
        }

        public a i(DialogInterface.OnCancelListener onCancelListener) {
            this.f62a.s = onCancelListener;
            return this;
        }

        public a j(DialogInterface.OnKeyListener onKeyListener) {
            this.f62a.u = onKeyListener;
            return this;
        }

        public a k(int i2, DialogInterface.OnClickListener onClickListener) {
            AlertController.f fVar = this.f62a;
            fVar.f57i = fVar.f49a.getText(i2);
            this.f62a.f59k = onClickListener;
            return this;
        }

        public a l(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
            AlertController.f fVar = this.f62a;
            fVar.f57i = charSequence;
            fVar.f59k = onClickListener;
            return this;
        }

        public a m(ListAdapter listAdapter, int i2, DialogInterface.OnClickListener onClickListener) {
            AlertController.f fVar = this.f62a;
            fVar.w = listAdapter;
            fVar.x = onClickListener;
            fVar.I = i2;
            fVar.H = true;
            return this;
        }

        public a n(CharSequence charSequence) {
            this.f62a.f54f = charSequence;
            return this;
        }
    }

    protected c(Context context, int i2) {
        super(context, f(context, i2));
        this.p = new AlertController(getContext(), this, getWindow());
    }

    static int f(Context context, int i2) {
        if (((i2 >>> 24) & 255) >= 1) {
            return i2;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(b.a.a.o, typedValue, true);
        return typedValue.resourceId;
    }

    public ListView e() {
        return this.p.d();
    }

    public void g(View view) {
        this.p.s(view);
    }

    @Override // androidx.appcompat.app.h, android.app.Dialog
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.p.e();
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (this.p.g(i2, keyEvent)) {
            return true;
        }
        return super.onKeyDown(i2, keyEvent);
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i2, KeyEvent keyEvent) {
        if (this.p.h(i2, keyEvent)) {
            return true;
        }
        return super.onKeyUp(i2, keyEvent);
    }

    @Override // androidx.appcompat.app.h, android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        this.p.q(charSequence);
    }
}
