package androidx.appcompat.app;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.app.a;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.d0;
import androidx.appcompat.widget.p0;
import b.a.n.b;
import b.g.l.r;
import b.g.l.v;
import b.g.l.w;
import b.g.l.x;
import b.g.l.y;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class n extends androidx.appcompat.app.a implements ActionBarOverlayLayout.d {
    private static final Interpolator B = new AccelerateInterpolator();
    private static final Interpolator C = new DecelerateInterpolator();
    final y A;

    /* renamed from: a, reason: collision with root package name */
    Context f127a;

    /* renamed from: b, reason: collision with root package name */
    private Context f128b;

    /* renamed from: c, reason: collision with root package name */
    ActionBarOverlayLayout f129c;

    /* renamed from: d, reason: collision with root package name */
    ActionBarContainer f130d;

    /* renamed from: e, reason: collision with root package name */
    d0 f131e;

    /* renamed from: f, reason: collision with root package name */
    ActionBarContextView f132f;

    /* renamed from: g, reason: collision with root package name */
    View f133g;

    /* renamed from: h, reason: collision with root package name */
    p0 f134h;

    /* renamed from: i, reason: collision with root package name */
    private boolean f135i;

    /* renamed from: j, reason: collision with root package name */
    d f136j;

    /* renamed from: k, reason: collision with root package name */
    b.a.n.b f137k;
    b.a l;
    private boolean m;
    private ArrayList<a.b> n;
    private boolean o;
    private int p;
    boolean q;
    boolean r;
    boolean s;
    private boolean t;
    private boolean u;
    b.a.n.h v;
    private boolean w;
    boolean x;
    final w y;
    final w z;

    class a extends x {
        a() {
        }

        @Override // b.g.l.w
        public void b(View view) {
            View view2;
            n nVar = n.this;
            if (nVar.q && (view2 = nVar.f133g) != null) {
                view2.setTranslationY(0.0f);
                n.this.f130d.setTranslationY(0.0f);
            }
            n.this.f130d.setVisibility(8);
            n.this.f130d.setTransitioning(false);
            n nVar2 = n.this;
            nVar2.v = null;
            nVar2.D();
            ActionBarOverlayLayout actionBarOverlayLayout = n.this.f129c;
            if (actionBarOverlayLayout != null) {
                r.I(actionBarOverlayLayout);
            }
        }
    }

    class b extends x {
        b() {
        }

        @Override // b.g.l.w
        public void b(View view) {
            n nVar = n.this;
            nVar.v = null;
            nVar.f130d.requestLayout();
        }
    }

    class c implements y {
        c() {
        }

        @Override // b.g.l.y
        public void a(View view) {
            ((View) n.this.f130d.getParent()).invalidate();
        }
    }

    public class d extends b.a.n.b implements g.a {
        private final Context p;
        private final androidx.appcompat.view.menu.g q;
        private b.a r;
        private WeakReference<View> s;

        public d(Context context, b.a aVar) {
            this.p = context;
            this.r = aVar;
            androidx.appcompat.view.menu.g gVar = new androidx.appcompat.view.menu.g(context);
            gVar.S(1);
            this.q = gVar;
            gVar.R(this);
        }

        @Override // androidx.appcompat.view.menu.g.a
        public boolean a(androidx.appcompat.view.menu.g gVar, MenuItem menuItem) {
            b.a aVar = this.r;
            if (aVar != null) {
                return aVar.c(this, menuItem);
            }
            return false;
        }

        @Override // androidx.appcompat.view.menu.g.a
        public void b(androidx.appcompat.view.menu.g gVar) {
            if (this.r == null) {
                return;
            }
            k();
            n.this.f132f.l();
        }

        @Override // b.a.n.b
        public void c() {
            n nVar = n.this;
            if (nVar.f136j != this) {
                return;
            }
            if (n.C(nVar.r, nVar.s, false)) {
                this.r.b(this);
            } else {
                n nVar2 = n.this;
                nVar2.f137k = this;
                nVar2.l = this.r;
            }
            this.r = null;
            n.this.B(false);
            n.this.f132f.g();
            n.this.f131e.n().sendAccessibilityEvent(32);
            n nVar3 = n.this;
            nVar3.f129c.setHideOnContentScrollEnabled(nVar3.x);
            n.this.f136j = null;
        }

        @Override // b.a.n.b
        public View d() {
            WeakReference<View> weakReference = this.s;
            if (weakReference != null) {
                return weakReference.get();
            }
            return null;
        }

        @Override // b.a.n.b
        public Menu e() {
            return this.q;
        }

        @Override // b.a.n.b
        public MenuInflater f() {
            return new b.a.n.g(this.p);
        }

        @Override // b.a.n.b
        public CharSequence g() {
            return n.this.f132f.getSubtitle();
        }

        @Override // b.a.n.b
        public CharSequence i() {
            return n.this.f132f.getTitle();
        }

        @Override // b.a.n.b
        public void k() {
            if (n.this.f136j != this) {
                return;
            }
            this.q.d0();
            try {
                this.r.a(this, this.q);
            } finally {
                this.q.c0();
            }
        }

        @Override // b.a.n.b
        public boolean l() {
            return n.this.f132f.j();
        }

        @Override // b.a.n.b
        public void m(View view) {
            n.this.f132f.setCustomView(view);
            this.s = new WeakReference<>(view);
        }

        @Override // b.a.n.b
        public void n(int i2) {
            o(n.this.f127a.getResources().getString(i2));
        }

        @Override // b.a.n.b
        public void o(CharSequence charSequence) {
            n.this.f132f.setSubtitle(charSequence);
        }

        @Override // b.a.n.b
        public void q(int i2) {
            r(n.this.f127a.getResources().getString(i2));
        }

        @Override // b.a.n.b
        public void r(CharSequence charSequence) {
            n.this.f132f.setTitle(charSequence);
        }

        @Override // b.a.n.b
        public void s(boolean z) {
            super.s(z);
            n.this.f132f.setTitleOptional(z);
        }

        public boolean t() {
            this.q.d0();
            try {
                return this.r.d(this, this.q);
            } finally {
                this.q.c0();
            }
        }
    }

    public n(Activity activity, boolean z) {
        new ArrayList();
        this.n = new ArrayList<>();
        this.p = 0;
        this.q = true;
        this.u = true;
        this.y = new a();
        this.z = new b();
        this.A = new c();
        View decorView = activity.getWindow().getDecorView();
        L(decorView);
        if (z) {
            return;
        }
        this.f133g = decorView.findViewById(R.id.content);
    }

    public n(Dialog dialog) {
        new ArrayList();
        this.n = new ArrayList<>();
        this.p = 0;
        this.q = true;
        this.u = true;
        this.y = new a();
        this.z = new b();
        this.A = new c();
        L(dialog.getWindow().getDecorView());
    }

    static boolean C(boolean z, boolean z2, boolean z3) {
        if (z3) {
            return true;
        }
        return (z || z2) ? false : true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private d0 G(View view) {
        if (view instanceof d0) {
            return (d0) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Can't make a decor toolbar out of ");
        sb.append(view != 0 ? view.getClass().getSimpleName() : "null");
        throw new IllegalStateException(sb.toString());
    }

    private void K() {
        if (this.t) {
            this.t = false;
            ActionBarOverlayLayout actionBarOverlayLayout = this.f129c;
            if (actionBarOverlayLayout != null) {
                actionBarOverlayLayout.setShowingForActionMode(false);
            }
            U(false);
        }
    }

    private void L(View view) {
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(b.a.f.p);
        this.f129c = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        this.f131e = G(view.findViewById(b.a.f.f748a));
        this.f132f = (ActionBarContextView) view.findViewById(b.a.f.f753f);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(b.a.f.f750c);
        this.f130d = actionBarContainer;
        d0 d0Var = this.f131e;
        if (d0Var == null || this.f132f == null || actionBarContainer == null) {
            throw new IllegalStateException(n.class.getSimpleName() + " can only be used with a compatible window decor layout");
        }
        this.f127a = d0Var.a();
        boolean z = (this.f131e.s() & 4) != 0;
        if (z) {
            this.f135i = true;
        }
        b.a.n.a b2 = b.a.n.a.b(this.f127a);
        R(b2.a() || z);
        P(b2.g());
        TypedArray obtainStyledAttributes = this.f127a.obtainStyledAttributes(null, b.a.j.f785a, b.a.a.f708c, 0);
        if (obtainStyledAttributes.getBoolean(b.a.j.f795k, false)) {
            Q(true);
        }
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(b.a.j.f793i, 0);
        if (dimensionPixelSize != 0) {
            O(dimensionPixelSize);
        }
        obtainStyledAttributes.recycle();
    }

    private void P(boolean z) {
        this.o = z;
        if (z) {
            this.f130d.setTabContainer(null);
            this.f131e.m(this.f134h);
        } else {
            this.f131e.m(null);
            this.f130d.setTabContainer(this.f134h);
        }
        boolean z2 = J() == 2;
        p0 p0Var = this.f134h;
        if (p0Var != null) {
            if (z2) {
                p0Var.setVisibility(0);
                ActionBarOverlayLayout actionBarOverlayLayout = this.f129c;
                if (actionBarOverlayLayout != null) {
                    r.I(actionBarOverlayLayout);
                }
            } else {
                p0Var.setVisibility(8);
            }
        }
        this.f131e.z(!this.o && z2);
        this.f129c.setHasNonEmbeddedTabs(!this.o && z2);
    }

    private boolean S() {
        return r.y(this.f130d);
    }

    private void T() {
        if (this.t) {
            return;
        }
        this.t = true;
        ActionBarOverlayLayout actionBarOverlayLayout = this.f129c;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setShowingForActionMode(true);
        }
        U(false);
    }

    private void U(boolean z) {
        if (C(this.r, this.s, this.t)) {
            if (this.u) {
                return;
            }
            this.u = true;
            F(z);
            return;
        }
        if (this.u) {
            this.u = false;
            E(z);
        }
    }

    @Override // androidx.appcompat.app.a
    public b.a.n.b A(b.a aVar) {
        d dVar = this.f136j;
        if (dVar != null) {
            dVar.c();
        }
        this.f129c.setHideOnContentScrollEnabled(false);
        this.f132f.k();
        d dVar2 = new d(this.f132f.getContext(), aVar);
        if (!dVar2.t()) {
            return null;
        }
        this.f136j = dVar2;
        dVar2.k();
        this.f132f.h(dVar2);
        B(true);
        this.f132f.sendAccessibilityEvent(32);
        return dVar2;
    }

    public void B(boolean z) {
        v w;
        v f2;
        if (z) {
            T();
        } else {
            K();
        }
        if (!S()) {
            if (z) {
                this.f131e.l(4);
                this.f132f.setVisibility(0);
                return;
            } else {
                this.f131e.l(0);
                this.f132f.setVisibility(8);
                return;
            }
        }
        if (z) {
            f2 = this.f131e.w(4, 100L);
            w = this.f132f.f(0, 200L);
        } else {
            w = this.f131e.w(0, 200L);
            f2 = this.f132f.f(8, 100L);
        }
        b.a.n.h hVar = new b.a.n.h();
        hVar.d(f2, w);
        hVar.h();
    }

    void D() {
        b.a aVar = this.l;
        if (aVar != null) {
            aVar.b(this.f137k);
            this.f137k = null;
            this.l = null;
        }
    }

    public void E(boolean z) {
        View view;
        b.a.n.h hVar = this.v;
        if (hVar != null) {
            hVar.a();
        }
        if (this.p != 0 || (!this.w && !z)) {
            this.y.b(null);
            return;
        }
        this.f130d.setAlpha(1.0f);
        this.f130d.setTransitioning(true);
        b.a.n.h hVar2 = new b.a.n.h();
        float f2 = -this.f130d.getHeight();
        if (z) {
            this.f130d.getLocationInWindow(new int[]{0, 0});
            f2 -= r5[1];
        }
        v b2 = r.b(this.f130d);
        b2.k(f2);
        b2.i(this.A);
        hVar2.c(b2);
        if (this.q && (view = this.f133g) != null) {
            v b3 = r.b(view);
            b3.k(f2);
            hVar2.c(b3);
        }
        hVar2.f(B);
        hVar2.e(250L);
        hVar2.g(this.y);
        this.v = hVar2;
        hVar2.h();
    }

    public void F(boolean z) {
        View view;
        View view2;
        b.a.n.h hVar = this.v;
        if (hVar != null) {
            hVar.a();
        }
        this.f130d.setVisibility(0);
        if (this.p == 0 && (this.w || z)) {
            this.f130d.setTranslationY(0.0f);
            float f2 = -this.f130d.getHeight();
            if (z) {
                this.f130d.getLocationInWindow(new int[]{0, 0});
                f2 -= r5[1];
            }
            this.f130d.setTranslationY(f2);
            b.a.n.h hVar2 = new b.a.n.h();
            v b2 = r.b(this.f130d);
            b2.k(0.0f);
            b2.i(this.A);
            hVar2.c(b2);
            if (this.q && (view2 = this.f133g) != null) {
                view2.setTranslationY(f2);
                v b3 = r.b(this.f133g);
                b3.k(0.0f);
                hVar2.c(b3);
            }
            hVar2.f(C);
            hVar2.e(250L);
            hVar2.g(this.z);
            this.v = hVar2;
            hVar2.h();
        } else {
            this.f130d.setAlpha(1.0f);
            this.f130d.setTranslationY(0.0f);
            if (this.q && (view = this.f133g) != null) {
                view.setTranslationY(0.0f);
            }
            this.z.b(null);
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.f129c;
        if (actionBarOverlayLayout != null) {
            r.I(actionBarOverlayLayout);
        }
    }

    public int H() {
        return this.f130d.getHeight();
    }

    public int I() {
        return this.f129c.getActionBarHideOffset();
    }

    public int J() {
        return this.f131e.v();
    }

    public void M(boolean z) {
        N(z ? 4 : 0, 4);
    }

    public void N(int i2, int i3) {
        int s = this.f131e.s();
        if ((i3 & 4) != 0) {
            this.f135i = true;
        }
        this.f131e.r((i2 & i3) | ((~i3) & s));
    }

    public void O(float f2) {
        r.P(this.f130d, f2);
    }

    public void Q(boolean z) {
        if (z && !this.f129c.q()) {
            throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
        }
        this.x = z;
        this.f129c.setHideOnContentScrollEnabled(z);
    }

    public void R(boolean z) {
        this.f131e.o(z);
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void a() {
        if (this.s) {
            this.s = false;
            U(true);
        }
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void b() {
        b.a.n.h hVar = this.v;
        if (hVar != null) {
            hVar.a();
            this.v = null;
        }
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void c(int i2) {
        this.p = i2;
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void d() {
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void e(boolean z) {
        this.q = z;
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void f() {
        if (this.s) {
            return;
        }
        this.s = true;
        U(true);
    }

    @Override // androidx.appcompat.app.a
    public boolean h() {
        d0 d0Var = this.f131e;
        if (d0Var == null || !d0Var.q()) {
            return false;
        }
        this.f131e.collapseActionView();
        return true;
    }

    @Override // androidx.appcompat.app.a
    public void i(boolean z) {
        if (z == this.m) {
            return;
        }
        this.m = z;
        int size = this.n.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.n.get(i2).a(z);
        }
    }

    @Override // androidx.appcompat.app.a
    public int j() {
        return this.f131e.s();
    }

    @Override // androidx.appcompat.app.a
    public Context k() {
        if (this.f128b == null) {
            TypedValue typedValue = new TypedValue();
            this.f127a.getTheme().resolveAttribute(b.a.a.f712g, typedValue, true);
            int i2 = typedValue.resourceId;
            if (i2 != 0) {
                this.f128b = new ContextThemeWrapper(this.f127a, i2);
            } else {
                this.f128b = this.f127a;
            }
        }
        return this.f128b;
    }

    @Override // androidx.appcompat.app.a
    public void l() {
        if (this.r) {
            return;
        }
        this.r = true;
        U(false);
    }

    @Override // androidx.appcompat.app.a
    public boolean n() {
        int H = H();
        return this.u && (H == 0 || I() < H);
    }

    @Override // androidx.appcompat.app.a
    public void o(Configuration configuration) {
        P(b.a.n.a.b(this.f127a).g());
    }

    @Override // androidx.appcompat.app.a
    public boolean q(int i2, KeyEvent keyEvent) {
        Menu e2;
        d dVar = this.f136j;
        if (dVar == null || (e2 = dVar.e()) == null) {
            return false;
        }
        e2.setQwertyMode(KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1);
        return e2.performShortcut(i2, keyEvent, 0);
    }

    @Override // androidx.appcompat.app.a
    public void t(Drawable drawable) {
        this.f130d.setPrimaryBackground(drawable);
    }

    @Override // androidx.appcompat.app.a
    public void u(boolean z) {
        if (this.f135i) {
            return;
        }
        M(z);
    }

    @Override // androidx.appcompat.app.a
    public void v(boolean z) {
        N(z ? 8 : 0, 8);
    }

    @Override // androidx.appcompat.app.a
    public void w(boolean z) {
        b.a.n.h hVar;
        this.w = z;
        if (z || (hVar = this.v) == null) {
            return;
        }
        hVar.a();
    }

    @Override // androidx.appcompat.app.a
    public void x(CharSequence charSequence) {
        this.f131e.setTitle(charSequence);
    }

    @Override // androidx.appcompat.app.a
    public void y(CharSequence charSequence) {
        this.f131e.setWindowTitle(charSequence);
    }

    @Override // androidx.appcompat.app.a
    public void z() {
        if (this.r) {
            this.r = false;
            U(false);
        }
    }
}
