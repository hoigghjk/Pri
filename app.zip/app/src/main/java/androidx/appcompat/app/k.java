package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.appcompat.app.a;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.d0;
import androidx.appcompat.widget.x0;
import b.g.l.r;
import com.pichillilorenzo.flutter_inappwebview.R;
import java.util.ArrayList;

/* loaded from: classes.dex */
class k extends androidx.appcompat.app.a {

    /* renamed from: a, reason: collision with root package name */
    d0 f104a;

    /* renamed from: b, reason: collision with root package name */
    boolean f105b;

    /* renamed from: c, reason: collision with root package name */
    Window.Callback f106c;

    /* renamed from: d, reason: collision with root package name */
    private boolean f107d;

    /* renamed from: e, reason: collision with root package name */
    private boolean f108e;

    /* renamed from: f, reason: collision with root package name */
    private ArrayList<a.b> f109f = new ArrayList<>();

    /* renamed from: g, reason: collision with root package name */
    private final Runnable f110g = new a();

    /* renamed from: h, reason: collision with root package name */
    private final Toolbar.f f111h;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            k.this.D();
        }
    }

    class b implements Toolbar.f {
        b() {
        }

        @Override // androidx.appcompat.widget.Toolbar.f
        public boolean onMenuItemClick(MenuItem menuItem) {
            return k.this.f106c.onMenuItemSelected(0, menuItem);
        }
    }

    private final class c implements m.a {
        private boolean n;

        c() {
        }

        @Override // androidx.appcompat.view.menu.m.a
        public void b(androidx.appcompat.view.menu.g gVar, boolean z) {
            if (this.n) {
                return;
            }
            this.n = true;
            k.this.f104a.j();
            Window.Callback callback = k.this.f106c;
            if (callback != null) {
                callback.onPanelClosed(R.styleable.AppCompatTheme_textColorAlertDialogListItem, gVar);
            }
            this.n = false;
        }

        @Override // androidx.appcompat.view.menu.m.a
        public boolean c(androidx.appcompat.view.menu.g gVar) {
            Window.Callback callback = k.this.f106c;
            if (callback == null) {
                return false;
            }
            callback.onMenuOpened(R.styleable.AppCompatTheme_textColorAlertDialogListItem, gVar);
            return true;
        }
    }

    private final class d implements g.a {
        d() {
        }

        @Override // androidx.appcompat.view.menu.g.a
        public boolean a(androidx.appcompat.view.menu.g gVar, MenuItem menuItem) {
            return false;
        }

        @Override // androidx.appcompat.view.menu.g.a
        public void b(androidx.appcompat.view.menu.g gVar) {
            k kVar = k.this;
            if (kVar.f106c != null) {
                if (kVar.f104a.c()) {
                    k.this.f106c.onPanelClosed(R.styleable.AppCompatTheme_textColorAlertDialogListItem, gVar);
                } else if (k.this.f106c.onPreparePanel(0, null, gVar)) {
                    k.this.f106c.onMenuOpened(R.styleable.AppCompatTheme_textColorAlertDialogListItem, gVar);
                }
            }
        }
    }

    private class e extends b.a.n.i {
        public e(Window.Callback callback) {
            super(callback);
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public View onCreatePanelView(int i2) {
            return i2 == 0 ? new View(k.this.f104a.a()) : super.onCreatePanelView(i2);
        }

        @Override // b.a.n.i, android.view.Window.Callback
        public boolean onPreparePanel(int i2, View view, Menu menu) {
            boolean onPreparePanel = super.onPreparePanel(i2, view, menu);
            if (onPreparePanel) {
                k kVar = k.this;
                if (!kVar.f105b) {
                    kVar.f104a.d();
                    k.this.f105b = true;
                }
            }
            return onPreparePanel;
        }
    }

    k(Toolbar toolbar, CharSequence charSequence, Window.Callback callback) {
        b bVar = new b();
        this.f111h = bVar;
        this.f104a = new x0(toolbar, false);
        e eVar = new e(callback);
        this.f106c = eVar;
        this.f104a.setWindowCallback(eVar);
        toolbar.setOnMenuItemClickListener(bVar);
        this.f104a.setWindowTitle(charSequence);
    }

    private Menu B() {
        if (!this.f107d) {
            this.f104a.k(new c(), new d());
            this.f107d = true;
        }
        return this.f104a.t();
    }

    public Window.Callback C() {
        return this.f106c;
    }

    void D() {
        Menu B = B();
        androidx.appcompat.view.menu.g gVar = B instanceof androidx.appcompat.view.menu.g ? (androidx.appcompat.view.menu.g) B : null;
        if (gVar != null) {
            gVar.d0();
        }
        try {
            B.clear();
            if (!this.f106c.onCreatePanelMenu(0, B) || !this.f106c.onPreparePanel(0, null, B)) {
                B.clear();
            }
        } finally {
            if (gVar != null) {
                gVar.c0();
            }
        }
    }

    public void E(int i2, int i3) {
        this.f104a.r((i2 & i3) | ((~i3) & this.f104a.s()));
    }

    @Override // androidx.appcompat.app.a
    public boolean g() {
        return this.f104a.g();
    }

    @Override // androidx.appcompat.app.a
    public boolean h() {
        if (!this.f104a.q()) {
            return false;
        }
        this.f104a.collapseActionView();
        return true;
    }

    @Override // androidx.appcompat.app.a
    public void i(boolean z) {
        if (z == this.f108e) {
            return;
        }
        this.f108e = z;
        int size = this.f109f.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f109f.get(i2).a(z);
        }
    }

    @Override // androidx.appcompat.app.a
    public int j() {
        return this.f104a.s();
    }

    @Override // androidx.appcompat.app.a
    public Context k() {
        return this.f104a.a();
    }

    @Override // androidx.appcompat.app.a
    public void l() {
        this.f104a.l(8);
    }

    @Override // androidx.appcompat.app.a
    public boolean m() {
        this.f104a.n().removeCallbacks(this.f110g);
        r.G(this.f104a.n(), this.f110g);
        return true;
    }

    @Override // androidx.appcompat.app.a
    public boolean n() {
        return this.f104a.p() == 0;
    }

    @Override // androidx.appcompat.app.a
    public void o(Configuration configuration) {
        super.o(configuration);
    }

    @Override // androidx.appcompat.app.a
    void p() {
        this.f104a.n().removeCallbacks(this.f110g);
    }

    @Override // androidx.appcompat.app.a
    public boolean q(int i2, KeyEvent keyEvent) {
        Menu B = B();
        if (B == null) {
            return false;
        }
        B.setQwertyMode(KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1);
        return B.performShortcut(i2, keyEvent, 0);
    }

    @Override // androidx.appcompat.app.a
    public boolean r(KeyEvent keyEvent) {
        if (keyEvent.getAction() == 1) {
            s();
        }
        return true;
    }

    @Override // androidx.appcompat.app.a
    public boolean s() {
        return this.f104a.h();
    }

    @Override // androidx.appcompat.app.a
    public void t(Drawable drawable) {
        this.f104a.e(drawable);
    }

    @Override // androidx.appcompat.app.a
    public void u(boolean z) {
    }

    @Override // androidx.appcompat.app.a
    public void v(boolean z) {
        E(z ? 8 : 0, 8);
    }

    @Override // androidx.appcompat.app.a
    public void w(boolean z) {
    }

    @Override // androidx.appcompat.app.a
    public void x(CharSequence charSequence) {
        this.f104a.setTitle(charSequence);
    }

    @Override // androidx.appcompat.app.a
    public void y(CharSequence charSequence) {
        this.f104a.setWindowTitle(charSequence);
    }

    @Override // androidx.appcompat.app.a
    public void z() {
        this.f104a.l(0);
    }
}
