package androidx.appcompat.app;

import android.R;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.appcompat.widget.b0;
import androidx.appcompat.widget.o;
import androidx.appcompat.widget.p;
import androidx.appcompat.widget.s;
import androidx.appcompat.widget.t;
import androidx.appcompat.widget.t0;
import androidx.appcompat.widget.u;
import androidx.appcompat.widget.w;
import androidx.appcompat.widget.z;
import b.g.l.r;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public class i {

    /* renamed from: b, reason: collision with root package name */
    private static final Class<?>[] f91b = {Context.class, AttributeSet.class};

    /* renamed from: c, reason: collision with root package name */
    private static final int[] f92c = {R.attr.onClick};

    /* renamed from: d, reason: collision with root package name */
    private static final String[] f93d = {"android.widget.", "android.view.", "android.webkit."};

    /* renamed from: e, reason: collision with root package name */
    private static final b.e.g<String, Constructor<? extends View>> f94e = new b.e.g<>();

    /* renamed from: a, reason: collision with root package name */
    private final Object[] f95a = new Object[2];

    private static class a implements View.OnClickListener {
        private final View n;
        private final String o;
        private Method p;
        private Context q;

        public a(View view, String str) {
            this.n = view;
            this.o = str;
        }

        private void a(Context context) {
            String str;
            Method method;
            while (context != null) {
                try {
                    if (!context.isRestricted() && (method = context.getClass().getMethod(this.o, View.class)) != null) {
                        this.p = method;
                        this.q = context;
                        return;
                    }
                } catch (NoSuchMethodException unused) {
                }
                context = context instanceof ContextWrapper ? ((ContextWrapper) context).getBaseContext() : null;
            }
            int id = this.n.getId();
            if (id == -1) {
                str = "";
            } else {
                str = " with id '" + this.n.getContext().getResources().getResourceEntryName(id) + "'";
            }
            throw new IllegalStateException("Could not find method " + this.o + "(View) in a parent or ancestor Context for android:onClick attribute defined on view " + this.n.getClass() + str);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (this.p == null) {
                a(this.n.getContext());
            }
            try {
                this.p.invoke(this.q, view);
            } catch (IllegalAccessException e2) {
                throw new IllegalStateException("Could not execute non-public method for android:onClick", e2);
            } catch (InvocationTargetException e3) {
                throw new IllegalStateException("Could not execute method for android:onClick", e3);
            }
        }
    }

    private void a(View view, AttributeSet attributeSet) {
        Context context = view.getContext();
        if (context instanceof ContextWrapper) {
            if (Build.VERSION.SDK_INT < 15 || r.v(view)) {
                TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f92c);
                String string = obtainStyledAttributes.getString(0);
                if (string != null) {
                    view.setOnClickListener(new a(view, string));
                }
                obtainStyledAttributes.recycle();
            }
        }
    }

    private View r(Context context, String str, String str2) {
        String str3;
        b.e.g<String, Constructor<? extends View>> gVar = f94e;
        Constructor<? extends View> constructor = gVar.get(str);
        if (constructor == null) {
            if (str2 != null) {
                try {
                    str3 = str2 + str;
                } catch (Exception unused) {
                    return null;
                }
            } else {
                str3 = str;
            }
            constructor = Class.forName(str3, false, context.getClassLoader()).asSubclass(View.class).getConstructor(f91b);
            gVar.put(str, constructor);
        }
        constructor.setAccessible(true);
        return constructor.newInstance(this.f95a);
    }

    private View s(Context context, String str, AttributeSet attributeSet) {
        if (str.equals("view")) {
            str = attributeSet.getAttributeValue(null, "class");
        }
        try {
            Object[] objArr = this.f95a;
            objArr[0] = context;
            objArr[1] = attributeSet;
            if (-1 != str.indexOf(46)) {
                return r(context, str, null);
            }
            int i2 = 0;
            while (true) {
                String[] strArr = f93d;
                if (i2 >= strArr.length) {
                    return null;
                }
                View r = r(context, str, strArr[i2]);
                if (r != null) {
                    return r;
                }
                i2++;
            }
        } catch (Exception unused) {
            return null;
        } finally {
            Object[] objArr2 = this.f95a;
            objArr2[0] = null;
            objArr2[1] = null;
        }
    }

    private static Context t(Context context, AttributeSet attributeSet, boolean z, boolean z2) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.a.j.l3, 0, 0);
        int resourceId = z ? obtainStyledAttributes.getResourceId(b.a.j.m3, 0) : 0;
        if (z2 && resourceId == 0 && (resourceId = obtainStyledAttributes.getResourceId(b.a.j.n3, 0)) != 0) {
            Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
        }
        obtainStyledAttributes.recycle();
        return resourceId != 0 ? ((context instanceof b.a.n.d) && ((b.a.n.d) context).c() == resourceId) ? context : new b.a.n.d(context, resourceId) : context;
    }

    private void u(View view, String str) {
        if (view != null) {
            return;
        }
        throw new IllegalStateException(i.class.getName() + " asked to inflate view for <" + str + ">, but returned null");
    }

    protected androidx.appcompat.widget.d b(Context context, AttributeSet attributeSet) {
        return new androidx.appcompat.widget.d(context, attributeSet);
    }

    protected androidx.appcompat.widget.f c(Context context, AttributeSet attributeSet) {
        return new androidx.appcompat.widget.f(context, attributeSet);
    }

    protected androidx.appcompat.widget.g d(Context context, AttributeSet attributeSet) {
        return new androidx.appcompat.widget.g(context, attributeSet);
    }

    protected androidx.appcompat.widget.h e(Context context, AttributeSet attributeSet) {
        return new androidx.appcompat.widget.h(context, attributeSet);
    }

    protected androidx.appcompat.widget.k f(Context context, AttributeSet attributeSet) {
        return new androidx.appcompat.widget.k(context, attributeSet);
    }

    protected androidx.appcompat.widget.m g(Context context, AttributeSet attributeSet) {
        return new androidx.appcompat.widget.m(context, attributeSet);
    }

    protected o h(Context context, AttributeSet attributeSet) {
        return new o(context, attributeSet);
    }

    protected p i(Context context, AttributeSet attributeSet) {
        return new p(context, attributeSet);
    }

    protected s j(Context context, AttributeSet attributeSet) {
        return new s(context, attributeSet);
    }

    protected t k(Context context, AttributeSet attributeSet) {
        return new t(context, attributeSet);
    }

    protected u l(Context context, AttributeSet attributeSet) {
        return new u(context, attributeSet);
    }

    protected w m(Context context, AttributeSet attributeSet) {
        return new w(context, attributeSet);
    }

    protected z n(Context context, AttributeSet attributeSet) {
        return new z(context, attributeSet);
    }

    protected b0 o(Context context, AttributeSet attributeSet) {
        return new b0(context, attributeSet);
    }

    protected View p(Context context, String str, AttributeSet attributeSet) {
        return null;
    }

    final View q(View view, String str, Context context, AttributeSet attributeSet, boolean z, boolean z2, boolean z3, boolean z4) {
        Context context2;
        View k2;
        context2 = (!z || view == null) ? context : view.getContext();
        if (z2 || z3) {
            context2 = t(context2, attributeSet, z2, z3);
        }
        if (z4) {
            context2 = t0.b(context2);
        }
        str.hashCode();
        switch (str) {
            case "RatingBar":
                k2 = k(context2, attributeSet);
                u(k2, str);
                break;
            case "CheckedTextView":
                k2 = e(context2, attributeSet);
                u(k2, str);
                break;
            case "MultiAutoCompleteTextView":
                k2 = i(context2, attributeSet);
                u(k2, str);
                break;
            case "TextView":
                k2 = n(context2, attributeSet);
                u(k2, str);
                break;
            case "ImageButton":
                k2 = g(context2, attributeSet);
                u(k2, str);
                break;
            case "SeekBar":
                k2 = l(context2, attributeSet);
                u(k2, str);
                break;
            case "Spinner":
                k2 = m(context2, attributeSet);
                u(k2, str);
                break;
            case "RadioButton":
                k2 = j(context2, attributeSet);
                u(k2, str);
                break;
            case "ToggleButton":
                k2 = o(context2, attributeSet);
                u(k2, str);
                break;
            case "ImageView":
                k2 = h(context2, attributeSet);
                u(k2, str);
                break;
            case "AutoCompleteTextView":
                k2 = b(context2, attributeSet);
                u(k2, str);
                break;
            case "CheckBox":
                k2 = d(context2, attributeSet);
                u(k2, str);
                break;
            case "EditText":
                k2 = f(context2, attributeSet);
                u(k2, str);
                break;
            case "Button":
                k2 = c(context2, attributeSet);
                u(k2, str);
                break;
            default:
                k2 = p(context2, str, attributeSet);
                break;
        }
        if (k2 == null && context != context2) {
            k2 = s(context2, str, attributeSet);
        }
        if (k2 != null) {
            a(k2, attributeSet);
        }
        return k2;
    }
}
