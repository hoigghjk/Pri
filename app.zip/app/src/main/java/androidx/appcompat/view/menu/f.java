package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.n;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class f extends BaseAdapter {
    g n;
    private int o = -1;
    private boolean p;
    private final boolean q;
    private final LayoutInflater r;
    private final int s;

    public f(g gVar, LayoutInflater layoutInflater, boolean z, int i2) {
        this.q = z;
        this.r = layoutInflater;
        this.n = gVar;
        this.s = i2;
        a();
    }

    void a() {
        i v = this.n.v();
        if (v != null) {
            ArrayList<i> z = this.n.z();
            int size = z.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (z.get(i2) == v) {
                    this.o = i2;
                    return;
                }
            }
        }
        this.o = -1;
    }

    public g b() {
        return this.n;
    }

    @Override // android.widget.Adapter
    /* renamed from: c, reason: merged with bridge method [inline-methods] */
    public i getItem(int i2) {
        ArrayList<i> z = this.q ? this.n.z() : this.n.E();
        int i3 = this.o;
        if (i3 >= 0 && i2 >= i3) {
            i2++;
        }
        return z.get(i2);
    }

    public void d(boolean z) {
        this.p = z;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        ArrayList<i> z = this.q ? this.n.z() : this.n.E();
        int i2 = this.o;
        int size = z.size();
        return i2 < 0 ? size : size - 1;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i2) {
        return i2;
    }

    @Override // android.widget.Adapter
    public View getView(int i2, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.r.inflate(this.s, viewGroup, false);
        }
        int groupId = getItem(i2).getGroupId();
        int i3 = i2 - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.setGroupDividerEnabled(this.n.F() && groupId != (i3 >= 0 ? getItem(i3).getGroupId() : groupId));
        n.a aVar = (n.a) view;
        if (this.p) {
            listMenuItemView.setForceShowIcon(true);
        }
        aVar.d(getItem(i2), 0);
        return view;
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
