package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.k0;
import androidx.appcompat.widget.l0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
final class d extends k implements m, View.OnKeyListener, PopupWindow.OnDismissListener {
    private static final int O = b.a.g.f763e;
    private View B;
    View C;
    private boolean E;
    private boolean F;
    private int G;
    private int H;
    private boolean J;
    private m.a K;
    ViewTreeObserver L;
    private PopupWindow.OnDismissListener M;
    boolean N;
    private final Context o;
    private final int p;
    private final int q;
    private final int r;
    private final boolean s;
    final Handler t;
    private final List<g> u = new ArrayList();
    final List<C0012d> v = new ArrayList();
    final ViewTreeObserver.OnGlobalLayoutListener w = new a();
    private final View.OnAttachStateChangeListener x = new b();
    private final k0 y = new c();
    private int z = 0;
    private int A = 0;
    private boolean I = false;
    private int D = D();

    class a implements ViewTreeObserver.OnGlobalLayoutListener {
        a() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!d.this.c() || d.this.v.size() <= 0 || d.this.v.get(0).f155a.x()) {
                return;
            }
            View view = d.this.C;
            if (view == null || !view.isShown()) {
                d.this.dismiss();
                return;
            }
            Iterator<C0012d> it = d.this.v.iterator();
            while (it.hasNext()) {
                it.next().f155a.a();
            }
        }
    }

    class b implements View.OnAttachStateChangeListener {
        b() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = d.this.L;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    d.this.L = view.getViewTreeObserver();
                }
                d dVar = d.this;
                dVar.L.removeGlobalOnLayoutListener(dVar.w);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    class c implements k0 {

        class a implements Runnable {
            final /* synthetic */ C0012d n;
            final /* synthetic */ MenuItem o;
            final /* synthetic */ g p;

            a(C0012d c0012d, MenuItem menuItem, g gVar) {
                this.n = c0012d;
                this.o = menuItem;
                this.p = gVar;
            }

            @Override // java.lang.Runnable
            public void run() {
                C0012d c0012d = this.n;
                if (c0012d != null) {
                    d.this.N = true;
                    c0012d.f156b.e(false);
                    d.this.N = false;
                }
                if (this.o.isEnabled() && this.o.hasSubMenu()) {
                    this.p.L(this.o, 4);
                }
            }
        }

        c() {
        }

        @Override // androidx.appcompat.widget.k0
        public void b(g gVar, MenuItem menuItem) {
            d.this.t.removeCallbacksAndMessages(null);
            int size = d.this.v.size();
            int i2 = 0;
            while (true) {
                if (i2 >= size) {
                    i2 = -1;
                    break;
                } else if (gVar == d.this.v.get(i2).f156b) {
                    break;
                } else {
                    i2++;
                }
            }
            if (i2 == -1) {
                return;
            }
            int i3 = i2 + 1;
            d.this.t.postAtTime(new a(i3 < d.this.v.size() ? d.this.v.get(i3) : null, menuItem, gVar), gVar, SystemClock.uptimeMillis() + 200);
        }

        @Override // androidx.appcompat.widget.k0
        public void d(g gVar, MenuItem menuItem) {
            d.this.t.removeCallbacksAndMessages(gVar);
        }
    }

    /* renamed from: androidx.appcompat.view.menu.d$d, reason: collision with other inner class name */
    private static class C0012d {

        /* renamed from: a, reason: collision with root package name */
        public final l0 f155a;

        /* renamed from: b, reason: collision with root package name */
        public final g f156b;

        /* renamed from: c, reason: collision with root package name */
        public final int f157c;

        public C0012d(l0 l0Var, g gVar, int i2) {
            this.f155a = l0Var;
            this.f156b = gVar;
            this.f157c = i2;
        }

        public ListView a() {
            return this.f155a.h();
        }
    }

    public d(Context context, View view, int i2, int i3, boolean z) {
        this.o = context;
        this.B = view;
        this.q = i2;
        this.r = i3;
        this.s = z;
        Resources resources = context.getResources();
        this.p = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(b.a.d.f729d));
        this.t = new Handler();
    }

    private int A(g gVar) {
        int size = this.v.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (gVar == this.v.get(i2).f156b) {
                return i2;
            }
        }
        return -1;
    }

    private MenuItem B(g gVar, g gVar2) {
        int size = gVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            MenuItem item = gVar.getItem(i2);
            if (item.hasSubMenu() && gVar2 == item.getSubMenu()) {
                return item;
            }
        }
        return null;
    }

    private View C(C0012d c0012d, g gVar) {
        f fVar;
        int i2;
        int firstVisiblePosition;
        MenuItem B = B(c0012d.f156b, gVar);
        if (B == null) {
            return null;
        }
        ListView a2 = c0012d.a();
        ListAdapter adapter = a2.getAdapter();
        int i3 = 0;
        if (adapter instanceof HeaderViewListAdapter) {
            HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
            i2 = headerViewListAdapter.getHeadersCount();
            fVar = (f) headerViewListAdapter.getWrappedAdapter();
        } else {
            fVar = (f) adapter;
            i2 = 0;
        }
        int count = fVar.getCount();
        while (true) {
            if (i3 >= count) {
                i3 = -1;
                break;
            }
            if (B == fVar.getItem(i3)) {
                break;
            }
            i3++;
        }
        if (i3 != -1 && (firstVisiblePosition = (i3 + i2) - a2.getFirstVisiblePosition()) >= 0 && firstVisiblePosition < a2.getChildCount()) {
            return a2.getChildAt(firstVisiblePosition);
        }
        return null;
    }

    private int D() {
        return b.g.l.r.p(this.B) == 1 ? 0 : 1;
    }

    private int E(int i2) {
        List<C0012d> list = this.v;
        ListView a2 = list.get(list.size() - 1).a();
        int[] iArr = new int[2];
        a2.getLocationOnScreen(iArr);
        Rect rect = new Rect();
        this.C.getWindowVisibleDisplayFrame(rect);
        return this.D == 1 ? (iArr[0] + a2.getWidth()) + i2 > rect.right ? 0 : 1 : iArr[0] - i2 < 0 ? 1 : 0;
    }

    private void F(g gVar) {
        C0012d c0012d;
        View view;
        int i2;
        int i3;
        int i4;
        LayoutInflater from = LayoutInflater.from(this.o);
        f fVar = new f(gVar, from, this.s, O);
        if (!c() && this.I) {
            fVar.d(true);
        } else if (c()) {
            fVar.d(k.x(gVar));
        }
        int o = k.o(fVar, null, this.o, this.p);
        l0 z = z();
        z.p(fVar);
        z.B(o);
        z.C(this.A);
        if (this.v.size() > 0) {
            List<C0012d> list = this.v;
            c0012d = list.get(list.size() - 1);
            view = C(c0012d, gVar);
        } else {
            c0012d = null;
            view = null;
        }
        if (view != null) {
            z.Q(false);
            z.N(null);
            int E = E(o);
            boolean z2 = E == 1;
            this.D = E;
            if (Build.VERSION.SDK_INT >= 26) {
                z.z(view);
                i3 = 0;
                i2 = 0;
            } else {
                int[] iArr = new int[2];
                this.B.getLocationOnScreen(iArr);
                int[] iArr2 = new int[2];
                view.getLocationOnScreen(iArr2);
                if ((this.A & 7) == 5) {
                    iArr[0] = iArr[0] + this.B.getWidth();
                    iArr2[0] = iArr2[0] + view.getWidth();
                }
                i2 = iArr2[0] - iArr[0];
                i3 = iArr2[1] - iArr[1];
            }
            if ((this.A & 5) == 5) {
                if (!z2) {
                    o = view.getWidth();
                    i4 = i2 - o;
                }
                i4 = i2 + o;
            } else {
                if (z2) {
                    o = view.getWidth();
                    i4 = i2 + o;
                }
                i4 = i2 - o;
            }
            z.l(i4);
            z.I(true);
            z.j(i3);
        } else {
            if (this.E) {
                z.l(this.G);
            }
            if (this.F) {
                z.j(this.H);
            }
            z.D(n());
        }
        this.v.add(new C0012d(z, gVar, this.D));
        z.a();
        ListView h2 = z.h();
        h2.setOnKeyListener(this);
        if (c0012d == null && this.J && gVar.x() != null) {
            FrameLayout frameLayout = (FrameLayout) from.inflate(b.a.g.l, (ViewGroup) h2, false);
            TextView textView = (TextView) frameLayout.findViewById(R.id.title);
            frameLayout.setEnabled(false);
            textView.setText(gVar.x());
            h2.addHeaderView(frameLayout, null, false);
            z.a();
        }
    }

    private l0 z() {
        l0 l0Var = new l0(this.o, null, this.q, this.r);
        l0Var.P(this.y);
        l0Var.H(this);
        l0Var.G(this);
        l0Var.z(this.B);
        l0Var.C(this.A);
        l0Var.F(true);
        l0Var.E(2);
        return l0Var;
    }

    @Override // androidx.appcompat.view.menu.p
    public void a() {
        if (c()) {
            return;
        }
        Iterator<g> it = this.u.iterator();
        while (it.hasNext()) {
            F(it.next());
        }
        this.u.clear();
        View view = this.B;
        this.C = view;
        if (view != null) {
            boolean z = this.L == null;
            ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
            this.L = viewTreeObserver;
            if (z) {
                viewTreeObserver.addOnGlobalLayoutListener(this.w);
            }
            this.C.addOnAttachStateChangeListener(this.x);
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public void b(g gVar, boolean z) {
        int A = A(gVar);
        if (A < 0) {
            return;
        }
        int i2 = A + 1;
        if (i2 < this.v.size()) {
            this.v.get(i2).f156b.e(false);
        }
        C0012d remove = this.v.remove(A);
        remove.f156b.O(this);
        if (this.N) {
            remove.f155a.O(null);
            remove.f155a.A(0);
        }
        remove.f155a.dismiss();
        int size = this.v.size();
        this.D = size > 0 ? this.v.get(size - 1).f157c : D();
        if (size != 0) {
            if (z) {
                this.v.get(0).f156b.e(false);
                return;
            }
            return;
        }
        dismiss();
        m.a aVar = this.K;
        if (aVar != null) {
            aVar.b(gVar, true);
        }
        ViewTreeObserver viewTreeObserver = this.L;
        if (viewTreeObserver != null) {
            if (viewTreeObserver.isAlive()) {
                this.L.removeGlobalOnLayoutListener(this.w);
            }
            this.L = null;
        }
        this.C.removeOnAttachStateChangeListener(this.x);
        this.M.onDismiss();
    }

    @Override // androidx.appcompat.view.menu.p
    public boolean c() {
        return this.v.size() > 0 && this.v.get(0).f155a.c();
    }

    @Override // androidx.appcompat.view.menu.p
    public void dismiss() {
        int size = this.v.size();
        if (size > 0) {
            C0012d[] c0012dArr = (C0012d[]) this.v.toArray(new C0012d[size]);
            for (int i2 = size - 1; i2 >= 0; i2--) {
                C0012d c0012d = c0012dArr[i2];
                if (c0012d.f155a.c()) {
                    c0012d.f155a.dismiss();
                }
            }
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean e(r rVar) {
        for (C0012d c0012d : this.v) {
            if (rVar == c0012d.f156b) {
                c0012d.a().requestFocus();
                return true;
            }
        }
        if (!rVar.hasVisibleItems()) {
            return false;
        }
        l(rVar);
        m.a aVar = this.K;
        if (aVar != null) {
            aVar.c(rVar);
        }
        return true;
    }

    @Override // androidx.appcompat.view.menu.m
    public void f(boolean z) {
        Iterator<C0012d> it = this.v.iterator();
        while (it.hasNext()) {
            k.y(it.next().a().getAdapter()).notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean g() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.p
    public ListView h() {
        if (this.v.isEmpty()) {
            return null;
        }
        return this.v.get(r0.size() - 1).a();
    }

    @Override // androidx.appcompat.view.menu.m
    public void k(m.a aVar) {
        this.K = aVar;
    }

    @Override // androidx.appcompat.view.menu.k
    public void l(g gVar) {
        gVar.c(this, this.o);
        if (c()) {
            F(gVar);
        } else {
            this.u.add(gVar);
        }
    }

    @Override // androidx.appcompat.view.menu.k
    protected boolean m() {
        return false;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        C0012d c0012d;
        int size = this.v.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                c0012d = null;
                break;
            }
            c0012d = this.v.get(i2);
            if (!c0012d.f155a.c()) {
                break;
            } else {
                i2++;
            }
        }
        if (c0012d != null) {
            c0012d.f156b.e(false);
        }
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // androidx.appcompat.view.menu.k
    public void p(View view) {
        if (this.B != view) {
            this.B = view;
            this.A = b.g.l.d.a(this.z, b.g.l.r.p(view));
        }
    }

    @Override // androidx.appcompat.view.menu.k
    public void r(boolean z) {
        this.I = z;
    }

    @Override // androidx.appcompat.view.menu.k
    public void s(int i2) {
        if (this.z != i2) {
            this.z = i2;
            this.A = b.g.l.d.a(i2, b.g.l.r.p(this.B));
        }
    }

    @Override // androidx.appcompat.view.menu.k
    public void t(int i2) {
        this.E = true;
        this.G = i2;
    }

    @Override // androidx.appcompat.view.menu.k
    public void u(PopupWindow.OnDismissListener onDismissListener) {
        this.M = onDismissListener;
    }

    @Override // androidx.appcompat.view.menu.k
    public void v(boolean z) {
        this.J = z;
    }

    @Override // androidx.appcompat.view.menu.k
    public void w(int i2) {
        this.F = true;
        this.H = i2;
    }
}
