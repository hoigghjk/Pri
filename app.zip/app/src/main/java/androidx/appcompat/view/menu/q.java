package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.l0;

/* loaded from: classes.dex */
final class q extends k implements PopupWindow.OnDismissListener, AdapterView.OnItemClickListener, m, View.OnKeyListener {
    private static final int I = b.a.g.m;
    View A;
    private m.a B;
    ViewTreeObserver C;
    private boolean D;
    private boolean E;
    private int F;
    private boolean H;
    private final Context o;
    private final g p;
    private final f q;
    private final boolean r;
    private final int s;
    private final int t;
    private final int u;
    final l0 v;
    private PopupWindow.OnDismissListener y;
    private View z;
    final ViewTreeObserver.OnGlobalLayoutListener w = new a();
    private final View.OnAttachStateChangeListener x = new b();
    private int G = 0;

    class a implements ViewTreeObserver.OnGlobalLayoutListener {
        a() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!q.this.c() || q.this.v.x()) {
                return;
            }
            View view = q.this.A;
            if (view == null || !view.isShown()) {
                q.this.dismiss();
            } else {
                q.this.v.a();
            }
        }
    }

    class b implements View.OnAttachStateChangeListener {
        b() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = q.this.C;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    q.this.C = view.getViewTreeObserver();
                }
                q qVar = q.this;
                qVar.C.removeGlobalOnLayoutListener(qVar.w);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    public q(Context context, g gVar, View view, int i2, int i3, boolean z) {
        this.o = context;
        this.p = gVar;
        this.r = z;
        this.q = new f(gVar, LayoutInflater.from(context), z, I);
        this.t = i2;
        this.u = i3;
        Resources resources = context.getResources();
        this.s = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(b.a.d.f729d));
        this.z = view;
        this.v = new l0(context, null, i2, i3);
        gVar.c(this, context);
    }

    private boolean z() {
        View view;
        if (c()) {
            return true;
        }
        if (this.D || (view = this.z) == null) {
            return false;
        }
        this.A = view;
        this.v.G(this);
        this.v.H(this);
        this.v.F(true);
        View view2 = this.A;
        boolean z = this.C == null;
        ViewTreeObserver viewTreeObserver = view2.getViewTreeObserver();
        this.C = viewTreeObserver;
        if (z) {
            viewTreeObserver.addOnGlobalLayoutListener(this.w);
        }
        view2.addOnAttachStateChangeListener(this.x);
        this.v.z(view2);
        this.v.C(this.G);
        if (!this.E) {
            this.F = k.o(this.q, null, this.o, this.s);
            this.E = true;
        }
        this.v.B(this.F);
        this.v.E(2);
        this.v.D(n());
        this.v.a();
        ListView h2 = this.v.h();
        h2.setOnKeyListener(this);
        if (this.H && this.p.x() != null) {
            FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(this.o).inflate(b.a.g.l, (ViewGroup) h2, false);
            TextView textView = (TextView) frameLayout.findViewById(R.id.title);
            if (textView != null) {
                textView.setText(this.p.x());
            }
            frameLayout.setEnabled(false);
            h2.addHeaderView(frameLayout, null, false);
        }
        this.v.p(this.q);
        this.v.a();
        return true;
    }

    @Override // androidx.appcompat.view.menu.p
    public void a() {
        if (!z()) {
            throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public void b(g gVar, boolean z) {
        if (gVar != this.p) {
            return;
        }
        dismiss();
        m.a aVar = this.B;
        if (aVar != null) {
            aVar.b(gVar, z);
        }
    }

    @Override // androidx.appcompat.view.menu.p
    public boolean c() {
        return !this.D && this.v.c();
    }

    @Override // androidx.appcompat.view.menu.p
    public void dismiss() {
        if (c()) {
            this.v.dismiss();
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean e(r rVar) {
        if (rVar.hasVisibleItems()) {
            l lVar = new l(this.o, rVar, this.A, this.r, this.t, this.u);
            lVar.j(this.B);
            lVar.g(k.x(rVar));
            lVar.i(this.y);
            this.y = null;
            this.p.e(false);
            int f2 = this.v.f();
            int n = this.v.n();
            if ((Gravity.getAbsoluteGravity(this.G, b.g.l.r.p(this.z)) & 7) == 5) {
                f2 += this.z.getWidth();
            }
            if (lVar.n(f2, n)) {
                m.a aVar = this.B;
                if (aVar == null) {
                    return true;
                }
                aVar.c(rVar);
                return true;
            }
        }
        return false;
    }

    @Override // androidx.appcompat.view.menu.m
    public void f(boolean z) {
        this.E = false;
        f fVar = this.q;
        if (fVar != null) {
            fVar.notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean g() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.p
    public ListView h() {
        return this.v.h();
    }

    @Override // androidx.appcompat.view.menu.m
    public void k(m.a aVar) {
        this.B = aVar;
    }

    @Override // androidx.appcompat.view.menu.k
    public void l(g gVar) {
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        this.D = true;
        this.p.close();
        ViewTreeObserver viewTreeObserver = this.C;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.C = this.A.getViewTreeObserver();
            }
            this.C.removeGlobalOnLayoutListener(this.w);
            this.C = null;
        }
        this.A.removeOnAttachStateChangeListener(this.x);
        PopupWindow.OnDismissListener onDismissListener = this.y;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // androidx.appcompat.view.menu.k
    public void p(View view) {
        this.z = view;
    }

    @Override // androidx.appcompat.view.menu.k
    public void r(boolean z) {
        this.q.d(z);
    }

    @Override // androidx.appcompat.view.menu.k
    public void s(int i2) {
        this.G = i2;
    }

    @Override // androidx.appcompat.view.menu.k
    public void t(int i2) {
        this.v.l(i2);
    }

    @Override // androidx.appcompat.view.menu.k
    public void u(PopupWindow.OnDismissListener onDismissListener) {
        this.y = onDismissListener;
    }

    @Override // androidx.appcompat.view.menu.k
    public void v(boolean z) {
        this.H = z;
    }

    @Override // androidx.appcompat.view.menu.k
    public void w(int i2) {
        this.v.j(i2);
    }
}
