package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;

/* loaded from: classes.dex */
abstract class c {

    /* renamed from: a, reason: collision with root package name */
    final Context f152a;

    /* renamed from: b, reason: collision with root package name */
    private b.e.g<b.g.g.a.b, MenuItem> f153b;

    /* renamed from: c, reason: collision with root package name */
    private b.e.g<b.g.g.a.c, SubMenu> f154c;

    c(Context context) {
        this.f152a = context;
    }

    final MenuItem c(MenuItem menuItem) {
        if (!(menuItem instanceof b.g.g.a.b)) {
            return menuItem;
        }
        b.g.g.a.b bVar = (b.g.g.a.b) menuItem;
        if (this.f153b == null) {
            this.f153b = new b.e.g<>();
        }
        MenuItem menuItem2 = this.f153b.get(menuItem);
        if (menuItem2 != null) {
            return menuItem2;
        }
        j jVar = new j(this.f152a, bVar);
        this.f153b.put(bVar, jVar);
        return jVar;
    }

    final SubMenu d(SubMenu subMenu) {
        if (!(subMenu instanceof b.g.g.a.c)) {
            return subMenu;
        }
        b.g.g.a.c cVar = (b.g.g.a.c) subMenu;
        if (this.f154c == null) {
            this.f154c = new b.e.g<>();
        }
        SubMenu subMenu2 = this.f154c.get(cVar);
        if (subMenu2 != null) {
            return subMenu2;
        }
        s sVar = new s(this.f152a, cVar);
        this.f154c.put(cVar, sVar);
        return sVar;
    }

    final void e() {
        b.e.g<b.g.g.a.b, MenuItem> gVar = this.f153b;
        if (gVar != null) {
            gVar.clear();
        }
        b.e.g<b.g.g.a.c, SubMenu> gVar2 = this.f154c;
        if (gVar2 != null) {
            gVar2.clear();
        }
    }

    final void f(int i2) {
        if (this.f153b == null) {
            return;
        }
        int i3 = 0;
        while (i3 < this.f153b.size()) {
            if (this.f153b.i(i3).getGroupId() == i2) {
                this.f153b.k(i3);
                i3--;
            }
            i3++;
        }
    }

    final void g(int i2) {
        if (this.f153b == null) {
            return;
        }
        for (int i3 = 0; i3 < this.f153b.size(); i3++) {
            if (this.f153b.i(i3).getItemId() == i2) {
                this.f153b.k(i3);
                return;
            }
        }
    }
}
