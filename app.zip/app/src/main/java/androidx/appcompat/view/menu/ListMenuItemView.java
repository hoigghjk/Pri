package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.view.menu.n;
import androidx.appcompat.widget.w0;

/* loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements n.a, AbsListView.SelectionBoundsAdjuster {
    private Drawable A;
    private boolean B;
    private LayoutInflater C;
    private boolean D;
    private i n;
    private ImageView o;
    private RadioButton p;
    private TextView q;
    private CheckBox r;
    private TextView s;
    private ImageView t;
    private ImageView u;
    private LinearLayout v;
    private Drawable w;
    private int x;
    private Context y;
    private boolean z;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b.a.a.C);
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet);
        w0 u = w0.u(getContext(), attributeSet, b.a.j.L1, i2, 0);
        this.w = u.f(b.a.j.N1);
        this.x = u.m(b.a.j.M1, -1);
        this.z = u.a(b.a.j.O1, false);
        this.y = context;
        this.A = u.f(b.a.j.P1);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{R.attr.divider}, b.a.a.z, 0);
        this.B = obtainStyledAttributes.hasValue(0);
        u.v();
        obtainStyledAttributes.recycle();
    }

    private void b(View view) {
        c(view, -1);
    }

    private void c(View view, int i2) {
        LinearLayout linearLayout = this.v;
        if (linearLayout != null) {
            linearLayout.addView(view, i2);
        } else {
            addView(view, i2);
        }
    }

    private void e() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(b.a.g.f766h, (ViewGroup) this, false);
        this.r = checkBox;
        b(checkBox);
    }

    private void f() {
        ImageView imageView = (ImageView) getInflater().inflate(b.a.g.f767i, (ViewGroup) this, false);
        this.o = imageView;
        c(imageView, 0);
    }

    private void g() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(b.a.g.f769k, (ViewGroup) this, false);
        this.p = radioButton;
        b(radioButton);
    }

    private LayoutInflater getInflater() {
        if (this.C == null) {
            this.C = LayoutInflater.from(getContext());
        }
        return this.C;
    }

    private void setSubMenuArrowVisible(boolean z) {
        ImageView imageView = this.t;
        if (imageView != null) {
            imageView.setVisibility(z ? 0 : 8);
        }
    }

    @Override // androidx.appcompat.view.menu.n.a
    public boolean a() {
        return false;
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.u;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.u.getLayoutParams();
        rect.top += this.u.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    @Override // androidx.appcompat.view.menu.n.a
    public void d(i iVar, int i2) {
        this.n = iVar;
        setVisibility(iVar.isVisible() ? 0 : 8);
        setTitle(iVar.i(this));
        setCheckable(iVar.isCheckable());
        h(iVar.A(), iVar.g());
        setIcon(iVar.getIcon());
        setEnabled(iVar.isEnabled());
        setSubMenuArrowVisible(iVar.hasSubMenu());
        setContentDescription(iVar.getContentDescription());
    }

    @Override // androidx.appcompat.view.menu.n.a
    public i getItemData() {
        return this.n;
    }

    public void h(boolean z, char c2) {
        int i2 = (z && this.n.A()) ? 0 : 8;
        if (i2 == 0) {
            this.s.setText(this.n.h());
        }
        if (this.s.getVisibility() != i2) {
            this.s.setVisibility(i2);
        }
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        b.g.l.r.M(this, this.w);
        TextView textView = (TextView) findViewById(b.a.f.M);
        this.q = textView;
        int i2 = this.x;
        if (i2 != -1) {
            textView.setTextAppearance(this.y, i2);
        }
        this.s = (TextView) findViewById(b.a.f.F);
        ImageView imageView = (ImageView) findViewById(b.a.f.I);
        this.t = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.A);
        }
        this.u = (ImageView) findViewById(b.a.f.r);
        this.v = (LinearLayout) findViewById(b.a.f.l);
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        if (this.o != null && this.z) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.o.getLayoutParams();
            int i4 = layoutParams.height;
            if (i4 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i4;
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCheckable(boolean z) {
        CompoundButton compoundButton;
        CompoundButton compoundButton2;
        if (!z && this.p == null && this.r == null) {
            return;
        }
        if (this.n.m()) {
            if (this.p == null) {
                g();
            }
            compoundButton = this.p;
            compoundButton2 = this.r;
        } else {
            if (this.r == null) {
                e();
            }
            compoundButton = this.r;
            compoundButton2 = this.p;
        }
        if (z) {
            compoundButton.setChecked(this.n.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (compoundButton2 == null || compoundButton2.getVisibility() == 8) {
                return;
            }
            compoundButton2.setVisibility(8);
            return;
        }
        CheckBox checkBox = this.r;
        if (checkBox != null) {
            checkBox.setVisibility(8);
        }
        RadioButton radioButton = this.p;
        if (radioButton != null) {
            radioButton.setVisibility(8);
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.n.m()) {
            if (this.p == null) {
                g();
            }
            compoundButton = this.p;
        } else {
            if (this.r == null) {
                e();
            }
            compoundButton = this.r;
        }
        compoundButton.setChecked(z);
    }

    public void setForceShowIcon(boolean z) {
        this.D = z;
        this.z = z;
    }

    public void setGroupDividerEnabled(boolean z) {
        ImageView imageView = this.u;
        if (imageView != null) {
            imageView.setVisibility((this.B || !z) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z = this.n.z() || this.D;
        if (z || this.z) {
            ImageView imageView = this.o;
            if (imageView == null && drawable == null && !this.z) {
                return;
            }
            if (imageView == null) {
                f();
            }
            if (drawable == null && !this.z) {
                this.o.setVisibility(8);
                return;
            }
            ImageView imageView2 = this.o;
            if (!z) {
                drawable = null;
            }
            imageView2.setImageDrawable(drawable);
            if (this.o.getVisibility() != 0) {
                this.o.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        int i2;
        TextView textView;
        if (charSequence != null) {
            this.q.setText(charSequence);
            if (this.q.getVisibility() == 0) {
                return;
            }
            textView = this.q;
            i2 = 0;
        } else {
            i2 = 8;
            if (this.q.getVisibility() == 8) {
                return;
            } else {
                textView = this.q;
            }
        }
        textView.setVisibility(i2);
    }
}
