package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.view.menu.n;
import java.util.ArrayList;

/* loaded from: classes.dex */
public abstract class b implements m {
    protected Context n;
    protected Context o;
    protected g p;
    protected LayoutInflater q;
    private m.a r;
    private int s;
    private int t;
    protected n u;

    public b(Context context, int i2, int i3) {
        this.n = context;
        this.q = LayoutInflater.from(context);
        this.s = i2;
        this.t = i3;
    }

    protected void a(View view, int i2) {
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        if (viewGroup != null) {
            viewGroup.removeView(view);
        }
        ((ViewGroup) this.u).addView(view, i2);
    }

    @Override // androidx.appcompat.view.menu.m
    public void b(g gVar, boolean z) {
        m.a aVar = this.r;
        if (aVar != null) {
            aVar.b(gVar, z);
        }
    }

    public abstract void c(i iVar, n.a aVar);

    @Override // androidx.appcompat.view.menu.m
    public void d(Context context, g gVar) {
        this.o = context;
        LayoutInflater.from(context);
        this.p = gVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v4, types: [androidx.appcompat.view.menu.g] */
    @Override // androidx.appcompat.view.menu.m
    public boolean e(r rVar) {
        m.a aVar = this.r;
        r rVar2 = rVar;
        if (aVar == null) {
            return false;
        }
        if (rVar == null) {
            rVar2 = this.p;
        }
        return aVar.c(rVar2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.appcompat.view.menu.m
    public void f(boolean z) {
        ViewGroup viewGroup = (ViewGroup) this.u;
        if (viewGroup == null) {
            return;
        }
        g gVar = this.p;
        int i2 = 0;
        if (gVar != null) {
            gVar.r();
            ArrayList<i> E = this.p.E();
            int size = E.size();
            int i3 = 0;
            for (int i4 = 0; i4 < size; i4++) {
                i iVar = E.get(i4);
                if (q(i3, iVar)) {
                    View childAt = viewGroup.getChildAt(i3);
                    i itemData = childAt instanceof n.a ? ((n.a) childAt).getItemData() : null;
                    View n = n(iVar, childAt, viewGroup);
                    if (iVar != itemData) {
                        n.setPressed(false);
                        n.jumpDrawablesToCurrentState();
                    }
                    if (n != childAt) {
                        a(n, i3);
                    }
                    i3++;
                }
            }
            i2 = i3;
        }
        while (i2 < viewGroup.getChildCount()) {
            if (!l(viewGroup, i2)) {
                i2++;
            }
        }
    }

    public n.a h(ViewGroup viewGroup) {
        return (n.a) this.q.inflate(this.t, viewGroup, false);
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean i(g gVar, i iVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean j(g gVar, i iVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.m
    public void k(m.a aVar) {
        this.r = aVar;
    }

    protected boolean l(ViewGroup viewGroup, int i2) {
        viewGroup.removeViewAt(i2);
        return true;
    }

    public m.a m() {
        return this.r;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public View n(i iVar, View view, ViewGroup viewGroup) {
        n.a h2 = view instanceof n.a ? (n.a) view : h(viewGroup);
        c(iVar, h2);
        return (View) h2;
    }

    public n o(ViewGroup viewGroup) {
        if (this.u == null) {
            n nVar = (n) this.q.inflate(this.s, viewGroup, false);
            this.u = nVar;
            nVar.b(this.p);
            f(true);
        }
        return this.u;
    }

    public void p(int i2) {
    }

    public abstract boolean q(int i2, i iVar);
}
