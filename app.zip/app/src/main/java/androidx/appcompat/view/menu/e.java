package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.view.menu.n;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class e implements m, AdapterView.OnItemClickListener {
    Context n;
    LayoutInflater o;
    g p;
    ExpandedMenuView q;
    int r;
    int s;
    int t;
    private m.a u;
    a v;

    private class a extends BaseAdapter {
        private int n = -1;

        public a() {
            a();
        }

        void a() {
            i v = e.this.p.v();
            if (v != null) {
                ArrayList<i> z = e.this.p.z();
                int size = z.size();
                for (int i2 = 0; i2 < size; i2++) {
                    if (z.get(i2) == v) {
                        this.n = i2;
                        return;
                    }
                }
            }
            this.n = -1;
        }

        @Override // android.widget.Adapter
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public i getItem(int i2) {
            ArrayList<i> z = e.this.p.z();
            int i3 = i2 + e.this.r;
            int i4 = this.n;
            if (i4 >= 0 && i3 >= i4) {
                i3++;
            }
            return z.get(i3);
        }

        @Override // android.widget.Adapter
        public int getCount() {
            int size = e.this.p.z().size() - e.this.r;
            return this.n < 0 ? size : size - 1;
        }

        @Override // android.widget.Adapter
        public long getItemId(int i2) {
            return i2;
        }

        @Override // android.widget.Adapter
        public View getView(int i2, View view, ViewGroup viewGroup) {
            if (view == null) {
                e eVar = e.this;
                view = eVar.o.inflate(eVar.t, viewGroup, false);
            }
            ((n.a) view).d(getItem(i2), 0);
            return view;
        }

        @Override // android.widget.BaseAdapter
        public void notifyDataSetChanged() {
            a();
            super.notifyDataSetChanged();
        }
    }

    public e(int i2, int i3) {
        this.t = i2;
        this.s = i3;
    }

    public e(Context context, int i2) {
        this(i2, 0);
        this.n = context;
        this.o = LayoutInflater.from(context);
    }

    public ListAdapter a() {
        if (this.v == null) {
            this.v = new a();
        }
        return this.v;
    }

    @Override // androidx.appcompat.view.menu.m
    public void b(g gVar, boolean z) {
        m.a aVar = this.u;
        if (aVar != null) {
            aVar.b(gVar, z);
        }
    }

    public n c(ViewGroup viewGroup) {
        if (this.q == null) {
            this.q = (ExpandedMenuView) this.o.inflate(b.a.g.f765g, viewGroup, false);
            if (this.v == null) {
                this.v = new a();
            }
            this.q.setAdapter((ListAdapter) this.v);
            this.q.setOnItemClickListener(this);
        }
        return this.q;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0029  */
    @Override // androidx.appcompat.view.menu.m
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void d(android.content.Context r3, androidx.appcompat.view.menu.g r4) {
        /*
            r2 = this;
            int r0 = r2.s
            if (r0 == 0) goto L14
            android.view.ContextThemeWrapper r0 = new android.view.ContextThemeWrapper
            int r1 = r2.s
            r0.<init>(r3, r1)
            r2.n = r0
            android.view.LayoutInflater r3 = android.view.LayoutInflater.from(r0)
        L11:
            r2.o = r3
            goto L23
        L14:
            android.content.Context r0 = r2.n
            if (r0 == 0) goto L23
            r2.n = r3
            android.view.LayoutInflater r0 = r2.o
            if (r0 != 0) goto L23
            android.view.LayoutInflater r3 = android.view.LayoutInflater.from(r3)
            goto L11
        L23:
            r2.p = r4
            androidx.appcompat.view.menu.e$a r3 = r2.v
            if (r3 == 0) goto L2c
            r3.notifyDataSetChanged()
        L2c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.e.d(android.content.Context, androidx.appcompat.view.menu.g):void");
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean e(r rVar) {
        if (!rVar.hasVisibleItems()) {
            return false;
        }
        new h(rVar).d(null);
        m.a aVar = this.u;
        if (aVar == null) {
            return true;
        }
        aVar.c(rVar);
        return true;
    }

    @Override // androidx.appcompat.view.menu.m
    public void f(boolean z) {
        a aVar = this.v;
        if (aVar != null) {
            aVar.notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean g() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean i(g gVar, i iVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.m
    public boolean j(g gVar, i iVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.m
    public void k(m.a aVar) {
        this.u = aVar;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
        this.p.M(this.v.getItem(i2), this, 0);
    }
}
