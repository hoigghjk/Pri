package androidx.appcompat.view.menu;

import android.content.Context;

/* loaded from: classes.dex */
public interface m {

    public interface a {
        void b(g gVar, boolean z);

        boolean c(g gVar);
    }

    void b(g gVar, boolean z);

    void d(Context context, g gVar);

    boolean e(r rVar);

    void f(boolean z);

    boolean g();

    boolean i(g gVar, i iVar);

    boolean j(g gVar, i iVar);

    void k(a aVar);
}
