package androidx.appcompat.view.menu;

/* loaded from: classes.dex */
public interface n {

    public interface a {
        boolean a();

        void d(i iVar, int i2);

        i getItemData();
    }

    void b(g gVar);
}
