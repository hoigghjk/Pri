package androidx.activity;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: classes.dex */
public abstract class b {

    /* renamed from: a, reason: collision with root package name */
    private boolean f32a;

    /* renamed from: b, reason: collision with root package name */
    private CopyOnWriteArrayList<a> f33b = new CopyOnWriteArrayList<>();

    public b(boolean z) {
        this.f32a = z;
    }

    void a(a aVar) {
        this.f33b.add(aVar);
    }

    public abstract void b();

    public final boolean c() {
        return this.f32a;
    }

    public final void d() {
        Iterator<a> it = this.f33b.iterator();
        while (it.hasNext()) {
            it.next().cancel();
        }
    }

    void e(a aVar) {
        this.f33b.remove(aVar);
    }

    public final void f(boolean z) {
        this.f32a = z;
    }
}
