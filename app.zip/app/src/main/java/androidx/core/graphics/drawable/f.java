package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;

/* loaded from: classes.dex */
final class f extends Drawable.ConstantState {

    /* renamed from: a, reason: collision with root package name */
    int f504a;

    /* renamed from: b, reason: collision with root package name */
    Drawable.ConstantState f505b;

    /* renamed from: c, reason: collision with root package name */
    ColorStateList f506c;

    /* renamed from: d, reason: collision with root package name */
    PorterDuff.Mode f507d;

    f(f fVar) {
        this.f506c = null;
        this.f507d = d.t;
        if (fVar != null) {
            this.f504a = fVar.f504a;
            this.f505b = fVar.f505b;
            this.f506c = fVar.f506c;
            this.f507d = fVar.f507d;
        }
    }

    boolean a() {
        return this.f505b != null;
    }

    @Override // android.graphics.drawable.Drawable.ConstantState
    public int getChangingConfigurations() {
        int i2 = this.f504a;
        Drawable.ConstantState constantState = this.f505b;
        return i2 | (constantState != null ? constantState.getChangingConfigurations() : 0);
    }

    @Override // android.graphics.drawable.Drawable.ConstantState
    public Drawable newDrawable() {
        return newDrawable(null);
    }

    @Override // android.graphics.drawable.Drawable.ConstantState
    public Drawable newDrawable(Resources resources) {
        return Build.VERSION.SDK_INT >= 21 ? new e(this, resources) : new d(this, resources);
    }
}
