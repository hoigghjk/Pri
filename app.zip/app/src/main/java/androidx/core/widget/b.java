package androidx.core.widget;

import android.os.Build;

/* loaded from: classes.dex */
public interface b {

    /* renamed from: a, reason: collision with root package name */
    public static final boolean f519a;

    static {
        f519a = Build.VERSION.SDK_INT >= 27;
    }
}
