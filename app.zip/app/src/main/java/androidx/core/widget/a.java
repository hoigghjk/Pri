package androidx.core.widget;

import android.content.res.Resources;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import b.g.l.r;

/* loaded from: classes.dex */
public abstract class a implements View.OnTouchListener {
    private static final int E = ViewConfiguration.getTapTimeout();
    boolean A;
    boolean B;
    private boolean C;
    private boolean D;
    final View p;
    private Runnable q;
    private int t;
    private int u;
    private boolean y;
    boolean z;
    final C0021a n = new C0021a();
    private final Interpolator o = new AccelerateInterpolator();
    private float[] r = {0.0f, 0.0f};
    private float[] s = {Float.MAX_VALUE, Float.MAX_VALUE};
    private float[] v = {0.0f, 0.0f};
    private float[] w = {0.0f, 0.0f};
    private float[] x = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* renamed from: androidx.core.widget.a$a, reason: collision with other inner class name */
    private static class C0021a {

        /* renamed from: a, reason: collision with root package name */
        private int f508a;

        /* renamed from: b, reason: collision with root package name */
        private int f509b;

        /* renamed from: c, reason: collision with root package name */
        private float f510c;

        /* renamed from: d, reason: collision with root package name */
        private float f511d;

        /* renamed from: j, reason: collision with root package name */
        private float f517j;

        /* renamed from: k, reason: collision with root package name */
        private int f518k;

        /* renamed from: e, reason: collision with root package name */
        private long f512e = Long.MIN_VALUE;

        /* renamed from: i, reason: collision with root package name */
        private long f516i = -1;

        /* renamed from: f, reason: collision with root package name */
        private long f513f = 0;

        /* renamed from: g, reason: collision with root package name */
        private int f514g = 0;

        /* renamed from: h, reason: collision with root package name */
        private int f515h = 0;

        C0021a() {
        }

        private float e(long j2) {
            if (j2 < this.f512e) {
                return 0.0f;
            }
            long j3 = this.f516i;
            if (j3 < 0 || j2 < j3) {
                return a.e((j2 - r0) / this.f508a, 0.0f, 1.0f) * 0.5f;
            }
            float f2 = this.f517j;
            return (1.0f - f2) + (f2 * a.e((j2 - j3) / this.f518k, 0.0f, 1.0f));
        }

        private float g(float f2) {
            return ((-4.0f) * f2 * f2) + (f2 * 4.0f);
        }

        public void a() {
            if (this.f513f == 0) {
                throw new RuntimeException("Cannot compute scroll delta before calling start()");
            }
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            float g2 = g(e(currentAnimationTimeMillis));
            long j2 = currentAnimationTimeMillis - this.f513f;
            this.f513f = currentAnimationTimeMillis;
            float f2 = j2 * g2;
            this.f514g = (int) (this.f510c * f2);
            this.f515h = (int) (f2 * this.f511d);
        }

        public int b() {
            return this.f514g;
        }

        public int c() {
            return this.f515h;
        }

        public int d() {
            float f2 = this.f510c;
            return (int) (f2 / Math.abs(f2));
        }

        public int f() {
            float f2 = this.f511d;
            return (int) (f2 / Math.abs(f2));
        }

        public boolean h() {
            return this.f516i > 0 && AnimationUtils.currentAnimationTimeMillis() > this.f516i + ((long) this.f518k);
        }

        public void i() {
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.f518k = a.f((int) (currentAnimationTimeMillis - this.f512e), 0, this.f509b);
            this.f517j = e(currentAnimationTimeMillis);
            this.f516i = currentAnimationTimeMillis;
        }

        public void j(int i2) {
            this.f509b = i2;
        }

        public void k(int i2) {
            this.f508a = i2;
        }

        public void l(float f2, float f3) {
            this.f510c = f2;
            this.f511d = f3;
        }

        public void m() {
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.f512e = currentAnimationTimeMillis;
            this.f516i = -1L;
            this.f513f = currentAnimationTimeMillis;
            this.f517j = 0.5f;
            this.f514g = 0;
            this.f515h = 0;
        }
    }

    private class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            a aVar = a.this;
            if (aVar.B) {
                if (aVar.z) {
                    aVar.z = false;
                    aVar.n.m();
                }
                C0021a c0021a = a.this.n;
                if (c0021a.h() || !a.this.u()) {
                    a.this.B = false;
                    return;
                }
                a aVar2 = a.this;
                if (aVar2.A) {
                    aVar2.A = false;
                    aVar2.c();
                }
                c0021a.a();
                a.this.j(c0021a.b(), c0021a.c());
                r.G(a.this.p, this);
            }
        }
    }

    public a(View view) {
        this.p = view;
        float f2 = Resources.getSystem().getDisplayMetrics().density;
        float f3 = (int) ((1575.0f * f2) + 0.5f);
        o(f3, f3);
        float f4 = (int) ((f2 * 315.0f) + 0.5f);
        p(f4, f4);
        l(1);
        n(Float.MAX_VALUE, Float.MAX_VALUE);
        s(0.2f, 0.2f);
        t(1.0f, 1.0f);
        k(E);
        r(500);
        q(500);
    }

    private float d(int i2, float f2, float f3, float f4) {
        float h2 = h(this.r[i2], f3, this.s[i2], f2);
        if (h2 == 0.0f) {
            return 0.0f;
        }
        float f5 = this.v[i2];
        float f6 = this.w[i2];
        float f7 = this.x[i2];
        float f8 = f5 * f4;
        return h2 > 0.0f ? e(h2 * f8, f6, f7) : -e((-h2) * f8, f6, f7);
    }

    static float e(float f2, float f3, float f4) {
        return f2 > f4 ? f4 : f2 < f3 ? f3 : f2;
    }

    static int f(int i2, int i3, int i4) {
        return i2 > i4 ? i4 : i2 < i3 ? i3 : i2;
    }

    private float g(float f2, float f3) {
        if (f3 == 0.0f) {
            return 0.0f;
        }
        int i2 = this.t;
        if (i2 == 0 || i2 == 1) {
            if (f2 < f3) {
                if (f2 >= 0.0f) {
                    return 1.0f - (f2 / f3);
                }
                if (this.B && i2 == 1) {
                    return 1.0f;
                }
            }
        } else if (i2 == 2 && f2 < 0.0f) {
            return f2 / (-f3);
        }
        return 0.0f;
    }

    private float h(float f2, float f3, float f4, float f5) {
        float interpolation;
        float e2 = e(f2 * f3, 0.0f, f4);
        float g2 = g(f3 - f5, e2) - g(f5, e2);
        if (g2 < 0.0f) {
            interpolation = -this.o.getInterpolation(-g2);
        } else {
            if (g2 <= 0.0f) {
                return 0.0f;
            }
            interpolation = this.o.getInterpolation(g2);
        }
        return e(interpolation, -1.0f, 1.0f);
    }

    private void i() {
        if (this.z) {
            this.B = false;
        } else {
            this.n.i();
        }
    }

    private void v() {
        int i2;
        if (this.q == null) {
            this.q = new b();
        }
        this.B = true;
        this.z = true;
        if (this.y || (i2 = this.u) <= 0) {
            this.q.run();
        } else {
            r.H(this.p, this.q, i2);
        }
        this.y = true;
    }

    public abstract boolean a(int i2);

    public abstract boolean b(int i2);

    void c() {
        long uptimeMillis = SystemClock.uptimeMillis();
        MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
        this.p.onTouchEvent(obtain);
        obtain.recycle();
    }

    public abstract void j(int i2, int i3);

    public a k(int i2) {
        this.u = i2;
        return this;
    }

    public a l(int i2) {
        this.t = i2;
        return this;
    }

    public a m(boolean z) {
        if (this.C && !z) {
            i();
        }
        this.C = z;
        return this;
    }

    public a n(float f2, float f3) {
        float[] fArr = this.s;
        fArr[0] = f2;
        fArr[1] = f3;
        return this;
    }

    public a o(float f2, float f3) {
        float[] fArr = this.x;
        fArr[0] = f2 / 1000.0f;
        fArr[1] = f3 / 1000.0f;
        return this;
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0013, code lost:
    
        if (r0 != 3) goto L20;
     */
    @Override // android.view.View.OnTouchListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean onTouch(android.view.View r6, android.view.MotionEvent r7) {
        /*
            r5 = this;
            boolean r0 = r5.C
            r1 = 0
            if (r0 != 0) goto L6
            return r1
        L6:
            int r0 = r7.getActionMasked()
            r2 = 1
            if (r0 == 0) goto L1a
            if (r0 == r2) goto L16
            r3 = 2
            if (r0 == r3) goto L1e
            r6 = 3
            if (r0 == r6) goto L16
            goto L58
        L16:
            r5.i()
            goto L58
        L1a:
            r5.A = r2
            r5.y = r1
        L1e:
            float r0 = r7.getX()
            int r3 = r6.getWidth()
            float r3 = (float) r3
            android.view.View r4 = r5.p
            int r4 = r4.getWidth()
            float r4 = (float) r4
            float r0 = r5.d(r1, r0, r3, r4)
            float r7 = r7.getY()
            int r6 = r6.getHeight()
            float r6 = (float) r6
            android.view.View r3 = r5.p
            int r3 = r3.getHeight()
            float r3 = (float) r3
            float r6 = r5.d(r2, r7, r6, r3)
            androidx.core.widget.a$a r7 = r5.n
            r7.l(r0, r6)
            boolean r6 = r5.B
            if (r6 != 0) goto L58
            boolean r6 = r5.u()
            if (r6 == 0) goto L58
            r5.v()
        L58:
            boolean r6 = r5.D
            if (r6 == 0) goto L61
            boolean r6 = r5.B
            if (r6 == 0) goto L61
            r1 = 1
        L61:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.a.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }

    public a p(float f2, float f3) {
        float[] fArr = this.w;
        fArr[0] = f2 / 1000.0f;
        fArr[1] = f3 / 1000.0f;
        return this;
    }

    public a q(int i2) {
        this.n.j(i2);
        return this;
    }

    public a r(int i2) {
        this.n.k(i2);
        return this;
    }

    public a s(float f2, float f3) {
        float[] fArr = this.r;
        fArr[0] = f2;
        fArr[1] = f3;
        return this;
    }

    public a t(float f2, float f3) {
        float[] fArr = this.v;
        fArr[0] = f2 / 1000.0f;
        fArr[1] = f3 / 1000.0f;
        return this;
    }

    boolean u() {
        C0021a c0021a = this.n;
        int f2 = c0021a.f();
        int d2 = c0021a.d();
        return (f2 != 0 && b(f2)) || (d2 != 0 && a(d2));
    }
}
