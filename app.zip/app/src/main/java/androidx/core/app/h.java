package androidx.core.app;

import android.app.Notification;

/* loaded from: classes.dex */
public interface h {
    Notification.Builder a();
}
