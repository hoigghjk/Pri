package androidx.core.app;

import android.app.Person;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: classes.dex */
public class l {

    /* renamed from: a, reason: collision with root package name */
    CharSequence f483a;

    /* renamed from: b, reason: collision with root package name */
    IconCompat f484b;

    /* renamed from: c, reason: collision with root package name */
    String f485c;

    /* renamed from: d, reason: collision with root package name */
    String f486d;

    /* renamed from: e, reason: collision with root package name */
    boolean f487e;

    /* renamed from: f, reason: collision with root package name */
    boolean f488f;

    public IconCompat a() {
        return this.f484b;
    }

    public String b() {
        return this.f486d;
    }

    public CharSequence c() {
        return this.f483a;
    }

    public String d() {
        return this.f485c;
    }

    public boolean e() {
        return this.f487e;
    }

    public boolean f() {
        return this.f488f;
    }

    public String g() {
        String str = this.f485c;
        if (str != null) {
            return str;
        }
        if (this.f483a == null) {
            return "";
        }
        return "name:" + ((Object) this.f483a);
    }

    public Person h() {
        return new Person.Builder().setName(c()).setIcon(a() != null ? a().p() : null).setUri(d()).setKey(b()).setBot(e()).setImportant(f()).build();
    }
}
