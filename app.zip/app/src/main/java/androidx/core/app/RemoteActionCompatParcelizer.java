package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(androidx.versionedparcelable.a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        remoteActionCompat.f403a = (IconCompat) aVar.v(remoteActionCompat.f403a, 1);
        remoteActionCompat.f404b = aVar.l(remoteActionCompat.f404b, 2);
        remoteActionCompat.f405c = aVar.l(remoteActionCompat.f405c, 3);
        remoteActionCompat.f406d = (PendingIntent) aVar.r(remoteActionCompat.f406d, 4);
        remoteActionCompat.f407e = aVar.h(remoteActionCompat.f407e, 5);
        remoteActionCompat.f408f = aVar.h(remoteActionCompat.f408f, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, androidx.versionedparcelable.a aVar) {
        aVar.x(false, false);
        aVar.M(remoteActionCompat.f403a, 1);
        aVar.D(remoteActionCompat.f404b, 2);
        aVar.D(remoteActionCompat.f405c, 3);
        aVar.H(remoteActionCompat.f406d, 4);
        aVar.z(remoteActionCompat.f407e, 5);
        aVar.z(remoteActionCompat.f408f, 6);
    }
}
