package androidx.core.app;

import android.app.Service;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobServiceEngine;
import android.app.job.JobWorkItem;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.util.ArrayList;
import java.util.HashMap;

@Deprecated
/* loaded from: classes.dex */
public abstract class f extends Service {
    static final Object t = new Object();
    static final HashMap<ComponentName, h> u = new HashMap<>();
    b n;
    h o;
    a p;
    boolean q = false;
    boolean r = false;
    final ArrayList<d> s;

    final class a extends AsyncTask<Void, Void, Void> {
        a() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public Void doInBackground(Void... voidArr) {
            while (true) {
                e a2 = f.this.a();
                if (a2 == null) {
                    return null;
                }
                f.this.g(a2.getIntent());
                a2.a();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public void onCancelled(Void r1) {
            f.this.i();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* renamed from: c, reason: merged with bridge method [inline-methods] */
        public void onPostExecute(Void r1) {
            f.this.i();
        }
    }

    interface b {
        e a();

        IBinder b();
    }

    static final class c extends h {

        /* renamed from: d, reason: collision with root package name */
        private final Context f423d;

        /* renamed from: e, reason: collision with root package name */
        private final PowerManager.WakeLock f424e;

        /* renamed from: f, reason: collision with root package name */
        private final PowerManager.WakeLock f425f;

        /* renamed from: g, reason: collision with root package name */
        boolean f426g;

        /* renamed from: h, reason: collision with root package name */
        boolean f427h;

        c(Context context, ComponentName componentName) {
            super(componentName);
            this.f423d = context.getApplicationContext();
            PowerManager powerManager = (PowerManager) context.getSystemService("power");
            PowerManager.WakeLock newWakeLock = powerManager.newWakeLock(1, componentName.getClassName() + ":launch");
            this.f424e = newWakeLock;
            newWakeLock.setReferenceCounted(false);
            PowerManager.WakeLock newWakeLock2 = powerManager.newWakeLock(1, componentName.getClassName() + ":run");
            this.f425f = newWakeLock2;
            newWakeLock2.setReferenceCounted(false);
        }

        @Override // androidx.core.app.f.h
        void a(Intent intent) {
            Intent intent2 = new Intent(intent);
            intent2.setComponent(this.f438a);
            if (this.f423d.startService(intent2) != null) {
                synchronized (this) {
                    if (!this.f426g) {
                        this.f426g = true;
                        if (!this.f427h) {
                            this.f424e.acquire(60000L);
                        }
                    }
                }
            }
        }

        @Override // androidx.core.app.f.h
        public void c() {
            synchronized (this) {
                if (this.f427h) {
                    if (this.f426g) {
                        this.f424e.acquire(60000L);
                    }
                    this.f427h = false;
                    this.f425f.release();
                }
            }
        }

        @Override // androidx.core.app.f.h
        public void d() {
            synchronized (this) {
                if (!this.f427h) {
                    this.f427h = true;
                    this.f425f.acquire(600000L);
                    this.f424e.release();
                }
            }
        }

        @Override // androidx.core.app.f.h
        public void e() {
            synchronized (this) {
                this.f426g = false;
            }
        }
    }

    final class d implements e {

        /* renamed from: a, reason: collision with root package name */
        final Intent f428a;

        /* renamed from: b, reason: collision with root package name */
        final int f429b;

        d(Intent intent, int i2) {
            this.f428a = intent;
            this.f429b = i2;
        }

        @Override // androidx.core.app.f.e
        public void a() {
            f.this.stopSelf(this.f429b);
        }

        @Override // androidx.core.app.f.e
        public Intent getIntent() {
            return this.f428a;
        }
    }

    interface e {
        void a();

        Intent getIntent();
    }

    /* renamed from: androidx.core.app.f$f, reason: collision with other inner class name */
    static final class JobServiceEngineC0019f extends JobServiceEngine implements b {

        /* renamed from: a, reason: collision with root package name */
        final f f431a;

        /* renamed from: b, reason: collision with root package name */
        final Object f432b;

        /* renamed from: c, reason: collision with root package name */
        JobParameters f433c;

        /* renamed from: androidx.core.app.f$f$a */
        final class a implements e {

            /* renamed from: a, reason: collision with root package name */
            final JobWorkItem f434a;

            a(JobWorkItem jobWorkItem) {
                this.f434a = jobWorkItem;
            }

            @Override // androidx.core.app.f.e
            public void a() {
                synchronized (JobServiceEngineC0019f.this.f432b) {
                    JobParameters jobParameters = JobServiceEngineC0019f.this.f433c;
                    if (jobParameters != null) {
                        jobParameters.completeWork(this.f434a);
                    }
                }
            }

            @Override // androidx.core.app.f.e
            public Intent getIntent() {
                return this.f434a.getIntent();
            }
        }

        JobServiceEngineC0019f(f fVar) {
            super(fVar);
            this.f432b = new Object();
            this.f431a = fVar;
        }

        @Override // androidx.core.app.f.b
        public e a() {
            synchronized (this.f432b) {
                JobParameters jobParameters = this.f433c;
                if (jobParameters == null) {
                    return null;
                }
                JobWorkItem dequeueWork = jobParameters.dequeueWork();
                if (dequeueWork == null) {
                    return null;
                }
                dequeueWork.getIntent().setExtrasClassLoader(this.f431a.getClassLoader());
                return new a(dequeueWork);
            }
        }

        @Override // androidx.core.app.f.b
        public IBinder b() {
            return getBinder();
        }

        @Override // android.app.job.JobServiceEngine
        public boolean onStartJob(JobParameters jobParameters) {
            this.f433c = jobParameters;
            this.f431a.e(false);
            return true;
        }

        @Override // android.app.job.JobServiceEngine
        public boolean onStopJob(JobParameters jobParameters) {
            boolean b2 = this.f431a.b();
            synchronized (this.f432b) {
                this.f433c = null;
            }
            return b2;
        }
    }

    static final class g extends h {

        /* renamed from: d, reason: collision with root package name */
        private final JobInfo f436d;

        /* renamed from: e, reason: collision with root package name */
        private final JobScheduler f437e;

        g(Context context, ComponentName componentName, int i2) {
            super(componentName);
            b(i2);
            this.f436d = new JobInfo.Builder(i2, this.f438a).setOverrideDeadline(0L).build();
            this.f437e = (JobScheduler) context.getApplicationContext().getSystemService("jobscheduler");
        }

        @Override // androidx.core.app.f.h
        void a(Intent intent) {
            this.f437e.enqueue(this.f436d, new JobWorkItem(intent));
        }
    }

    static abstract class h {

        /* renamed from: a, reason: collision with root package name */
        final ComponentName f438a;

        /* renamed from: b, reason: collision with root package name */
        boolean f439b;

        /* renamed from: c, reason: collision with root package name */
        int f440c;

        h(ComponentName componentName) {
            this.f438a = componentName;
        }

        abstract void a(Intent intent);

        void b(int i2) {
            if (!this.f439b) {
                this.f439b = true;
                this.f440c = i2;
            } else {
                if (this.f440c == i2) {
                    return;
                }
                throw new IllegalArgumentException("Given job ID " + i2 + " is different than previous " + this.f440c);
            }
        }

        public void c() {
        }

        public void d() {
        }

        public void e() {
        }
    }

    public f() {
        this.s = Build.VERSION.SDK_INT >= 26 ? null : new ArrayList<>();
    }

    public static void c(Context context, ComponentName componentName, int i2, Intent intent) {
        if (intent == null) {
            throw new IllegalArgumentException("work must not be null");
        }
        synchronized (t) {
            h f2 = f(context, componentName, true, i2);
            f2.b(i2);
            f2.a(intent);
        }
    }

    public static void d(Context context, Class<?> cls, int i2, Intent intent) {
        c(context, new ComponentName(context, cls), i2, intent);
    }

    static h f(Context context, ComponentName componentName, boolean z, int i2) {
        h cVar;
        HashMap<ComponentName, h> hashMap = u;
        h hVar = hashMap.get(componentName);
        if (hVar != null) {
            return hVar;
        }
        if (Build.VERSION.SDK_INT < 26) {
            cVar = new c(context, componentName);
        } else {
            if (!z) {
                throw new IllegalArgumentException("Can't be here without a job id");
            }
            cVar = new g(context, componentName, i2);
        }
        h hVar2 = cVar;
        hashMap.put(componentName, hVar2);
        return hVar2;
    }

    e a() {
        b bVar = this.n;
        if (bVar != null) {
            return bVar.a();
        }
        synchronized (this.s) {
            if (this.s.size() <= 0) {
                return null;
            }
            return this.s.remove(0);
        }
    }

    boolean b() {
        a aVar = this.p;
        if (aVar != null) {
            aVar.cancel(this.q);
        }
        return h();
    }

    void e(boolean z) {
        if (this.p == null) {
            this.p = new a();
            h hVar = this.o;
            if (hVar != null && z) {
                hVar.d();
            }
            this.p.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
        }
    }

    protected abstract void g(Intent intent);

    public boolean h() {
        return true;
    }

    void i() {
        ArrayList<d> arrayList = this.s;
        if (arrayList != null) {
            synchronized (arrayList) {
                this.p = null;
                ArrayList<d> arrayList2 = this.s;
                if (arrayList2 != null && arrayList2.size() > 0) {
                    e(false);
                } else if (!this.r) {
                    this.o.c();
                }
            }
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        b bVar = this.n;
        if (bVar != null) {
            return bVar.b();
        }
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            this.n = new JobServiceEngineC0019f(this);
            this.o = null;
        } else {
            this.n = null;
            this.o = f(this, new ComponentName(this, getClass()), false, 0);
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        ArrayList<d> arrayList = this.s;
        if (arrayList != null) {
            synchronized (arrayList) {
                this.r = true;
                this.o.c();
            }
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i2, int i3) {
        if (this.s == null) {
            return 2;
        }
        this.o.e();
        synchronized (this.s) {
            ArrayList<d> arrayList = this.s;
            if (intent == null) {
                intent = new Intent();
            }
            arrayList.add(new d(intent, i3));
            e(true);
        }
        return 3;
    }
}
