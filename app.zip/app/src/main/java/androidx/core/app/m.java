package androidx.core.app;

import android.app.RemoteInput;
import android.os.Build;
import android.os.Bundle;
import java.util.Iterator;
import java.util.Set;

/* loaded from: classes.dex */
public final class m {
    static RemoteInput a(m mVar) {
        Set<String> d2;
        RemoteInput.Builder addExtras = new RemoteInput.Builder(mVar.i()).setLabel(mVar.h()).setChoices(mVar.e()).setAllowFreeFormInput(mVar.c()).addExtras(mVar.g());
        if (Build.VERSION.SDK_INT >= 26 && (d2 = mVar.d()) != null) {
            Iterator<String> it = d2.iterator();
            while (it.hasNext()) {
                addExtras.setAllowDataType(it.next(), true);
            }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            addExtras.setEditChoicesBeforeSending(mVar.f());
        }
        return addExtras.build();
    }

    static RemoteInput[] b(m[] mVarArr) {
        if (mVarArr == null) {
            return null;
        }
        RemoteInput[] remoteInputArr = new RemoteInput[mVarArr.length];
        for (int i2 = 0; i2 < mVarArr.length; i2++) {
            remoteInputArr[i2] = a(mVarArr[i2]);
        }
        return remoteInputArr;
    }

    public boolean c() {
        throw null;
    }

    public Set<String> d() {
        throw null;
    }

    public CharSequence[] e() {
        throw null;
    }

    public int f() {
        throw null;
    }

    public Bundle g() {
        throw null;
    }

    public CharSequence h() {
        throw null;
    }

    public String i() {
        throw null;
    }
}
