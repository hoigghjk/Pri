package androidx.core.app;

import android.app.Activity;
import android.app.Application;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

/* loaded from: classes.dex */
final class b {

    /* renamed from: a, reason: collision with root package name */
    protected static final Class<?> f411a;

    /* renamed from: b, reason: collision with root package name */
    protected static final Field f412b;

    /* renamed from: c, reason: collision with root package name */
    protected static final Field f413c;

    /* renamed from: d, reason: collision with root package name */
    protected static final Method f414d;

    /* renamed from: e, reason: collision with root package name */
    protected static final Method f415e;

    /* renamed from: f, reason: collision with root package name */
    protected static final Method f416f;

    /* renamed from: g, reason: collision with root package name */
    private static final Handler f417g = new Handler(Looper.getMainLooper());

    class a implements Runnable {
        final /* synthetic */ d n;
        final /* synthetic */ Object o;

        a(d dVar, Object obj) {
            this.n = dVar;
            this.o = obj;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.n.n = this.o;
        }
    }

    /* renamed from: androidx.core.app.b$b, reason: collision with other inner class name */
    class RunnableC0018b implements Runnable {
        final /* synthetic */ Application n;
        final /* synthetic */ d o;

        RunnableC0018b(Application application, d dVar) {
            this.n = application;
            this.o = dVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.n.unregisterActivityLifecycleCallbacks(this.o);
        }
    }

    class c implements Runnable {
        final /* synthetic */ Object n;
        final /* synthetic */ Object o;

        c(Object obj, Object obj2) {
            this.n = obj;
            this.o = obj2;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                Method method = b.f414d;
                if (method != null) {
                    method.invoke(this.n, this.o, Boolean.FALSE, "AppCompat recreation");
                } else {
                    b.f415e.invoke(this.n, this.o, Boolean.FALSE);
                }
            } catch (RuntimeException e2) {
                if (e2.getClass() == RuntimeException.class && e2.getMessage() != null && e2.getMessage().startsWith("Unable to stop")) {
                    throw e2;
                }
            } catch (Throwable th) {
                Log.e("ActivityRecreator", "Exception while invoking performStopActivity", th);
            }
        }
    }

    private static final class d implements Application.ActivityLifecycleCallbacks {
        Object n;
        private Activity o;
        private final int p;
        private boolean q = false;
        private boolean r = false;
        private boolean s = false;

        d(Activity activity) {
            this.o = activity;
            this.p = activity.hashCode();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityDestroyed(Activity activity) {
            if (this.o == activity) {
                this.o = null;
                this.r = true;
            }
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
            if (!this.r || this.s || this.q || !b.h(this.n, this.p, activity)) {
                return;
            }
            this.s = true;
            this.n = null;
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityResumed(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStarted(Activity activity) {
            if (this.o == activity) {
                this.q = true;
            }
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
        }
    }

    static {
        Class<?> a2 = a();
        f411a = a2;
        f412b = b();
        f413c = f();
        f414d = d(a2);
        f415e = c(a2);
        f416f = e(a2);
    }

    private static Class<?> a() {
        try {
            return Class.forName("android.app.ActivityThread");
        } catch (Throwable unused) {
            return null;
        }
    }

    private static Field b() {
        try {
            Field declaredField = Activity.class.getDeclaredField("mMainThread");
            declaredField.setAccessible(true);
            return declaredField;
        } catch (Throwable unused) {
            return null;
        }
    }

    private static Method c(Class<?> cls) {
        if (cls == null) {
            return null;
        }
        try {
            Method declaredMethod = cls.getDeclaredMethod("performStopActivity", IBinder.class, Boolean.TYPE);
            declaredMethod.setAccessible(true);
            return declaredMethod;
        } catch (Throwable unused) {
            return null;
        }
    }

    private static Method d(Class<?> cls) {
        if (cls == null) {
            return null;
        }
        try {
            Method declaredMethod = cls.getDeclaredMethod("performStopActivity", IBinder.class, Boolean.TYPE, String.class);
            declaredMethod.setAccessible(true);
            return declaredMethod;
        } catch (Throwable unused) {
            return null;
        }
    }

    private static Method e(Class<?> cls) {
        if (g() && cls != null) {
            try {
                Class<?> cls2 = Boolean.TYPE;
                Method declaredMethod = cls.getDeclaredMethod("requestRelaunchActivity", IBinder.class, List.class, List.class, Integer.TYPE, cls2, Configuration.class, Configuration.class, cls2, cls2);
                declaredMethod.setAccessible(true);
                return declaredMethod;
            } catch (Throwable unused) {
            }
        }
        return null;
    }

    private static Field f() {
        try {
            Field declaredField = Activity.class.getDeclaredField("mToken");
            declaredField.setAccessible(true);
            return declaredField;
        } catch (Throwable unused) {
            return null;
        }
    }

    private static boolean g() {
        int i2 = Build.VERSION.SDK_INT;
        return i2 == 26 || i2 == 27;
    }

    protected static boolean h(Object obj, int i2, Activity activity) {
        try {
            Object obj2 = f413c.get(activity);
            if (obj2 == obj && activity.hashCode() == i2) {
                f417g.postAtFrontOfQueue(new c(f412b.get(activity), obj2));
                return true;
            }
            return false;
        } catch (Throwable th) {
            Log.e("ActivityRecreator", "Exception while fetching field values", th);
            return false;
        }
    }

    static boolean i(Activity activity) {
        Object obj;
        if (Build.VERSION.SDK_INT >= 28) {
            activity.recreate();
            return true;
        }
        if (g() && f416f == null) {
            return false;
        }
        if (f415e == null && f414d == null) {
            return false;
        }
        try {
            Object obj2 = f413c.get(activity);
            if (obj2 == null || (obj = f412b.get(activity)) == null) {
                return false;
            }
            Application application = activity.getApplication();
            d dVar = new d(activity);
            application.registerActivityLifecycleCallbacks(dVar);
            Handler handler = f417g;
            handler.post(new a(dVar, obj2));
            try {
                if (g()) {
                    Method method = f416f;
                    Boolean bool = Boolean.FALSE;
                    method.invoke(obj, obj2, null, null, 0, bool, null, null, bool, bool);
                } else {
                    activity.recreate();
                }
                handler.post(new RunnableC0018b(application, dVar));
                return true;
            } catch (Throwable th) {
                f417g.post(new RunnableC0018b(application, dVar));
                throw th;
            }
        } catch (Throwable unused) {
            return false;
        }
    }
}
