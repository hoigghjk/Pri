package androidx.core.app;

import android.app.Activity;
import android.app.SharedElementCallback;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.View;
import androidx.core.app.n;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public class a extends b.g.e.a {

    /* renamed from: d, reason: collision with root package name */
    private static d f409d;

    /* renamed from: androidx.core.app.a$a, reason: collision with other inner class name */
    class RunnableC0016a implements Runnable {
        final /* synthetic */ String[] n;
        final /* synthetic */ Activity o;
        final /* synthetic */ int p;

        RunnableC0016a(String[] strArr, Activity activity, int i2) {
            this.n = strArr;
            this.o = activity;
            this.p = i2;
        }

        @Override // java.lang.Runnable
        public void run() {
            int[] iArr = new int[this.n.length];
            PackageManager packageManager = this.o.getPackageManager();
            String packageName = this.o.getPackageName();
            int length = this.n.length;
            for (int i2 = 0; i2 < length; i2++) {
                iArr[i2] = packageManager.checkPermission(this.n[i2], packageName);
            }
            ((c) this.o).onRequestPermissionsResult(this.p, this.n, iArr);
        }
    }

    class b implements Runnable {
        final /* synthetic */ Activity n;

        b(Activity activity) {
            this.n = activity;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.n.isFinishing() || androidx.core.app.b.i(this.n)) {
                return;
            }
            this.n.recreate();
        }
    }

    public interface c {
        void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr);
    }

    public interface d {
        boolean a(Activity activity, int i2, int i3, Intent intent);

        boolean b(Activity activity, String[] strArr, int i2);
    }

    public interface e {
        void validateRequestPermissionsRequestCode(int i2);
    }

    private static class f extends SharedElementCallback {

        /* renamed from: a, reason: collision with root package name */
        private final n f410a;

        /* renamed from: androidx.core.app.a$f$a, reason: collision with other inner class name */
        class C0017a implements n.a {
            C0017a(f fVar, SharedElementCallback.OnSharedElementsReadyListener onSharedElementsReadyListener) {
            }
        }

        f(n nVar) {
        }

        @Override // android.app.SharedElementCallback
        public Parcelable onCaptureSharedElementSnapshot(View view, Matrix matrix, RectF rectF) {
            return this.f410a.a(view, matrix, rectF);
        }

        @Override // android.app.SharedElementCallback
        public View onCreateSnapshotView(Context context, Parcelable parcelable) {
            return this.f410a.b(context, parcelable);
        }

        @Override // android.app.SharedElementCallback
        public void onMapSharedElements(List<String> list, Map<String, View> map) {
            this.f410a.c(list, map);
        }

        @Override // android.app.SharedElementCallback
        public void onRejectSharedElements(List<View> list) {
            this.f410a.d(list);
        }

        @Override // android.app.SharedElementCallback
        public void onSharedElementEnd(List<String> list, List<View> list2, List<View> list3) {
            this.f410a.e(list, list2, list3);
        }

        @Override // android.app.SharedElementCallback
        public void onSharedElementStart(List<String> list, List<View> list2, List<View> list3) {
            this.f410a.f(list, list2, list3);
        }

        @Override // android.app.SharedElementCallback
        public void onSharedElementsArrived(List<String> list, List<View> list2, SharedElementCallback.OnSharedElementsReadyListener onSharedElementsReadyListener) {
            this.f410a.g(list, list2, new C0017a(this, onSharedElementsReadyListener));
        }
    }

    public static void l(Activity activity) {
        if (Build.VERSION.SDK_INT >= 16) {
            activity.finishAffinity();
        } else {
            activity.finish();
        }
    }

    public static void m(Activity activity) {
        if (Build.VERSION.SDK_INT >= 21) {
            activity.finishAfterTransition();
        } else {
            activity.finish();
        }
    }

    public static d n() {
        return f409d;
    }

    public static void o(Activity activity) {
        if (Build.VERSION.SDK_INT >= 21) {
            activity.postponeEnterTransition();
        }
    }

    public static void p(Activity activity) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 < 28) {
            if (i2 <= 23) {
                new Handler(activity.getMainLooper()).post(new b(activity));
                return;
            } else if (androidx.core.app.b.i(activity)) {
                return;
            }
        }
        activity.recreate();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void q(Activity activity, String[] strArr, int i2) {
        d dVar = f409d;
        if (dVar == null || !dVar.b(activity, strArr, i2)) {
            for (String str : strArr) {
                if (TextUtils.isEmpty(str)) {
                    throw new IllegalArgumentException("Permission request for permissions " + Arrays.toString(strArr) + " must not contain null or empty values");
                }
            }
            if (Build.VERSION.SDK_INT >= 23) {
                if (activity instanceof e) {
                    ((e) activity).validateRequestPermissionsRequestCode(i2);
                }
                activity.requestPermissions(strArr, i2);
            } else if (activity instanceof c) {
                new Handler(Looper.getMainLooper()).post(new RunnableC0016a(strArr, activity, i2));
            }
        }
    }

    public static void r(Activity activity, n nVar) {
        if (Build.VERSION.SDK_INT >= 21) {
            activity.setEnterSharedElementCallback(nVar != null ? new f(nVar) : null);
        }
    }

    public static void s(Activity activity, n nVar) {
        if (Build.VERSION.SDK_INT >= 21) {
            activity.setExitSharedElementCallback(nVar != null ? new f(nVar) : null);
        }
    }

    public static void t(Activity activity, Intent intent, int i2, Bundle bundle) {
        if (Build.VERSION.SDK_INT >= 16) {
            activity.startActivityForResult(intent, i2, bundle);
        } else {
            activity.startActivityForResult(intent, i2);
        }
    }

    public static void u(Activity activity, IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5, Bundle bundle) {
        if (Build.VERSION.SDK_INT >= 16) {
            activity.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5, bundle);
        } else {
            activity.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5);
        }
    }

    public static void v(Activity activity) {
        if (Build.VERSION.SDK_INT >= 21) {
            activity.startPostponedEnterTransition();
        }
    }
}
