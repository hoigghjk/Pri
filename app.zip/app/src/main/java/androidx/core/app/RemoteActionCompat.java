package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements androidx.versionedparcelable.c {

    /* renamed from: a, reason: collision with root package name */
    public IconCompat f403a;

    /* renamed from: b, reason: collision with root package name */
    public CharSequence f404b;

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f405c;

    /* renamed from: d, reason: collision with root package name */
    public PendingIntent f406d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f407e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f408f;
}
