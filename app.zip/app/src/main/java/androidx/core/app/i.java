package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class i {

    public static class a {

        /* renamed from: a, reason: collision with root package name */
        final Bundle f441a;

        /* renamed from: b, reason: collision with root package name */
        private IconCompat f442b;

        /* renamed from: c, reason: collision with root package name */
        private final m[] f443c;

        /* renamed from: d, reason: collision with root package name */
        private final m[] f444d;

        /* renamed from: e, reason: collision with root package name */
        private boolean f445e;

        /* renamed from: f, reason: collision with root package name */
        boolean f446f;

        /* renamed from: g, reason: collision with root package name */
        private final int f447g;

        /* renamed from: h, reason: collision with root package name */
        private final boolean f448h;

        /* renamed from: i, reason: collision with root package name */
        @Deprecated
        public int f449i;

        /* renamed from: j, reason: collision with root package name */
        public CharSequence f450j;

        /* renamed from: k, reason: collision with root package name */
        public PendingIntent f451k;

        public a(int i2, CharSequence charSequence, PendingIntent pendingIntent) {
            this(i2 != 0 ? IconCompat.c(null, "", i2) : null, charSequence, pendingIntent);
        }

        public a(IconCompat iconCompat, CharSequence charSequence, PendingIntent pendingIntent) {
            this(iconCompat, charSequence, pendingIntent, new Bundle(), null, null, true, 0, true, false);
        }

        a(IconCompat iconCompat, CharSequence charSequence, PendingIntent pendingIntent, Bundle bundle, m[] mVarArr, m[] mVarArr2, boolean z, int i2, boolean z2, boolean z3) {
            this.f446f = true;
            this.f442b = iconCompat;
            if (iconCompat != null && iconCompat.i() == 2) {
                this.f449i = iconCompat.e();
            }
            this.f450j = e.d(charSequence);
            this.f451k = pendingIntent;
            this.f441a = bundle == null ? new Bundle() : bundle;
            this.f443c = mVarArr;
            this.f444d = mVarArr2;
            this.f445e = z;
            this.f447g = i2;
            this.f446f = z2;
            this.f448h = z3;
        }

        public PendingIntent a() {
            return this.f451k;
        }

        public boolean b() {
            return this.f445e;
        }

        public m[] c() {
            return this.f444d;
        }

        public Bundle d() {
            return this.f441a;
        }

        public IconCompat e() {
            int i2;
            if (this.f442b == null && (i2 = this.f449i) != 0) {
                this.f442b = IconCompat.c(null, "", i2);
            }
            return this.f442b;
        }

        public m[] f() {
            return this.f443c;
        }

        public int g() {
            return this.f447g;
        }

        public boolean h() {
            return this.f446f;
        }

        public CharSequence i() {
            return this.f450j;
        }

        public boolean j() {
            return this.f448h;
        }
    }

    public static class b extends f {

        /* renamed from: e, reason: collision with root package name */
        private Bitmap f452e;

        /* renamed from: f, reason: collision with root package name */
        private IconCompat f453f;

        /* renamed from: g, reason: collision with root package name */
        private boolean f454g;

        private static class a {
            static void a(Notification.BigPictureStyle bigPictureStyle, Bitmap bitmap) {
                bigPictureStyle.bigLargeIcon(bitmap);
            }

            static void b(Notification.BigPictureStyle bigPictureStyle, CharSequence charSequence) {
                bigPictureStyle.setSummaryText(charSequence);
            }
        }

        /* renamed from: androidx.core.app.i$b$b, reason: collision with other inner class name */
        private static class C0020b {
            static void a(Notification.BigPictureStyle bigPictureStyle, Icon icon) {
                bigPictureStyle.bigLargeIcon(icon);
            }
        }

        @Override // androidx.core.app.i.f
        public void b(h hVar) {
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 16) {
                Notification.BigPictureStyle bigPicture = new Notification.BigPictureStyle(hVar.a()).setBigContentTitle(this.f468b).bigPicture(this.f452e);
                if (this.f454g) {
                    IconCompat iconCompat = this.f453f;
                    if (iconCompat != null) {
                        if (i2 >= 23) {
                            C0020b.a(bigPicture, this.f453f.q(hVar instanceof j ? ((j) hVar).f() : null));
                        } else if (iconCompat.i() == 1) {
                            a.a(bigPicture, this.f453f.d());
                        }
                    }
                    a.a(bigPicture, null);
                }
                if (this.f470d) {
                    a.b(bigPicture, this.f469c);
                }
            }
        }

        @Override // androidx.core.app.i.f
        protected String c() {
            return "androidx.core.app.NotificationCompat$BigPictureStyle";
        }

        public b h(Bitmap bitmap) {
            this.f453f = bitmap == null ? null : IconCompat.b(bitmap);
            this.f454g = true;
            return this;
        }

        public b i(Bitmap bitmap) {
            this.f452e = bitmap;
            return this;
        }
    }

    public static class c extends f {

        /* renamed from: e, reason: collision with root package name */
        private CharSequence f455e;

        @Override // androidx.core.app.i.f
        public void a(Bundle bundle) {
            super.a(bundle);
            if (Build.VERSION.SDK_INT < 21) {
                bundle.putCharSequence("android.bigText", this.f455e);
            }
        }

        @Override // androidx.core.app.i.f
        public void b(h hVar) {
            if (Build.VERSION.SDK_INT >= 16) {
                Notification.BigTextStyle bigText = new Notification.BigTextStyle(hVar.a()).setBigContentTitle(this.f468b).bigText(this.f455e);
                if (this.f470d) {
                    bigText.setSummaryText(this.f469c);
                }
            }
        }

        @Override // androidx.core.app.i.f
        protected String c() {
            return "androidx.core.app.NotificationCompat$BigTextStyle";
        }

        public c h(CharSequence charSequence) {
            this.f455e = e.d(charSequence);
            return this;
        }
    }

    public static final class d {

        private static class a {
            static Notification.BubbleMetadata a(d dVar) {
                if (dVar == null) {
                    return null;
                }
                dVar.a();
                throw null;
            }
        }

        private static class b {
            static Notification.BubbleMetadata a(d dVar) {
                if (dVar == null) {
                    return null;
                }
                dVar.b();
                throw null;
            }
        }

        public static Notification.BubbleMetadata c(d dVar) {
            if (dVar == null) {
                return null;
            }
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 30) {
                return b.a(dVar);
            }
            if (i2 == 29) {
                return a.a(dVar);
            }
            return null;
        }

        public PendingIntent a() {
            throw null;
        }

        public String b() {
            throw null;
        }
    }

    public static class e {
        boolean A;
        boolean B;
        String C;
        Bundle D;
        int E;
        int F;
        Notification G;
        RemoteViews H;
        RemoteViews I;
        RemoteViews J;
        String K;
        int L;
        String M;
        b.g.e.c N;
        long O;
        int P;
        boolean Q;
        d R;
        Notification S;
        boolean T;
        Icon U;

        @Deprecated
        public ArrayList<String> V;

        /* renamed from: a, reason: collision with root package name */
        public Context f456a;

        /* renamed from: b, reason: collision with root package name */
        public ArrayList<a> f457b;

        /* renamed from: c, reason: collision with root package name */
        public ArrayList<l> f458c;

        /* renamed from: d, reason: collision with root package name */
        ArrayList<a> f459d;

        /* renamed from: e, reason: collision with root package name */
        CharSequence f460e;

        /* renamed from: f, reason: collision with root package name */
        CharSequence f461f;

        /* renamed from: g, reason: collision with root package name */
        PendingIntent f462g;

        /* renamed from: h, reason: collision with root package name */
        PendingIntent f463h;

        /* renamed from: i, reason: collision with root package name */
        RemoteViews f464i;

        /* renamed from: j, reason: collision with root package name */
        Bitmap f465j;

        /* renamed from: k, reason: collision with root package name */
        CharSequence f466k;
        int l;
        int m;
        boolean n;
        boolean o;
        f p;
        CharSequence q;
        CharSequence r;
        CharSequence[] s;
        int t;
        int u;
        boolean v;
        String w;
        boolean x;
        String y;
        boolean z;

        @Deprecated
        public e(Context context) {
            this(context, null);
        }

        public e(Context context, String str) {
            this.f457b = new ArrayList<>();
            this.f458c = new ArrayList<>();
            this.f459d = new ArrayList<>();
            this.n = true;
            this.z = false;
            this.E = 0;
            this.F = 0;
            this.L = 0;
            this.P = 0;
            Notification notification = new Notification();
            this.S = notification;
            this.f456a = context;
            this.K = str;
            notification.when = System.currentTimeMillis();
            this.S.audioStreamType = -1;
            this.m = 0;
            this.V = new ArrayList<>();
            this.Q = true;
        }

        protected static CharSequence d(CharSequence charSequence) {
            return (charSequence != null && charSequence.length() > 5120) ? charSequence.subSequence(0, 5120) : charSequence;
        }

        private Bitmap e(Bitmap bitmap) {
            if (bitmap == null || Build.VERSION.SDK_INT >= 27) {
                return bitmap;
            }
            Resources resources = this.f456a.getResources();
            int dimensionPixelSize = resources.getDimensionPixelSize(b.g.b.f1093b);
            int dimensionPixelSize2 = resources.getDimensionPixelSize(b.g.b.f1092a);
            if (bitmap.getWidth() <= dimensionPixelSize && bitmap.getHeight() <= dimensionPixelSize2) {
                return bitmap;
            }
            double min = Math.min(dimensionPixelSize / Math.max(1, bitmap.getWidth()), dimensionPixelSize2 / Math.max(1, bitmap.getHeight()));
            return Bitmap.createScaledBitmap(bitmap, (int) Math.ceil(bitmap.getWidth() * min), (int) Math.ceil(bitmap.getHeight() * min), true);
        }

        private void n(int i2, boolean z) {
            Notification notification;
            int i3;
            if (z) {
                notification = this.S;
                i3 = i2 | notification.flags;
            } else {
                notification = this.S;
                i3 = (~i2) & notification.flags;
            }
            notification.flags = i3;
        }

        public e A(long j2) {
            this.S.when = j2;
            return this;
        }

        public e a(int i2, CharSequence charSequence, PendingIntent pendingIntent) {
            this.f457b.add(new a(i2, charSequence, pendingIntent));
            return this;
        }

        public Notification b() {
            return new j(this).c();
        }

        public Bundle c() {
            if (this.D == null) {
                this.D = new Bundle();
            }
            return this.D;
        }

        public e f(boolean z) {
            n(16, z);
            return this;
        }

        public e g(String str) {
            this.K = str;
            return this;
        }

        public e h(int i2) {
            this.E = i2;
            return this;
        }

        public e i(PendingIntent pendingIntent) {
            this.f462g = pendingIntent;
            return this;
        }

        public e j(CharSequence charSequence) {
            this.f461f = d(charSequence);
            return this;
        }

        public e k(CharSequence charSequence) {
            this.f460e = d(charSequence);
            return this;
        }

        public e l(int i2) {
            Notification notification = this.S;
            notification.defaults = i2;
            if ((i2 & 4) != 0) {
                notification.flags |= 1;
            }
            return this;
        }

        public e m(PendingIntent pendingIntent) {
            this.S.deleteIntent = pendingIntent;
            return this;
        }

        public e o(Bitmap bitmap) {
            this.f465j = e(bitmap);
            return this;
        }

        public e p(int i2, int i3, int i4) {
            Notification notification = this.S;
            notification.ledARGB = i2;
            notification.ledOnMS = i3;
            notification.ledOffMS = i4;
            notification.flags = ((i3 == 0 || i4 == 0) ? 0 : 1) | (notification.flags & (-2));
            return this;
        }

        public e q(boolean z) {
            this.z = z;
            return this;
        }

        public e r(int i2) {
            this.l = i2;
            return this;
        }

        public e s(int i2) {
            this.m = i2;
            return this;
        }

        public e t(boolean z) {
            this.n = z;
            return this;
        }

        public e u(int i2) {
            this.S.icon = i2;
            return this;
        }

        public e v(Uri uri) {
            Notification notification = this.S;
            notification.sound = uri;
            notification.audioStreamType = -1;
            if (Build.VERSION.SDK_INT >= 21) {
                notification.audioAttributes = new AudioAttributes.Builder().setContentType(4).setUsage(5).build();
            }
            return this;
        }

        public e w(f fVar) {
            if (this.p != fVar) {
                this.p = fVar;
                if (fVar != null) {
                    fVar.g(this);
                }
            }
            return this;
        }

        public e x(CharSequence charSequence) {
            this.S.tickerText = d(charSequence);
            return this;
        }

        public e y(long[] jArr) {
            this.S.vibrate = jArr;
            return this;
        }

        public e z(int i2) {
            this.F = i2;
            return this;
        }
    }

    public static abstract class f {

        /* renamed from: a, reason: collision with root package name */
        protected e f467a;

        /* renamed from: b, reason: collision with root package name */
        CharSequence f468b;

        /* renamed from: c, reason: collision with root package name */
        CharSequence f469c;

        /* renamed from: d, reason: collision with root package name */
        boolean f470d = false;

        public void a(Bundle bundle) {
            if (this.f470d) {
                bundle.putCharSequence("android.summaryText", this.f469c);
            }
            CharSequence charSequence = this.f468b;
            if (charSequence != null) {
                bundle.putCharSequence("android.title.big", charSequence);
            }
            String c2 = c();
            if (c2 != null) {
                bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", c2);
            }
        }

        public abstract void b(h hVar);

        protected abstract String c();

        public RemoteViews d(h hVar) {
            return null;
        }

        public RemoteViews e(h hVar) {
            return null;
        }

        public RemoteViews f(h hVar) {
            return null;
        }

        public void g(e eVar) {
            if (this.f467a != eVar) {
                this.f467a = eVar;
                if (eVar != null) {
                    eVar.w(this);
                }
            }
        }
    }

    public static Bundle a(Notification notification) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 19) {
            return notification.extras;
        }
        if (i2 >= 16) {
            return k.c(notification);
        }
        return null;
    }
}
