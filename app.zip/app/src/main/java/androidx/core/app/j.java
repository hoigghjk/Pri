package androidx.core.app;

import android.app.Notification;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.SparseArray;
import android.widget.RemoteViews;
import androidx.core.app.i;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
class j implements h {

    /* renamed from: a, reason: collision with root package name */
    private final Context f471a;

    /* renamed from: b, reason: collision with root package name */
    private final Notification.Builder f472b;

    /* renamed from: c, reason: collision with root package name */
    private final i.e f473c;

    /* renamed from: d, reason: collision with root package name */
    private RemoteViews f474d;

    /* renamed from: e, reason: collision with root package name */
    private RemoteViews f475e;

    /* renamed from: f, reason: collision with root package name */
    private final List<Bundle> f476f = new ArrayList();

    /* renamed from: g, reason: collision with root package name */
    private final Bundle f477g = new Bundle();

    /* renamed from: h, reason: collision with root package name */
    private int f478h;

    /* renamed from: i, reason: collision with root package name */
    private RemoteViews f479i;

    j(i.e eVar) {
        Icon icon;
        List<String> e2;
        Bundle bundle;
        String str;
        this.f473c = eVar;
        this.f471a = eVar.f456a;
        int i2 = Build.VERSION.SDK_INT;
        Context context = eVar.f456a;
        this.f472b = i2 >= 26 ? new Notification.Builder(context, eVar.K) : new Notification.Builder(context);
        Notification notification = eVar.S;
        this.f472b.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, eVar.f464i).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(eVar.f460e).setContentText(eVar.f461f).setContentInfo(eVar.f466k).setContentIntent(eVar.f462g).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(eVar.f463h, (notification.flags & 128) != 0).setLargeIcon(eVar.f465j).setNumber(eVar.l).setProgress(eVar.t, eVar.u, eVar.v);
        if (i2 < 21) {
            this.f472b.setSound(notification.sound, notification.audioStreamType);
        }
        if (i2 >= 16) {
            this.f472b.setSubText(eVar.q).setUsesChronometer(eVar.o).setPriority(eVar.m);
            Iterator<i.a> it = eVar.f457b.iterator();
            while (it.hasNext()) {
                b(it.next());
            }
            Bundle bundle2 = eVar.D;
            if (bundle2 != null) {
                this.f477g.putAll(bundle2);
            }
            if (Build.VERSION.SDK_INT < 20) {
                if (eVar.z) {
                    this.f477g.putBoolean("android.support.localOnly", true);
                }
                String str2 = eVar.w;
                if (str2 != null) {
                    this.f477g.putString("android.support.groupKey", str2);
                    if (eVar.x) {
                        bundle = this.f477g;
                        str = "android.support.isGroupSummary";
                    } else {
                        bundle = this.f477g;
                        str = "android.support.useSideChannel";
                    }
                    bundle.putBoolean(str, true);
                }
                String str3 = eVar.y;
                if (str3 != null) {
                    this.f477g.putString("android.support.sortKey", str3);
                }
            }
            this.f474d = eVar.H;
            this.f475e = eVar.I;
        }
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 17) {
            this.f472b.setShowWhen(eVar.n);
        }
        if (i3 >= 19 && i3 < 21 && (e2 = e(g(eVar.f458c), eVar.V)) != null && !e2.isEmpty()) {
            this.f477g.putStringArray("android.people", (String[]) e2.toArray(new String[e2.size()]));
        }
        if (i3 >= 20) {
            this.f472b.setLocalOnly(eVar.z).setGroup(eVar.w).setGroupSummary(eVar.x).setSortKey(eVar.y);
            this.f478h = eVar.P;
        }
        if (i3 >= 21) {
            this.f472b.setCategory(eVar.C).setColor(eVar.E).setVisibility(eVar.F).setPublicVersion(eVar.G).setSound(notification.sound, notification.audioAttributes);
            List e3 = i3 < 28 ? e(g(eVar.f458c), eVar.V) : eVar.V;
            if (e3 != null && !e3.isEmpty()) {
                Iterator it2 = e3.iterator();
                while (it2.hasNext()) {
                    this.f472b.addPerson((String) it2.next());
                }
            }
            this.f479i = eVar.J;
            if (eVar.f459d.size() > 0) {
                Bundle bundle3 = eVar.c().getBundle("android.car.EXTENSIONS");
                bundle3 = bundle3 == null ? new Bundle() : bundle3;
                Bundle bundle4 = new Bundle(bundle3);
                Bundle bundle5 = new Bundle();
                for (int i4 = 0; i4 < eVar.f459d.size(); i4++) {
                    bundle5.putBundle(Integer.toString(i4), k.b(eVar.f459d.get(i4)));
                }
                bundle3.putBundle("invisible_actions", bundle5);
                bundle4.putBundle("invisible_actions", bundle5);
                eVar.c().putBundle("android.car.EXTENSIONS", bundle3);
                this.f477g.putBundle("android.car.EXTENSIONS", bundle4);
            }
        }
        int i5 = Build.VERSION.SDK_INT;
        if (i5 >= 23 && (icon = eVar.U) != null) {
            this.f472b.setSmallIcon(icon);
        }
        if (i5 >= 24) {
            this.f472b.setExtras(eVar.D).setRemoteInputHistory(eVar.s);
            RemoteViews remoteViews = eVar.H;
            if (remoteViews != null) {
                this.f472b.setCustomContentView(remoteViews);
            }
            RemoteViews remoteViews2 = eVar.I;
            if (remoteViews2 != null) {
                this.f472b.setCustomBigContentView(remoteViews2);
            }
            RemoteViews remoteViews3 = eVar.J;
            if (remoteViews3 != null) {
                this.f472b.setCustomHeadsUpContentView(remoteViews3);
            }
        }
        if (i5 >= 26) {
            this.f472b.setBadgeIconType(eVar.L).setSettingsText(eVar.r).setShortcutId(eVar.M).setTimeoutAfter(eVar.O).setGroupAlertBehavior(eVar.P);
            if (eVar.B) {
                this.f472b.setColorized(eVar.A);
            }
            if (!TextUtils.isEmpty(eVar.K)) {
                this.f472b.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null);
            }
        }
        if (i5 >= 28) {
            Iterator<l> it3 = eVar.f458c.iterator();
            while (it3.hasNext()) {
                this.f472b.addPerson(it3.next().h());
            }
        }
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 29) {
            this.f472b.setAllowSystemGeneratedContextualActions(eVar.Q);
            this.f472b.setBubbleMetadata(i.d.c(eVar.R));
            b.g.e.c cVar = eVar.N;
            if (cVar != null) {
                cVar.a();
                throw null;
            }
        }
        if (eVar.T) {
            if (this.f473c.x) {
                this.f478h = 2;
            } else {
                this.f478h = 1;
            }
            this.f472b.setVibrate(null);
            this.f472b.setSound(null);
            int i7 = notification.defaults & (-2);
            notification.defaults = i7;
            int i8 = i7 & (-3);
            notification.defaults = i8;
            this.f472b.setDefaults(i8);
            if (i6 >= 26) {
                if (TextUtils.isEmpty(this.f473c.w)) {
                    this.f472b.setGroup("silent");
                }
                this.f472b.setGroupAlertBehavior(this.f478h);
            }
        }
    }

    private void b(i.a aVar) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 < 20) {
            if (i2 >= 16) {
                this.f476f.add(k.f(this.f472b, aVar));
                return;
            }
            return;
        }
        IconCompat e2 = aVar.e();
        Notification.Action.Builder builder = i2 >= 23 ? new Notification.Action.Builder(e2 != null ? e2.p() : null, aVar.i(), aVar.a()) : new Notification.Action.Builder(e2 != null ? e2.e() : 0, aVar.i(), aVar.a());
        if (aVar.f() != null) {
            for (RemoteInput remoteInput : m.b(aVar.f())) {
                builder.addRemoteInput(remoteInput);
            }
        }
        Bundle bundle = aVar.d() != null ? new Bundle(aVar.d()) : new Bundle();
        bundle.putBoolean("android.support.allowGeneratedReplies", aVar.b());
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 24) {
            builder.setAllowGeneratedReplies(aVar.b());
        }
        bundle.putInt("android.support.action.semanticAction", aVar.g());
        if (i3 >= 28) {
            builder.setSemanticAction(aVar.g());
        }
        if (i3 >= 29) {
            builder.setContextual(aVar.j());
        }
        bundle.putBoolean("android.support.action.showsUserInterface", aVar.h());
        builder.addExtras(bundle);
        this.f472b.addAction(builder.build());
    }

    private static List<String> e(List<String> list, List<String> list2) {
        if (list == null) {
            return list2;
        }
        if (list2 == null) {
            return list;
        }
        b.e.b bVar = new b.e.b(list.size() + list2.size());
        bVar.addAll(list);
        bVar.addAll(list2);
        return new ArrayList(bVar);
    }

    private static List<String> g(List<l> list) {
        if (list == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(list.size());
        Iterator<l> it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(it.next().g());
        }
        return arrayList;
    }

    private void h(Notification notification) {
        notification.sound = null;
        notification.vibrate = null;
        int i2 = notification.defaults & (-2);
        notification.defaults = i2;
        notification.defaults = i2 & (-3);
    }

    @Override // androidx.core.app.h
    public Notification.Builder a() {
        return this.f472b;
    }

    public Notification c() {
        Bundle a2;
        RemoteViews f2;
        RemoteViews d2;
        i.f fVar = this.f473c.p;
        if (fVar != null) {
            fVar.b(this);
        }
        RemoteViews e2 = fVar != null ? fVar.e(this) : null;
        Notification d3 = d();
        if (e2 != null || (e2 = this.f473c.H) != null) {
            d3.contentView = e2;
        }
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 16 && fVar != null && (d2 = fVar.d(this)) != null) {
            d3.bigContentView = d2;
        }
        if (i2 >= 21 && fVar != null && (f2 = this.f473c.p.f(this)) != null) {
            d3.headsUpContentView = f2;
        }
        if (i2 >= 16 && fVar != null && (a2 = i.a(d3)) != null) {
            fVar.a(a2);
        }
        return d3;
    }

    protected Notification d() {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 26) {
            return this.f472b.build();
        }
        if (i2 >= 24) {
            Notification build = this.f472b.build();
            if (this.f478h != 0) {
                if (build.getGroup() != null && (build.flags & 512) != 0 && this.f478h == 2) {
                    h(build);
                }
                if (build.getGroup() != null && (build.flags & 512) == 0 && this.f478h == 1) {
                    h(build);
                }
            }
            return build;
        }
        if (i2 >= 21) {
            this.f472b.setExtras(this.f477g);
            Notification build2 = this.f472b.build();
            RemoteViews remoteViews = this.f474d;
            if (remoteViews != null) {
                build2.contentView = remoteViews;
            }
            RemoteViews remoteViews2 = this.f475e;
            if (remoteViews2 != null) {
                build2.bigContentView = remoteViews2;
            }
            RemoteViews remoteViews3 = this.f479i;
            if (remoteViews3 != null) {
                build2.headsUpContentView = remoteViews3;
            }
            if (this.f478h != 0) {
                if (build2.getGroup() != null && (build2.flags & 512) != 0 && this.f478h == 2) {
                    h(build2);
                }
                if (build2.getGroup() != null && (build2.flags & 512) == 0 && this.f478h == 1) {
                    h(build2);
                }
            }
            return build2;
        }
        if (i2 >= 20) {
            this.f472b.setExtras(this.f477g);
            Notification build3 = this.f472b.build();
            RemoteViews remoteViews4 = this.f474d;
            if (remoteViews4 != null) {
                build3.contentView = remoteViews4;
            }
            RemoteViews remoteViews5 = this.f475e;
            if (remoteViews5 != null) {
                build3.bigContentView = remoteViews5;
            }
            if (this.f478h != 0) {
                if (build3.getGroup() != null && (build3.flags & 512) != 0 && this.f478h == 2) {
                    h(build3);
                }
                if (build3.getGroup() != null && (build3.flags & 512) == 0 && this.f478h == 1) {
                    h(build3);
                }
            }
            return build3;
        }
        if (i2 >= 19) {
            SparseArray<Bundle> a2 = k.a(this.f476f);
            if (a2 != null) {
                this.f477g.putSparseParcelableArray("android.support.actionExtras", a2);
            }
            this.f472b.setExtras(this.f477g);
            Notification build4 = this.f472b.build();
            RemoteViews remoteViews6 = this.f474d;
            if (remoteViews6 != null) {
                build4.contentView = remoteViews6;
            }
            RemoteViews remoteViews7 = this.f475e;
            if (remoteViews7 != null) {
                build4.bigContentView = remoteViews7;
            }
            return build4;
        }
        if (i2 < 16) {
            return this.f472b.getNotification();
        }
        Notification build5 = this.f472b.build();
        Bundle a3 = i.a(build5);
        Bundle bundle = new Bundle(this.f477g);
        for (String str : this.f477g.keySet()) {
            if (a3.containsKey(str)) {
                bundle.remove(str);
            }
        }
        a3.putAll(bundle);
        SparseArray<Bundle> a4 = k.a(this.f476f);
        if (a4 != null) {
            i.a(build5).putSparseParcelableArray("android.support.actionExtras", a4);
        }
        RemoteViews remoteViews8 = this.f474d;
        if (remoteViews8 != null) {
            build5.contentView = remoteViews8;
        }
        RemoteViews remoteViews9 = this.f475e;
        if (remoteViews9 != null) {
            build5.bigContentView = remoteViews9;
        }
        return build5;
    }

    Context f() {
        return this.f471a;
    }
}
