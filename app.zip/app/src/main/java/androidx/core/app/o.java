package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class o implements Iterable<Intent> {
    private final ArrayList<Intent> n = new ArrayList<>();
    private final Context o;

    public interface a {
        Intent getSupportParentActivityIntent();
    }

    private o(Context context) {
        this.o = context;
    }

    public static o g(Context context) {
        return new o(context);
    }

    public o b(Intent intent) {
        this.n.add(intent);
        return this;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public o e(Activity activity) {
        Intent supportParentActivityIntent = activity instanceof a ? ((a) activity).getSupportParentActivityIntent() : null;
        if (supportParentActivityIntent == null) {
            supportParentActivityIntent = g.a(activity);
        }
        if (supportParentActivityIntent != null) {
            ComponentName component = supportParentActivityIntent.getComponent();
            if (component == null) {
                component = supportParentActivityIntent.resolveActivity(this.o.getPackageManager());
            }
            f(component);
            b(supportParentActivityIntent);
        }
        return this;
    }

    public o f(ComponentName componentName) {
        int size = this.n.size();
        try {
            Context context = this.o;
            while (true) {
                Intent b2 = g.b(context, componentName);
                if (b2 == null) {
                    return this;
                }
                this.n.add(size, b2);
                context = this.o;
                componentName = b2.getComponent();
            }
        } catch (PackageManager.NameNotFoundException e2) {
            Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
            throw new IllegalArgumentException(e2);
        }
    }

    public void i() {
        j(null);
    }

    @Override // java.lang.Iterable
    @Deprecated
    public Iterator<Intent> iterator() {
        return this.n.iterator();
    }

    public void j(Bundle bundle) {
        if (this.n.isEmpty()) {
            throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
        }
        ArrayList<Intent> arrayList = this.n;
        Intent[] intentArr = (Intent[]) arrayList.toArray(new Intent[arrayList.size()]);
        intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
        if (b.g.e.a.j(this.o, intentArr, bundle)) {
            return;
        }
        Intent intent = new Intent(intentArr[intentArr.length - 1]);
        intent.addFlags(268435456);
        this.o.startActivity(intent);
    }
}
