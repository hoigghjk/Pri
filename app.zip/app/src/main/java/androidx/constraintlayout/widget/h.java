package androidx.constraintlayout.widget;

import android.R;

/* loaded from: classes.dex */
public final class h {
    public static final int A = 26;
    public static final int A0 = 21;
    public static final int A1 = 75;
    public static final int B = 27;
    public static final int B0 = 22;
    public static final int B1 = 76;
    public static final int C = 28;
    public static final int C0 = 23;
    public static final int C1 = 77;
    public static final int D = 29;
    public static final int D0 = 24;
    public static final int D1 = 78;
    public static final int E = 30;
    public static final int E0 = 25;
    public static final int E1 = 79;
    public static final int F = 31;
    public static final int F0 = 26;
    public static final int G = 32;
    public static final int G0 = 27;
    public static final int H = 33;
    public static final int H0 = 28;
    public static final int I = 34;
    public static final int I0 = 29;
    public static final int J = 35;
    public static final int J0 = 30;
    public static final int K = 36;
    public static final int K0 = 33;
    public static final int L = 37;
    public static final int L0 = 34;
    public static final int M = 38;
    public static final int M0 = 35;
    public static final int N = 39;
    public static final int N0 = 36;
    public static final int O = 40;
    public static final int O0 = 37;
    public static final int P = 41;
    public static final int P0 = 38;
    public static final int Q = 42;
    public static final int Q0 = 39;
    public static final int R = 43;
    public static final int R0 = 40;
    public static final int S = 44;
    public static final int S0 = 41;
    public static final int T = 45;
    public static final int T0 = 42;
    public static final int U = 46;
    public static final int U0 = 43;
    public static final int V = 47;
    public static final int V0 = 44;
    public static final int W = 48;
    public static final int W0 = 45;
    public static final int X = 49;
    public static final int X0 = 46;
    public static final int Y = 50;
    public static final int Y0 = 47;
    public static final int Z = 51;
    public static final int Z0 = 48;
    public static final int a0 = 52;
    public static final int a1 = 49;

    /* renamed from: b, reason: collision with root package name */
    public static final int f393b = 0;
    public static final int b0 = 53;
    public static final int b1 = 50;

    /* renamed from: c, reason: collision with root package name */
    public static final int f394c = 1;
    public static final int c0 = 54;
    public static final int c1 = 51;

    /* renamed from: d, reason: collision with root package name */
    public static final int f395d = 2;
    public static final int d0 = 55;
    public static final int d1 = 52;

    /* renamed from: e, reason: collision with root package name */
    public static final int f396e = 3;
    public static final int e0 = 56;
    public static final int e1 = 53;

    /* renamed from: f, reason: collision with root package name */
    public static final int f397f = 4;
    public static final int f0 = 57;
    public static final int f1 = 54;

    /* renamed from: g, reason: collision with root package name */
    public static final int f398g = 5;
    public static final int g0 = 58;
    public static final int g1 = 55;

    /* renamed from: h, reason: collision with root package name */
    public static final int f399h = 6;
    public static final int h0 = 59;
    public static final int h1 = 56;

    /* renamed from: i, reason: collision with root package name */
    public static final int f400i = 8;
    public static final int i1 = 57;

    /* renamed from: j, reason: collision with root package name */
    public static final int f401j = 9;
    public static final int j0 = 0;
    public static final int j1 = 58;

    /* renamed from: k, reason: collision with root package name */
    public static final int f402k = 10;
    public static final int k0 = 1;
    public static final int k1 = 59;
    public static final int l = 11;
    public static final int l0 = 2;
    public static final int l1 = 60;
    public static final int m = 12;
    public static final int m0 = 3;
    public static final int m1 = 61;
    public static final int n = 13;
    public static final int n0 = 4;
    public static final int n1 = 62;
    public static final int o = 14;
    public static final int o0 = 5;
    public static final int o1 = 63;
    public static final int p = 15;
    public static final int p0 = 6;
    public static final int p1 = 64;
    public static final int q = 16;
    public static final int q0 = 7;
    public static final int q1 = 65;
    public static final int r = 17;
    public static final int r0 = 8;
    public static final int r1 = 66;
    public static final int s = 18;
    public static final int s0 = 13;
    public static final int s1 = 67;
    public static final int t = 19;
    public static final int t0 = 14;
    public static final int t1 = 68;
    public static final int u = 20;
    public static final int u0 = 15;
    public static final int u1 = 69;
    public static final int v = 21;
    public static final int v0 = 16;
    public static final int v1 = 70;
    public static final int w = 22;
    public static final int w0 = 17;
    public static final int w1 = 71;
    public static final int x = 23;
    public static final int x0 = 18;
    public static final int x1 = 72;
    public static final int y = 24;
    public static final int y0 = 19;
    public static final int y1 = 73;
    public static final int z = 25;
    public static final int z0 = 20;
    public static final int z1 = 74;

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f392a = {R.attr.orientation, R.attr.maxWidth, R.attr.maxHeight, R.attr.minWidth, R.attr.minHeight, com.pichillilorenzo.flutter_inappwebview.R.attr.barrierAllowsGoneWidgets, com.pichillilorenzo.flutter_inappwebview.R.attr.barrierDirection, com.pichillilorenzo.flutter_inappwebview.R.attr.chainUseRtl, com.pichillilorenzo.flutter_inappwebview.R.attr.constraintSet, com.pichillilorenzo.flutter_inappwebview.R.attr.constraint_referenced_ids, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constrainedHeight, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constrainedWidth, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintBaseline_creator, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintBaseline_toBaselineOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintBottom_creator, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintBottom_toBottomOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintBottom_toTopOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintCircle, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintCircleAngle, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintCircleRadius, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintDimensionRatio, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintEnd_toEndOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintEnd_toStartOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintGuide_begin, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintGuide_end, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintGuide_percent, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHeight_default, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHeight_max, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHeight_min, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHeight_percent, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHorizontal_bias, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHorizontal_chainStyle, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHorizontal_weight, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintLeft_creator, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintLeft_toLeftOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintLeft_toRightOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintRight_creator, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintRight_toLeftOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintRight_toRightOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintStart_toEndOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintStart_toStartOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintTop_creator, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintTop_toBottomOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintTop_toTopOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintVertical_bias, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintVertical_chainStyle, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintVertical_weight, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintWidth_default, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintWidth_max, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintWidth_min, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintWidth_percent, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_editor_absoluteX, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_editor_absoluteY, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginBottom, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginEnd, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginLeft, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginRight, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginStart, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginTop, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_optimizationLevel};
    public static final int[] i0 = {R.attr.orientation, R.attr.id, R.attr.visibility, R.attr.layout_width, R.attr.layout_height, R.attr.layout_marginLeft, R.attr.layout_marginTop, R.attr.layout_marginRight, R.attr.layout_marginBottom, R.attr.maxWidth, R.attr.maxHeight, R.attr.minWidth, R.attr.minHeight, R.attr.alpha, R.attr.transformPivotX, R.attr.transformPivotY, R.attr.translationX, R.attr.translationY, R.attr.scaleX, R.attr.scaleY, R.attr.rotation, R.attr.rotationX, R.attr.rotationY, R.attr.layout_marginStart, R.attr.layout_marginEnd, R.attr.translationZ, R.attr.elevation, com.pichillilorenzo.flutter_inappwebview.R.attr.barrierAllowsGoneWidgets, com.pichillilorenzo.flutter_inappwebview.R.attr.barrierDirection, com.pichillilorenzo.flutter_inappwebview.R.attr.chainUseRtl, com.pichillilorenzo.flutter_inappwebview.R.attr.constraint_referenced_ids, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constrainedHeight, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constrainedWidth, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintBaseline_creator, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintBaseline_toBaselineOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintBottom_creator, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintBottom_toBottomOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintBottom_toTopOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintCircle, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintCircleAngle, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintCircleRadius, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintDimensionRatio, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintEnd_toEndOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintEnd_toStartOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintGuide_begin, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintGuide_end, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintGuide_percent, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHeight_default, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHeight_max, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHeight_min, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHeight_percent, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHorizontal_bias, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHorizontal_chainStyle, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintHorizontal_weight, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintLeft_creator, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintLeft_toLeftOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintLeft_toRightOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintRight_creator, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintRight_toLeftOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintRight_toRightOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintStart_toEndOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintStart_toStartOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintTop_creator, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintTop_toBottomOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintTop_toTopOf, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintVertical_bias, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintVertical_chainStyle, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintVertical_weight, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintWidth_default, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintWidth_max, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintWidth_min, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_constraintWidth_percent, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_editor_absoluteX, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_editor_absoluteY, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginBottom, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginEnd, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginLeft, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginRight, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginStart, com.pichillilorenzo.flutter_inappwebview.R.attr.layout_goneMarginTop};
}
