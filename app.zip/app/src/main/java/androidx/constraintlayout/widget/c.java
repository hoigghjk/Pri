package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.d;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public class c {

    /* renamed from: b, reason: collision with root package name */
    private static final int[] f378b = {0, 4, 8};

    /* renamed from: c, reason: collision with root package name */
    private static SparseIntArray f379c;

    /* renamed from: a, reason: collision with root package name */
    private HashMap<Integer, b> f380a = new HashMap<>();

    private static class b {
        public int A;
        public int B;
        public int C;
        public int D;
        public int E;
        public int F;
        public int G;
        public int H;
        public int I;
        public int J;
        public int K;
        public int L;
        public int M;
        public int N;
        public int O;
        public int P;
        public float Q;
        public float R;
        public int S;
        public int T;
        public float U;
        public boolean V;
        public float W;
        public float X;
        public float Y;
        public float Z;

        /* renamed from: a, reason: collision with root package name */
        boolean f381a;
        public float a0;

        /* renamed from: b, reason: collision with root package name */
        public int f382b;
        public float b0;

        /* renamed from: c, reason: collision with root package name */
        public int f383c;
        public float c0;

        /* renamed from: d, reason: collision with root package name */
        int f384d;
        public float d0;

        /* renamed from: e, reason: collision with root package name */
        public int f385e;
        public float e0;

        /* renamed from: f, reason: collision with root package name */
        public int f386f;
        public float f0;

        /* renamed from: g, reason: collision with root package name */
        public float f387g;
        public float g0;

        /* renamed from: h, reason: collision with root package name */
        public int f388h;
        public boolean h0;

        /* renamed from: i, reason: collision with root package name */
        public int f389i;
        public boolean i0;

        /* renamed from: j, reason: collision with root package name */
        public int f390j;
        public int j0;

        /* renamed from: k, reason: collision with root package name */
        public int f391k;
        public int k0;
        public int l;
        public int l0;
        public int m;
        public int m0;
        public int n;
        public int n0;
        public int o;
        public int o0;
        public int p;
        public float p0;
        public int q;
        public float q0;
        public int r;
        public boolean r0;
        public int s;
        public int s0;
        public int t;
        public int t0;
        public float u;
        public int[] u0;
        public float v;
        public String v0;
        public String w;
        public int x;
        public int y;
        public float z;

        private b() {
            this.f381a = false;
            this.f385e = -1;
            this.f386f = -1;
            this.f387g = -1.0f;
            this.f388h = -1;
            this.f389i = -1;
            this.f390j = -1;
            this.f391k = -1;
            this.l = -1;
            this.m = -1;
            this.n = -1;
            this.o = -1;
            this.p = -1;
            this.q = -1;
            this.r = -1;
            this.s = -1;
            this.t = -1;
            this.u = 0.5f;
            this.v = 0.5f;
            this.w = null;
            this.x = -1;
            this.y = 0;
            this.z = 0.0f;
            this.A = -1;
            this.B = -1;
            this.C = -1;
            this.D = -1;
            this.E = -1;
            this.F = -1;
            this.G = -1;
            this.H = -1;
            this.I = -1;
            this.J = 0;
            this.K = -1;
            this.L = -1;
            this.M = -1;
            this.N = -1;
            this.O = -1;
            this.P = -1;
            this.Q = 0.0f;
            this.R = 0.0f;
            this.S = 0;
            this.T = 0;
            this.U = 1.0f;
            this.V = false;
            this.W = 0.0f;
            this.X = 0.0f;
            this.Y = 0.0f;
            this.Z = 0.0f;
            this.a0 = 1.0f;
            this.b0 = 1.0f;
            this.c0 = Float.NaN;
            this.d0 = Float.NaN;
            this.e0 = 0.0f;
            this.f0 = 0.0f;
            this.g0 = 0.0f;
            this.h0 = false;
            this.i0 = false;
            this.j0 = 0;
            this.k0 = 0;
            this.l0 = -1;
            this.m0 = -1;
            this.n0 = -1;
            this.o0 = -1;
            this.p0 = 1.0f;
            this.q0 = 1.0f;
            this.r0 = false;
            this.s0 = -1;
            this.t0 = -1;
        }

        private void e(int i2, ConstraintLayout.a aVar) {
            this.f384d = i2;
            this.f388h = aVar.f369d;
            this.f389i = aVar.f370e;
            this.f390j = aVar.f371f;
            this.f391k = aVar.f372g;
            this.l = aVar.f373h;
            this.m = aVar.f374i;
            this.n = aVar.f375j;
            this.o = aVar.f376k;
            this.p = aVar.l;
            this.q = aVar.p;
            this.r = aVar.q;
            this.s = aVar.r;
            this.t = aVar.s;
            this.u = aVar.z;
            this.v = aVar.A;
            this.w = aVar.B;
            this.x = aVar.m;
            this.y = aVar.n;
            this.z = aVar.o;
            this.A = aVar.P;
            this.B = aVar.Q;
            this.C = aVar.R;
            this.f387g = aVar.f368c;
            this.f385e = aVar.f366a;
            this.f386f = aVar.f367b;
            this.f382b = ((ViewGroup.MarginLayoutParams) aVar).width;
            this.f383c = ((ViewGroup.MarginLayoutParams) aVar).height;
            this.D = ((ViewGroup.MarginLayoutParams) aVar).leftMargin;
            this.E = ((ViewGroup.MarginLayoutParams) aVar).rightMargin;
            this.F = ((ViewGroup.MarginLayoutParams) aVar).topMargin;
            this.G = ((ViewGroup.MarginLayoutParams) aVar).bottomMargin;
            this.Q = aVar.E;
            this.R = aVar.D;
            this.T = aVar.G;
            this.S = aVar.F;
            boolean z = aVar.S;
            this.h0 = z;
            this.i0 = aVar.T;
            this.j0 = aVar.H;
            this.k0 = aVar.I;
            this.h0 = z;
            this.l0 = aVar.L;
            this.m0 = aVar.M;
            this.n0 = aVar.J;
            this.o0 = aVar.K;
            this.p0 = aVar.N;
            this.q0 = aVar.O;
            if (Build.VERSION.SDK_INT >= 17) {
                this.H = aVar.getMarginEnd();
                this.I = aVar.getMarginStart();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void f(int i2, d.a aVar) {
            e(i2, aVar);
            this.U = aVar.m0;
            this.X = aVar.p0;
            this.Y = aVar.q0;
            this.Z = aVar.r0;
            this.a0 = aVar.s0;
            this.b0 = aVar.t0;
            this.c0 = aVar.u0;
            this.d0 = aVar.v0;
            this.e0 = aVar.w0;
            this.f0 = aVar.x0;
            this.g0 = aVar.y0;
            this.W = aVar.o0;
            this.V = aVar.n0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void g(androidx.constraintlayout.widget.b bVar, int i2, d.a aVar) {
            f(i2, aVar);
            if (bVar instanceof androidx.constraintlayout.widget.a) {
                this.t0 = 1;
                androidx.constraintlayout.widget.a aVar2 = (androidx.constraintlayout.widget.a) bVar;
                this.s0 = aVar2.getType();
                this.u0 = aVar2.getReferencedIds();
            }
        }

        public void c(ConstraintLayout.a aVar) {
            aVar.f369d = this.f388h;
            aVar.f370e = this.f389i;
            aVar.f371f = this.f390j;
            aVar.f372g = this.f391k;
            aVar.f373h = this.l;
            aVar.f374i = this.m;
            aVar.f375j = this.n;
            aVar.f376k = this.o;
            aVar.l = this.p;
            aVar.p = this.q;
            aVar.q = this.r;
            aVar.r = this.s;
            aVar.s = this.t;
            ((ViewGroup.MarginLayoutParams) aVar).leftMargin = this.D;
            ((ViewGroup.MarginLayoutParams) aVar).rightMargin = this.E;
            ((ViewGroup.MarginLayoutParams) aVar).topMargin = this.F;
            ((ViewGroup.MarginLayoutParams) aVar).bottomMargin = this.G;
            aVar.x = this.P;
            aVar.y = this.O;
            aVar.z = this.u;
            aVar.A = this.v;
            aVar.m = this.x;
            aVar.n = this.y;
            aVar.o = this.z;
            aVar.B = this.w;
            aVar.P = this.A;
            aVar.Q = this.B;
            aVar.E = this.Q;
            aVar.D = this.R;
            aVar.G = this.T;
            aVar.F = this.S;
            aVar.S = this.h0;
            aVar.T = this.i0;
            aVar.H = this.j0;
            aVar.I = this.k0;
            aVar.L = this.l0;
            aVar.M = this.m0;
            aVar.J = this.n0;
            aVar.K = this.o0;
            aVar.N = this.p0;
            aVar.O = this.q0;
            aVar.R = this.C;
            aVar.f368c = this.f387g;
            aVar.f366a = this.f385e;
            aVar.f367b = this.f386f;
            ((ViewGroup.MarginLayoutParams) aVar).width = this.f382b;
            ((ViewGroup.MarginLayoutParams) aVar).height = this.f383c;
            if (Build.VERSION.SDK_INT >= 17) {
                aVar.setMarginStart(this.I);
                aVar.setMarginEnd(this.H);
            }
            aVar.a();
        }

        /* renamed from: d, reason: merged with bridge method [inline-methods] */
        public b clone() {
            b bVar = new b();
            bVar.f381a = this.f381a;
            bVar.f382b = this.f382b;
            bVar.f383c = this.f383c;
            bVar.f385e = this.f385e;
            bVar.f386f = this.f386f;
            bVar.f387g = this.f387g;
            bVar.f388h = this.f388h;
            bVar.f389i = this.f389i;
            bVar.f390j = this.f390j;
            bVar.f391k = this.f391k;
            bVar.l = this.l;
            bVar.m = this.m;
            bVar.n = this.n;
            bVar.o = this.o;
            bVar.p = this.p;
            bVar.q = this.q;
            bVar.r = this.r;
            bVar.s = this.s;
            bVar.t = this.t;
            bVar.u = this.u;
            bVar.v = this.v;
            bVar.w = this.w;
            bVar.A = this.A;
            bVar.B = this.B;
            bVar.u = this.u;
            bVar.u = this.u;
            bVar.u = this.u;
            bVar.u = this.u;
            bVar.u = this.u;
            bVar.C = this.C;
            bVar.D = this.D;
            bVar.E = this.E;
            bVar.F = this.F;
            bVar.G = this.G;
            bVar.H = this.H;
            bVar.I = this.I;
            bVar.J = this.J;
            bVar.K = this.K;
            bVar.L = this.L;
            bVar.M = this.M;
            bVar.N = this.N;
            bVar.O = this.O;
            bVar.P = this.P;
            bVar.Q = this.Q;
            bVar.R = this.R;
            bVar.S = this.S;
            bVar.T = this.T;
            bVar.U = this.U;
            bVar.V = this.V;
            bVar.W = this.W;
            bVar.X = this.X;
            bVar.Y = this.Y;
            bVar.Z = this.Z;
            bVar.a0 = this.a0;
            bVar.b0 = this.b0;
            bVar.c0 = this.c0;
            bVar.d0 = this.d0;
            bVar.e0 = this.e0;
            bVar.f0 = this.f0;
            bVar.g0 = this.g0;
            bVar.h0 = this.h0;
            bVar.i0 = this.i0;
            bVar.j0 = this.j0;
            bVar.k0 = this.k0;
            bVar.l0 = this.l0;
            bVar.m0 = this.m0;
            bVar.n0 = this.n0;
            bVar.o0 = this.o0;
            bVar.p0 = this.p0;
            bVar.q0 = this.q0;
            bVar.s0 = this.s0;
            bVar.t0 = this.t0;
            int[] iArr = this.u0;
            if (iArr != null) {
                bVar.u0 = Arrays.copyOf(iArr, iArr.length);
            }
            bVar.x = this.x;
            bVar.y = this.y;
            bVar.z = this.z;
            bVar.r0 = this.r0;
            return bVar;
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f379c = sparseIntArray;
        sparseIntArray.append(h.g1, 25);
        f379c.append(h.h1, 26);
        f379c.append(h.j1, 29);
        f379c.append(h.k1, 30);
        f379c.append(h.p1, 36);
        f379c.append(h.o1, 35);
        f379c.append(h.O0, 4);
        f379c.append(h.N0, 3);
        f379c.append(h.L0, 1);
        f379c.append(h.x1, 6);
        f379c.append(h.y1, 7);
        f379c.append(h.V0, 17);
        f379c.append(h.W0, 18);
        f379c.append(h.X0, 19);
        f379c.append(h.j0, 27);
        f379c.append(h.l1, 32);
        f379c.append(h.m1, 33);
        f379c.append(h.U0, 10);
        f379c.append(h.T0, 9);
        f379c.append(h.B1, 13);
        f379c.append(h.E1, 16);
        f379c.append(h.C1, 14);
        f379c.append(h.z1, 11);
        f379c.append(h.D1, 15);
        f379c.append(h.A1, 12);
        f379c.append(h.s1, 40);
        f379c.append(h.e1, 39);
        f379c.append(h.d1, 41);
        f379c.append(h.r1, 42);
        f379c.append(h.c1, 20);
        f379c.append(h.q1, 37);
        f379c.append(h.S0, 5);
        f379c.append(h.f1, 75);
        f379c.append(h.n1, 75);
        f379c.append(h.i1, 75);
        f379c.append(h.M0, 75);
        f379c.append(h.K0, 75);
        f379c.append(h.o0, 24);
        f379c.append(h.q0, 28);
        f379c.append(h.C0, 31);
        f379c.append(h.D0, 8);
        f379c.append(h.p0, 34);
        f379c.append(h.r0, 2);
        f379c.append(h.m0, 23);
        f379c.append(h.n0, 21);
        f379c.append(h.l0, 22);
        f379c.append(h.s0, 43);
        f379c.append(h.F0, 44);
        f379c.append(h.A0, 45);
        f379c.append(h.B0, 46);
        f379c.append(h.z0, 60);
        f379c.append(h.x0, 47);
        f379c.append(h.y0, 48);
        f379c.append(h.t0, 49);
        f379c.append(h.u0, 50);
        f379c.append(h.v0, 51);
        f379c.append(h.w0, 52);
        f379c.append(h.E0, 53);
        f379c.append(h.t1, 54);
        f379c.append(h.Y0, 55);
        f379c.append(h.u1, 56);
        f379c.append(h.Z0, 57);
        f379c.append(h.v1, 58);
        f379c.append(h.a1, 59);
        f379c.append(h.P0, 61);
        f379c.append(h.R0, 62);
        f379c.append(h.Q0, 63);
        f379c.append(h.k0, 38);
        f379c.append(h.w1, 69);
        f379c.append(h.b1, 70);
        f379c.append(h.I0, 71);
        f379c.append(h.H0, 72);
        f379c.append(h.J0, 73);
        f379c.append(h.G0, 74);
    }

    private int[] c(View view, String str) {
        int i2;
        Object c2;
        String[] split = str.split(",");
        Context context = view.getContext();
        int[] iArr = new int[split.length];
        int i3 = 0;
        int i4 = 0;
        while (i3 < split.length) {
            String trim = split[i3].trim();
            try {
                i2 = g.class.getField(trim).getInt(null);
            } catch (Exception unused) {
                i2 = 0;
            }
            if (i2 == 0) {
                i2 = context.getResources().getIdentifier(trim, "id", context.getPackageName());
            }
            if (i2 == 0 && view.isInEditMode() && (view.getParent() instanceof ConstraintLayout) && (c2 = ((ConstraintLayout) view.getParent()).c(0, trim)) != null && (c2 instanceof Integer)) {
                i2 = ((Integer) c2).intValue();
            }
            iArr[i4] = i2;
            i3++;
            i4++;
        }
        return i4 != split.length ? Arrays.copyOf(iArr, i4) : iArr;
    }

    private b d(Context context, AttributeSet attributeSet) {
        b bVar = new b();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h.i0);
        g(bVar, obtainStyledAttributes);
        obtainStyledAttributes.recycle();
        return bVar;
    }

    private static int f(TypedArray typedArray, int i2, int i3) {
        int resourceId = typedArray.getResourceId(i2, i3);
        return resourceId == -1 ? typedArray.getInt(i2, -1) : resourceId;
    }

    private void g(b bVar, TypedArray typedArray) {
        StringBuilder sb;
        String str;
        int indexCount = typedArray.getIndexCount();
        for (int i2 = 0; i2 < indexCount; i2++) {
            int index = typedArray.getIndex(i2);
            int i3 = f379c.get(index);
            switch (i3) {
                case 1:
                    bVar.p = f(typedArray, index, bVar.p);
                    break;
                case 2:
                    bVar.G = typedArray.getDimensionPixelSize(index, bVar.G);
                    break;
                case 3:
                    bVar.o = f(typedArray, index, bVar.o);
                    break;
                case 4:
                    bVar.n = f(typedArray, index, bVar.n);
                    break;
                case 5:
                    bVar.w = typedArray.getString(index);
                    break;
                case 6:
                    bVar.A = typedArray.getDimensionPixelOffset(index, bVar.A);
                    break;
                case 7:
                    bVar.B = typedArray.getDimensionPixelOffset(index, bVar.B);
                    break;
                case 8:
                    bVar.H = typedArray.getDimensionPixelSize(index, bVar.H);
                    break;
                case 9:
                    bVar.t = f(typedArray, index, bVar.t);
                    break;
                case 10:
                    bVar.s = f(typedArray, index, bVar.s);
                    break;
                case 11:
                    bVar.N = typedArray.getDimensionPixelSize(index, bVar.N);
                    break;
                case 12:
                    bVar.O = typedArray.getDimensionPixelSize(index, bVar.O);
                    break;
                case 13:
                    bVar.K = typedArray.getDimensionPixelSize(index, bVar.K);
                    break;
                case 14:
                    bVar.M = typedArray.getDimensionPixelSize(index, bVar.M);
                    break;
                case 15:
                    bVar.P = typedArray.getDimensionPixelSize(index, bVar.P);
                    break;
                case 16:
                    bVar.L = typedArray.getDimensionPixelSize(index, bVar.L);
                    break;
                case 17:
                    bVar.f385e = typedArray.getDimensionPixelOffset(index, bVar.f385e);
                    break;
                case 18:
                    bVar.f386f = typedArray.getDimensionPixelOffset(index, bVar.f386f);
                    break;
                case 19:
                    bVar.f387g = typedArray.getFloat(index, bVar.f387g);
                    break;
                case 20:
                    bVar.u = typedArray.getFloat(index, bVar.u);
                    break;
                case 21:
                    bVar.f383c = typedArray.getLayoutDimension(index, bVar.f383c);
                    break;
                case 22:
                    int i4 = typedArray.getInt(index, bVar.J);
                    bVar.J = i4;
                    bVar.J = f378b[i4];
                    break;
                case 23:
                    bVar.f382b = typedArray.getLayoutDimension(index, bVar.f382b);
                    break;
                case 24:
                    bVar.D = typedArray.getDimensionPixelSize(index, bVar.D);
                    break;
                case 25:
                    bVar.f388h = f(typedArray, index, bVar.f388h);
                    break;
                case 26:
                    bVar.f389i = f(typedArray, index, bVar.f389i);
                    break;
                case 27:
                    bVar.C = typedArray.getInt(index, bVar.C);
                    break;
                case 28:
                    bVar.E = typedArray.getDimensionPixelSize(index, bVar.E);
                    break;
                case 29:
                    bVar.f390j = f(typedArray, index, bVar.f390j);
                    break;
                case 30:
                    bVar.f391k = f(typedArray, index, bVar.f391k);
                    break;
                case 31:
                    bVar.I = typedArray.getDimensionPixelSize(index, bVar.I);
                    break;
                case 32:
                    bVar.q = f(typedArray, index, bVar.q);
                    break;
                case 33:
                    bVar.r = f(typedArray, index, bVar.r);
                    break;
                case 34:
                    bVar.F = typedArray.getDimensionPixelSize(index, bVar.F);
                    break;
                case 35:
                    bVar.m = f(typedArray, index, bVar.m);
                    break;
                case 36:
                    bVar.l = f(typedArray, index, bVar.l);
                    break;
                case 37:
                    bVar.v = typedArray.getFloat(index, bVar.v);
                    break;
                case 38:
                    bVar.f384d = typedArray.getResourceId(index, bVar.f384d);
                    break;
                case 39:
                    bVar.R = typedArray.getFloat(index, bVar.R);
                    break;
                case 40:
                    bVar.Q = typedArray.getFloat(index, bVar.Q);
                    break;
                case 41:
                    bVar.S = typedArray.getInt(index, bVar.S);
                    break;
                case 42:
                    bVar.T = typedArray.getInt(index, bVar.T);
                    break;
                case 43:
                    bVar.U = typedArray.getFloat(index, bVar.U);
                    break;
                case 44:
                    bVar.V = true;
                    bVar.W = typedArray.getDimension(index, bVar.W);
                    break;
                case 45:
                    bVar.Y = typedArray.getFloat(index, bVar.Y);
                    break;
                case 46:
                    bVar.Z = typedArray.getFloat(index, bVar.Z);
                    break;
                case 47:
                    bVar.a0 = typedArray.getFloat(index, bVar.a0);
                    break;
                case 48:
                    bVar.b0 = typedArray.getFloat(index, bVar.b0);
                    break;
                case 49:
                    bVar.c0 = typedArray.getFloat(index, bVar.c0);
                    break;
                case 50:
                    bVar.d0 = typedArray.getFloat(index, bVar.d0);
                    break;
                case 51:
                    bVar.e0 = typedArray.getDimension(index, bVar.e0);
                    break;
                case 52:
                    bVar.f0 = typedArray.getDimension(index, bVar.f0);
                    break;
                case 53:
                    bVar.g0 = typedArray.getDimension(index, bVar.g0);
                    break;
                default:
                    switch (i3) {
                        case 60:
                            bVar.X = typedArray.getFloat(index, bVar.X);
                            break;
                        case 61:
                            bVar.x = f(typedArray, index, bVar.x);
                            break;
                        case 62:
                            bVar.y = typedArray.getDimensionPixelSize(index, bVar.y);
                            break;
                        case 63:
                            bVar.z = typedArray.getFloat(index, bVar.z);
                            break;
                        default:
                            switch (i3) {
                                case 69:
                                    bVar.p0 = typedArray.getFloat(index, 1.0f);
                                    continue;
                                case 70:
                                    bVar.q0 = typedArray.getFloat(index, 1.0f);
                                    continue;
                                case 71:
                                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                                    continue;
                                case 72:
                                    bVar.s0 = typedArray.getInt(index, bVar.s0);
                                    continue;
                                case 73:
                                    bVar.v0 = typedArray.getString(index);
                                    continue;
                                case 74:
                                    bVar.r0 = typedArray.getBoolean(index, bVar.r0);
                                    continue;
                                case 75:
                                    sb = new StringBuilder();
                                    str = "unused attribute 0x";
                                    break;
                                default:
                                    sb = new StringBuilder();
                                    str = "Unknown attribute 0x";
                                    break;
                            }
                            sb.append(str);
                            sb.append(Integer.toHexString(index));
                            sb.append("   ");
                            sb.append(f379c.get(index));
                            Log.w("ConstraintSet", sb.toString());
                            break;
                    }
            }
        }
    }

    void a(ConstraintLayout constraintLayout) {
        int childCount = constraintLayout.getChildCount();
        HashSet hashSet = new HashSet(this.f380a.keySet());
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            int id = childAt.getId();
            if (id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (this.f380a.containsKey(Integer.valueOf(id))) {
                hashSet.remove(Integer.valueOf(id));
                b bVar = this.f380a.get(Integer.valueOf(id));
                if (childAt instanceof androidx.constraintlayout.widget.a) {
                    bVar.t0 = 1;
                }
                int i3 = bVar.t0;
                if (i3 != -1 && i3 == 1) {
                    androidx.constraintlayout.widget.a aVar = (androidx.constraintlayout.widget.a) childAt;
                    aVar.setId(id);
                    aVar.setType(bVar.s0);
                    aVar.setAllowsGoneWidget(bVar.r0);
                    int[] iArr = bVar.u0;
                    if (iArr != null) {
                        aVar.setReferencedIds(iArr);
                    } else {
                        String str = bVar.v0;
                        if (str != null) {
                            int[] c2 = c(aVar, str);
                            bVar.u0 = c2;
                            aVar.setReferencedIds(c2);
                        }
                    }
                }
                ConstraintLayout.a aVar2 = (ConstraintLayout.a) childAt.getLayoutParams();
                bVar.c(aVar2);
                childAt.setLayoutParams(aVar2);
                childAt.setVisibility(bVar.J);
                int i4 = Build.VERSION.SDK_INT;
                if (i4 >= 17) {
                    childAt.setAlpha(bVar.U);
                    childAt.setRotation(bVar.X);
                    childAt.setRotationX(bVar.Y);
                    childAt.setRotationY(bVar.Z);
                    childAt.setScaleX(bVar.a0);
                    childAt.setScaleY(bVar.b0);
                    if (!Float.isNaN(bVar.c0)) {
                        childAt.setPivotX(bVar.c0);
                    }
                    if (!Float.isNaN(bVar.d0)) {
                        childAt.setPivotY(bVar.d0);
                    }
                    childAt.setTranslationX(bVar.e0);
                    childAt.setTranslationY(bVar.f0);
                    if (i4 >= 21) {
                        childAt.setTranslationZ(bVar.g0);
                        if (bVar.V) {
                            childAt.setElevation(bVar.W);
                        }
                    }
                }
            }
        }
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            Integer num = (Integer) it.next();
            b bVar2 = this.f380a.get(num);
            int i5 = bVar2.t0;
            if (i5 != -1 && i5 == 1) {
                androidx.constraintlayout.widget.a aVar3 = new androidx.constraintlayout.widget.a(constraintLayout.getContext());
                aVar3.setId(num.intValue());
                int[] iArr2 = bVar2.u0;
                if (iArr2 != null) {
                    aVar3.setReferencedIds(iArr2);
                } else {
                    String str2 = bVar2.v0;
                    if (str2 != null) {
                        int[] c3 = c(aVar3, str2);
                        bVar2.u0 = c3;
                        aVar3.setReferencedIds(c3);
                    }
                }
                aVar3.setType(bVar2.s0);
                ConstraintLayout.a generateDefaultLayoutParams = constraintLayout.generateDefaultLayoutParams();
                aVar3.f();
                bVar2.c(generateDefaultLayoutParams);
                constraintLayout.addView(aVar3, generateDefaultLayoutParams);
            }
            if (bVar2.f381a) {
                View eVar = new e(constraintLayout.getContext());
                eVar.setId(num.intValue());
                ConstraintLayout.a generateDefaultLayoutParams2 = constraintLayout.generateDefaultLayoutParams();
                bVar2.c(generateDefaultLayoutParams2);
                constraintLayout.addView(eVar, generateDefaultLayoutParams2);
            }
        }
    }

    public void b(d dVar) {
        int childCount = dVar.getChildCount();
        this.f380a.clear();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = dVar.getChildAt(i2);
            d.a aVar = (d.a) childAt.getLayoutParams();
            int id = childAt.getId();
            if (id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (!this.f380a.containsKey(Integer.valueOf(id))) {
                this.f380a.put(Integer.valueOf(id), new b());
            }
            b bVar = this.f380a.get(Integer.valueOf(id));
            if (childAt instanceof androidx.constraintlayout.widget.b) {
                bVar.g((androidx.constraintlayout.widget.b) childAt, id, aVar);
            }
            bVar.f(id, aVar);
        }
    }

    public void e(Context context, int i2) {
        XmlResourceParser xml = context.getResources().getXml(i2);
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    b d2 = d(context, Xml.asAttributeSet(xml));
                    if (name.equalsIgnoreCase("Guideline")) {
                        d2.f381a = true;
                    }
                    this.f380a.put(Integer.valueOf(d2.f384d), d2);
                }
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        } catch (XmlPullParserException e3) {
            e3.printStackTrace();
        }
    }
}
