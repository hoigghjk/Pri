package androidx.constraintlayout.widget;

/* loaded from: classes.dex */
public final class g {
    private g() {
    }
}
