package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import b.f.a.j.j;
import java.util.Arrays;

/* loaded from: classes.dex */
public abstract class b extends View {
    protected int[] n;
    protected int o;
    protected Context p;
    protected j q;
    protected boolean r;
    private String s;

    public b(Context context) {
        super(context);
        this.n = new int[32];
        this.r = false;
        this.p = context;
        b(null);
    }

    private void a(String str) {
        int i2;
        Object c2;
        if (str == null || this.p == null) {
            return;
        }
        String trim = str.trim();
        try {
            i2 = g.class.getField(trim).getInt(null);
        } catch (Exception unused) {
            i2 = 0;
        }
        if (i2 == 0) {
            i2 = this.p.getResources().getIdentifier(trim, "id", this.p.getPackageName());
        }
        if (i2 == 0 && isInEditMode() && (getParent() instanceof ConstraintLayout) && (c2 = ((ConstraintLayout) getParent()).c(0, trim)) != null && (c2 instanceof Integer)) {
            i2 = ((Integer) c2).intValue();
        }
        if (i2 != 0) {
            setTag(i2, null);
            return;
        }
        Log.w("ConstraintHelper", "Could not find id of \"" + trim + "\"");
    }

    private void setIds(String str) {
        if (str == null) {
            return;
        }
        int i2 = 0;
        while (true) {
            int indexOf = str.indexOf(44, i2);
            if (indexOf == -1) {
                a(str.substring(i2));
                return;
            } else {
                a(str.substring(i2, indexOf));
                i2 = indexOf + 1;
            }
        }
    }

    protected void b(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, h.f392a);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == h.f401j) {
                    String string = obtainStyledAttributes.getString(index);
                    this.s = string;
                    setIds(string);
                }
            }
        }
    }

    public void c(ConstraintLayout constraintLayout) {
    }

    public void d(ConstraintLayout constraintLayout) {
    }

    public void e(ConstraintLayout constraintLayout) {
        if (isInEditMode()) {
            setIds(this.s);
        }
        j jVar = this.q;
        if (jVar == null) {
            return;
        }
        jVar.J0();
        for (int i2 = 0; i2 < this.o; i2++) {
            View e2 = constraintLayout.e(this.n[i2]);
            if (e2 != null) {
                this.q.I0(constraintLayout.f(e2));
            }
        }
    }

    public void f() {
        if (this.q == null) {
            return;
        }
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.a) {
            ((ConstraintLayout.a) layoutParams).k0 = this.q;
        }
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.n, this.o);
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        if (this.r) {
            super.onMeasure(i2, i3);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.o = 0;
        for (int i2 : iArr) {
            setTag(i2, null);
        }
    }

    @Override // android.view.View
    public void setTag(int i2, Object obj) {
        int i3 = this.o + 1;
        int[] iArr = this.n;
        if (i3 > iArr.length) {
            this.n = Arrays.copyOf(iArr, iArr.length * 2);
        }
        int[] iArr2 = this.n;
        int i4 = this.o;
        iArr2[i4] = i2;
        this.o = i4 + 1;
    }
}
