package androidx.media;

import java.util.Arrays;

/* loaded from: classes.dex */
class AudioAttributesImplBase implements AudioAttributesImpl {

    /* renamed from: a, reason: collision with root package name */
    int f655a = 0;

    /* renamed from: b, reason: collision with root package name */
    int f656b = 0;

    /* renamed from: c, reason: collision with root package name */
    int f657c = 0;

    /* renamed from: d, reason: collision with root package name */
    int f658d = -1;

    AudioAttributesImplBase() {
    }

    public int a() {
        return this.f656b;
    }

    public int b() {
        int i2 = this.f657c;
        int c2 = c();
        if (c2 == 6) {
            i2 |= 4;
        } else if (c2 == 7) {
            i2 |= 1;
        }
        return i2 & 273;
    }

    public int c() {
        int i2 = this.f658d;
        return i2 != -1 ? i2 : AudioAttributesCompat.a(false, this.f657c, this.f655a);
    }

    public int d() {
        return this.f655a;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof AudioAttributesImplBase)) {
            return false;
        }
        AudioAttributesImplBase audioAttributesImplBase = (AudioAttributesImplBase) obj;
        return this.f656b == audioAttributesImplBase.a() && this.f657c == audioAttributesImplBase.b() && this.f655a == audioAttributesImplBase.d() && this.f658d == audioAttributesImplBase.f658d;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f656b), Integer.valueOf(this.f657c), Integer.valueOf(this.f655a), Integer.valueOf(this.f658d)});
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("AudioAttributesCompat:");
        if (this.f658d != -1) {
            sb.append(" stream=");
            sb.append(this.f658d);
            sb.append(" derived");
        }
        sb.append(" usage=");
        sb.append(AudioAttributesCompat.b(this.f655a));
        sb.append(" content=");
        sb.append(this.f656b);
        sb.append(" flags=0x");
        sb.append(Integer.toHexString(this.f657c).toUpperCase());
        return sb.toString();
    }
}
