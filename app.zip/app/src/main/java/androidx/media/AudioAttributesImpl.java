package androidx.media;

import androidx.versionedparcelable.c;

/* loaded from: classes.dex */
interface AudioAttributesImpl extends c {
}
