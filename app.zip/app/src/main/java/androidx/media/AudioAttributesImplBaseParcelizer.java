package androidx.media;

import androidx.versionedparcelable.a;

/* loaded from: classes.dex */
public final class AudioAttributesImplBaseParcelizer {
    public static AudioAttributesImplBase read(a aVar) {
        AudioAttributesImplBase audioAttributesImplBase = new AudioAttributesImplBase();
        audioAttributesImplBase.f655a = aVar.p(audioAttributesImplBase.f655a, 1);
        audioAttributesImplBase.f656b = aVar.p(audioAttributesImplBase.f656b, 2);
        audioAttributesImplBase.f657c = aVar.p(audioAttributesImplBase.f657c, 3);
        audioAttributesImplBase.f658d = aVar.p(audioAttributesImplBase.f658d, 4);
        return audioAttributesImplBase;
    }

    public static void write(AudioAttributesImplBase audioAttributesImplBase, a aVar) {
        aVar.x(false, false);
        aVar.F(audioAttributesImplBase.f655a, 1);
        aVar.F(audioAttributesImplBase.f656b, 2);
        aVar.F(audioAttributesImplBase.f657c, 3);
        aVar.F(audioAttributesImplBase.f658d, 4);
    }
}
