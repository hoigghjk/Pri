package androidx.fragment.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;

/* loaded from: classes.dex */
public class c extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
    private Handler k0;
    private Runnable l0 = new a();
    int m0 = 0;
    int n0 = 0;
    boolean o0 = true;
    boolean p0 = true;
    int q0 = -1;
    Dialog r0;
    boolean s0;
    boolean t0;
    boolean u0;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            c cVar = c.this;
            Dialog dialog = cVar.r0;
            if (dialog != null) {
                cVar.onDismiss(dialog);
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void R(Bundle bundle) {
        Bundle bundle2;
        super.R(bundle);
        if (this.p0) {
            View H = H();
            if (H != null) {
                if (H.getParent() != null) {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                }
                this.r0.setContentView(H);
            }
            d h2 = h();
            if (h2 != null) {
                this.r0.setOwnerActivity(h2);
            }
            this.r0.setCancelable(this.o0);
            this.r0.setOnCancelListener(this);
            this.r0.setOnDismissListener(this);
            if (bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
                return;
            }
            this.r0.onRestoreInstanceState(bundle2);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void U(Context context) {
        super.U(context);
        if (this.u0) {
            return;
        }
        this.t0 = false;
    }

    @Override // androidx.fragment.app.Fragment
    public void X(Bundle bundle) {
        super.X(bundle);
        this.k0 = new Handler();
        this.p0 = this.J == 0;
        if (bundle != null) {
            this.m0 = bundle.getInt("android:style", 0);
            this.n0 = bundle.getInt("android:theme", 0);
            this.o0 = bundle.getBoolean("android:cancelable", true);
            this.p0 = bundle.getBoolean("android:showsDialog", this.p0);
            this.q0 = bundle.getInt("android:backStackId", -1);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void e0() {
        super.e0();
        Dialog dialog = this.r0;
        if (dialog != null) {
            this.s0 = true;
            dialog.setOnDismissListener(null);
            this.r0.dismiss();
            if (!this.t0) {
                onDismiss(this.r0);
            }
            this.r0 = null;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void f0() {
        super.f0();
        if (this.u0 || this.t0) {
            return;
        }
        this.t0 = true;
    }

    @Override // androidx.fragment.app.Fragment
    public LayoutInflater g0(Bundle bundle) {
        Context e2;
        if (!this.p0) {
            return super.g0(bundle);
        }
        Dialog m1 = m1(bundle);
        this.r0 = m1;
        if (m1 != null) {
            o1(m1, this.m0);
            e2 = this.r0.getContext();
        } else {
            e2 = this.F.e();
        }
        return (LayoutInflater) e2.getSystemService("layout_inflater");
    }

    void l1(boolean z, boolean z2) {
        if (this.t0) {
            return;
        }
        this.t0 = true;
        this.u0 = false;
        Dialog dialog = this.r0;
        if (dialog != null) {
            dialog.setOnDismissListener(null);
            this.r0.dismiss();
            if (!z2) {
                if (Looper.myLooper() == this.k0.getLooper()) {
                    onDismiss(this.r0);
                } else {
                    this.k0.post(this.l0);
                }
            }
        }
        this.s0 = true;
        if (this.q0 >= 0) {
            X0().g(this.q0, 1);
            this.q0 = -1;
            return;
        }
        n a2 = X0().a();
        a2.g(this);
        if (z) {
            a2.e();
        } else {
            a2.d();
        }
    }

    public Dialog m1(Bundle bundle) {
        throw null;
    }

    public void n1(boolean z) {
        this.p0 = z;
    }

    public void o1(Dialog dialog, int i2) {
        if (i2 != 1 && i2 != 2) {
            if (i2 != 3) {
                return;
            } else {
                dialog.getWindow().addFlags(24);
            }
        }
        dialog.requestWindowFeature(1);
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        if (this.s0) {
            return;
        }
        l1(true, true);
    }

    public void p1(i iVar, String str) {
        this.t0 = false;
        this.u0 = true;
        n a2 = iVar.a();
        a2.b(this, str);
        a2.d();
    }

    @Override // androidx.fragment.app.Fragment
    public void t0(Bundle bundle) {
        Bundle onSaveInstanceState;
        super.t0(bundle);
        Dialog dialog = this.r0;
        if (dialog != null && (onSaveInstanceState = dialog.onSaveInstanceState()) != null) {
            bundle.putBundle("android:savedDialogState", onSaveInstanceState);
        }
        int i2 = this.m0;
        if (i2 != 0) {
            bundle.putInt("android:style", i2);
        }
        int i3 = this.n0;
        if (i3 != 0) {
            bundle.putInt("android:theme", i3);
        }
        boolean z = this.o0;
        if (!z) {
            bundle.putBoolean("android:cancelable", z);
        }
        boolean z2 = this.p0;
        if (!z2) {
            bundle.putBoolean("android:showsDialog", z2);
        }
        int i4 = this.q0;
        if (i4 != -1) {
            bundle.putInt("android:backStackId", i4);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void u0() {
        super.u0();
        Dialog dialog = this.r0;
        if (dialog != null) {
            this.s0 = false;
            dialog.show();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void v0() {
        super.v0();
        Dialog dialog = this.r0;
        if (dialog != null) {
            dialog.hide();
        }
    }
}
