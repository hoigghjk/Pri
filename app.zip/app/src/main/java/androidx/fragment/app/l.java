package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.q;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/* loaded from: classes.dex */
class l extends androidx.lifecycle.p {

    /* renamed from: h, reason: collision with root package name */
    private static final q.a f570h = new a();

    /* renamed from: e, reason: collision with root package name */
    private final boolean f574e;

    /* renamed from: b, reason: collision with root package name */
    private final HashSet<Fragment> f571b = new HashSet<>();

    /* renamed from: c, reason: collision with root package name */
    private final HashMap<String, l> f572c = new HashMap<>();

    /* renamed from: d, reason: collision with root package name */
    private final HashMap<String, androidx.lifecycle.r> f573d = new HashMap<>();

    /* renamed from: f, reason: collision with root package name */
    private boolean f575f = false;

    /* renamed from: g, reason: collision with root package name */
    private boolean f576g = false;

    static class a implements q.a {
        a() {
        }

        @Override // androidx.lifecycle.q.a
        public <T extends androidx.lifecycle.p> T a(Class<T> cls) {
            return new l(true);
        }
    }

    l(boolean z) {
        this.f574e = z;
    }

    static l g(androidx.lifecycle.r rVar) {
        return (l) new androidx.lifecycle.q(rVar, f570h).a(l.class);
    }

    @Override // androidx.lifecycle.p
    protected void c() {
        if (j.U) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.f575f = true;
    }

    boolean d(Fragment fragment) {
        return this.f571b.add(fragment);
    }

    void e(Fragment fragment) {
        if (j.U) {
            Log.d("FragmentManager", "Clearing non-config state for " + fragment);
        }
        l lVar = this.f572c.get(fragment.r);
        if (lVar != null) {
            lVar.c();
            this.f572c.remove(fragment.r);
        }
        androidx.lifecycle.r rVar = this.f573d.get(fragment.r);
        if (rVar != null) {
            rVar.a();
            this.f573d.remove(fragment.r);
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        l lVar = (l) obj;
        return this.f571b.equals(lVar.f571b) && this.f572c.equals(lVar.f572c) && this.f573d.equals(lVar.f573d);
    }

    l f(Fragment fragment) {
        l lVar = this.f572c.get(fragment.r);
        if (lVar != null) {
            return lVar;
        }
        l lVar2 = new l(this.f574e);
        this.f572c.put(fragment.r, lVar2);
        return lVar2;
    }

    Collection<Fragment> h() {
        return this.f571b;
    }

    public int hashCode() {
        return (((this.f571b.hashCode() * 31) + this.f572c.hashCode()) * 31) + this.f573d.hashCode();
    }

    androidx.lifecycle.r i(Fragment fragment) {
        androidx.lifecycle.r rVar = this.f573d.get(fragment.r);
        if (rVar != null) {
            return rVar;
        }
        androidx.lifecycle.r rVar2 = new androidx.lifecycle.r();
        this.f573d.put(fragment.r, rVar2);
        return rVar2;
    }

    boolean j() {
        return this.f575f;
    }

    boolean k(Fragment fragment) {
        return this.f571b.remove(fragment);
    }

    boolean l(Fragment fragment) {
        if (this.f571b.contains(fragment)) {
            return this.f574e ? this.f575f : !this.f576g;
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator<Fragment> it = this.f571b.iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator<String> it2 = this.f572c.keySet().iterator();
        while (it2.hasNext()) {
            sb.append(it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator<String> it3 = this.f573d.keySet().iterator();
        while (it3.hasNext()) {
            sb.append(it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
