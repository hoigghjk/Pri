package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* loaded from: classes.dex */
public abstract class h<E> extends e {
    private final Activity n;
    private final Context o;
    private final Handler p;
    private final int q;
    final j r;

    h(Activity activity, Context context, Handler handler, int i2) {
        this.r = new j();
        this.n = activity;
        b.g.k.h.c(context, "context == null");
        this.o = context;
        b.g.k.h.c(handler, "handler == null");
        this.p = handler;
        this.q = i2;
    }

    h(d dVar) {
        this(dVar, dVar, new Handler(), 0);
    }

    @Override // androidx.fragment.app.e
    public View b(int i2) {
        return null;
    }

    @Override // androidx.fragment.app.e
    public boolean c() {
        return true;
    }

    Activity d() {
        return this.n;
    }

    Context e() {
        return this.o;
    }

    Handler f() {
        return this.p;
    }

    void g(Fragment fragment) {
    }

    public void h(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
    }

    public abstract E i();

    public LayoutInflater j() {
        return LayoutInflater.from(this.o);
    }

    public int k() {
        return this.q;
    }

    public boolean l() {
        return true;
    }

    public boolean m(Fragment fragment) {
        return true;
    }

    public void n(Fragment fragment, Intent intent, int i2, Bundle bundle) {
        if (i2 != -1) {
            throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
        }
        this.o.startActivity(intent);
    }

    public void o() {
    }
}
