package androidx.fragment.app;

import android.util.Log;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.j;
import androidx.fragment.app.n;
import java.io.PrintWriter;
import java.util.ArrayList;

/* loaded from: classes.dex */
final class a extends n implements j.k {
    final j r;
    boolean s;
    int t = -1;

    public a(j jVar) {
        this.r = jVar;
    }

    private static boolean r(n.a aVar) {
        Fragment fragment = aVar.f589b;
        return (fragment == null || !fragment.x || fragment.T == null || fragment.M || fragment.L || !fragment.N()) ? false : true;
    }

    @Override // androidx.fragment.app.j.k
    public boolean a(ArrayList<a> arrayList, ArrayList<Boolean> arrayList2) {
        if (j.U) {
            Log.v("FragmentManager", "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (!this.f584h) {
            return true;
        }
        this.r.k(this);
        return true;
    }

    @Override // androidx.fragment.app.n
    public int d() {
        return i(false);
    }

    @Override // androidx.fragment.app.n
    public int e() {
        return i(true);
    }

    @Override // androidx.fragment.app.n
    void f(int i2, Fragment fragment, String str, int i3) {
        super.f(i2, fragment, str, i3);
        fragment.E = this.r;
    }

    @Override // androidx.fragment.app.n
    public n g(Fragment fragment) {
        j jVar = fragment.E;
        if (jVar == null || jVar == this.r) {
            super.g(fragment);
            return this;
        }
        throw new IllegalStateException("Cannot remove Fragment attached to a different FragmentManager. Fragment " + fragment.toString() + " is already attached to a FragmentManager.");
    }

    void h(int i2) {
        if (this.f584h) {
            if (j.U) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i2);
            }
            int size = this.f577a.size();
            for (int i3 = 0; i3 < size; i3++) {
                n.a aVar = this.f577a.get(i3);
                Fragment fragment = aVar.f589b;
                if (fragment != null) {
                    fragment.D += i2;
                    if (j.U) {
                        Log.v("FragmentManager", "Bump nesting of " + aVar.f589b + " to " + aVar.f589b.D);
                    }
                }
            }
        }
    }

    int i(boolean z) {
        if (this.s) {
            throw new IllegalStateException("commit already called");
        }
        if (j.U) {
            Log.v("FragmentManager", "Commit: " + this);
            PrintWriter printWriter = new PrintWriter(new b.g.k.c("FragmentManager"));
            j("  ", printWriter);
            printWriter.close();
        }
        this.s = true;
        this.t = this.f584h ? this.r.n(this) : -1;
        this.r.i0(this, z);
        return this.t;
    }

    public void j(String str, PrintWriter printWriter) {
        k(str, printWriter, true);
    }

    public void k(String str, PrintWriter printWriter, boolean z) {
        String str2;
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f585i);
            printWriter.print(" mIndex=");
            printWriter.print(this.t);
            printWriter.print(" mCommitted=");
            printWriter.println(this.s);
            if (this.f582f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f582f));
                printWriter.print(" mTransitionStyle=#");
                printWriter.println(Integer.toHexString(this.f583g));
            }
            if (this.f578b != 0 || this.f579c != 0) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f578b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f579c));
            }
            if (this.f580d != 0 || this.f581e != 0) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f580d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f581e));
            }
            if (this.f586j != 0 || this.f587k != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f586j));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f587k);
            }
            if (this.l != 0 || this.m != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.l));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.m);
            }
        }
        if (this.f577a.isEmpty()) {
            return;
        }
        printWriter.print(str);
        printWriter.println("Operations:");
        int size = this.f577a.size();
        for (int i2 = 0; i2 < size; i2++) {
            n.a aVar = this.f577a.get(i2);
            switch (aVar.f588a) {
                case 0:
                    str2 = "NULL";
                    break;
                case 1:
                    str2 = "ADD";
                    break;
                case 2:
                    str2 = "REPLACE";
                    break;
                case 3:
                    str2 = "REMOVE";
                    break;
                case 4:
                    str2 = "HIDE";
                    break;
                case 5:
                    str2 = "SHOW";
                    break;
                case 6:
                    str2 = "DETACH";
                    break;
                case 7:
                    str2 = "ATTACH";
                    break;
                case 8:
                    str2 = "SET_PRIMARY_NAV";
                    break;
                case 9:
                    str2 = "UNSET_PRIMARY_NAV";
                    break;
                case 10:
                    str2 = "OP_SET_MAX_LIFECYCLE";
                    break;
                default:
                    str2 = "cmd=" + aVar.f588a;
                    break;
            }
            printWriter.print(str);
            printWriter.print("  Op #");
            printWriter.print(i2);
            printWriter.print(": ");
            printWriter.print(str2);
            printWriter.print(" ");
            printWriter.println(aVar.f589b);
            if (z) {
                if (aVar.f590c != 0 || aVar.f591d != 0) {
                    printWriter.print(str);
                    printWriter.print("enterAnim=#");
                    printWriter.print(Integer.toHexString(aVar.f590c));
                    printWriter.print(" exitAnim=#");
                    printWriter.println(Integer.toHexString(aVar.f591d));
                }
                if (aVar.f592e != 0 || aVar.f593f != 0) {
                    printWriter.print(str);
                    printWriter.print("popEnterAnim=#");
                    printWriter.print(Integer.toHexString(aVar.f592e));
                    printWriter.print(" popExitAnim=#");
                    printWriter.println(Integer.toHexString(aVar.f593f));
                }
            }
        }
    }

    void l() {
        int size = this.f577a.size();
        for (int i2 = 0; i2 < size; i2++) {
            n.a aVar = this.f577a.get(i2);
            Fragment fragment = aVar.f589b;
            if (fragment != null) {
                fragment.g1(this.f582f, this.f583g);
            }
            switch (aVar.f588a) {
                case 1:
                    fragment.f1(aVar.f590c);
                    this.r.l(fragment, false);
                    break;
                case 2:
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + aVar.f588a);
                case 3:
                    fragment.f1(aVar.f591d);
                    this.r.Y0(fragment);
                    break;
                case 4:
                    fragment.f1(aVar.f591d);
                    this.r.C0(fragment);
                    break;
                case 5:
                    fragment.f1(aVar.f590c);
                    this.r.l1(fragment);
                    break;
                case 6:
                    fragment.f1(aVar.f591d);
                    this.r.x(fragment);
                    break;
                case 7:
                    fragment.f1(aVar.f590c);
                    this.r.q(fragment);
                    break;
                case 8:
                    this.r.k1(fragment);
                    break;
                case 9:
                    this.r.k1(null);
                    break;
                case 10:
                    this.r.j1(fragment, aVar.f595h);
                    break;
            }
            if (!this.p && aVar.f588a != 1 && fragment != null) {
                this.r.O0(fragment);
            }
        }
        if (this.p) {
            return;
        }
        j jVar = this.r;
        jVar.P0(jVar.C, true);
    }

    void m(boolean z) {
        for (int size = this.f577a.size() - 1; size >= 0; size--) {
            n.a aVar = this.f577a.get(size);
            Fragment fragment = aVar.f589b;
            if (fragment != null) {
                fragment.g1(j.d1(this.f582f), this.f583g);
            }
            switch (aVar.f588a) {
                case 1:
                    fragment.f1(aVar.f593f);
                    this.r.Y0(fragment);
                    break;
                case 2:
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + aVar.f588a);
                case 3:
                    fragment.f1(aVar.f592e);
                    this.r.l(fragment, false);
                    break;
                case 4:
                    fragment.f1(aVar.f592e);
                    this.r.l1(fragment);
                    break;
                case 5:
                    fragment.f1(aVar.f593f);
                    this.r.C0(fragment);
                    break;
                case 6:
                    fragment.f1(aVar.f592e);
                    this.r.q(fragment);
                    break;
                case 7:
                    fragment.f1(aVar.f593f);
                    this.r.x(fragment);
                    break;
                case 8:
                    this.r.k1(null);
                    break;
                case 9:
                    this.r.k1(fragment);
                    break;
                case 10:
                    this.r.j1(fragment, aVar.f594g);
                    break;
            }
            if (!this.p && aVar.f588a != 3 && fragment != null) {
                this.r.O0(fragment);
            }
        }
        if (this.p || !z) {
            return;
        }
        j jVar = this.r;
        jVar.P0(jVar.C, true);
    }

    Fragment n(ArrayList<Fragment> arrayList, Fragment fragment) {
        Fragment fragment2 = fragment;
        int i2 = 0;
        while (i2 < this.f577a.size()) {
            n.a aVar = this.f577a.get(i2);
            int i3 = aVar.f588a;
            if (i3 != 1) {
                if (i3 == 2) {
                    Fragment fragment3 = aVar.f589b;
                    int i4 = fragment3.J;
                    boolean z = false;
                    for (int size = arrayList.size() - 1; size >= 0; size--) {
                        Fragment fragment4 = arrayList.get(size);
                        if (fragment4.J == i4) {
                            if (fragment4 == fragment3) {
                                z = true;
                            } else {
                                if (fragment4 == fragment2) {
                                    this.f577a.add(i2, new n.a(9, fragment4));
                                    i2++;
                                    fragment2 = null;
                                }
                                n.a aVar2 = new n.a(3, fragment4);
                                aVar2.f590c = aVar.f590c;
                                aVar2.f592e = aVar.f592e;
                                aVar2.f591d = aVar.f591d;
                                aVar2.f593f = aVar.f593f;
                                this.f577a.add(i2, aVar2);
                                arrayList.remove(fragment4);
                                i2++;
                            }
                        }
                    }
                    if (z) {
                        this.f577a.remove(i2);
                        i2--;
                    } else {
                        aVar.f588a = 1;
                        arrayList.add(fragment3);
                    }
                } else if (i3 == 3 || i3 == 6) {
                    arrayList.remove(aVar.f589b);
                    Fragment fragment5 = aVar.f589b;
                    if (fragment5 == fragment2) {
                        this.f577a.add(i2, new n.a(9, fragment5));
                        i2++;
                        fragment2 = null;
                    }
                } else if (i3 != 7) {
                    if (i3 == 8) {
                        this.f577a.add(i2, new n.a(9, fragment2));
                        i2++;
                        fragment2 = aVar.f589b;
                    }
                }
                i2++;
            }
            arrayList.add(aVar.f589b);
            i2++;
        }
        return fragment2;
    }

    public String o() {
        return this.f585i;
    }

    boolean p(int i2) {
        int size = this.f577a.size();
        for (int i3 = 0; i3 < size; i3++) {
            Fragment fragment = this.f577a.get(i3).f589b;
            int i4 = fragment != null ? fragment.J : 0;
            if (i4 != 0 && i4 == i2) {
                return true;
            }
        }
        return false;
    }

    boolean q(ArrayList<a> arrayList, int i2, int i3) {
        if (i3 == i2) {
            return false;
        }
        int size = this.f577a.size();
        int i4 = -1;
        for (int i5 = 0; i5 < size; i5++) {
            Fragment fragment = this.f577a.get(i5).f589b;
            int i6 = fragment != null ? fragment.J : 0;
            if (i6 != 0 && i6 != i4) {
                for (int i7 = i2; i7 < i3; i7++) {
                    a aVar = arrayList.get(i7);
                    int size2 = aVar.f577a.size();
                    for (int i8 = 0; i8 < size2; i8++) {
                        Fragment fragment2 = aVar.f577a.get(i8).f589b;
                        if ((fragment2 != null ? fragment2.J : 0) == i6) {
                            return true;
                        }
                    }
                }
                i4 = i6;
            }
        }
        return false;
    }

    boolean s() {
        for (int i2 = 0; i2 < this.f577a.size(); i2++) {
            if (r(this.f577a.get(i2))) {
                return true;
            }
        }
        return false;
    }

    public void t() {
        if (this.q != null) {
            for (int i2 = 0; i2 < this.q.size(); i2++) {
                this.q.get(i2).run();
            }
            this.q = null;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.t >= 0) {
            sb.append(" #");
            sb.append(this.t);
        }
        if (this.f585i != null) {
            sb.append(" ");
            sb.append(this.f585i);
        }
        sb.append("}");
        return sb.toString();
    }

    void u(Fragment.e eVar) {
        for (int i2 = 0; i2 < this.f577a.size(); i2++) {
            n.a aVar = this.f577a.get(i2);
            if (r(aVar)) {
                aVar.f589b.h1(eVar);
            }
        }
    }

    Fragment v(ArrayList<Fragment> arrayList, Fragment fragment) {
        for (int size = this.f577a.size() - 1; size >= 0; size--) {
            n.a aVar = this.f577a.get(size);
            int i2 = aVar.f588a;
            if (i2 != 1) {
                if (i2 != 3) {
                    switch (i2) {
                        case 8:
                            fragment = null;
                            break;
                        case 9:
                            fragment = aVar.f589b;
                            break;
                        case 10:
                            aVar.f595h = aVar.f594g;
                            break;
                    }
                }
                arrayList.add(aVar.f589b);
            }
            arrayList.remove(aVar.f589b);
        }
        return fragment;
    }
}
