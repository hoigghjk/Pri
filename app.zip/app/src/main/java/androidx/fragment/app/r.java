package androidx.fragment.app;

import androidx.lifecycle.d;

/* loaded from: classes.dex */
class r implements androidx.lifecycle.g {
    private androidx.lifecycle.h n = null;

    r() {
    }

    void a(d.a aVar) {
        this.n.i(aVar);
    }

    void b() {
        if (this.n == null) {
            this.n = new androidx.lifecycle.h(this);
        }
    }

    boolean c() {
        return this.n != null;
    }

    @Override // androidx.lifecycle.g
    public androidx.lifecycle.d getLifecycle() {
        b();
        return this.n;
    }
}
