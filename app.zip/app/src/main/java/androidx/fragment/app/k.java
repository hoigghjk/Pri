package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* loaded from: classes.dex */
final class k implements Parcelable {
    public static final Parcelable.Creator<k> CREATOR = new a();
    ArrayList<m> n;
    ArrayList<String> o;
    b[] p;
    String q;
    int r;

    static class a implements Parcelable.Creator<k> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public k createFromParcel(Parcel parcel) {
            return new k(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public k[] newArray(int i2) {
            return new k[i2];
        }
    }

    public k() {
        this.q = null;
    }

    public k(Parcel parcel) {
        this.q = null;
        this.n = parcel.createTypedArrayList(m.CREATOR);
        this.o = parcel.createStringArrayList();
        this.p = (b[]) parcel.createTypedArray(b.CREATOR);
        this.q = parcel.readString();
        this.r = parcel.readInt();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeTypedList(this.n);
        parcel.writeStringList(this.o);
        parcel.writeTypedArray(this.p, i2);
        parcel.writeString(this.q);
        parcel.writeInt(this.r);
    }
}
