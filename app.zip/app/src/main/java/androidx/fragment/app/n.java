package androidx.fragment.app;

import androidx.lifecycle.d;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

/* loaded from: classes.dex */
public abstract class n {

    /* renamed from: b, reason: collision with root package name */
    int f578b;

    /* renamed from: c, reason: collision with root package name */
    int f579c;

    /* renamed from: d, reason: collision with root package name */
    int f580d;

    /* renamed from: e, reason: collision with root package name */
    int f581e;

    /* renamed from: f, reason: collision with root package name */
    int f582f;

    /* renamed from: g, reason: collision with root package name */
    int f583g;

    /* renamed from: h, reason: collision with root package name */
    boolean f584h;

    /* renamed from: i, reason: collision with root package name */
    String f585i;

    /* renamed from: j, reason: collision with root package name */
    int f586j;

    /* renamed from: k, reason: collision with root package name */
    CharSequence f587k;
    int l;
    CharSequence m;
    ArrayList<String> n;
    ArrayList<String> o;
    ArrayList<Runnable> q;

    /* renamed from: a, reason: collision with root package name */
    ArrayList<a> f577a = new ArrayList<>();
    boolean p = false;

    static final class a {

        /* renamed from: a, reason: collision with root package name */
        int f588a;

        /* renamed from: b, reason: collision with root package name */
        Fragment f589b;

        /* renamed from: c, reason: collision with root package name */
        int f590c;

        /* renamed from: d, reason: collision with root package name */
        int f591d;

        /* renamed from: e, reason: collision with root package name */
        int f592e;

        /* renamed from: f, reason: collision with root package name */
        int f593f;

        /* renamed from: g, reason: collision with root package name */
        d.b f594g;

        /* renamed from: h, reason: collision with root package name */
        d.b f595h;

        a() {
        }

        a(int i2, Fragment fragment) {
            this.f588a = i2;
            this.f589b = fragment;
            d.b bVar = d.b.RESUMED;
            this.f594g = bVar;
            this.f595h = bVar;
        }
    }

    public n b(Fragment fragment, String str) {
        f(0, fragment, str, 1);
        return this;
    }

    void c(a aVar) {
        this.f577a.add(aVar);
        aVar.f590c = this.f578b;
        aVar.f591d = this.f579c;
        aVar.f592e = this.f580d;
        aVar.f593f = this.f581e;
    }

    public abstract int d();

    public abstract int e();

    void f(int i2, Fragment fragment, String str, int i3) {
        Class<?> cls = fragment.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            throw new IllegalStateException("Fragment " + cls.getCanonicalName() + " must be a public static class to be  properly recreated from instance state.");
        }
        if (str != null) {
            String str2 = fragment.K;
            if (str2 != null && !str.equals(str2)) {
                throw new IllegalStateException("Can't change tag of fragment " + fragment + ": was " + fragment.K + " now " + str);
            }
            fragment.K = str;
        }
        if (i2 != 0) {
            if (i2 == -1) {
                throw new IllegalArgumentException("Can't add fragment " + fragment + " with tag " + str + " to container view with no id");
            }
            int i4 = fragment.I;
            if (i4 != 0 && i4 != i2) {
                throw new IllegalStateException("Can't change container ID of fragment " + fragment + ": was " + fragment.I + " now " + i2);
            }
            fragment.I = i2;
            fragment.J = i2;
        }
        c(new a(i3, fragment));
    }

    public n g(Fragment fragment) {
        c(new a(3, fragment));
        return this;
    }
}
