package androidx.fragment.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

/* loaded from: classes.dex */
public class f {

    /* renamed from: a, reason: collision with root package name */
    private final h<?> f544a;

    private f(h<?> hVar) {
        this.f544a = hVar;
    }

    public static f b(h<?> hVar) {
        b.g.k.h.c(hVar, "callbacks == null");
        return new f(hVar);
    }

    public void a(Fragment fragment) {
        h<?> hVar = this.f544a;
        hVar.r.p(hVar, hVar, fragment);
    }

    public void c() {
        this.f544a.r.y();
    }

    public void d(Configuration configuration) {
        this.f544a.r.z(configuration);
    }

    public boolean e(MenuItem menuItem) {
        return this.f544a.r.A(menuItem);
    }

    public void f() {
        this.f544a.r.B();
    }

    public boolean g(Menu menu, MenuInflater menuInflater) {
        return this.f544a.r.C(menu, menuInflater);
    }

    public void h() {
        this.f544a.r.D();
    }

    public void i() {
        this.f544a.r.F();
    }

    public void j(boolean z) {
        this.f544a.r.G(z);
    }

    public boolean k(MenuItem menuItem) {
        return this.f544a.r.V(menuItem);
    }

    public void l(Menu menu) {
        this.f544a.r.W(menu);
    }

    public void m() {
        this.f544a.r.Y();
    }

    public void n(boolean z) {
        this.f544a.r.Z(z);
    }

    public boolean o(Menu menu) {
        return this.f544a.r.a0(menu);
    }

    public void p() {
        this.f544a.r.c0();
    }

    public void q() {
        this.f544a.r.d0();
    }

    public void r() {
        this.f544a.r.f0();
    }

    public boolean s() {
        return this.f544a.r.l0();
    }

    public Fragment t(String str) {
        return this.f544a.r.q0(str);
    }

    public i u() {
        return this.f544a.r;
    }

    public void v() {
        this.f544a.r.S0();
    }

    public View w(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f544a.r.onCreateView(view, str, context, attributeSet);
    }

    public void x(Parcelable parcelable) {
        h<?> hVar = this.f544a;
        if (!(hVar instanceof androidx.lifecycle.s)) {
            throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
        }
        hVar.r.c1(parcelable);
    }

    public Parcelable y() {
        return this.f544a.r.e1();
    }
}
