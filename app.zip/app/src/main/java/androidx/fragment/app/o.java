package androidx.fragment.app;

import android.graphics.Rect;
import android.os.Build;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/* loaded from: classes.dex */
class o {

    /* renamed from: a, reason: collision with root package name */
    private static final int[] f596a = {0, 3, 0, 1, 5, 4, 7, 6, 9, 8, 10};

    /* renamed from: b, reason: collision with root package name */
    private static final q f597b;

    /* renamed from: c, reason: collision with root package name */
    private static final q f598c;

    static class a implements Runnable {
        final /* synthetic */ ArrayList n;

        a(ArrayList arrayList) {
            this.n = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            o.B(this.n, 4);
        }
    }

    static class b implements Runnable {
        final /* synthetic */ Object n;
        final /* synthetic */ q o;
        final /* synthetic */ View p;
        final /* synthetic */ Fragment q;
        final /* synthetic */ ArrayList r;
        final /* synthetic */ ArrayList s;
        final /* synthetic */ ArrayList t;
        final /* synthetic */ Object u;

        b(Object obj, q qVar, View view, Fragment fragment, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, Object obj2) {
            this.n = obj;
            this.o = qVar;
            this.p = view;
            this.q = fragment;
            this.r = arrayList;
            this.s = arrayList2;
            this.t = arrayList3;
            this.u = obj2;
        }

        @Override // java.lang.Runnable
        public void run() {
            Object obj = this.n;
            if (obj != null) {
                this.o.p(obj, this.p);
                this.s.addAll(o.k(this.o, this.n, this.q, this.r, this.p));
            }
            if (this.t != null) {
                if (this.u != null) {
                    ArrayList<View> arrayList = new ArrayList<>();
                    arrayList.add(this.p);
                    this.o.q(this.u, this.t, arrayList);
                }
                this.t.clear();
                this.t.add(this.p);
            }
        }
    }

    static class c implements Runnable {
        final /* synthetic */ Fragment n;
        final /* synthetic */ Fragment o;
        final /* synthetic */ boolean p;
        final /* synthetic */ b.e.a q;
        final /* synthetic */ View r;
        final /* synthetic */ q s;
        final /* synthetic */ Rect t;

        c(Fragment fragment, Fragment fragment2, boolean z, b.e.a aVar, View view, q qVar, Rect rect) {
            this.n = fragment;
            this.o = fragment2;
            this.p = z;
            this.q = aVar;
            this.r = view;
            this.s = qVar;
            this.t = rect;
        }

        @Override // java.lang.Runnable
        public void run() {
            o.f(this.n, this.o, this.p, this.q, false);
            View view = this.r;
            if (view != null) {
                this.s.k(view, this.t);
            }
        }
    }

    static class d implements Runnable {
        final /* synthetic */ q n;
        final /* synthetic */ b.e.a o;
        final /* synthetic */ Object p;
        final /* synthetic */ e q;
        final /* synthetic */ ArrayList r;
        final /* synthetic */ View s;
        final /* synthetic */ Fragment t;
        final /* synthetic */ Fragment u;
        final /* synthetic */ boolean v;
        final /* synthetic */ ArrayList w;
        final /* synthetic */ Object x;
        final /* synthetic */ Rect y;

        d(q qVar, b.e.a aVar, Object obj, e eVar, ArrayList arrayList, View view, Fragment fragment, Fragment fragment2, boolean z, ArrayList arrayList2, Object obj2, Rect rect) {
            this.n = qVar;
            this.o = aVar;
            this.p = obj;
            this.q = eVar;
            this.r = arrayList;
            this.s = view;
            this.t = fragment;
            this.u = fragment2;
            this.v = z;
            this.w = arrayList2;
            this.x = obj2;
            this.y = rect;
        }

        @Override // java.lang.Runnable
        public void run() {
            b.e.a<String, View> h2 = o.h(this.n, this.o, this.p, this.q);
            if (h2 != null) {
                this.r.addAll(h2.values());
                this.r.add(this.s);
            }
            o.f(this.t, this.u, this.v, h2, false);
            Object obj = this.p;
            if (obj != null) {
                this.n.z(obj, this.w, this.r);
                View t = o.t(h2, this.q, this.x, this.v);
                if (t != null) {
                    this.n.k(t, this.y);
                }
            }
        }
    }

    static class e {

        /* renamed from: a, reason: collision with root package name */
        public Fragment f599a;

        /* renamed from: b, reason: collision with root package name */
        public boolean f600b;

        /* renamed from: c, reason: collision with root package name */
        public androidx.fragment.app.a f601c;

        /* renamed from: d, reason: collision with root package name */
        public Fragment f602d;

        /* renamed from: e, reason: collision with root package name */
        public boolean f603e;

        /* renamed from: f, reason: collision with root package name */
        public androidx.fragment.app.a f604f;

        e() {
        }
    }

    static {
        f597b = Build.VERSION.SDK_INT >= 21 ? new p() : null;
        f598c = x();
    }

    private static void A(q qVar, Object obj, Object obj2, b.e.a<String, View> aVar, boolean z, androidx.fragment.app.a aVar2) {
        ArrayList<String> arrayList = aVar2.n;
        if (arrayList == null || arrayList.isEmpty()) {
            return;
        }
        View view = aVar.get((z ? aVar2.o : aVar2.n).get(0));
        qVar.v(obj, view);
        if (obj2 != null) {
            qVar.v(obj2, view);
        }
    }

    static void B(ArrayList<View> arrayList, int i2) {
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            arrayList.get(size).setVisibility(i2);
        }
    }

    static void C(j jVar, ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3, boolean z) {
        if (jVar.C < 1) {
            return;
        }
        SparseArray sparseArray = new SparseArray();
        for (int i4 = i2; i4 < i3; i4++) {
            androidx.fragment.app.a aVar = arrayList.get(i4);
            if (arrayList2.get(i4).booleanValue()) {
                e(aVar, sparseArray, z);
            } else {
                c(aVar, sparseArray, z);
            }
        }
        if (sparseArray.size() != 0) {
            View view = new View(jVar.D.e());
            int size = sparseArray.size();
            for (int i5 = 0; i5 < size; i5++) {
                int keyAt = sparseArray.keyAt(i5);
                b.e.a<String, String> d2 = d(keyAt, arrayList, arrayList2, i2, i3);
                e eVar = (e) sparseArray.valueAt(i5);
                if (z) {
                    o(jVar, keyAt, eVar, view, d2);
                } else {
                    n(jVar, keyAt, eVar, view, d2);
                }
            }
        }
    }

    private static void a(ArrayList<View> arrayList, b.e.a<String, View> aVar, Collection<String> collection) {
        for (int size = aVar.size() - 1; size >= 0; size--) {
            View m = aVar.m(size);
            if (collection.contains(b.g.l.r.t(m))) {
                arrayList.add(m);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:63:0x0041, code lost:
    
        if (r10.x != false) goto L69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x0092, code lost:
    
        r1 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:0x0076, code lost:
    
        r1 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:99:0x0090, code lost:
    
        if (r10.L == false) goto L69;
     */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00a0  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00ae A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00d3 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00e5 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:56:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static void b(androidx.fragment.app.a r16, androidx.fragment.app.n.a r17, android.util.SparseArray<androidx.fragment.app.o.e> r18, boolean r19, boolean r20) {
        /*
            Method dump skipped, instructions count: 240
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.o.b(androidx.fragment.app.a, androidx.fragment.app.n$a, android.util.SparseArray, boolean, boolean):void");
    }

    public static void c(androidx.fragment.app.a aVar, SparseArray<e> sparseArray, boolean z) {
        int size = aVar.f577a.size();
        for (int i2 = 0; i2 < size; i2++) {
            b(aVar, aVar.f577a.get(i2), sparseArray, false, z);
        }
    }

    private static b.e.a<String, String> d(int i2, ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, int i3, int i4) {
        ArrayList<String> arrayList3;
        ArrayList<String> arrayList4;
        b.e.a<String, String> aVar = new b.e.a<>();
        for (int i5 = i4 - 1; i5 >= i3; i5--) {
            androidx.fragment.app.a aVar2 = arrayList.get(i5);
            if (aVar2.p(i2)) {
                boolean booleanValue = arrayList2.get(i5).booleanValue();
                ArrayList<String> arrayList5 = aVar2.n;
                if (arrayList5 != null) {
                    int size = arrayList5.size();
                    if (booleanValue) {
                        arrayList3 = aVar2.n;
                        arrayList4 = aVar2.o;
                    } else {
                        ArrayList<String> arrayList6 = aVar2.n;
                        arrayList3 = aVar2.o;
                        arrayList4 = arrayList6;
                    }
                    for (int i6 = 0; i6 < size; i6++) {
                        String str = arrayList4.get(i6);
                        String str2 = arrayList3.get(i6);
                        String remove = aVar.remove(str2);
                        if (remove != null) {
                            aVar.put(str, remove);
                        } else {
                            aVar.put(str, str2);
                        }
                    }
                }
            }
        }
        return aVar;
    }

    public static void e(androidx.fragment.app.a aVar, SparseArray<e> sparseArray, boolean z) {
        if (aVar.r.E.c()) {
            for (int size = aVar.f577a.size() - 1; size >= 0; size--) {
                b(aVar, aVar.f577a.get(size), sparseArray, true, z);
            }
        }
    }

    static void f(Fragment fragment, Fragment fragment2, boolean z, b.e.a<String, View> aVar, boolean z2) {
        androidx.core.app.n p = z ? fragment2.p() : fragment.p();
        if (p != null) {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            int size = aVar == null ? 0 : aVar.size();
            for (int i2 = 0; i2 < size; i2++) {
                arrayList2.add(aVar.i(i2));
                arrayList.add(aVar.m(i2));
            }
            if (z2) {
                p.f(arrayList2, arrayList, null);
            } else {
                p.e(arrayList2, arrayList, null);
            }
        }
    }

    private static boolean g(q qVar, List<Object> list) {
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (!qVar.e(list.get(i2))) {
                return false;
            }
        }
        return true;
    }

    static b.e.a<String, View> h(q qVar, b.e.a<String, String> aVar, Object obj, e eVar) {
        androidx.core.app.n p;
        ArrayList<String> arrayList;
        String q;
        Fragment fragment = eVar.f599a;
        View H = fragment.H();
        if (aVar.isEmpty() || obj == null || H == null) {
            aVar.clear();
            return null;
        }
        b.e.a<String, View> aVar2 = new b.e.a<>();
        qVar.j(aVar2, H);
        androidx.fragment.app.a aVar3 = eVar.f601c;
        if (eVar.f600b) {
            p = fragment.r();
            arrayList = aVar3.n;
        } else {
            p = fragment.p();
            arrayList = aVar3.o;
        }
        if (arrayList != null) {
            aVar2.o(arrayList);
            aVar2.o(aVar.values());
        }
        if (p != null) {
            p.c(arrayList, aVar2);
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                String str = arrayList.get(size);
                View view = aVar2.get(str);
                if (view == null) {
                    String q2 = q(aVar, str);
                    if (q2 != null) {
                        aVar.remove(q2);
                    }
                } else if (!str.equals(b.g.l.r.t(view)) && (q = q(aVar, str)) != null) {
                    aVar.put(q, b.g.l.r.t(view));
                }
            }
        } else {
            y(aVar, aVar2);
        }
        return aVar2;
    }

    private static b.e.a<String, View> i(q qVar, b.e.a<String, String> aVar, Object obj, e eVar) {
        androidx.core.app.n r;
        ArrayList<String> arrayList;
        if (aVar.isEmpty() || obj == null) {
            aVar.clear();
            return null;
        }
        Fragment fragment = eVar.f602d;
        b.e.a<String, View> aVar2 = new b.e.a<>();
        qVar.j(aVar2, fragment.Y0());
        androidx.fragment.app.a aVar3 = eVar.f604f;
        if (eVar.f603e) {
            r = fragment.p();
            arrayList = aVar3.o;
        } else {
            r = fragment.r();
            arrayList = aVar3.n;
        }
        aVar2.o(arrayList);
        if (r != null) {
            r.c(arrayList, aVar2);
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                String str = arrayList.get(size);
                View view = aVar2.get(str);
                if (view == null) {
                    aVar.remove(str);
                } else if (!str.equals(b.g.l.r.t(view))) {
                    aVar.put(b.g.l.r.t(view), aVar.remove(str));
                }
            }
        } else {
            aVar.o(aVar2.keySet());
        }
        return aVar2;
    }

    private static q j(Fragment fragment, Fragment fragment2) {
        ArrayList arrayList = new ArrayList();
        if (fragment != null) {
            Object q = fragment.q();
            if (q != null) {
                arrayList.add(q);
            }
            Object C = fragment.C();
            if (C != null) {
                arrayList.add(C);
            }
            Object E = fragment.E();
            if (E != null) {
                arrayList.add(E);
            }
        }
        if (fragment2 != null) {
            Object o = fragment2.o();
            if (o != null) {
                arrayList.add(o);
            }
            Object z = fragment2.z();
            if (z != null) {
                arrayList.add(z);
            }
            Object D = fragment2.D();
            if (D != null) {
                arrayList.add(D);
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        q qVar = f597b;
        if (qVar != null && g(qVar, arrayList)) {
            return qVar;
        }
        q qVar2 = f598c;
        if (qVar2 != null && g(qVar2, arrayList)) {
            return qVar2;
        }
        if (qVar == null && qVar2 == null) {
            return null;
        }
        throw new IllegalArgumentException("Invalid Transition types");
    }

    static ArrayList<View> k(q qVar, Object obj, Fragment fragment, ArrayList<View> arrayList, View view) {
        if (obj == null) {
            return null;
        }
        ArrayList<View> arrayList2 = new ArrayList<>();
        View H = fragment.H();
        if (H != null) {
            qVar.f(arrayList2, H);
        }
        if (arrayList != null) {
            arrayList2.removeAll(arrayList);
        }
        if (arrayList2.isEmpty()) {
            return arrayList2;
        }
        arrayList2.add(view);
        qVar.b(obj, arrayList2);
        return arrayList2;
    }

    private static Object l(q qVar, ViewGroup viewGroup, View view, b.e.a<String, String> aVar, e eVar, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        Object u;
        b.e.a<String, String> aVar2;
        Object obj3;
        Rect rect;
        Fragment fragment = eVar.f599a;
        Fragment fragment2 = eVar.f602d;
        if (fragment == null || fragment2 == null) {
            return null;
        }
        boolean z = eVar.f600b;
        if (aVar.isEmpty()) {
            aVar2 = aVar;
            u = null;
        } else {
            u = u(qVar, fragment, fragment2, z);
            aVar2 = aVar;
        }
        b.e.a<String, View> i2 = i(qVar, aVar2, u, eVar);
        if (aVar.isEmpty()) {
            obj3 = null;
        } else {
            arrayList.addAll(i2.values());
            obj3 = u;
        }
        if (obj == null && obj2 == null && obj3 == null) {
            return null;
        }
        f(fragment, fragment2, z, i2, true);
        if (obj3 != null) {
            rect = new Rect();
            qVar.y(obj3, view, arrayList);
            A(qVar, obj3, obj2, i2, eVar.f603e, eVar.f604f);
            if (obj != null) {
                qVar.u(obj, rect);
            }
        } else {
            rect = null;
        }
        b.g.l.p.a(viewGroup, new d(qVar, aVar, obj3, eVar, arrayList2, view, fragment, fragment2, z, arrayList, obj, rect));
        return obj3;
    }

    private static Object m(q qVar, ViewGroup viewGroup, View view, b.e.a<String, String> aVar, e eVar, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        Object obj3;
        View view2;
        Rect rect;
        Fragment fragment = eVar.f599a;
        Fragment fragment2 = eVar.f602d;
        if (fragment != null) {
            fragment.Y0().setVisibility(0);
        }
        if (fragment == null || fragment2 == null) {
            return null;
        }
        boolean z = eVar.f600b;
        Object u = aVar.isEmpty() ? null : u(qVar, fragment, fragment2, z);
        b.e.a<String, View> i2 = i(qVar, aVar, u, eVar);
        b.e.a<String, View> h2 = h(qVar, aVar, u, eVar);
        if (aVar.isEmpty()) {
            if (i2 != null) {
                i2.clear();
            }
            if (h2 != null) {
                h2.clear();
            }
            obj3 = null;
        } else {
            a(arrayList, i2, aVar.keySet());
            a(arrayList2, h2, aVar.values());
            obj3 = u;
        }
        if (obj == null && obj2 == null && obj3 == null) {
            return null;
        }
        f(fragment, fragment2, z, i2, true);
        if (obj3 != null) {
            arrayList2.add(view);
            qVar.y(obj3, view, arrayList);
            A(qVar, obj3, obj2, i2, eVar.f603e, eVar.f604f);
            Rect rect2 = new Rect();
            View t = t(h2, eVar, obj, z);
            if (t != null) {
                qVar.u(obj, rect2);
            }
            rect = rect2;
            view2 = t;
        } else {
            view2 = null;
            rect = null;
        }
        b.g.l.p.a(viewGroup, new c(fragment, fragment2, z, h2, view2, qVar, rect));
        return obj3;
    }

    private static void n(j jVar, int i2, e eVar, View view, b.e.a<String, String> aVar) {
        Fragment fragment;
        Fragment fragment2;
        q j2;
        Object obj;
        ViewGroup viewGroup = jVar.E.c() ? (ViewGroup) jVar.E.b(i2) : null;
        if (viewGroup == null || (j2 = j((fragment2 = eVar.f602d), (fragment = eVar.f599a))) == null) {
            return;
        }
        boolean z = eVar.f600b;
        boolean z2 = eVar.f603e;
        Object r = r(j2, fragment, z);
        Object s = s(j2, fragment2, z2);
        ArrayList arrayList = new ArrayList();
        ArrayList<View> arrayList2 = new ArrayList<>();
        Object l = l(j2, viewGroup, view, aVar, eVar, arrayList, arrayList2, r, s);
        if (r == null && l == null) {
            obj = s;
            if (obj == null) {
                return;
            }
        } else {
            obj = s;
        }
        ArrayList<View> k2 = k(j2, obj, fragment2, arrayList, view);
        Object obj2 = (k2 == null || k2.isEmpty()) ? null : obj;
        j2.a(r, view);
        Object v = v(j2, r, obj2, l, fragment, eVar.f600b);
        if (v != null) {
            ArrayList<View> arrayList3 = new ArrayList<>();
            j2.t(v, r, arrayList3, obj2, k2, l, arrayList2);
            z(j2, viewGroup, fragment, view, arrayList2, r, arrayList3, obj2, k2);
            j2.w(viewGroup, arrayList2, aVar);
            j2.c(viewGroup, v);
            j2.s(viewGroup, arrayList2, aVar);
        }
    }

    private static void o(j jVar, int i2, e eVar, View view, b.e.a<String, String> aVar) {
        Fragment fragment;
        Fragment fragment2;
        q j2;
        Object obj;
        ViewGroup viewGroup = jVar.E.c() ? (ViewGroup) jVar.E.b(i2) : null;
        if (viewGroup == null || (j2 = j((fragment2 = eVar.f602d), (fragment = eVar.f599a))) == null) {
            return;
        }
        boolean z = eVar.f600b;
        boolean z2 = eVar.f603e;
        ArrayList<View> arrayList = new ArrayList<>();
        ArrayList<View> arrayList2 = new ArrayList<>();
        Object r = r(j2, fragment, z);
        Object s = s(j2, fragment2, z2);
        Object m = m(j2, viewGroup, view, aVar, eVar, arrayList2, arrayList, r, s);
        if (r == null && m == null) {
            obj = s;
            if (obj == null) {
                return;
            }
        } else {
            obj = s;
        }
        ArrayList<View> k2 = k(j2, obj, fragment2, arrayList2, view);
        ArrayList<View> k3 = k(j2, r, fragment, arrayList, view);
        B(k3, 4);
        Object v = v(j2, r, obj, m, fragment, z);
        if (v != null) {
            w(j2, obj, fragment2, k2);
            ArrayList<String> o = j2.o(arrayList);
            j2.t(v, r, k3, obj, k2, m, arrayList);
            j2.c(viewGroup, v);
            j2.x(viewGroup, arrayList2, arrayList, o, aVar);
            B(k3, 0);
            j2.z(m, arrayList2, arrayList);
        }
    }

    private static e p(e eVar, SparseArray<e> sparseArray, int i2) {
        if (eVar != null) {
            return eVar;
        }
        e eVar2 = new e();
        sparseArray.put(i2, eVar2);
        return eVar2;
    }

    private static String q(b.e.a<String, String> aVar, String str) {
        int size = aVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (str.equals(aVar.m(i2))) {
                return aVar.i(i2);
            }
        }
        return null;
    }

    private static Object r(q qVar, Fragment fragment, boolean z) {
        if (fragment == null) {
            return null;
        }
        return qVar.g(z ? fragment.z() : fragment.o());
    }

    private static Object s(q qVar, Fragment fragment, boolean z) {
        if (fragment == null) {
            return null;
        }
        return qVar.g(z ? fragment.C() : fragment.q());
    }

    static View t(b.e.a<String, View> aVar, e eVar, Object obj, boolean z) {
        ArrayList<String> arrayList;
        androidx.fragment.app.a aVar2 = eVar.f601c;
        if (obj == null || aVar == null || (arrayList = aVar2.n) == null || arrayList.isEmpty()) {
            return null;
        }
        return aVar.get((z ? aVar2.n : aVar2.o).get(0));
    }

    private static Object u(q qVar, Fragment fragment, Fragment fragment2, boolean z) {
        if (fragment == null || fragment2 == null) {
            return null;
        }
        return qVar.A(qVar.g(z ? fragment2.E() : fragment.D()));
    }

    private static Object v(q qVar, Object obj, Object obj2, Object obj3, Fragment fragment, boolean z) {
        return (obj == null || obj2 == null || fragment == null) ? true : z ? fragment.j() : fragment.i() ? qVar.n(obj2, obj, obj3) : qVar.m(obj2, obj, obj3);
    }

    private static void w(q qVar, Object obj, Fragment fragment, ArrayList<View> arrayList) {
        if (fragment != null && obj != null && fragment.x && fragment.L && fragment.Z) {
            fragment.e1(true);
            qVar.r(obj, fragment.H(), arrayList);
            b.g.l.p.a(fragment.S, new a(arrayList));
        }
    }

    private static q x() {
        try {
            return (q) Class.forName("androidx.transition.FragmentTransitionSupport").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception unused) {
            return null;
        }
    }

    private static void y(b.e.a<String, String> aVar, b.e.a<String, View> aVar2) {
        for (int size = aVar.size() - 1; size >= 0; size--) {
            if (!aVar2.containsKey(aVar.m(size))) {
                aVar.k(size);
            }
        }
    }

    private static void z(q qVar, ViewGroup viewGroup, Fragment fragment, View view, ArrayList<View> arrayList, Object obj, ArrayList<View> arrayList2, Object obj2, ArrayList<View> arrayList3) {
        b.g.l.p.a(viewGroup, new b(obj, qVar, view, fragment, arrayList, arrayList2, arrayList3, obj2));
    }
}
