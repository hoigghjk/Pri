package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.fragment.app.n;
import androidx.lifecycle.d;
import java.util.ArrayList;

/* loaded from: classes.dex */
final class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new a();
    final ArrayList<String> A;
    final boolean B;
    final int[] n;
    final ArrayList<String> o;
    final int[] p;
    final int[] q;
    final int r;
    final int s;
    final String t;
    final int u;
    final int v;
    final CharSequence w;
    final int x;
    final CharSequence y;
    final ArrayList<String> z;

    static class a implements Parcelable.Creator<b> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public b createFromParcel(Parcel parcel) {
            return new b(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public b[] newArray(int i2) {
            return new b[i2];
        }
    }

    public b(Parcel parcel) {
        this.n = parcel.createIntArray();
        this.o = parcel.createStringArrayList();
        this.p = parcel.createIntArray();
        this.q = parcel.createIntArray();
        this.r = parcel.readInt();
        this.s = parcel.readInt();
        this.t = parcel.readString();
        this.u = parcel.readInt();
        this.v = parcel.readInt();
        this.w = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.x = parcel.readInt();
        this.y = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.z = parcel.createStringArrayList();
        this.A = parcel.createStringArrayList();
        this.B = parcel.readInt() != 0;
    }

    public b(androidx.fragment.app.a aVar) {
        int size = aVar.f577a.size();
        this.n = new int[size * 5];
        if (!aVar.f584h) {
            throw new IllegalStateException("Not on back stack");
        }
        this.o = new ArrayList<>(size);
        this.p = new int[size];
        this.q = new int[size];
        int i2 = 0;
        int i3 = 0;
        while (i2 < size) {
            n.a aVar2 = aVar.f577a.get(i2);
            int i4 = i3 + 1;
            this.n[i3] = aVar2.f588a;
            ArrayList<String> arrayList = this.o;
            Fragment fragment = aVar2.f589b;
            arrayList.add(fragment != null ? fragment.r : null);
            int[] iArr = this.n;
            int i5 = i4 + 1;
            iArr[i4] = aVar2.f590c;
            int i6 = i5 + 1;
            iArr[i5] = aVar2.f591d;
            int i7 = i6 + 1;
            iArr[i6] = aVar2.f592e;
            iArr[i7] = aVar2.f593f;
            this.p[i2] = aVar2.f594g.ordinal();
            this.q[i2] = aVar2.f595h.ordinal();
            i2++;
            i3 = i7 + 1;
        }
        this.r = aVar.f582f;
        this.s = aVar.f583g;
        this.t = aVar.f585i;
        this.u = aVar.t;
        this.v = aVar.f586j;
        this.w = aVar.f587k;
        this.x = aVar.l;
        this.y = aVar.m;
        this.z = aVar.n;
        this.A = aVar.o;
        this.B = aVar.p;
    }

    public androidx.fragment.app.a a(j jVar) {
        androidx.fragment.app.a aVar = new androidx.fragment.app.a(jVar);
        int i2 = 0;
        int i3 = 0;
        while (true) {
            int[] iArr = this.n;
            if (i2 >= iArr.length) {
                aVar.f582f = this.r;
                aVar.f583g = this.s;
                aVar.f585i = this.t;
                aVar.t = this.u;
                aVar.f584h = true;
                aVar.f586j = this.v;
                aVar.f587k = this.w;
                aVar.l = this.x;
                aVar.m = this.y;
                aVar.n = this.z;
                aVar.o = this.A;
                aVar.p = this.B;
                aVar.h(1);
                return aVar;
            }
            n.a aVar2 = new n.a();
            int i4 = i2 + 1;
            aVar2.f588a = iArr[i2];
            if (j.U) {
                Log.v("FragmentManager", "Instantiate " + aVar + " op #" + i3 + " base fragment #" + this.n[i4]);
            }
            String str = this.o.get(i3);
            aVar2.f589b = str != null ? jVar.t.get(str) : null;
            aVar2.f594g = d.b.values()[this.p[i3]];
            aVar2.f595h = d.b.values()[this.q[i3]];
            int[] iArr2 = this.n;
            int i5 = i4 + 1;
            int i6 = iArr2[i4];
            aVar2.f590c = i6;
            int i7 = i5 + 1;
            int i8 = iArr2[i5];
            aVar2.f591d = i8;
            int i9 = i7 + 1;
            int i10 = iArr2[i7];
            aVar2.f592e = i10;
            int i11 = iArr2[i9];
            aVar2.f593f = i11;
            aVar.f578b = i6;
            aVar.f579c = i8;
            aVar.f580d = i10;
            aVar.f581e = i11;
            aVar.c(aVar2);
            i3++;
            i2 = i9 + 1;
        }
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeIntArray(this.n);
        parcel.writeStringList(this.o);
        parcel.writeIntArray(this.p);
        parcel.writeIntArray(this.q);
        parcel.writeInt(this.r);
        parcel.writeInt(this.s);
        parcel.writeString(this.t);
        parcel.writeInt(this.u);
        parcel.writeInt(this.v);
        TextUtils.writeToParcel(this.w, parcel, 0);
        parcel.writeInt(this.x);
        TextUtils.writeToParcel(this.y, parcel, 0);
        parcel.writeStringList(this.z);
        parcel.writeStringList(this.A);
        parcel.writeInt(this.B ? 1 : 0);
    }
}
