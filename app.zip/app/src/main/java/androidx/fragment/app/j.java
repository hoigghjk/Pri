package androidx.fragment.app;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import androidx.activity.OnBackPressedDispatcher;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.i;
import androidx.lifecycle.d;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: classes.dex */
final class j extends androidx.fragment.app.i implements LayoutInflater.Factory2 {
    static boolean U = false;
    static final Interpolator V = new DecelerateInterpolator(2.5f);
    static final Interpolator W = new DecelerateInterpolator(1.5f);
    ArrayList<i.b> A;
    androidx.fragment.app.h D;
    androidx.fragment.app.e E;
    Fragment F;
    Fragment G;
    boolean H;
    boolean I;
    boolean J;
    boolean K;
    boolean L;
    ArrayList<androidx.fragment.app.a> M;
    ArrayList<Boolean> N;
    ArrayList<Fragment> O;
    ArrayList<m> R;
    private androidx.fragment.app.l S;
    ArrayList<k> p;
    boolean q;
    ArrayList<androidx.fragment.app.a> u;
    ArrayList<Fragment> v;
    private OnBackPressedDispatcher w;
    ArrayList<androidx.fragment.app.a> y;
    ArrayList<Integer> z;
    int r = 0;
    final ArrayList<Fragment> s = new ArrayList<>();
    final HashMap<String, Fragment> t = new HashMap<>();
    private final androidx.activity.b x = new a(false);
    private final CopyOnWriteArrayList<i> B = new CopyOnWriteArrayList<>();
    int C = 0;
    Bundle P = null;
    SparseArray<Parcelable> Q = null;
    Runnable T = new b();

    class a extends androidx.activity.b {
        a(boolean z) {
            super(z);
        }

        @Override // androidx.activity.b
        public void b() {
            j.this.B0();
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            j.this.l0();
        }
    }

    class c implements Animation.AnimationListener {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ViewGroup f547a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ Fragment f548b;

        class a implements Runnable {
            a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                if (c.this.f548b.k() != null) {
                    c.this.f548b.b1(null);
                    c cVar = c.this;
                    j jVar = j.this;
                    Fragment fragment = cVar.f548b;
                    jVar.R0(fragment, fragment.F(), 0, 0, false);
                }
            }
        }

        c(ViewGroup viewGroup, Fragment fragment) {
            this.f547a = viewGroup;
            this.f548b = fragment;
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationEnd(Animation animation) {
            this.f547a.post(new a());
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationRepeat(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationStart(Animation animation) {
        }
    }

    class d extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ViewGroup f550a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f551b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ Fragment f552c;

        d(ViewGroup viewGroup, View view, Fragment fragment) {
            this.f550a = viewGroup;
            this.f551b = view;
            this.f552c = fragment;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f550a.endViewTransition(this.f551b);
            Animator l = this.f552c.l();
            this.f552c.c1(null);
            if (l == null || this.f550a.indexOfChild(this.f551b) >= 0) {
                return;
            }
            j jVar = j.this;
            Fragment fragment = this.f552c;
            jVar.R0(fragment, fragment.F(), 0, 0, false);
        }
    }

    class e extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ ViewGroup f554a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f555b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ Fragment f556c;

        e(j jVar, ViewGroup viewGroup, View view, Fragment fragment) {
            this.f554a = viewGroup;
            this.f555b = view;
            this.f556c = fragment;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f554a.endViewTransition(this.f555b);
            animator.removeListener(this);
            Fragment fragment = this.f556c;
            View view = fragment.T;
            if (view == null || !fragment.L) {
                return;
            }
            view.setVisibility(8);
        }
    }

    class f extends androidx.fragment.app.g {
        f() {
        }

        @Override // androidx.fragment.app.g
        public Fragment a(ClassLoader classLoader, String str) {
            androidx.fragment.app.h hVar = j.this.D;
            return hVar.a(hVar.e(), str, null);
        }
    }

    private static class g {

        /* renamed from: a, reason: collision with root package name */
        public final Animation f558a;

        /* renamed from: b, reason: collision with root package name */
        public final Animator f559b;

        g(Animator animator) {
            this.f558a = null;
            this.f559b = animator;
            if (animator == null) {
                throw new IllegalStateException("Animator cannot be null");
            }
        }

        g(Animation animation) {
            this.f558a = animation;
            this.f559b = null;
            if (animation == null) {
                throw new IllegalStateException("Animation cannot be null");
            }
        }
    }

    private static class h extends AnimationSet implements Runnable {
        private final ViewGroup n;
        private final View o;
        private boolean p;
        private boolean q;
        private boolean r;

        h(Animation animation, ViewGroup viewGroup, View view) {
            super(false);
            this.r = true;
            this.n = viewGroup;
            this.o = view;
            addAnimation(animation);
            viewGroup.post(this);
        }

        @Override // android.view.animation.AnimationSet, android.view.animation.Animation
        public boolean getTransformation(long j2, Transformation transformation) {
            this.r = true;
            if (this.p) {
                return !this.q;
            }
            if (!super.getTransformation(j2, transformation)) {
                this.p = true;
                b.g.l.p.a(this.n, this);
            }
            return true;
        }

        @Override // android.view.animation.Animation
        public boolean getTransformation(long j2, Transformation transformation, float f2) {
            this.r = true;
            if (this.p) {
                return !this.q;
            }
            if (!super.getTransformation(j2, transformation, f2)) {
                this.p = true;
                b.g.l.p.a(this.n, this);
            }
            return true;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.p || !this.r) {
                this.n.endViewTransition(this.o);
                this.q = true;
            } else {
                this.r = false;
                this.n.post(this);
            }
        }
    }

    private static final class i {

        /* renamed from: a, reason: collision with root package name */
        final i.a f560a;

        /* renamed from: b, reason: collision with root package name */
        final boolean f561b;
    }

    /* renamed from: androidx.fragment.app.j$j, reason: collision with other inner class name */
    static class C0022j {

        /* renamed from: a, reason: collision with root package name */
        public static final int[] f562a = {R.attr.name, R.attr.id, R.attr.tag};
    }

    interface k {
        boolean a(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2);
    }

    private class l implements k {

        /* renamed from: a, reason: collision with root package name */
        final String f563a;

        /* renamed from: b, reason: collision with root package name */
        final int f564b;

        /* renamed from: c, reason: collision with root package name */
        final int f565c;

        l(String str, int i2, int i3) {
            this.f563a = str;
            this.f564b = i2;
            this.f565c = i3;
        }

        @Override // androidx.fragment.app.j.k
        public boolean a(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2) {
            Fragment fragment = j.this.G;
            if (fragment == null || this.f564b >= 0 || this.f563a != null || !fragment.m().h()) {
                return j.this.V0(arrayList, arrayList2, this.f563a, this.f564b, this.f565c);
            }
            return false;
        }
    }

    static class m implements Fragment.e {

        /* renamed from: a, reason: collision with root package name */
        final boolean f567a;

        /* renamed from: b, reason: collision with root package name */
        final androidx.fragment.app.a f568b;

        /* renamed from: c, reason: collision with root package name */
        private int f569c;

        m(androidx.fragment.app.a aVar, boolean z) {
            this.f567a = z;
            this.f568b = aVar;
        }

        @Override // androidx.fragment.app.Fragment.e
        public void a() {
            int i2 = this.f569c - 1;
            this.f569c = i2;
            if (i2 != 0) {
                return;
            }
            this.f568b.r.h1();
        }

        @Override // androidx.fragment.app.Fragment.e
        public void b() {
            this.f569c++;
        }

        public void c() {
            androidx.fragment.app.a aVar = this.f568b;
            aVar.r.v(aVar, this.f567a, false, false);
        }

        public void d() {
            boolean z = this.f569c > 0;
            j jVar = this.f568b.r;
            int size = jVar.s.size();
            for (int i2 = 0; i2 < size; i2++) {
                Fragment fragment = jVar.s.get(i2);
                fragment.h1(null);
                if (z && fragment.N()) {
                    fragment.k1();
                }
            }
            androidx.fragment.app.a aVar = this.f568b;
            aVar.r.v(aVar, this.f567a, !z, true);
        }

        public boolean e() {
            return this.f569c == 0;
        }
    }

    j() {
    }

    private boolean E0(Fragment fragment) {
        return (fragment.P && fragment.Q) || fragment.G.s();
    }

    static g K0(float f2, float f3) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(f2, f3);
        alphaAnimation.setInterpolator(W);
        alphaAnimation.setDuration(220L);
        return new g(alphaAnimation);
    }

    static g M0(float f2, float f3, float f4, float f5) {
        AnimationSet animationSet = new AnimationSet(false);
        ScaleAnimation scaleAnimation = new ScaleAnimation(f2, f3, f2, f3, 1, 0.5f, 1, 0.5f);
        scaleAnimation.setInterpolator(V);
        scaleAnimation.setDuration(220L);
        animationSet.addAnimation(scaleAnimation);
        AlphaAnimation alphaAnimation = new AlphaAnimation(f4, f5);
        alphaAnimation.setInterpolator(W);
        alphaAnimation.setDuration(220L);
        animationSet.addAnimation(alphaAnimation);
        return new g(animationSet);
    }

    private void N0(b.e.b<Fragment> bVar) {
        int size = bVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            Fragment l2 = bVar.l(i2);
            if (!l2.x) {
                View Y0 = l2.Y0();
                l2.a0 = Y0.getAlpha();
                Y0.setAlpha(0.0f);
            }
        }
    }

    private boolean U0(String str, int i2, int i3) {
        l0();
        j0(true);
        Fragment fragment = this.G;
        if (fragment != null && i2 < 0 && str == null && fragment.m().h()) {
            return true;
        }
        boolean V0 = V0(this.M, this.N, str, i2, i3);
        if (V0) {
            this.q = true;
            try {
                Z0(this.M, this.N);
            } finally {
                u();
            }
        }
        p1();
        g0();
        r();
        return V0;
    }

    private int W0(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3, b.e.b<Fragment> bVar) {
        int i4 = i3;
        for (int i5 = i3 - 1; i5 >= i2; i5--) {
            androidx.fragment.app.a aVar = arrayList.get(i5);
            boolean booleanValue = arrayList2.get(i5).booleanValue();
            if (aVar.s() && !aVar.q(arrayList, i5 + 1, i3)) {
                if (this.R == null) {
                    this.R = new ArrayList<>();
                }
                m mVar = new m(aVar, booleanValue);
                this.R.add(mVar);
                aVar.u(mVar);
                if (booleanValue) {
                    aVar.l();
                } else {
                    aVar.m(false);
                }
                i4--;
                if (i5 != i4) {
                    arrayList.remove(i5);
                    arrayList.add(i4, aVar);
                }
                j(bVar);
            }
        }
        return i4;
    }

    private void X(Fragment fragment) {
        if (fragment == null || this.t.get(fragment.r) != fragment) {
            return;
        }
        fragment.Q0();
    }

    private void Z0(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2) {
        if (arrayList == null || arrayList.isEmpty()) {
            return;
        }
        if (arrayList2 == null || arrayList.size() != arrayList2.size()) {
            throw new IllegalStateException("Internal error with the back stack records");
        }
        o0(arrayList, arrayList2);
        int size = arrayList.size();
        int i2 = 0;
        int i3 = 0;
        while (i2 < size) {
            if (!arrayList.get(i2).p) {
                if (i3 != i2) {
                    n0(arrayList, arrayList2, i3, i2);
                }
                i3 = i2 + 1;
                if (arrayList2.get(i2).booleanValue()) {
                    while (i3 < size && arrayList2.get(i3).booleanValue() && !arrayList.get(i3).p) {
                        i3++;
                    }
                }
                n0(arrayList, arrayList2, i2, i3);
                i2 = i3 - 1;
            }
            i2++;
        }
        if (i3 != size) {
            n0(arrayList, arrayList2, i3, size);
        }
    }

    public static int d1(int i2) {
        if (i2 == 4097) {
            return 8194;
        }
        if (i2 != 4099) {
            return i2 != 8194 ? 0 : 4097;
        }
        return 4099;
    }

    private void e0(int i2) {
        try {
            this.q = true;
            P0(i2, false);
            this.q = false;
            l0();
        } catch (Throwable th) {
            this.q = false;
            throw th;
        }
    }

    private void h0() {
        for (Fragment fragment : this.t.values()) {
            if (fragment != null) {
                if (fragment.k() != null) {
                    int F = fragment.F();
                    View k2 = fragment.k();
                    Animation animation = k2.getAnimation();
                    if (animation != null) {
                        animation.cancel();
                        k2.clearAnimation();
                    }
                    fragment.b1(null);
                    R0(fragment, F, 0, 0, false);
                } else if (fragment.l() != null) {
                    fragment.l().end();
                }
            }
        }
    }

    private void j(b.e.b<Fragment> bVar) {
        int i2 = this.C;
        if (i2 < 1) {
            return;
        }
        int min = Math.min(i2, 3);
        int size = this.s.size();
        for (int i3 = 0; i3 < size; i3++) {
            Fragment fragment = this.s.get(i3);
            if (fragment.n < min) {
                R0(fragment, min, fragment.v(), fragment.w(), false);
                if (fragment.T != null && !fragment.L && fragment.Y) {
                    bVar.add(fragment);
                }
            }
        }
    }

    private void j0(boolean z) {
        if (this.q) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        }
        if (this.D == null) {
            throw new IllegalStateException("Fragment host has been destroyed");
        }
        if (Looper.myLooper() != this.D.f().getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
        if (!z) {
            t();
        }
        if (this.M == null) {
            this.M = new ArrayList<>();
            this.N = new ArrayList<>();
        }
        this.q = true;
        try {
            o0(null, null);
        } finally {
            this.q = false;
        }
    }

    private static void m0(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        while (i2 < i3) {
            androidx.fragment.app.a aVar = arrayList.get(i2);
            if (arrayList2.get(i2).booleanValue()) {
                aVar.h(-1);
                aVar.m(i2 == i3 + (-1));
            } else {
                aVar.h(1);
                aVar.l();
            }
            i2++;
        }
    }

    private void n0(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        int i4;
        int i5;
        int i6 = i2;
        boolean z = arrayList.get(i6).p;
        ArrayList<Fragment> arrayList3 = this.O;
        if (arrayList3 == null) {
            this.O = new ArrayList<>();
        } else {
            arrayList3.clear();
        }
        this.O.addAll(this.s);
        Fragment z0 = z0();
        boolean z2 = false;
        for (int i7 = i6; i7 < i3; i7++) {
            androidx.fragment.app.a aVar = arrayList.get(i7);
            z0 = !arrayList2.get(i7).booleanValue() ? aVar.n(this.O, z0) : aVar.v(this.O, z0);
            z2 = z2 || aVar.f584h;
        }
        this.O.clear();
        if (!z) {
            o.C(this, arrayList, arrayList2, i2, i3, false);
        }
        m0(arrayList, arrayList2, i2, i3);
        if (z) {
            b.e.b<Fragment> bVar = new b.e.b<>();
            j(bVar);
            int W0 = W0(arrayList, arrayList2, i2, i3, bVar);
            N0(bVar);
            i4 = W0;
        } else {
            i4 = i3;
        }
        if (i4 != i6 && z) {
            o.C(this, arrayList, arrayList2, i2, i4, true);
            P0(this.C, true);
        }
        while (i6 < i3) {
            androidx.fragment.app.a aVar2 = arrayList.get(i6);
            if (arrayList2.get(i6).booleanValue() && (i5 = aVar2.t) >= 0) {
                t0(i5);
                aVar2.t = -1;
            }
            aVar2.t();
            i6++;
        }
        if (z2) {
            b1();
        }
    }

    private void n1(RuntimeException runtimeException) {
        Log.e("FragmentManager", runtimeException.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter printWriter = new PrintWriter(new b.g.k.c("FragmentManager"));
        androidx.fragment.app.h hVar = this.D;
        try {
            if (hVar != null) {
                hVar.h("  ", null, printWriter, new String[0]);
            } else {
                b("  ", null, printWriter, new String[0]);
            }
            throw runtimeException;
        } catch (Exception e2) {
            Log.e("FragmentManager", "Failed dumping state", e2);
            throw runtimeException;
        }
    }

    private void o(Fragment fragment, g gVar, int i2) {
        View view = fragment.T;
        ViewGroup viewGroup = fragment.S;
        viewGroup.startViewTransition(view);
        fragment.i1(i2);
        if (gVar.f558a != null) {
            h hVar = new h(gVar.f558a, viewGroup, view);
            fragment.b1(fragment.T);
            hVar.setAnimationListener(new c(viewGroup, fragment));
            fragment.T.startAnimation(hVar);
            return;
        }
        Animator animator = gVar.f559b;
        fragment.c1(animator);
        animator.addListener(new d(viewGroup, view, fragment));
        animator.setTarget(fragment.T);
        animator.start();
    }

    private void o0(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2) {
        int indexOf;
        int indexOf2;
        ArrayList<m> arrayList3 = this.R;
        int size = arrayList3 == null ? 0 : arrayList3.size();
        int i2 = 0;
        while (i2 < size) {
            m mVar = this.R.get(i2);
            if (arrayList == null || mVar.f567a || (indexOf2 = arrayList.indexOf(mVar.f568b)) == -1 || !arrayList2.get(indexOf2).booleanValue()) {
                if (mVar.e() || (arrayList != null && mVar.f568b.q(arrayList, 0, arrayList.size()))) {
                    this.R.remove(i2);
                    i2--;
                    size--;
                    if (arrayList == null || mVar.f567a || (indexOf = arrayList.indexOf(mVar.f568b)) == -1 || !arrayList2.get(indexOf).booleanValue()) {
                        mVar.d();
                    }
                }
                i2++;
            } else {
                this.R.remove(i2);
                i2--;
                size--;
            }
            mVar.c();
            i2++;
        }
    }

    public static int o1(int i2, boolean z) {
        if (i2 == 4097) {
            return z ? 1 : 2;
        }
        if (i2 == 4099) {
            return z ? 5 : 6;
        }
        if (i2 != 8194) {
            return -1;
        }
        return z ? 3 : 4;
    }

    private void p1() {
        ArrayList<k> arrayList = this.p;
        if (arrayList == null || arrayList.isEmpty()) {
            this.x.f(v0() > 0 && F0(this.F));
        } else {
            this.x.f(true);
        }
    }

    private void r() {
        this.t.values().removeAll(Collections.singleton(null));
    }

    private Fragment r0(Fragment fragment) {
        ViewGroup viewGroup = fragment.S;
        View view = fragment.T;
        if (viewGroup != null && view != null) {
            for (int indexOf = this.s.indexOf(fragment) - 1; indexOf >= 0; indexOf--) {
                Fragment fragment2 = this.s.get(indexOf);
                if (fragment2.S == viewGroup && fragment2.T != null) {
                    return fragment2;
                }
            }
        }
        return null;
    }

    private void s0() {
        if (this.R != null) {
            while (!this.R.isEmpty()) {
                this.R.remove(0).d();
            }
        }
    }

    private void t() {
        if (H0()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
    }

    private void u() {
        this.q = false;
        this.N.clear();
        this.M.clear();
    }

    private boolean u0(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2) {
        synchronized (this) {
            ArrayList<k> arrayList3 = this.p;
            if (arrayList3 != null && arrayList3.size() != 0) {
                int size = this.p.size();
                boolean z = false;
                for (int i2 = 0; i2 < size; i2++) {
                    z |= this.p.get(i2).a(arrayList, arrayList2);
                }
                this.p.clear();
                this.D.f().removeCallbacks(this.T);
                return z;
            }
            return false;
        }
    }

    public boolean A(MenuItem menuItem) {
        if (this.C < 1) {
            return false;
        }
        for (int i2 = 0; i2 < this.s.size(); i2++) {
            Fragment fragment = this.s.get(i2);
            if (fragment != null && fragment.B0(menuItem)) {
                return true;
            }
        }
        return false;
    }

    androidx.lifecycle.r A0(Fragment fragment) {
        return this.S.i(fragment);
    }

    public void B() {
        this.I = false;
        this.J = false;
        e0(1);
    }

    void B0() {
        l0();
        if (this.x.c()) {
            h();
        } else {
            this.w.c();
        }
    }

    public boolean C(Menu menu, MenuInflater menuInflater) {
        if (this.C < 1) {
            return false;
        }
        ArrayList<Fragment> arrayList = null;
        boolean z = false;
        for (int i2 = 0; i2 < this.s.size(); i2++) {
            Fragment fragment = this.s.get(i2);
            if (fragment != null && fragment.D0(menu, menuInflater)) {
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                }
                arrayList.add(fragment);
                z = true;
            }
        }
        if (this.v != null) {
            for (int i3 = 0; i3 < this.v.size(); i3++) {
                Fragment fragment2 = this.v.get(i3);
                if (arrayList == null || !arrayList.contains(fragment2)) {
                    fragment2.d0();
                }
            }
        }
        this.v = arrayList;
        return z;
    }

    public void C0(Fragment fragment) {
        if (U) {
            Log.v("FragmentManager", "hide: " + fragment);
        }
        if (fragment.L) {
            return;
        }
        fragment.L = true;
        fragment.Z = true ^ fragment.Z;
    }

    public void D() {
        this.K = true;
        l0();
        e0(0);
        this.D = null;
        this.E = null;
        this.F = null;
        if (this.w != null) {
            this.x.d();
            this.w = null;
        }
    }

    public boolean D0() {
        return this.K;
    }

    public void E() {
        e0(1);
    }

    public void F() {
        for (int i2 = 0; i2 < this.s.size(); i2++) {
            Fragment fragment = this.s.get(i2);
            if (fragment != null) {
                fragment.J0();
            }
        }
    }

    boolean F0(Fragment fragment) {
        if (fragment == null) {
            return true;
        }
        j jVar = fragment.E;
        return fragment == jVar.z0() && F0(jVar.F);
    }

    public void G(boolean z) {
        int size = this.s.size();
        while (true) {
            size--;
            if (size < 0) {
                return;
            }
            Fragment fragment = this.s.get(size);
            if (fragment != null) {
                fragment.K0(z);
            }
        }
    }

    boolean G0(int i2) {
        return this.C >= i2;
    }

    void H(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).H(fragment, bundle, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.a(this, fragment, bundle);
            }
        }
    }

    public boolean H0() {
        return this.I || this.J;
    }

    void I(Fragment fragment, Context context, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).I(fragment, context, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.b(this, fragment, context);
            }
        }
    }

    g I0(Fragment fragment, int i2, boolean z, int i3) {
        int o1;
        int v = fragment.v();
        boolean z2 = false;
        fragment.f1(0);
        ViewGroup viewGroup = fragment.S;
        if (viewGroup != null && viewGroup.getLayoutTransition() != null) {
            return null;
        }
        Animation Y = fragment.Y(i2, z, v);
        if (Y != null) {
            return new g(Y);
        }
        Animator Z = fragment.Z(i2, z, v);
        if (Z != null) {
            return new g(Z);
        }
        if (v != 0) {
            boolean equals = "anim".equals(this.D.e().getResources().getResourceTypeName(v));
            if (equals) {
                try {
                    Animation loadAnimation = AnimationUtils.loadAnimation(this.D.e(), v);
                    if (loadAnimation != null) {
                        return new g(loadAnimation);
                    }
                    z2 = true;
                } catch (Resources.NotFoundException e2) {
                    throw e2;
                } catch (RuntimeException unused) {
                }
            }
            if (!z2) {
                try {
                    Animator loadAnimator = AnimatorInflater.loadAnimator(this.D.e(), v);
                    if (loadAnimator != null) {
                        return new g(loadAnimator);
                    }
                } catch (RuntimeException e3) {
                    if (equals) {
                        throw e3;
                    }
                    Animation loadAnimation2 = AnimationUtils.loadAnimation(this.D.e(), v);
                    if (loadAnimation2 != null) {
                        return new g(loadAnimation2);
                    }
                }
            }
        }
        if (i2 == 0 || (o1 = o1(i2, z)) < 0) {
            return null;
        }
        switch (o1) {
            case 1:
                return M0(1.125f, 1.0f, 0.0f, 1.0f);
            case 2:
                return M0(1.0f, 0.975f, 1.0f, 0.0f);
            case 3:
                return M0(0.975f, 1.0f, 0.0f, 1.0f);
            case 4:
                return M0(1.0f, 1.075f, 1.0f, 0.0f);
            case 5:
                return K0(0.0f, 1.0f);
            case 6:
                return K0(1.0f, 0.0f);
            default:
                if (i3 == 0 && this.D.l()) {
                    this.D.k();
                }
                return null;
        }
    }

    void J(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).J(fragment, bundle, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.c(this, fragment, bundle);
            }
        }
    }

    void J0(Fragment fragment) {
        if (this.t.get(fragment.r) != null) {
            return;
        }
        this.t.put(fragment.r, fragment);
        if (fragment.O) {
            if (fragment.N) {
                m(fragment);
            } else {
                a1(fragment);
            }
            fragment.O = false;
        }
        if (U) {
            Log.v("FragmentManager", "Added fragment to active set " + fragment);
        }
    }

    void K(Fragment fragment, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).K(fragment, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.d(this, fragment);
            }
        }
    }

    void L(Fragment fragment, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).L(fragment, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.e(this, fragment);
            }
        }
    }

    void L0(Fragment fragment) {
        if (this.t.get(fragment.r) == null) {
            return;
        }
        if (U) {
            Log.v("FragmentManager", "Removed fragment from active set " + fragment);
        }
        for (Fragment fragment2 : this.t.values()) {
            if (fragment2 != null && fragment.r.equals(fragment2.u)) {
                fragment2.t = fragment;
                fragment2.u = null;
            }
        }
        this.t.put(fragment.r, null);
        a1(fragment);
        String str = fragment.u;
        if (str != null) {
            fragment.t = this.t.get(str);
        }
        fragment.J();
    }

    void M(Fragment fragment, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).M(fragment, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.f(this, fragment);
            }
        }
    }

    void N(Fragment fragment, Context context, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).N(fragment, context, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.g(this, fragment, context);
            }
        }
    }

    void O(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).O(fragment, bundle, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.h(this, fragment, bundle);
            }
        }
    }

    void O0(Fragment fragment) {
        if (fragment == null) {
            return;
        }
        if (!this.t.containsKey(fragment.r)) {
            if (U) {
                Log.v("FragmentManager", "Ignoring moving " + fragment + " to state " + this.C + "since it is not added to " + this);
                return;
            }
            return;
        }
        int i2 = this.C;
        if (fragment.y) {
            i2 = fragment.M() ? Math.min(i2, 1) : Math.min(i2, 0);
        }
        R0(fragment, i2, fragment.w(), fragment.x(), false);
        if (fragment.T != null) {
            Fragment r0 = r0(fragment);
            if (r0 != null) {
                View view = r0.T;
                ViewGroup viewGroup = fragment.S;
                int indexOfChild = viewGroup.indexOfChild(view);
                int indexOfChild2 = viewGroup.indexOfChild(fragment.T);
                if (indexOfChild2 < indexOfChild) {
                    viewGroup.removeViewAt(indexOfChild2);
                    viewGroup.addView(fragment.T, indexOfChild);
                }
            }
            if (fragment.Y && fragment.S != null) {
                float f2 = fragment.a0;
                if (f2 > 0.0f) {
                    fragment.T.setAlpha(f2);
                }
                fragment.a0 = 0.0f;
                fragment.Y = false;
                g I0 = I0(fragment, fragment.w(), true, fragment.x());
                if (I0 != null) {
                    Animation animation = I0.f558a;
                    if (animation != null) {
                        fragment.T.startAnimation(animation);
                    } else {
                        I0.f559b.setTarget(fragment.T);
                        I0.f559b.start();
                    }
                }
            }
        }
        if (fragment.Z) {
            w(fragment);
        }
    }

    void P(Fragment fragment, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).P(fragment, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.i(this, fragment);
            }
        }
    }

    void P0(int i2, boolean z) {
        androidx.fragment.app.h hVar;
        if (this.D == null && i2 != 0) {
            throw new IllegalStateException("No activity");
        }
        if (z || i2 != this.C) {
            this.C = i2;
            int size = this.s.size();
            for (int i3 = 0; i3 < size; i3++) {
                O0(this.s.get(i3));
            }
            for (Fragment fragment : this.t.values()) {
                if (fragment != null && (fragment.y || fragment.M)) {
                    if (!fragment.Y) {
                        O0(fragment);
                    }
                }
            }
            m1();
            if (this.H && (hVar = this.D) != null && this.C == 4) {
                hVar.o();
                this.H = false;
            }
        }
    }

    void Q(Fragment fragment, Bundle bundle, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).Q(fragment, bundle, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.j(this, fragment, bundle);
            }
        }
    }

    void Q0(Fragment fragment) {
        R0(fragment, this.C, 0, 0, false);
    }

    void R(Fragment fragment, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).R(fragment, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.k(this, fragment);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:40:0x0084, code lost:
    
        if (r0 != 3) goto L268;
     */
    /* JADX WARN: Removed duplicated region for block: B:43:0x02ff  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x04d9  */
    /* JADX WARN: Removed duplicated region for block: B:52:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x02dd  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    void R0(androidx.fragment.app.Fragment r19, int r20, int r21, int r22, boolean r23) {
        /*
            Method dump skipped, instructions count: 1282
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.j.R0(androidx.fragment.app.Fragment, int, int, int, boolean):void");
    }

    void S(Fragment fragment, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).S(fragment, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.l(this, fragment);
            }
        }
    }

    public void S0() {
        this.I = false;
        this.J = false;
        int size = this.s.size();
        for (int i2 = 0; i2 < size; i2++) {
            Fragment fragment = this.s.get(i2);
            if (fragment != null) {
                fragment.Q();
            }
        }
    }

    void T(Fragment fragment, View view, Bundle bundle, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).T(fragment, view, bundle, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.m(this, fragment, view, bundle);
            }
        }
    }

    public void T0(Fragment fragment) {
        if (fragment.V) {
            if (this.q) {
                this.L = true;
            } else {
                fragment.V = false;
                R0(fragment, this.C, 0, 0, false);
            }
        }
    }

    void U(Fragment fragment, boolean z) {
        Fragment fragment2 = this.F;
        if (fragment2 != null) {
            androidx.fragment.app.i s = fragment2.s();
            if (s instanceof j) {
                ((j) s).U(fragment, true);
            }
        }
        Iterator<i> it = this.B.iterator();
        while (it.hasNext()) {
            i next = it.next();
            if (!z || next.f561b) {
                next.f560a.n(this, fragment);
            }
        }
    }

    public boolean V(MenuItem menuItem) {
        if (this.C < 1) {
            return false;
        }
        for (int i2 = 0; i2 < this.s.size(); i2++) {
            Fragment fragment = this.s.get(i2);
            if (fragment != null && fragment.L0(menuItem)) {
                return true;
            }
        }
        return false;
    }

    boolean V0(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, String str, int i2, int i3) {
        int i4;
        ArrayList<androidx.fragment.app.a> arrayList3 = this.u;
        if (arrayList3 == null) {
            return false;
        }
        if (str == null && i2 < 0 && (i3 & 1) == 0) {
            int size = arrayList3.size() - 1;
            if (size < 0) {
                return false;
            }
            arrayList.add(this.u.remove(size));
            arrayList2.add(Boolean.TRUE);
        } else {
            if (str != null || i2 >= 0) {
                int size2 = arrayList3.size() - 1;
                while (size2 >= 0) {
                    androidx.fragment.app.a aVar = this.u.get(size2);
                    if ((str != null && str.equals(aVar.o())) || (i2 >= 0 && i2 == aVar.t)) {
                        break;
                    }
                    size2--;
                }
                if (size2 < 0) {
                    return false;
                }
                if ((i3 & 1) != 0) {
                    while (true) {
                        size2--;
                        if (size2 < 0) {
                            break;
                        }
                        androidx.fragment.app.a aVar2 = this.u.get(size2);
                        if (str == null || !str.equals(aVar2.o())) {
                            if (i2 < 0 || i2 != aVar2.t) {
                                break;
                            }
                        }
                    }
                }
                i4 = size2;
            } else {
                i4 = -1;
            }
            if (i4 == this.u.size() - 1) {
                return false;
            }
            for (int size3 = this.u.size() - 1; size3 > i4; size3--) {
                arrayList.add(this.u.remove(size3));
                arrayList2.add(Boolean.TRUE);
            }
        }
        return true;
    }

    public void W(Menu menu) {
        if (this.C < 1) {
            return;
        }
        for (int i2 = 0; i2 < this.s.size(); i2++) {
            Fragment fragment = this.s.get(i2);
            if (fragment != null) {
                fragment.M0(menu);
            }
        }
    }

    public void X0(Bundle bundle, String str, Fragment fragment) {
        if (fragment.E == this) {
            bundle.putString(str, fragment.r);
            return;
        }
        n1(new IllegalStateException("Fragment " + fragment + " is not currently in the FragmentManager"));
        throw null;
    }

    public void Y() {
        e0(3);
    }

    public void Y0(Fragment fragment) {
        if (U) {
            Log.v("FragmentManager", "remove: " + fragment + " nesting=" + fragment.D);
        }
        boolean z = !fragment.M();
        if (!fragment.M || z) {
            synchronized (this.s) {
                this.s.remove(fragment);
            }
            if (E0(fragment)) {
                this.H = true;
            }
            fragment.x = false;
            fragment.y = true;
        }
    }

    public void Z(boolean z) {
        int size = this.s.size();
        while (true) {
            size--;
            if (size < 0) {
                return;
            }
            Fragment fragment = this.s.get(size);
            if (fragment != null) {
                fragment.O0(z);
            }
        }
    }

    @Override // androidx.fragment.app.i
    public n a() {
        return new androidx.fragment.app.a(this);
    }

    public boolean a0(Menu menu) {
        if (this.C < 1) {
            return false;
        }
        boolean z = false;
        for (int i2 = 0; i2 < this.s.size(); i2++) {
            Fragment fragment = this.s.get(i2);
            if (fragment != null && fragment.P0(menu)) {
                z = true;
            }
        }
        return z;
    }

    void a1(Fragment fragment) {
        if (H0()) {
            if (U) {
                Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
            }
        } else if (this.S.k(fragment) && U) {
            Log.v("FragmentManager", "Updating retained Fragments: Removed " + fragment);
        }
    }

    @Override // androidx.fragment.app.i
    public void b(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        int size3;
        int size4;
        String str2 = str + "    ";
        if (!this.t.isEmpty()) {
            printWriter.print(str);
            printWriter.print("Active Fragments in ");
            printWriter.print(Integer.toHexString(System.identityHashCode(this)));
            printWriter.println(":");
            for (Fragment fragment : this.t.values()) {
                printWriter.print(str);
                printWriter.println(fragment);
                if (fragment != null) {
                    fragment.e(str2, fileDescriptor, printWriter, strArr);
                }
            }
        }
        int size5 = this.s.size();
        if (size5 > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i2 = 0; i2 < size5; i2++) {
                Fragment fragment2 = this.s.get(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(fragment2.toString());
            }
        }
        ArrayList<Fragment> arrayList = this.v;
        if (arrayList != null && (size4 = arrayList.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i3 = 0; i3 < size4; i3++) {
                Fragment fragment3 = this.v.get(i3);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i3);
                printWriter.print(": ");
                printWriter.println(fragment3.toString());
            }
        }
        ArrayList<androidx.fragment.app.a> arrayList2 = this.u;
        if (arrayList2 != null && (size3 = arrayList2.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i4 = 0; i4 < size3; i4++) {
                androidx.fragment.app.a aVar = this.u.get(i4);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i4);
                printWriter.print(": ");
                printWriter.println(aVar.toString());
                aVar.j(str2, printWriter);
            }
        }
        synchronized (this) {
            ArrayList<androidx.fragment.app.a> arrayList3 = this.y;
            if (arrayList3 != null && (size2 = arrayList3.size()) > 0) {
                printWriter.print(str);
                printWriter.println("Back Stack Indices:");
                for (int i5 = 0; i5 < size2; i5++) {
                    Object obj = (androidx.fragment.app.a) this.y.get(i5);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i5);
                    printWriter.print(": ");
                    printWriter.println(obj);
                }
            }
            ArrayList<Integer> arrayList4 = this.z;
            if (arrayList4 != null && arrayList4.size() > 0) {
                printWriter.print(str);
                printWriter.print("mAvailBackStackIndices: ");
                printWriter.println(Arrays.toString(this.z.toArray()));
            }
        }
        ArrayList<k> arrayList5 = this.p;
        if (arrayList5 != null && (size = arrayList5.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Pending Actions:");
            for (int i6 = 0; i6 < size; i6++) {
                Object obj2 = (k) this.p.get(i6);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i6);
                printWriter.print(": ");
                printWriter.println(obj2);
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.D);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.E);
        if (this.F != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.F);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.C);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.I);
        printWriter.print(" mStopped=");
        printWriter.print(this.J);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.K);
        if (this.H) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.H);
        }
    }

    void b0() {
        p1();
        X(this.G);
    }

    void b1() {
        if (this.A != null) {
            for (int i2 = 0; i2 < this.A.size(); i2++) {
                this.A.get(i2).a();
            }
        }
    }

    @Override // androidx.fragment.app.i
    public boolean c() {
        boolean l0 = l0();
        s0();
        return l0;
    }

    public void c0() {
        this.I = false;
        this.J = false;
        e0(4);
    }

    void c1(Parcelable parcelable) {
        androidx.fragment.app.m mVar;
        if (parcelable == null) {
            return;
        }
        androidx.fragment.app.k kVar = (androidx.fragment.app.k) parcelable;
        if (kVar.n == null) {
            return;
        }
        for (Fragment fragment : this.S.h()) {
            if (U) {
                Log.v("FragmentManager", "restoreSaveState: re-attaching retained " + fragment);
            }
            Iterator<androidx.fragment.app.m> it = kVar.n.iterator();
            while (true) {
                if (it.hasNext()) {
                    mVar = it.next();
                    if (mVar.o.equals(fragment.r)) {
                        break;
                    }
                } else {
                    mVar = null;
                    break;
                }
            }
            if (mVar == null) {
                if (U) {
                    Log.v("FragmentManager", "Discarding retained Fragment " + fragment + " that was not found in the set of active Fragments " + kVar.n);
                }
                R0(fragment, 1, 0, 0, false);
                fragment.y = true;
                R0(fragment, 0, 0, 0, false);
            } else {
                mVar.A = fragment;
                fragment.p = null;
                fragment.D = 0;
                fragment.A = false;
                fragment.x = false;
                Fragment fragment2 = fragment.t;
                fragment.u = fragment2 != null ? fragment2.r : null;
                fragment.t = null;
                Bundle bundle = mVar.z;
                if (bundle != null) {
                    bundle.setClassLoader(this.D.e().getClassLoader());
                    fragment.p = mVar.z.getSparseParcelableArray("android:view_state");
                    fragment.o = mVar.z;
                }
            }
        }
        this.t.clear();
        Iterator<androidx.fragment.app.m> it2 = kVar.n.iterator();
        while (it2.hasNext()) {
            androidx.fragment.app.m next = it2.next();
            if (next != null) {
                Fragment a2 = next.a(this.D.e().getClassLoader(), e());
                a2.E = this;
                if (U) {
                    Log.v("FragmentManager", "restoreSaveState: active (" + a2.r + "): " + a2);
                }
                this.t.put(a2.r, a2);
                next.A = null;
            }
        }
        this.s.clear();
        ArrayList<String> arrayList = kVar.o;
        if (arrayList != null) {
            Iterator<String> it3 = arrayList.iterator();
            while (it3.hasNext()) {
                String next2 = it3.next();
                Fragment fragment3 = this.t.get(next2);
                if (fragment3 == null) {
                    n1(new IllegalStateException("No instantiated fragment for (" + next2 + ")"));
                    throw null;
                }
                fragment3.x = true;
                if (U) {
                    Log.v("FragmentManager", "restoreSaveState: added (" + next2 + "): " + fragment3);
                }
                if (this.s.contains(fragment3)) {
                    throw new IllegalStateException("Already added " + fragment3);
                }
                synchronized (this.s) {
                    this.s.add(fragment3);
                }
            }
        }
        if (kVar.p != null) {
            this.u = new ArrayList<>(kVar.p.length);
            int i2 = 0;
            while (true) {
                androidx.fragment.app.b[] bVarArr = kVar.p;
                if (i2 >= bVarArr.length) {
                    break;
                }
                androidx.fragment.app.a a3 = bVarArr[i2].a(this);
                if (U) {
                    Log.v("FragmentManager", "restoreAllState: back stack #" + i2 + " (index " + a3.t + "): " + a3);
                    PrintWriter printWriter = new PrintWriter(new b.g.k.c("FragmentManager"));
                    a3.k("  ", printWriter, false);
                    printWriter.close();
                }
                this.u.add(a3);
                int i3 = a3.t;
                if (i3 >= 0) {
                    i1(i3, a3);
                }
                i2++;
            }
        } else {
            this.u = null;
        }
        String str = kVar.q;
        if (str != null) {
            Fragment fragment4 = this.t.get(str);
            this.G = fragment4;
            X(fragment4);
        }
        this.r = kVar.r;
    }

    @Override // androidx.fragment.app.i
    public Fragment d(String str) {
        if (str != null) {
            for (int size = this.s.size() - 1; size >= 0; size--) {
                Fragment fragment = this.s.get(size);
                if (fragment != null && str.equals(fragment.K)) {
                    return fragment;
                }
            }
        }
        if (str == null) {
            return null;
        }
        for (Fragment fragment2 : this.t.values()) {
            if (fragment2 != null && str.equals(fragment2.K)) {
                return fragment2;
            }
        }
        return null;
    }

    public void d0() {
        this.I = false;
        this.J = false;
        e0(3);
    }

    @Override // androidx.fragment.app.i
    public androidx.fragment.app.g e() {
        if (super.e() == androidx.fragment.app.i.o) {
            Fragment fragment = this.F;
            if (fragment != null) {
                return fragment.E.e();
            }
            i(new f());
        }
        return super.e();
    }

    Parcelable e1() {
        ArrayList<String> arrayList;
        int size;
        s0();
        h0();
        l0();
        this.I = true;
        androidx.fragment.app.b[] bVarArr = null;
        if (this.t.isEmpty()) {
            return null;
        }
        ArrayList<androidx.fragment.app.m> arrayList2 = new ArrayList<>(this.t.size());
        boolean z = false;
        for (Fragment fragment : this.t.values()) {
            if (fragment != null) {
                if (fragment.E != this) {
                    n1(new IllegalStateException("Failure saving state: active " + fragment + " was removed from the FragmentManager"));
                    throw null;
                }
                androidx.fragment.app.m mVar = new androidx.fragment.app.m(fragment);
                arrayList2.add(mVar);
                if (fragment.n <= 0 || mVar.z != null) {
                    mVar.z = fragment.o;
                } else {
                    mVar.z = f1(fragment);
                    String str = fragment.u;
                    if (str != null) {
                        Fragment fragment2 = this.t.get(str);
                        if (fragment2 == null) {
                            n1(new IllegalStateException("Failure saving state: " + fragment + " has target not in fragment manager: " + fragment.u));
                            throw null;
                        }
                        if (mVar.z == null) {
                            mVar.z = new Bundle();
                        }
                        X0(mVar.z, "android:target_state", fragment2);
                        int i2 = fragment.v;
                        if (i2 != 0) {
                            mVar.z.putInt("android:target_req_state", i2);
                        }
                    }
                }
                if (U) {
                    Log.v("FragmentManager", "Saved state of " + fragment + ": " + mVar.z);
                }
                z = true;
            }
        }
        if (!z) {
            if (U) {
                Log.v("FragmentManager", "saveAllState: no fragments!");
            }
            return null;
        }
        int size2 = this.s.size();
        if (size2 > 0) {
            arrayList = new ArrayList<>(size2);
            Iterator<Fragment> it = this.s.iterator();
            while (it.hasNext()) {
                Fragment next = it.next();
                arrayList.add(next.r);
                if (next.E != this) {
                    n1(new IllegalStateException("Failure saving state: active " + next + " was removed from the FragmentManager"));
                    throw null;
                }
                if (U) {
                    Log.v("FragmentManager", "saveAllState: adding fragment (" + next.r + "): " + next);
                }
            }
        } else {
            arrayList = null;
        }
        ArrayList<androidx.fragment.app.a> arrayList3 = this.u;
        if (arrayList3 != null && (size = arrayList3.size()) > 0) {
            bVarArr = new androidx.fragment.app.b[size];
            for (int i3 = 0; i3 < size; i3++) {
                bVarArr[i3] = new androidx.fragment.app.b(this.u.get(i3));
                if (U) {
                    Log.v("FragmentManager", "saveAllState: adding back stack #" + i3 + ": " + this.u.get(i3));
                }
            }
        }
        androidx.fragment.app.k kVar = new androidx.fragment.app.k();
        kVar.n = arrayList2;
        kVar.o = arrayList;
        kVar.p = bVarArr;
        Fragment fragment3 = this.G;
        if (fragment3 != null) {
            kVar.q = fragment3.r;
        }
        kVar.r = this.r;
        return kVar;
    }

    @Override // androidx.fragment.app.i
    public List<Fragment> f() {
        List<Fragment> list;
        if (this.s.isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (this.s) {
            list = (List) this.s.clone();
        }
        return list;
    }

    public void f0() {
        this.J = true;
        e0(2);
    }

    Bundle f1(Fragment fragment) {
        if (this.P == null) {
            this.P = new Bundle();
        }
        fragment.S0(this.P);
        Q(fragment, this.P, false);
        Bundle bundle = null;
        if (!this.P.isEmpty()) {
            Bundle bundle2 = this.P;
            this.P = null;
            bundle = bundle2;
        }
        if (fragment.T != null) {
            g1(fragment);
        }
        if (fragment.p != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray("android:view_state", fragment.p);
        }
        if (!fragment.W) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", fragment.W);
        }
        return bundle;
    }

    @Override // androidx.fragment.app.i
    public void g(int i2, int i3) {
        if (i2 >= 0) {
            i0(new l(null, i2, i3), false);
            return;
        }
        throw new IllegalArgumentException("Bad id: " + i2);
    }

    void g0() {
        if (this.L) {
            this.L = false;
            m1();
        }
    }

    void g1(Fragment fragment) {
        if (fragment.U == null) {
            return;
        }
        SparseArray<Parcelable> sparseArray = this.Q;
        if (sparseArray == null) {
            this.Q = new SparseArray<>();
        } else {
            sparseArray.clear();
        }
        fragment.U.saveHierarchyState(this.Q);
        if (this.Q.size() > 0) {
            fragment.p = this.Q;
            this.Q = null;
        }
    }

    @Override // androidx.fragment.app.i
    public boolean h() {
        t();
        return U0(null, -1, 0);
    }

    void h1() {
        synchronized (this) {
            ArrayList<m> arrayList = this.R;
            boolean z = false;
            boolean z2 = (arrayList == null || arrayList.isEmpty()) ? false : true;
            ArrayList<k> arrayList2 = this.p;
            if (arrayList2 != null && arrayList2.size() == 1) {
                z = true;
            }
            if (z2 || z) {
                this.D.f().removeCallbacks(this.T);
                this.D.f().post(this.T);
                p1();
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x0027, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void i0(androidx.fragment.app.j.k r2, boolean r3) {
        /*
            r1 = this;
            if (r3 != 0) goto L5
            r1.t()
        L5:
            monitor-enter(r1)
            boolean r0 = r1.K     // Catch: java.lang.Throwable -> L30
            if (r0 != 0) goto L24
            androidx.fragment.app.h r0 = r1.D     // Catch: java.lang.Throwable -> L30
            if (r0 != 0) goto Lf
            goto L24
        Lf:
            java.util.ArrayList<androidx.fragment.app.j$k> r3 = r1.p     // Catch: java.lang.Throwable -> L30
            if (r3 != 0) goto L1a
            java.util.ArrayList r3 = new java.util.ArrayList     // Catch: java.lang.Throwable -> L30
            r3.<init>()     // Catch: java.lang.Throwable -> L30
            r1.p = r3     // Catch: java.lang.Throwable -> L30
        L1a:
            java.util.ArrayList<androidx.fragment.app.j$k> r3 = r1.p     // Catch: java.lang.Throwable -> L30
            r3.add(r2)     // Catch: java.lang.Throwable -> L30
            r1.h1()     // Catch: java.lang.Throwable -> L30
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L30
            return
        L24:
            if (r3 == 0) goto L28
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L30
            return
        L28:
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException     // Catch: java.lang.Throwable -> L30
            java.lang.String r3 = "Activity has been destroyed"
            r2.<init>(r3)     // Catch: java.lang.Throwable -> L30
            throw r2     // Catch: java.lang.Throwable -> L30
        L30:
            r2 = move-exception
            monitor-exit(r1)     // Catch: java.lang.Throwable -> L30
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.j.i0(androidx.fragment.app.j$k, boolean):void");
    }

    public void i1(int i2, androidx.fragment.app.a aVar) {
        synchronized (this) {
            if (this.y == null) {
                this.y = new ArrayList<>();
            }
            int size = this.y.size();
            if (i2 < size) {
                if (U) {
                    Log.v("FragmentManager", "Setting back stack index " + i2 + " to " + aVar);
                }
                this.y.set(i2, aVar);
            } else {
                while (size < i2) {
                    this.y.add(null);
                    if (this.z == null) {
                        this.z = new ArrayList<>();
                    }
                    if (U) {
                        Log.v("FragmentManager", "Adding available back stack index " + size);
                    }
                    this.z.add(Integer.valueOf(size));
                    size++;
                }
                if (U) {
                    Log.v("FragmentManager", "Adding back stack index " + i2 + " with " + aVar);
                }
                this.y.add(aVar);
            }
        }
    }

    public void j1(Fragment fragment, d.b bVar) {
        if (this.t.get(fragment.r) == fragment && (fragment.F == null || fragment.s() == this)) {
            fragment.d0 = bVar;
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    void k(androidx.fragment.app.a aVar) {
        if (this.u == null) {
            this.u = new ArrayList<>();
        }
        this.u.add(aVar);
    }

    void k0(Fragment fragment) {
        if (!fragment.z || fragment.C) {
            return;
        }
        fragment.E0(fragment.I0(fragment.o), null, fragment.o);
        View view = fragment.T;
        if (view == null) {
            fragment.U = null;
            return;
        }
        fragment.U = view;
        view.setSaveFromParentEnabled(false);
        if (fragment.L) {
            fragment.T.setVisibility(8);
        }
        fragment.w0(fragment.T, fragment.o);
        T(fragment, fragment.T, fragment.o, false);
    }

    public void k1(Fragment fragment) {
        if (fragment == null || (this.t.get(fragment.r) == fragment && (fragment.F == null || fragment.s() == this))) {
            Fragment fragment2 = this.G;
            this.G = fragment;
            X(fragment2);
            X(this.G);
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    public void l(Fragment fragment, boolean z) {
        if (U) {
            Log.v("FragmentManager", "add: " + fragment);
        }
        J0(fragment);
        if (fragment.M) {
            return;
        }
        if (this.s.contains(fragment)) {
            throw new IllegalStateException("Fragment already added: " + fragment);
        }
        synchronized (this.s) {
            this.s.add(fragment);
        }
        fragment.x = true;
        fragment.y = false;
        if (fragment.T == null) {
            fragment.Z = false;
        }
        if (E0(fragment)) {
            this.H = true;
        }
        if (z) {
            Q0(fragment);
        }
    }

    public boolean l0() {
        j0(true);
        boolean z = false;
        while (u0(this.M, this.N)) {
            this.q = true;
            try {
                Z0(this.M, this.N);
                u();
                z = true;
            } catch (Throwable th) {
                u();
                throw th;
            }
        }
        p1();
        g0();
        r();
        return z;
    }

    public void l1(Fragment fragment) {
        if (U) {
            Log.v("FragmentManager", "show: " + fragment);
        }
        if (fragment.L) {
            fragment.L = false;
            fragment.Z = !fragment.Z;
        }
    }

    void m(Fragment fragment) {
        if (H0()) {
            if (U) {
                Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved");
            }
        } else if (this.S.d(fragment) && U) {
            Log.v("FragmentManager", "Updating retained Fragments: Added " + fragment);
        }
    }

    void m1() {
        for (Fragment fragment : this.t.values()) {
            if (fragment != null) {
                T0(fragment);
            }
        }
    }

    public int n(androidx.fragment.app.a aVar) {
        synchronized (this) {
            ArrayList<Integer> arrayList = this.z;
            if (arrayList != null && arrayList.size() > 0) {
                int intValue = this.z.remove(r0.size() - 1).intValue();
                if (U) {
                    Log.v("FragmentManager", "Adding back stack index " + intValue + " with " + aVar);
                }
                this.y.set(intValue, aVar);
                return intValue;
            }
            if (this.y == null) {
                this.y = new ArrayList<>();
            }
            int size = this.y.size();
            if (U) {
                Log.v("FragmentManager", "Setting back stack index " + size + " to " + aVar);
            }
            this.y.add(aVar);
            return size;
        }
    }

    @Override // android.view.LayoutInflater.Factory2
    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        if (!"fragment".equals(str)) {
            return null;
        }
        String attributeValue = attributeSet.getAttributeValue(null, "class");
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0022j.f562a);
        if (attributeValue == null) {
            attributeValue = obtainStyledAttributes.getString(0);
        }
        String str2 = attributeValue;
        int resourceId = obtainStyledAttributes.getResourceId(1, -1);
        String string = obtainStyledAttributes.getString(2);
        obtainStyledAttributes.recycle();
        if (str2 == null || !androidx.fragment.app.g.b(context.getClassLoader(), str2)) {
            return null;
        }
        int id = view != null ? view.getId() : 0;
        if (id == -1 && resourceId == -1 && string == null) {
            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + str2);
        }
        Fragment p0 = resourceId != -1 ? p0(resourceId) : null;
        if (p0 == null && string != null) {
            p0 = d(string);
        }
        if (p0 == null && id != -1) {
            p0 = p0(id);
        }
        if (U) {
            Log.v("FragmentManager", "onCreateView: id=0x" + Integer.toHexString(resourceId) + " fname=" + str2 + " existing=" + p0);
        }
        if (p0 == null) {
            p0 = e().a(context.getClassLoader(), str2);
            p0.z = true;
            p0.I = resourceId != 0 ? resourceId : id;
            p0.J = id;
            p0.K = string;
            p0.A = true;
            p0.E = this;
            androidx.fragment.app.h hVar = this.D;
            p0.F = hVar;
            p0.j0(hVar.e(), attributeSet, p0.o);
            l(p0, true);
        } else {
            if (p0.A) {
                throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string + ", or parent id 0x" + Integer.toHexString(id) + " with another fragment for " + str2);
            }
            p0.A = true;
            androidx.fragment.app.h hVar2 = this.D;
            p0.F = hVar2;
            p0.j0(hVar2.e(), attributeSet, p0.o);
        }
        Fragment fragment = p0;
        if (this.C >= 1 || !fragment.z) {
            Q0(fragment);
        } else {
            R0(fragment, 1, 0, 0, false);
        }
        View view2 = fragment.T;
        if (view2 != null) {
            if (resourceId != 0) {
                view2.setId(resourceId);
            }
            if (fragment.T.getTag() == null) {
                fragment.T.setTag(string);
            }
            return fragment.T;
        }
        throw new IllegalStateException("Fragment " + str2 + " did not create a view.");
    }

    @Override // android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void p(androidx.fragment.app.h hVar, androidx.fragment.app.e eVar, Fragment fragment) {
        if (this.D != null) {
            throw new IllegalStateException("Already attached");
        }
        this.D = hVar;
        this.E = eVar;
        this.F = fragment;
        if (fragment != null) {
            p1();
        }
        if (hVar instanceof androidx.activity.c) {
            androidx.activity.c cVar = (androidx.activity.c) hVar;
            OnBackPressedDispatcher onBackPressedDispatcher = cVar.getOnBackPressedDispatcher();
            this.w = onBackPressedDispatcher;
            androidx.lifecycle.g gVar = cVar;
            if (fragment != null) {
                gVar = fragment;
            }
            onBackPressedDispatcher.a(gVar, this.x);
        }
        this.S = fragment != null ? fragment.E.w0(fragment) : hVar instanceof androidx.lifecycle.s ? androidx.fragment.app.l.g(((androidx.lifecycle.s) hVar).getViewModelStore()) : new androidx.fragment.app.l(false);
    }

    public Fragment p0(int i2) {
        for (int size = this.s.size() - 1; size >= 0; size--) {
            Fragment fragment = this.s.get(size);
            if (fragment != null && fragment.I == i2) {
                return fragment;
            }
        }
        for (Fragment fragment2 : this.t.values()) {
            if (fragment2 != null && fragment2.I == i2) {
                return fragment2;
            }
        }
        return null;
    }

    public void q(Fragment fragment) {
        if (U) {
            Log.v("FragmentManager", "attach: " + fragment);
        }
        if (fragment.M) {
            fragment.M = false;
            if (fragment.x) {
                return;
            }
            if (this.s.contains(fragment)) {
                throw new IllegalStateException("Fragment already added: " + fragment);
            }
            if (U) {
                Log.v("FragmentManager", "add from attach: " + fragment);
            }
            synchronized (this.s) {
                this.s.add(fragment);
            }
            fragment.x = true;
            if (E0(fragment)) {
                this.H = true;
            }
        }
    }

    public Fragment q0(String str) {
        Fragment g2;
        for (Fragment fragment : this.t.values()) {
            if (fragment != null && (g2 = fragment.g(str)) != null) {
                return g2;
            }
        }
        return null;
    }

    boolean s() {
        boolean z = false;
        for (Fragment fragment : this.t.values()) {
            if (fragment != null) {
                z = E0(fragment);
            }
            if (z) {
                return true;
            }
        }
        return false;
    }

    public void t0(int i2) {
        synchronized (this) {
            this.y.set(i2, null);
            if (this.z == null) {
                this.z = new ArrayList<>();
            }
            if (U) {
                Log.v("FragmentManager", "Freeing back stack index " + i2);
            }
            this.z.add(Integer.valueOf(i2));
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        Object obj = this.F;
        if (obj == null) {
            obj = this.D;
        }
        b.g.k.b.a(obj, sb);
        sb.append("}}");
        return sb.toString();
    }

    void v(androidx.fragment.app.a aVar, boolean z, boolean z2, boolean z3) {
        if (z) {
            aVar.m(z3);
        } else {
            aVar.l();
        }
        ArrayList arrayList = new ArrayList(1);
        ArrayList arrayList2 = new ArrayList(1);
        arrayList.add(aVar);
        arrayList2.add(Boolean.valueOf(z));
        if (z2) {
            o.C(this, arrayList, arrayList2, 0, 1, true);
        }
        if (z3) {
            P0(this.C, true);
        }
        for (Fragment fragment : this.t.values()) {
            if (fragment != null && fragment.T != null && fragment.Y && aVar.p(fragment.J)) {
                float f2 = fragment.a0;
                if (f2 > 0.0f) {
                    fragment.T.setAlpha(f2);
                }
                if (z3) {
                    fragment.a0 = 0.0f;
                } else {
                    fragment.a0 = -1.0f;
                    fragment.Y = false;
                }
            }
        }
    }

    public int v0() {
        ArrayList<androidx.fragment.app.a> arrayList = this.u;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    void w(Fragment fragment) {
        Animator animator;
        if (fragment.T != null) {
            g I0 = I0(fragment, fragment.w(), !fragment.L, fragment.x());
            if (I0 == null || (animator = I0.f559b) == null) {
                if (I0 != null) {
                    fragment.T.startAnimation(I0.f558a);
                    I0.f558a.start();
                }
                fragment.T.setVisibility((!fragment.L || fragment.L()) ? 0 : 8);
                if (fragment.L()) {
                    fragment.e1(false);
                }
            } else {
                animator.setTarget(fragment.T);
                if (!fragment.L) {
                    fragment.T.setVisibility(0);
                } else if (fragment.L()) {
                    fragment.e1(false);
                } else {
                    ViewGroup viewGroup = fragment.S;
                    View view = fragment.T;
                    viewGroup.startViewTransition(view);
                    I0.f559b.addListener(new e(this, viewGroup, view, fragment));
                }
                I0.f559b.start();
            }
        }
        if (fragment.x && E0(fragment)) {
            this.H = true;
        }
        fragment.Z = false;
        fragment.h0(fragment.L);
    }

    androidx.fragment.app.l w0(Fragment fragment) {
        return this.S.f(fragment);
    }

    public void x(Fragment fragment) {
        if (U) {
            Log.v("FragmentManager", "detach: " + fragment);
        }
        if (fragment.M) {
            return;
        }
        fragment.M = true;
        if (fragment.x) {
            if (U) {
                Log.v("FragmentManager", "remove from detach: " + fragment);
            }
            synchronized (this.s) {
                this.s.remove(fragment);
            }
            if (E0(fragment)) {
                this.H = true;
            }
            fragment.x = false;
        }
    }

    public Fragment x0(Bundle bundle, String str) {
        String string = bundle.getString(str);
        if (string == null) {
            return null;
        }
        Fragment fragment = this.t.get(string);
        if (fragment != null) {
            return fragment;
        }
        n1(new IllegalStateException("Fragment no longer exists for key " + str + ": unique id " + string));
        throw null;
    }

    public void y() {
        this.I = false;
        this.J = false;
        e0(2);
    }

    LayoutInflater.Factory2 y0() {
        return this;
    }

    public void z(Configuration configuration) {
        for (int i2 = 0; i2 < this.s.size(); i2++) {
            Fragment fragment = this.s.get(i2);
            if (fragment != null) {
                fragment.A0(configuration);
            }
        }
    }

    public Fragment z0() {
        return this.G;
    }
}
