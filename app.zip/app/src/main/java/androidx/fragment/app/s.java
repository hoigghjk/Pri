package androidx.fragment.app;

import android.util.AndroidRuntimeException;

/* loaded from: classes.dex */
final class s extends AndroidRuntimeException {
    public s(String str) {
        super(str);
    }
}
