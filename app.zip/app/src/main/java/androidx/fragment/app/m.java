package androidx.fragment.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import androidx.lifecycle.d;

/* loaded from: classes.dex */
final class m implements Parcelable {
    public static final Parcelable.Creator<m> CREATOR = new a();
    Fragment A;
    final String n;
    final String o;
    final boolean p;
    final int q;
    final int r;
    final String s;
    final boolean t;
    final boolean u;
    final boolean v;
    final Bundle w;
    final boolean x;
    final int y;
    Bundle z;

    static class a implements Parcelable.Creator<m> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public m createFromParcel(Parcel parcel) {
            return new m(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public m[] newArray(int i2) {
            return new m[i2];
        }
    }

    m(Parcel parcel) {
        this.n = parcel.readString();
        this.o = parcel.readString();
        this.p = parcel.readInt() != 0;
        this.q = parcel.readInt();
        this.r = parcel.readInt();
        this.s = parcel.readString();
        this.t = parcel.readInt() != 0;
        this.u = parcel.readInt() != 0;
        this.v = parcel.readInt() != 0;
        this.w = parcel.readBundle();
        this.x = parcel.readInt() != 0;
        this.z = parcel.readBundle();
        this.y = parcel.readInt();
    }

    m(Fragment fragment) {
        this.n = fragment.getClass().getName();
        this.o = fragment.r;
        this.p = fragment.z;
        this.q = fragment.I;
        this.r = fragment.J;
        this.s = fragment.K;
        this.t = fragment.N;
        this.u = fragment.y;
        this.v = fragment.M;
        this.w = fragment.s;
        this.x = fragment.L;
        this.y = fragment.d0.ordinal();
    }

    public Fragment a(ClassLoader classLoader, g gVar) {
        Fragment fragment;
        Bundle bundle;
        if (this.A == null) {
            Bundle bundle2 = this.w;
            if (bundle2 != null) {
                bundle2.setClassLoader(classLoader);
            }
            Fragment a2 = gVar.a(classLoader, this.n);
            this.A = a2;
            a2.d1(this.w);
            Bundle bundle3 = this.z;
            if (bundle3 != null) {
                bundle3.setClassLoader(classLoader);
                fragment = this.A;
                bundle = this.z;
            } else {
                fragment = this.A;
                bundle = new Bundle();
            }
            fragment.o = bundle;
            Fragment fragment2 = this.A;
            fragment2.r = this.o;
            fragment2.z = this.p;
            fragment2.B = true;
            fragment2.I = this.q;
            fragment2.J = this.r;
            fragment2.K = this.s;
            fragment2.N = this.t;
            fragment2.y = this.u;
            fragment2.M = this.v;
            fragment2.L = this.x;
            fragment2.d0 = d.b.values()[this.y];
            if (j.U) {
                Log.v("FragmentManager", "Instantiated fragment " + this.A);
            }
        }
        return this.A;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.n);
        sb.append(" (");
        sb.append(this.o);
        sb.append(")}:");
        if (this.p) {
            sb.append(" fromLayout");
        }
        if (this.r != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.r));
        }
        String str = this.s;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(this.s);
        }
        if (this.t) {
            sb.append(" retainInstance");
        }
        if (this.u) {
            sb.append(" removing");
        }
        if (this.v) {
            sb.append(" detached");
        }
        if (this.x) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeString(this.n);
        parcel.writeString(this.o);
        parcel.writeInt(this.p ? 1 : 0);
        parcel.writeInt(this.q);
        parcel.writeInt(this.r);
        parcel.writeString(this.s);
        parcel.writeInt(this.t ? 1 : 0);
        parcel.writeInt(this.u ? 1 : 0);
        parcel.writeInt(this.v ? 1 : 0);
        parcel.writeBundle(this.w);
        parcel.writeInt(this.x ? 1 : 0);
        parcel.writeBundle(this.z);
        parcel.writeInt(this.y);
    }
}
