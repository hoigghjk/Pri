package androidx.fragment.app;

import android.animation.Animator;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.lifecycle.d;
import androidx.savedstate.SavedStateRegistry;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.UUID;

/* loaded from: classes.dex */
public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, androidx.lifecycle.g, androidx.lifecycle.s, androidx.savedstate.b {
    static final Object j0 = new Object();
    boolean A;
    boolean B;
    boolean C;
    int D;
    j E;
    h F;
    Fragment H;
    int I;
    int J;
    String K;
    boolean L;
    boolean M;
    boolean N;
    boolean O;
    boolean P;
    private boolean R;
    ViewGroup S;
    View T;
    View U;
    boolean V;
    c X;
    boolean Y;
    boolean Z;
    float a0;
    LayoutInflater b0;
    boolean c0;
    androidx.lifecycle.h e0;
    r f0;
    androidx.savedstate.a h0;
    private int i0;
    Bundle o;
    SparseArray<Parcelable> p;
    Boolean q;
    Bundle s;
    Fragment t;
    int v;
    boolean x;
    boolean y;
    boolean z;
    int n = 0;
    String r = UUID.randomUUID().toString();
    String u = null;
    private Boolean w = null;
    j G = new j();
    boolean Q = true;
    boolean W = true;
    d.b d0 = d.b.RESUMED;
    androidx.lifecycle.l<androidx.lifecycle.g> g0 = new androidx.lifecycle.l<>();

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Fragment.this.d();
        }
    }

    class b extends androidx.fragment.app.e {
        b() {
        }

        @Override // androidx.fragment.app.e
        public View b(int i2) {
            View view = Fragment.this.T;
            if (view != null) {
                return view.findViewById(i2);
            }
            throw new IllegalStateException("Fragment " + this + " does not have a view");
        }

        @Override // androidx.fragment.app.e
        public boolean c() {
            return Fragment.this.T != null;
        }
    }

    static class c {

        /* renamed from: a, reason: collision with root package name */
        View f533a;

        /* renamed from: b, reason: collision with root package name */
        Animator f534b;

        /* renamed from: c, reason: collision with root package name */
        int f535c;

        /* renamed from: d, reason: collision with root package name */
        int f536d;

        /* renamed from: e, reason: collision with root package name */
        int f537e;

        /* renamed from: f, reason: collision with root package name */
        int f538f;

        /* renamed from: g, reason: collision with root package name */
        Object f539g = null;

        /* renamed from: h, reason: collision with root package name */
        Object f540h;

        /* renamed from: i, reason: collision with root package name */
        Object f541i;

        /* renamed from: j, reason: collision with root package name */
        Object f542j;

        /* renamed from: k, reason: collision with root package name */
        Object f543k;
        Object l;
        Boolean m;
        Boolean n;
        androidx.core.app.n o;
        androidx.core.app.n p;
        boolean q;
        e r;
        boolean s;

        c() {
            Object obj = Fragment.j0;
            this.f540h = obj;
            this.f541i = null;
            this.f542j = obj;
            this.f543k = null;
            this.l = obj;
        }
    }

    public static class d extends RuntimeException {
        public d(String str, Exception exc) {
            super(str, exc);
        }
    }

    interface e {
        void a();

        void b();
    }

    public Fragment() {
        I();
    }

    private void I() {
        this.e0 = new androidx.lifecycle.h(this);
        this.h0 = androidx.savedstate.a.a(this);
        if (Build.VERSION.SDK_INT >= 19) {
            this.e0.a(new androidx.lifecycle.e() { // from class: androidx.fragment.app.Fragment.2
                @Override // androidx.lifecycle.e
                public void d(androidx.lifecycle.g gVar, d.a aVar) {
                    View view;
                    if (aVar != d.a.ON_STOP || (view = Fragment.this.T) == null) {
                        return;
                    }
                    view.cancelPendingInputEvents();
                }
            });
        }
    }

    @Deprecated
    public static Fragment K(Context context, String str, Bundle bundle) {
        try {
            Fragment newInstance = g.d(context.getClassLoader(), str).getConstructor(new Class[0]).newInstance(new Object[0]);
            if (bundle != null) {
                bundle.setClassLoader(newInstance.getClass().getClassLoader());
                newInstance.d1(bundle);
            }
            return newInstance;
        } catch (IllegalAccessException e2) {
            throw new d("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e2);
        } catch (InstantiationException e3) {
            throw new d("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e3);
        } catch (NoSuchMethodException e4) {
            throw new d("Unable to instantiate fragment " + str + ": could not find Fragment constructor", e4);
        } catch (InvocationTargetException e5) {
            throw new d("Unable to instantiate fragment " + str + ": calling Fragment constructor caused an exception", e5);
        }
    }

    private c f() {
        if (this.X == null) {
            this.X = new c();
        }
        return this.X;
    }

    public final Resources A() {
        return W0().getResources();
    }

    void A0(Configuration configuration) {
        onConfigurationChanged(configuration);
        this.G.z(configuration);
    }

    public final boolean B() {
        return this.N;
    }

    boolean B0(MenuItem menuItem) {
        if (this.L) {
            return false;
        }
        return W(menuItem) || this.G.A(menuItem);
    }

    public Object C() {
        c cVar = this.X;
        if (cVar == null) {
            return null;
        }
        Object obj = cVar.f540h;
        return obj == j0 ? o() : obj;
    }

    void C0(Bundle bundle) {
        this.G.S0();
        this.n = 1;
        this.R = false;
        this.h0.c(bundle);
        X(bundle);
        this.c0 = true;
        if (this.R) {
            this.e0.i(d.a.ON_CREATE);
            return;
        }
        throw new s("Fragment " + this + " did not call through to super.onCreate()");
    }

    public Object D() {
        c cVar = this.X;
        if (cVar == null) {
            return null;
        }
        return cVar.f543k;
    }

    boolean D0(Menu menu, MenuInflater menuInflater) {
        boolean z = false;
        if (this.L) {
            return false;
        }
        if (this.P && this.Q) {
            z = true;
            a0(menu, menuInflater);
        }
        return z | this.G.C(menu, menuInflater);
    }

    public Object E() {
        c cVar = this.X;
        if (cVar == null) {
            return null;
        }
        Object obj = cVar.l;
        return obj == j0 ? D() : obj;
    }

    void E0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.G.S0();
        this.C = true;
        this.f0 = new r();
        View b0 = b0(layoutInflater, viewGroup, bundle);
        this.T = b0;
        if (b0 != null) {
            this.f0.b();
            this.g0.l(this.f0);
        } else {
            if (this.f0.c()) {
                throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
            }
            this.f0 = null;
        }
    }

    int F() {
        c cVar = this.X;
        if (cVar == null) {
            return 0;
        }
        return cVar.f535c;
    }

    void F0() {
        this.G.D();
        this.e0.i(d.a.ON_DESTROY);
        this.n = 0;
        this.R = false;
        this.c0 = false;
        c0();
        if (this.R) {
            return;
        }
        throw new s("Fragment " + this + " did not call through to super.onDestroy()");
    }

    public final Fragment G() {
        String str;
        Fragment fragment = this.t;
        if (fragment != null) {
            return fragment;
        }
        j jVar = this.E;
        if (jVar == null || (str = this.u) == null) {
            return null;
        }
        return jVar.t.get(str);
    }

    void G0() {
        this.G.E();
        if (this.T != null) {
            this.f0.a(d.a.ON_DESTROY);
        }
        this.n = 1;
        this.R = false;
        e0();
        if (this.R) {
            b.m.a.a.b(this).d();
            this.C = false;
        } else {
            throw new s("Fragment " + this + " did not call through to super.onDestroyView()");
        }
    }

    public View H() {
        return this.T;
    }

    void H0() {
        this.R = false;
        f0();
        this.b0 = null;
        if (this.R) {
            if (this.G.D0()) {
                return;
            }
            this.G.D();
            this.G = new j();
            return;
        }
        throw new s("Fragment " + this + " did not call through to super.onDetach()");
    }

    LayoutInflater I0(Bundle bundle) {
        LayoutInflater g0 = g0(bundle);
        this.b0 = g0;
        return g0;
    }

    void J() {
        I();
        this.r = UUID.randomUUID().toString();
        this.x = false;
        this.y = false;
        this.z = false;
        this.A = false;
        this.B = false;
        this.D = 0;
        this.E = null;
        this.G = new j();
        this.F = null;
        this.I = 0;
        this.J = 0;
        this.K = null;
        this.L = false;
        this.M = false;
    }

    void J0() {
        onLowMemory();
        this.G.F();
    }

    void K0(boolean z) {
        k0(z);
        this.G.G(z);
    }

    boolean L() {
        c cVar = this.X;
        if (cVar == null) {
            return false;
        }
        return cVar.s;
    }

    boolean L0(MenuItem menuItem) {
        if (this.L) {
            return false;
        }
        return (this.P && this.Q && l0(menuItem)) || this.G.V(menuItem);
    }

    final boolean M() {
        return this.D > 0;
    }

    void M0(Menu menu) {
        if (this.L) {
            return;
        }
        if (this.P && this.Q) {
            m0(menu);
        }
        this.G.W(menu);
    }

    boolean N() {
        c cVar = this.X;
        if (cVar == null) {
            return false;
        }
        return cVar.q;
    }

    void N0() {
        this.G.Y();
        if (this.T != null) {
            this.f0.a(d.a.ON_PAUSE);
        }
        this.e0.i(d.a.ON_PAUSE);
        this.n = 3;
        this.R = false;
        n0();
        if (this.R) {
            return;
        }
        throw new s("Fragment " + this + " did not call through to super.onPause()");
    }

    public final boolean O() {
        return this.y;
    }

    void O0(boolean z) {
        o0(z);
        this.G.Z(z);
    }

    public final boolean P() {
        j jVar = this.E;
        if (jVar == null) {
            return false;
        }
        return jVar.H0();
    }

    boolean P0(Menu menu) {
        boolean z = false;
        if (this.L) {
            return false;
        }
        if (this.P && this.Q) {
            z = true;
            p0(menu);
        }
        return z | this.G.a0(menu);
    }

    void Q() {
        this.G.S0();
    }

    void Q0() {
        boolean F0 = this.E.F0(this);
        Boolean bool = this.w;
        if (bool == null || bool.booleanValue() != F0) {
            this.w = Boolean.valueOf(F0);
            q0(F0);
            this.G.b0();
        }
    }

    public void R(Bundle bundle) {
        this.R = true;
    }

    void R0() {
        this.G.S0();
        this.G.l0();
        this.n = 4;
        this.R = false;
        s0();
        if (!this.R) {
            throw new s("Fragment " + this + " did not call through to super.onResume()");
        }
        androidx.lifecycle.h hVar = this.e0;
        d.a aVar = d.a.ON_RESUME;
        hVar.i(aVar);
        if (this.T != null) {
            this.f0.a(aVar);
        }
        this.G.c0();
        this.G.l0();
    }

    public void S(int i2, int i3, Intent intent) {
    }

    void S0(Bundle bundle) {
        t0(bundle);
        this.h0.d(bundle);
        Parcelable e1 = this.G.e1();
        if (e1 != null) {
            bundle.putParcelable("android:support:fragments", e1);
        }
    }

    @Deprecated
    public void T(Activity activity) {
        this.R = true;
    }

    void T0() {
        this.G.S0();
        this.G.l0();
        this.n = 3;
        this.R = false;
        u0();
        if (!this.R) {
            throw new s("Fragment " + this + " did not call through to super.onStart()");
        }
        androidx.lifecycle.h hVar = this.e0;
        d.a aVar = d.a.ON_START;
        hVar.i(aVar);
        if (this.T != null) {
            this.f0.a(aVar);
        }
        this.G.d0();
    }

    public void U(Context context) {
        this.R = true;
        h hVar = this.F;
        Activity d2 = hVar == null ? null : hVar.d();
        if (d2 != null) {
            this.R = false;
            T(d2);
        }
    }

    void U0() {
        this.G.f0();
        if (this.T != null) {
            this.f0.a(d.a.ON_STOP);
        }
        this.e0.i(d.a.ON_STOP);
        this.n = 2;
        this.R = false;
        v0();
        if (this.R) {
            return;
        }
        throw new s("Fragment " + this + " did not call through to super.onStop()");
    }

    public void V(Fragment fragment) {
    }

    public final androidx.fragment.app.d V0() {
        androidx.fragment.app.d h2 = h();
        if (h2 != null) {
            return h2;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to an activity.");
    }

    public boolean W(MenuItem menuItem) {
        return false;
    }

    public final Context W0() {
        Context n = n();
        if (n != null) {
            return n;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to a context.");
    }

    public void X(Bundle bundle) {
        this.R = true;
        Z0(bundle);
        if (this.G.G0(1)) {
            return;
        }
        this.G.B();
    }

    public final i X0() {
        i s = s();
        if (s != null) {
            return s;
        }
        throw new IllegalStateException("Fragment " + this + " not associated with a fragment manager.");
    }

    public Animation Y(int i2, boolean z, int i3) {
        return null;
    }

    public final View Y0() {
        View H = H();
        if (H != null) {
            return H;
        }
        throw new IllegalStateException("Fragment " + this + " did not return a View from onCreateView() or this was called before onCreateView().");
    }

    public Animator Z(int i2, boolean z, int i3) {
        return null;
    }

    void Z0(Bundle bundle) {
        Parcelable parcelable;
        if (bundle == null || (parcelable = bundle.getParcelable("android:support:fragments")) == null) {
            return;
        }
        this.G.c1(parcelable);
        this.G.B();
    }

    public void a0(Menu menu, MenuInflater menuInflater) {
    }

    final void a1(Bundle bundle) {
        SparseArray<Parcelable> sparseArray = this.p;
        if (sparseArray != null) {
            this.U.restoreHierarchyState(sparseArray);
            this.p = null;
        }
        this.R = false;
        x0(bundle);
        if (this.R) {
            if (this.T != null) {
                this.f0.a(d.a.ON_CREATE);
            }
        } else {
            throw new s("Fragment " + this + " did not call through to super.onViewStateRestored()");
        }
    }

    public View b0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i2 = this.i0;
        if (i2 != 0) {
            return layoutInflater.inflate(i2, viewGroup, false);
        }
        return null;
    }

    void b1(View view) {
        f().f533a = view;
    }

    public void c0() {
        this.R = true;
    }

    void c1(Animator animator) {
        f().f534b = animator;
    }

    void d() {
        c cVar = this.X;
        e eVar = null;
        if (cVar != null) {
            cVar.q = false;
            e eVar2 = cVar.r;
            cVar.r = null;
            eVar = eVar2;
        }
        if (eVar != null) {
            eVar.a();
        }
    }

    public void d0() {
    }

    public void d1(Bundle bundle) {
        if (this.E != null && P()) {
            throw new IllegalStateException("Fragment already added and state has been saved");
        }
        this.s = bundle;
    }

    public void e(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.I));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.J));
        printWriter.print(" mTag=");
        printWriter.println(this.K);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.n);
        printWriter.print(" mWho=");
        printWriter.print(this.r);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.D);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.x);
        printWriter.print(" mRemoving=");
        printWriter.print(this.y);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.z);
        printWriter.print(" mInLayout=");
        printWriter.println(this.A);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.L);
        printWriter.print(" mDetached=");
        printWriter.print(this.M);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.Q);
        printWriter.print(" mHasMenu=");
        printWriter.println(this.P);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.N);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.W);
        if (this.E != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.E);
        }
        if (this.F != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.F);
        }
        if (this.H != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.H);
        }
        if (this.s != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.s);
        }
        if (this.o != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.o);
        }
        if (this.p != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.p);
        }
        Fragment G = G();
        if (G != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(G);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.v);
        }
        if (v() != 0) {
            printWriter.print(str);
            printWriter.print("mNextAnim=");
            printWriter.println(v());
        }
        if (this.S != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.S);
        }
        if (this.T != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.T);
        }
        if (this.U != null) {
            printWriter.print(str);
            printWriter.print("mInnerView=");
            printWriter.println(this.T);
        }
        if (k() != null) {
            printWriter.print(str);
            printWriter.print("mAnimatingAway=");
            printWriter.println(k());
            printWriter.print(str);
            printWriter.print("mStateAfterAnimating=");
            printWriter.println(F());
        }
        if (n() != null) {
            b.m.a.a.b(this).a(str, fileDescriptor, printWriter, strArr);
        }
        printWriter.print(str);
        printWriter.println("Child " + this.G + ":");
        this.G.b(str + "  ", fileDescriptor, printWriter, strArr);
    }

    public void e0() {
        this.R = true;
    }

    void e1(boolean z) {
        f().s = z;
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    public void f0() {
        this.R = true;
    }

    void f1(int i2) {
        if (this.X == null && i2 == 0) {
            return;
        }
        f().f536d = i2;
    }

    Fragment g(String str) {
        return str.equals(this.r) ? this : this.G.q0(str);
    }

    public LayoutInflater g0(Bundle bundle) {
        return u(bundle);
    }

    void g1(int i2, int i3) {
        if (this.X == null && i2 == 0 && i3 == 0) {
            return;
        }
        f();
        c cVar = this.X;
        cVar.f537e = i2;
        cVar.f538f = i3;
    }

    @Override // androidx.lifecycle.g
    public androidx.lifecycle.d getLifecycle() {
        return this.e0;
    }

    @Override // androidx.savedstate.b
    public final SavedStateRegistry getSavedStateRegistry() {
        return this.h0.b();
    }

    @Override // androidx.lifecycle.s
    public androidx.lifecycle.r getViewModelStore() {
        j jVar = this.E;
        if (jVar != null) {
            return jVar.A0(this);
        }
        throw new IllegalStateException("Can't access ViewModels from detached fragment");
    }

    public final androidx.fragment.app.d h() {
        h hVar = this.F;
        if (hVar == null) {
            return null;
        }
        return (androidx.fragment.app.d) hVar.d();
    }

    public void h0(boolean z) {
    }

    void h1(e eVar) {
        f();
        c cVar = this.X;
        e eVar2 = cVar.r;
        if (eVar == eVar2) {
            return;
        }
        if (eVar != null && eVar2 != null) {
            throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
        }
        if (cVar.q) {
            cVar.r = eVar;
        }
        if (eVar != null) {
            eVar.b();
        }
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public boolean i() {
        Boolean bool;
        c cVar = this.X;
        if (cVar == null || (bool = cVar.n) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    @Deprecated
    public void i0(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        this.R = true;
    }

    void i1(int i2) {
        f().f535c = i2;
    }

    public boolean j() {
        Boolean bool;
        c cVar = this.X;
        if (cVar == null || (bool = cVar.m) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public void j0(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.R = true;
        h hVar = this.F;
        Activity d2 = hVar == null ? null : hVar.d();
        if (d2 != null) {
            this.R = false;
            i0(d2, attributeSet, bundle);
        }
    }

    public void j1(Intent intent, int i2, Bundle bundle) {
        h hVar = this.F;
        if (hVar != null) {
            hVar.n(this, intent, i2, bundle);
            return;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }

    View k() {
        c cVar = this.X;
        if (cVar == null) {
            return null;
        }
        return cVar.f533a;
    }

    public void k0(boolean z) {
    }

    public void k1() {
        j jVar = this.E;
        if (jVar == null || jVar.D == null) {
            f().q = false;
        } else if (Looper.myLooper() != this.E.D.f().getLooper()) {
            this.E.D.f().postAtFrontOfQueue(new a());
        } else {
            d();
        }
    }

    Animator l() {
        c cVar = this.X;
        if (cVar == null) {
            return null;
        }
        return cVar.f534b;
    }

    public boolean l0(MenuItem menuItem) {
        return false;
    }

    public final i m() {
        if (this.F != null) {
            return this.G;
        }
        throw new IllegalStateException("Fragment " + this + " has not been attached yet.");
    }

    public void m0(Menu menu) {
    }

    public Context n() {
        h hVar = this.F;
        if (hVar == null) {
            return null;
        }
        return hVar.e();
    }

    public void n0() {
        this.R = true;
    }

    public Object o() {
        c cVar = this.X;
        if (cVar == null) {
            return null;
        }
        return cVar.f539g;
    }

    public void o0(boolean z) {
    }

    @Override // android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        this.R = true;
    }

    @Override // android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        V0().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    @Override // android.content.ComponentCallbacks
    public void onLowMemory() {
        this.R = true;
    }

    androidx.core.app.n p() {
        c cVar = this.X;
        if (cVar == null) {
            return null;
        }
        return cVar.o;
    }

    public void p0(Menu menu) {
    }

    public Object q() {
        c cVar = this.X;
        if (cVar == null) {
            return null;
        }
        return cVar.f541i;
    }

    public void q0(boolean z) {
    }

    androidx.core.app.n r() {
        c cVar = this.X;
        if (cVar == null) {
            return null;
        }
        return cVar.p;
    }

    public void r0(int i2, String[] strArr, int[] iArr) {
    }

    public final i s() {
        return this.E;
    }

    public void s0() {
        this.R = true;
    }

    public void startActivityForResult(Intent intent, int i2) {
        j1(intent, i2, null);
    }

    public final Object t() {
        h hVar = this.F;
        if (hVar == null) {
            return null;
        }
        return hVar.i();
    }

    public void t0(Bundle bundle) {
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        b.g.k.b.a(this, sb);
        sb.append(" (");
        sb.append(this.r);
        sb.append(")");
        if (this.I != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.I));
        }
        if (this.K != null) {
            sb.append(" ");
            sb.append(this.K);
        }
        sb.append('}');
        return sb.toString();
    }

    @Deprecated
    public LayoutInflater u(Bundle bundle) {
        h hVar = this.F;
        if (hVar == null) {
            throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
        }
        LayoutInflater j2 = hVar.j();
        j jVar = this.G;
        jVar.y0();
        b.g.l.f.b(j2, jVar);
        return j2;
    }

    public void u0() {
        this.R = true;
    }

    int v() {
        c cVar = this.X;
        if (cVar == null) {
            return 0;
        }
        return cVar.f536d;
    }

    public void v0() {
        this.R = true;
    }

    int w() {
        c cVar = this.X;
        if (cVar == null) {
            return 0;
        }
        return cVar.f537e;
    }

    public void w0(View view, Bundle bundle) {
    }

    int x() {
        c cVar = this.X;
        if (cVar == null) {
            return 0;
        }
        return cVar.f538f;
    }

    public void x0(Bundle bundle) {
        this.R = true;
    }

    public final Fragment y() {
        return this.H;
    }

    void y0(Bundle bundle) {
        this.G.S0();
        this.n = 2;
        this.R = false;
        R(bundle);
        if (this.R) {
            this.G.y();
            return;
        }
        throw new s("Fragment " + this + " did not call through to super.onActivityCreated()");
    }

    public Object z() {
        c cVar = this.X;
        if (cVar == null) {
            return null;
        }
        Object obj = cVar.f542j;
        return obj == j0 ? q() : obj;
    }

    void z0() {
        this.G.p(this.F, new b(), this);
        this.R = false;
        U(this.F.e());
        if (this.R) {
            return;
        }
        throw new s("Fragment " + this + " did not call through to super.onAttach()");
    }
}
