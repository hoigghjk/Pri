package androidx.savedstate;

import androidx.lifecycle.g;

/* loaded from: classes.dex */
public interface b extends g {
    SavedStateRegistry getSavedStateRegistry();
}
