package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.d;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    private final b f663a;

    /* renamed from: b, reason: collision with root package name */
    private final SavedStateRegistry f664b = new SavedStateRegistry();

    private a(b bVar) {
        this.f663a = bVar;
    }

    public static a a(b bVar) {
        return new a(bVar);
    }

    public SavedStateRegistry b() {
        return this.f664b;
    }

    public void c(Bundle bundle) {
        d lifecycle = this.f663a.getLifecycle();
        if (lifecycle.b() != d.b.INITIALIZED) {
            throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
        }
        lifecycle.a(new Recreator(this.f663a));
        this.f664b.b(lifecycle, bundle);
    }

    public void d(Bundle bundle) {
        this.f664b.c(bundle);
    }
}
