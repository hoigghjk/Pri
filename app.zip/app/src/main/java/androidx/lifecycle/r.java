package androidx.lifecycle;

import java.util.HashMap;
import java.util.Iterator;

/* loaded from: classes.dex */
public class r {

    /* renamed from: a, reason: collision with root package name */
    private final HashMap<String, p> f650a = new HashMap<>();

    public final void a() {
        Iterator<p> it = this.f650a.values().iterator();
        while (it.hasNext()) {
            it.next().a();
        }
        this.f650a.clear();
    }

    final p b(String str) {
        return this.f650a.get(str);
    }

    final void c(String str, p pVar) {
        p put = this.f650a.put(str, pVar);
        if (put != null) {
            put.c();
        }
    }
}
