package androidx.lifecycle;

import androidx.lifecycle.d;

/* loaded from: classes.dex */
public interface e extends f {
    void d(g gVar, d.a aVar);
}
