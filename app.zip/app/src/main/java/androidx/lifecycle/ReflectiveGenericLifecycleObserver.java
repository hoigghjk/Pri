package androidx.lifecycle;

import androidx.lifecycle.a;
import androidx.lifecycle.d;

/* loaded from: classes.dex */
class ReflectiveGenericLifecycleObserver implements e {
    private final Object n;
    private final a.C0023a o;

    ReflectiveGenericLifecycleObserver(Object obj) {
        this.n = obj;
        this.o = a.f627c.c(obj.getClass());
    }

    @Override // androidx.lifecycle.e
    public void d(g gVar, d.a aVar) {
        this.o.a(gVar, aVar, this.n);
    }
}
