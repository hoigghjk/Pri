package androidx.lifecycle;

import androidx.lifecycle.d;

/* loaded from: classes.dex */
public abstract class LiveData<T> {

    /* renamed from: j, reason: collision with root package name */
    static final Object f617j = new Object();

    /* renamed from: a, reason: collision with root package name */
    final Object f618a = new Object();

    /* renamed from: b, reason: collision with root package name */
    private b.b.a.b.b<m<? super T>, LiveData<T>.b> f619b = new b.b.a.b.b<>();

    /* renamed from: c, reason: collision with root package name */
    int f620c = 0;

    /* renamed from: d, reason: collision with root package name */
    private volatile Object f621d;

    /* renamed from: e, reason: collision with root package name */
    volatile Object f622e;

    /* renamed from: f, reason: collision with root package name */
    private int f623f;

    /* renamed from: g, reason: collision with root package name */
    private boolean f624g;

    /* renamed from: h, reason: collision with root package name */
    private boolean f625h;

    /* renamed from: i, reason: collision with root package name */
    private final Runnable f626i;

    class LifecycleBoundObserver extends LiveData<T>.b implements Object {
        final g r;

        LifecycleBoundObserver(g gVar, m<? super T> mVar) {
            super(mVar);
            this.r = gVar;
        }

        public void d(g gVar, d.a aVar) {
            if (this.r.getLifecycle().b() == d.b.DESTROYED) {
                LiveData.this.k(this.n);
            } else {
                h(k());
            }
        }

        @Override // androidx.lifecycle.LiveData.b
        void i() {
            this.r.getLifecycle().c(this);
        }

        @Override // androidx.lifecycle.LiveData.b
        boolean j(g gVar) {
            return this.r == gVar;
        }

        @Override // androidx.lifecycle.LiveData.b
        boolean k() {
            return this.r.getLifecycle().b().c(d.b.STARTED);
        }
    }

    class a implements Runnable {
        a() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.lang.Runnable
        public void run() {
            Object obj;
            synchronized (LiveData.this.f618a) {
                obj = LiveData.this.f622e;
                LiveData.this.f622e = LiveData.f617j;
            }
            LiveData.this.l(obj);
        }
    }

    private abstract class b {
        final m<? super T> n;
        boolean o;
        int p = -1;

        b(m<? super T> mVar) {
            this.n = mVar;
        }

        void h(boolean z) {
            if (z == this.o) {
                return;
            }
            this.o = z;
            LiveData liveData = LiveData.this;
            int i2 = liveData.f620c;
            boolean z2 = i2 == 0;
            liveData.f620c = i2 + (z ? 1 : -1);
            if (z2 && z) {
                liveData.h();
            }
            LiveData liveData2 = LiveData.this;
            if (liveData2.f620c == 0 && !this.o) {
                liveData2.i();
            }
            if (this.o) {
                LiveData.this.d(this);
            }
        }

        void i() {
        }

        boolean j(g gVar) {
            return false;
        }

        abstract boolean k();
    }

    public LiveData() {
        Object obj = f617j;
        this.f621d = obj;
        this.f622e = obj;
        this.f623f = -1;
        this.f626i = new a();
    }

    private static void b(String str) {
        if (b.b.a.a.a.c().a()) {
            return;
        }
        throw new IllegalStateException("Cannot invoke " + str + " on a background thread");
    }

    private void c(LiveData<T>.b bVar) {
        if (bVar.o) {
            if (!bVar.k()) {
                bVar.h(false);
                return;
            }
            int i2 = bVar.p;
            int i3 = this.f623f;
            if (i2 >= i3) {
                return;
            }
            bVar.p = i3;
            bVar.n.a((Object) this.f621d);
        }
    }

    void d(LiveData<T>.b bVar) {
        if (this.f624g) {
            this.f625h = true;
            return;
        }
        this.f624g = true;
        do {
            this.f625h = false;
            if (bVar != null) {
                c(bVar);
                bVar = null;
            } else {
                b.b.a.b.b<m<? super T>, LiveData<T>.b>.d f2 = this.f619b.f();
                while (f2.hasNext()) {
                    c((b) f2.next().getValue());
                    if (this.f625h) {
                        break;
                    }
                }
            }
        } while (this.f625h);
        this.f624g = false;
    }

    public T e() {
        T t = (T) this.f621d;
        if (t != f617j) {
            return t;
        }
        return null;
    }

    public boolean f() {
        return this.f620c > 0;
    }

    public void g(g gVar, m<? super T> mVar) {
        b("observe");
        if (gVar.getLifecycle().b() == d.b.DESTROYED) {
            return;
        }
        LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(gVar, mVar);
        LiveData<T>.b j2 = this.f619b.j(mVar, lifecycleBoundObserver);
        if (j2 != null && !j2.j(gVar)) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (j2 != null) {
            return;
        }
        gVar.getLifecycle().a(lifecycleBoundObserver);
    }

    protected void h() {
    }

    protected void i() {
    }

    protected void j(T t) {
        boolean z;
        synchronized (this.f618a) {
            z = this.f622e == f617j;
            this.f622e = t;
        }
        if (z) {
            b.b.a.a.a.c().b(this.f626i);
        }
    }

    public void k(m<? super T> mVar) {
        b("removeObserver");
        LiveData<T>.b k2 = this.f619b.k(mVar);
        if (k2 == null) {
            return;
        }
        k2.i();
        k2.h(false);
    }

    protected void l(T t) {
        b("setValue");
        this.f623f++;
        this.f621d = t;
        d(null);
    }
}
