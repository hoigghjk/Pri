package androidx.lifecycle;

/* loaded from: classes.dex */
public class l<T> extends LiveData<T> {
    @Override // androidx.lifecycle.LiveData
    public void j(T t) {
        super.j(t);
    }

    @Override // androidx.lifecycle.LiveData
    public void l(T t) {
        super.l(t);
    }
}
