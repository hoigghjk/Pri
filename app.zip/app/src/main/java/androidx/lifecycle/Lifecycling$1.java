package androidx.lifecycle;

import androidx.lifecycle.d;

/* loaded from: classes.dex */
final class Lifecycling$1 implements e {
    final /* synthetic */ e n;

    @Override // androidx.lifecycle.e
    public void d(g gVar, d.a aVar) {
        this.n.d(gVar, aVar);
    }
}
