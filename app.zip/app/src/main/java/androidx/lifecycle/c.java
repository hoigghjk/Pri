package androidx.lifecycle;

import androidx.lifecycle.d;

/* loaded from: classes.dex */
public interface c {
    void a(g gVar, d.a aVar, boolean z, k kVar);
}
