package androidx.lifecycle;

import androidx.lifecycle.d;

/* loaded from: classes.dex */
class SingleGeneratedAdapterObserver implements e {
    private final c n;

    SingleGeneratedAdapterObserver(c cVar) {
        this.n = cVar;
    }

    @Override // androidx.lifecycle.e
    public void d(g gVar, d.a aVar) {
        this.n.a(gVar, aVar, false, null);
        this.n.a(gVar, aVar, true, null);
    }
}
