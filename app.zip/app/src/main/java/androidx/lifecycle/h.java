package androidx.lifecycle;

import androidx.lifecycle.d;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public class h extends d {

    /* renamed from: c, reason: collision with root package name */
    private final WeakReference<g> f636c;

    /* renamed from: a, reason: collision with root package name */
    private b.b.a.b.a<f, b> f634a = new b.b.a.b.a<>();

    /* renamed from: d, reason: collision with root package name */
    private int f637d = 0;

    /* renamed from: e, reason: collision with root package name */
    private boolean f638e = false;

    /* renamed from: f, reason: collision with root package name */
    private boolean f639f = false;

    /* renamed from: g, reason: collision with root package name */
    private ArrayList<d.b> f640g = new ArrayList<>();

    /* renamed from: b, reason: collision with root package name */
    private d.b f635b = d.b.INITIALIZED;

    static /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f641a;

        /* renamed from: b, reason: collision with root package name */
        static final /* synthetic */ int[] f642b;

        static {
            int[] iArr = new int[d.b.values().length];
            f642b = iArr;
            try {
                iArr[d.b.INITIALIZED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f642b[d.b.CREATED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f642b[d.b.STARTED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f642b[d.b.RESUMED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f642b[d.b.DESTROYED.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            int[] iArr2 = new int[d.a.values().length];
            f641a = iArr2;
            try {
                iArr2[d.a.ON_CREATE.ordinal()] = 1;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f641a[d.a.ON_STOP.ordinal()] = 2;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                f641a[d.a.ON_START.ordinal()] = 3;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                f641a[d.a.ON_PAUSE.ordinal()] = 4;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                f641a[d.a.ON_RESUME.ordinal()] = 5;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                f641a[d.a.ON_DESTROY.ordinal()] = 6;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                f641a[d.a.ON_ANY.ordinal()] = 7;
            } catch (NoSuchFieldError unused12) {
            }
        }
    }

    static class b {

        /* renamed from: a, reason: collision with root package name */
        d.b f643a;

        /* renamed from: b, reason: collision with root package name */
        e f644b;

        b(f fVar, d.b bVar) {
            this.f644b = j.f(fVar);
            this.f643a = bVar;
        }

        void a(g gVar, d.a aVar) {
            d.b h2 = h.h(aVar);
            this.f643a = h.l(this.f643a, h2);
            this.f644b.d(gVar, aVar);
            this.f643a = h2;
        }
    }

    public h(g gVar) {
        this.f636c = new WeakReference<>(gVar);
    }

    private void d(g gVar) {
        Iterator<Map.Entry<f, b>> descendingIterator = this.f634a.descendingIterator();
        while (descendingIterator.hasNext() && !this.f639f) {
            Map.Entry<f, b> next = descendingIterator.next();
            b value = next.getValue();
            while (value.f643a.compareTo(this.f635b) > 0 && !this.f639f && this.f634a.contains(next.getKey())) {
                d.a f2 = f(value.f643a);
                o(h(f2));
                value.a(gVar, f2);
                n();
            }
        }
    }

    private d.b e(f fVar) {
        Map.Entry<f, b> l = this.f634a.l(fVar);
        d.b bVar = null;
        d.b bVar2 = l != null ? l.getValue().f643a : null;
        if (!this.f640g.isEmpty()) {
            bVar = this.f640g.get(r0.size() - 1);
        }
        return l(l(this.f635b, bVar2), bVar);
    }

    private static d.a f(d.b bVar) {
        int i2 = a.f642b[bVar.ordinal()];
        if (i2 == 1) {
            throw new IllegalArgumentException();
        }
        if (i2 == 2) {
            return d.a.ON_DESTROY;
        }
        if (i2 == 3) {
            return d.a.ON_STOP;
        }
        if (i2 == 4) {
            return d.a.ON_PAUSE;
        }
        if (i2 == 5) {
            throw new IllegalArgumentException();
        }
        throw new IllegalArgumentException("Unexpected state value " + bVar);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void g(g gVar) {
        b.b.a.b.b<f, b>.d f2 = this.f634a.f();
        while (f2.hasNext() && !this.f639f) {
            Map.Entry next = f2.next();
            b bVar = (b) next.getValue();
            while (bVar.f643a.compareTo(this.f635b) < 0 && !this.f639f && this.f634a.contains(next.getKey())) {
                o(bVar.f643a);
                bVar.a(gVar, r(bVar.f643a));
                n();
            }
        }
    }

    static d.b h(d.a aVar) {
        switch (a.f641a[aVar.ordinal()]) {
            case 1:
            case 2:
                return d.b.CREATED;
            case 3:
            case 4:
                return d.b.STARTED;
            case 5:
                return d.b.RESUMED;
            case 6:
                return d.b.DESTROYED;
            default:
                throw new IllegalArgumentException("Unexpected event value " + aVar);
        }
    }

    private boolean j() {
        if (this.f634a.size() == 0) {
            return true;
        }
        d.b bVar = this.f634a.b().getValue().f643a;
        d.b bVar2 = this.f634a.g().getValue().f643a;
        return bVar == bVar2 && this.f635b == bVar2;
    }

    static d.b l(d.b bVar, d.b bVar2) {
        return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
    }

    private void m(d.b bVar) {
        if (this.f635b == bVar) {
            return;
        }
        this.f635b = bVar;
        if (this.f638e || this.f637d != 0) {
            this.f639f = true;
            return;
        }
        this.f638e = true;
        q();
        this.f638e = false;
    }

    private void n() {
        this.f640g.remove(r0.size() - 1);
    }

    private void o(d.b bVar) {
        this.f640g.add(bVar);
    }

    private void q() {
        g gVar = this.f636c.get();
        if (gVar == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
        }
        while (true) {
            boolean j2 = j();
            this.f639f = false;
            if (j2) {
                return;
            }
            if (this.f635b.compareTo(this.f634a.b().getValue().f643a) < 0) {
                d(gVar);
            }
            Map.Entry<f, b> g2 = this.f634a.g();
            if (!this.f639f && g2 != null && this.f635b.compareTo(g2.getValue().f643a) > 0) {
                g(gVar);
            }
        }
    }

    private static d.a r(d.b bVar) {
        int i2 = a.f642b[bVar.ordinal()];
        if (i2 != 1) {
            if (i2 == 2) {
                return d.a.ON_START;
            }
            if (i2 == 3) {
                return d.a.ON_RESUME;
            }
            if (i2 == 4) {
                throw new IllegalArgumentException();
            }
            if (i2 != 5) {
                throw new IllegalArgumentException("Unexpected state value " + bVar);
            }
        }
        return d.a.ON_CREATE;
    }

    @Override // androidx.lifecycle.d
    public void a(f fVar) {
        g gVar;
        d.b bVar = this.f635b;
        d.b bVar2 = d.b.DESTROYED;
        if (bVar != bVar2) {
            bVar2 = d.b.INITIALIZED;
        }
        b bVar3 = new b(fVar, bVar2);
        if (this.f634a.j(fVar, bVar3) == null && (gVar = this.f636c.get()) != null) {
            boolean z = this.f637d != 0 || this.f638e;
            d.b e2 = e(fVar);
            this.f637d++;
            while (bVar3.f643a.compareTo(e2) < 0 && this.f634a.contains(fVar)) {
                o(bVar3.f643a);
                bVar3.a(gVar, r(bVar3.f643a));
                n();
                e2 = e(fVar);
            }
            if (!z) {
                q();
            }
            this.f637d--;
        }
    }

    @Override // androidx.lifecycle.d
    public d.b b() {
        return this.f635b;
    }

    @Override // androidx.lifecycle.d
    public void c(f fVar) {
        this.f634a.k(fVar);
    }

    public void i(d.a aVar) {
        m(h(aVar));
    }

    @Deprecated
    public void k(d.b bVar) {
        p(bVar);
    }

    public void p(d.b bVar) {
        m(bVar);
    }
}
