package androidx.webkit;

/* loaded from: classes.dex */
public abstract class e {
    public abstract boolean a();

    public abstract boolean b();

    public abstract boolean c();

    public abstract int d();

    public abstract void e(boolean z);

    public abstract void f(boolean z);

    public abstract void g(boolean z);

    public abstract void h(int i2);
}
