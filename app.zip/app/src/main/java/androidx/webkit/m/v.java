package androidx.webkit.m;

import android.webkit.SafeBrowsingResponse;
import android.webkit.ServiceWorkerWebSettings;
import android.webkit.WebMessagePort;
import android.webkit.WebResourceError;
import java.lang.reflect.InvocationHandler;
import org.chromium.support_lib_boundary.WebkitToCompatConverterBoundaryInterface;

/* loaded from: classes.dex */
public class v {

    /* renamed from: a, reason: collision with root package name */
    private final WebkitToCompatConverterBoundaryInterface f705a;

    public v(WebkitToCompatConverterBoundaryInterface webkitToCompatConverterBoundaryInterface) {
        this.f705a = webkitToCompatConverterBoundaryInterface;
    }

    public SafeBrowsingResponse a(InvocationHandler invocationHandler) {
        return (SafeBrowsingResponse) this.f705a.convertSafeBrowsingResponse(invocationHandler);
    }

    public InvocationHandler b(SafeBrowsingResponse safeBrowsingResponse) {
        return this.f705a.convertSafeBrowsingResponse(safeBrowsingResponse);
    }

    public ServiceWorkerWebSettings c(InvocationHandler invocationHandler) {
        return (ServiceWorkerWebSettings) this.f705a.convertServiceWorkerSettings(invocationHandler);
    }

    public InvocationHandler d(ServiceWorkerWebSettings serviceWorkerWebSettings) {
        return this.f705a.convertServiceWorkerSettings(serviceWorkerWebSettings);
    }

    public WebMessagePort e(InvocationHandler invocationHandler) {
        return (WebMessagePort) this.f705a.convertWebMessagePort(invocationHandler);
    }

    public InvocationHandler f(WebMessagePort webMessagePort) {
        return this.f705a.convertWebMessagePort(webMessagePort);
    }

    public WebResourceError g(InvocationHandler invocationHandler) {
        return (WebResourceError) this.f705a.convertWebResourceError(invocationHandler);
    }

    public InvocationHandler h(WebResourceError webResourceError) {
        return this.f705a.convertWebResourceError(webResourceError);
    }
}
