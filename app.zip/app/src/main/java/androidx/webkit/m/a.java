package androidx.webkit.m;

/* loaded from: classes.dex */
public interface a {
    String c();

    boolean d();
}
