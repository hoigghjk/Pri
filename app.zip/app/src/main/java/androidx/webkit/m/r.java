package androidx.webkit.m;

import android.webkit.WebView;
import org.chromium.support_lib_boundary.ServiceWorkerControllerBoundaryInterface;
import org.chromium.support_lib_boundary.StaticsBoundaryInterface;
import org.chromium.support_lib_boundary.WebViewProviderBoundaryInterface;
import org.chromium.support_lib_boundary.WebViewProviderFactoryBoundaryInterface;
import org.chromium.support_lib_boundary.WebkitToCompatConverterBoundaryInterface;

/* loaded from: classes.dex */
public class r implements q {

    /* renamed from: a, reason: collision with root package name */
    WebViewProviderFactoryBoundaryInterface f700a;

    public r(WebViewProviderFactoryBoundaryInterface webViewProviderFactoryBoundaryInterface) {
        this.f700a = webViewProviderFactoryBoundaryInterface;
    }

    @Override // androidx.webkit.m.q
    public String[] a() {
        return this.f700a.getSupportedFeatures();
    }

    @Override // androidx.webkit.m.q
    public WebViewProviderBoundaryInterface createWebView(WebView webView) {
        return (WebViewProviderBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(WebViewProviderBoundaryInterface.class, this.f700a.createWebView(webView));
    }

    @Override // androidx.webkit.m.q
    public ServiceWorkerControllerBoundaryInterface getServiceWorkerController() {
        return (ServiceWorkerControllerBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(ServiceWorkerControllerBoundaryInterface.class, this.f700a.getServiceWorkerController());
    }

    @Override // androidx.webkit.m.q
    public StaticsBoundaryInterface getStatics() {
        return (StaticsBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(StaticsBoundaryInterface.class, this.f700a.getStatics());
    }

    @Override // androidx.webkit.m.q
    public WebkitToCompatConverterBoundaryInterface getWebkitToCompatConverter() {
        return (WebkitToCompatConverterBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(WebkitToCompatConverterBoundaryInterface.class, this.f700a.getWebkitToCompatConverter());
    }
}
