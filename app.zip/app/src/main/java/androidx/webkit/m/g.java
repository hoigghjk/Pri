package androidx.webkit.m;

import android.webkit.ServiceWorkerController;
import org.chromium.support_lib_boundary.ServiceWorkerControllerBoundaryInterface;

/* loaded from: classes.dex */
public class g extends androidx.webkit.d {

    /* renamed from: a, reason: collision with root package name */
    private ServiceWorkerController f686a;

    /* renamed from: b, reason: collision with root package name */
    private ServiceWorkerControllerBoundaryInterface f687b;

    /* renamed from: c, reason: collision with root package name */
    private final androidx.webkit.e f688c;

    public g() {
        h hVar;
        n nVar = n.SERVICE_WORKER_BASIC_USAGE;
        if (nVar.m()) {
            ServiceWorkerController serviceWorkerController = ServiceWorkerController.getInstance();
            this.f686a = serviceWorkerController;
            this.f687b = null;
            hVar = new h(serviceWorkerController.getServiceWorkerWebSettings());
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            this.f686a = null;
            ServiceWorkerControllerBoundaryInterface serviceWorkerController2 = o.d().getServiceWorkerController();
            this.f687b = serviceWorkerController2;
            hVar = new h(serviceWorkerController2.getServiceWorkerWebSettings());
        }
        this.f688c = hVar;
    }

    private ServiceWorkerControllerBoundaryInterface d() {
        if (this.f687b == null) {
            this.f687b = o.d().getServiceWorkerController();
        }
        return this.f687b;
    }

    private ServiceWorkerController e() {
        if (this.f686a == null) {
            this.f686a = ServiceWorkerController.getInstance();
        }
        return this.f686a;
    }

    @Override // androidx.webkit.d
    public androidx.webkit.e b() {
        return this.f688c;
    }

    @Override // androidx.webkit.d
    public void c(androidx.webkit.c cVar) {
        n nVar = n.SERVICE_WORKER_BASIC_USAGE;
        if (nVar.m()) {
            e().setServiceWorkerClient(new b(cVar));
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            d().setServiceWorkerClient(org.chromium.support_lib_boundary.a.a.c(new f(cVar)));
        }
    }
}
