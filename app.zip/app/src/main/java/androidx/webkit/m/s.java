package androidx.webkit.m;

import android.webkit.WebView;
import java.lang.reflect.InvocationHandler;
import java.util.concurrent.Executor;
import org.chromium.support_lib_boundary.WebViewRendererClientBoundaryInterface;

/* loaded from: classes.dex */
public class s implements WebViewRendererClientBoundaryInterface {
    private static final String[] p = {"WEB_VIEW_RENDERER_CLIENT_BASIC_USAGE"};
    private final Executor n;
    private final androidx.webkit.l o;

    class a implements Runnable {
        final /* synthetic */ androidx.webkit.l n;
        final /* synthetic */ WebView o;
        final /* synthetic */ androidx.webkit.k p;

        a(s sVar, androidx.webkit.l lVar, WebView webView, androidx.webkit.k kVar) {
            this.n = lVar;
            this.o = webView;
            this.p = kVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.n.onRenderProcessUnresponsive(this.o, this.p);
        }
    }

    class b implements Runnable {
        final /* synthetic */ androidx.webkit.l n;
        final /* synthetic */ WebView o;
        final /* synthetic */ androidx.webkit.k p;

        b(s sVar, androidx.webkit.l lVar, WebView webView, androidx.webkit.k kVar) {
            this.n = lVar;
            this.o = webView;
            this.p = kVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.n.onRenderProcessResponsive(this.o, this.p);
        }
    }

    public s(Executor executor, androidx.webkit.l lVar) {
        this.n = executor;
        this.o = lVar;
    }

    @Override // org.chromium.support_lib_boundary.FeatureFlagHolderBoundaryInterface
    public final String[] getSupportedFeatures() {
        return p;
    }

    @Override // org.chromium.support_lib_boundary.WebViewRendererClientBoundaryInterface
    public final void onRendererResponsive(WebView webView, InvocationHandler invocationHandler) {
        u c2 = u.c(invocationHandler);
        androidx.webkit.l lVar = this.o;
        Executor executor = this.n;
        if (executor == null) {
            lVar.onRenderProcessResponsive(webView, c2);
        } else {
            executor.execute(new b(this, lVar, webView, c2));
        }
    }

    @Override // org.chromium.support_lib_boundary.WebViewRendererClientBoundaryInterface
    public final void onRendererUnresponsive(WebView webView, InvocationHandler invocationHandler) {
        u c2 = u.c(invocationHandler);
        androidx.webkit.l lVar = this.o;
        Executor executor = this.n;
        if (executor == null) {
            lVar.onRenderProcessUnresponsive(webView, c2);
        } else {
            executor.execute(new a(this, lVar, webView, c2));
        }
    }
}
