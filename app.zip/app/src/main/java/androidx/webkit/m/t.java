package androidx.webkit.m;

import android.webkit.WebView;
import android.webkit.WebViewRenderProcess;
import android.webkit.WebViewRenderProcessClient;

/* loaded from: classes.dex */
public class t extends WebViewRenderProcessClient {

    /* renamed from: a, reason: collision with root package name */
    private androidx.webkit.l f701a;

    public t(androidx.webkit.l lVar) {
        this.f701a = lVar;
    }

    @Override // android.webkit.WebViewRenderProcessClient
    public void onRenderProcessResponsive(WebView webView, WebViewRenderProcess webViewRenderProcess) {
        this.f701a.onRenderProcessResponsive(webView, u.b(webViewRenderProcess));
    }

    @Override // android.webkit.WebViewRenderProcessClient
    public void onRenderProcessUnresponsive(WebView webView, WebViewRenderProcess webViewRenderProcess) {
        this.f701a.onRenderProcessUnresponsive(webView, u.b(webViewRenderProcess));
    }
}
