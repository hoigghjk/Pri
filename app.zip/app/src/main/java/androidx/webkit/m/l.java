package androidx.webkit.m;

import android.webkit.WebMessage;
import android.webkit.WebMessagePort;
import androidx.webkit.g;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.chromium.support_lib_boundary.WebMessagePortBoundaryInterface;

/* loaded from: classes.dex */
public class l extends androidx.webkit.g {

    /* renamed from: a, reason: collision with root package name */
    private WebMessagePort f691a;

    /* renamed from: b, reason: collision with root package name */
    private WebMessagePortBoundaryInterface f692b;

    class a extends WebMessagePort.WebMessageCallback {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ g.a f693a;

        a(l lVar, g.a aVar) {
            this.f693a = aVar;
        }

        @Override // android.webkit.WebMessagePort.WebMessageCallback
        public void onMessage(WebMessagePort webMessagePort, WebMessage webMessage) {
            this.f693a.onMessage(new l(webMessagePort), l.h(webMessage));
        }
    }

    public l(WebMessagePort webMessagePort) {
        this.f691a = webMessagePort;
    }

    public l(InvocationHandler invocationHandler) {
        this.f692b = (WebMessagePortBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(WebMessagePortBoundaryInterface.class, invocationHandler);
    }

    public static WebMessage f(androidx.webkit.f fVar) {
        return new WebMessage(fVar.a(), g(fVar.b()));
    }

    public static WebMessagePort[] g(androidx.webkit.g[] gVarArr) {
        if (gVarArr == null) {
            return null;
        }
        int length = gVarArr.length;
        WebMessagePort[] webMessagePortArr = new WebMessagePort[length];
        for (int i2 = 0; i2 < length; i2++) {
            webMessagePortArr[i2] = gVarArr[i2].b();
        }
        return webMessagePortArr;
    }

    public static androidx.webkit.f h(WebMessage webMessage) {
        return new androidx.webkit.f(webMessage.getData(), k(webMessage.getPorts()));
    }

    private WebMessagePortBoundaryInterface i() {
        if (this.f692b == null) {
            this.f692b = (WebMessagePortBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(WebMessagePortBoundaryInterface.class, o.c().f(this.f691a));
        }
        return this.f692b;
    }

    private WebMessagePort j() {
        if (this.f691a == null) {
            this.f691a = o.c().e(Proxy.getInvocationHandler(this.f692b));
        }
        return this.f691a;
    }

    public static androidx.webkit.g[] k(WebMessagePort[] webMessagePortArr) {
        if (webMessagePortArr == null) {
            return null;
        }
        androidx.webkit.g[] gVarArr = new androidx.webkit.g[webMessagePortArr.length];
        for (int i2 = 0; i2 < webMessagePortArr.length; i2++) {
            gVarArr[i2] = new l(webMessagePortArr[i2]);
        }
        return gVarArr;
    }

    @Override // androidx.webkit.g
    public void a() {
        n nVar = n.WEB_MESSAGE_PORT_CLOSE;
        if (nVar.m()) {
            j().close();
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            i().close();
        }
    }

    @Override // androidx.webkit.g
    public WebMessagePort b() {
        return j();
    }

    @Override // androidx.webkit.g
    public InvocationHandler c() {
        return Proxy.getInvocationHandler(i());
    }

    @Override // androidx.webkit.g
    public void d(androidx.webkit.f fVar) {
        n nVar = n.WEB_MESSAGE_PORT_POST_MESSAGE;
        if (nVar.m()) {
            j().postMessage(f(fVar));
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            i().postMessage(org.chromium.support_lib_boundary.a.a.c(new i(fVar)));
        }
    }

    @Override // androidx.webkit.g
    public void e(g.a aVar) {
        n nVar = n.WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK;
        if (nVar.m()) {
            j().setWebMessageCallback(new a(this, aVar));
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            i().setWebMessageCallback(org.chromium.support_lib_boundary.a.a.c(new j(aVar)));
        }
    }
}
