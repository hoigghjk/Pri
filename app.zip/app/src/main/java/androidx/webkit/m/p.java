package androidx.webkit.m;

import android.net.Uri;
import androidx.webkit.i;
import java.lang.reflect.InvocationHandler;
import java.util.concurrent.Executor;
import org.chromium.support_lib_boundary.WebViewProviderBoundaryInterface;

/* loaded from: classes.dex */
public class p {

    /* renamed from: a, reason: collision with root package name */
    WebViewProviderBoundaryInterface f699a;

    public p(WebViewProviderBoundaryInterface webViewProviderBoundaryInterface) {
        this.f699a = webViewProviderBoundaryInterface;
    }

    public void a(String str, String[] strArr, i.a aVar) {
        this.f699a.addWebMessageListener(str, strArr, org.chromium.support_lib_boundary.a.a.c(new k(aVar)));
    }

    public androidx.webkit.g[] b() {
        InvocationHandler[] createWebMessageChannel = this.f699a.createWebMessageChannel();
        androidx.webkit.g[] gVarArr = new androidx.webkit.g[createWebMessageChannel.length];
        for (int i2 = 0; i2 < createWebMessageChannel.length; i2++) {
            gVarArr[i2] = new l(createWebMessageChannel[i2]);
        }
        return gVarArr;
    }

    public void c(androidx.webkit.f fVar, Uri uri) {
        this.f699a.postMessageToMainFrame(org.chromium.support_lib_boundary.a.a.c(new i(fVar)), uri);
    }

    public void d(Executor executor, androidx.webkit.l lVar) {
        this.f699a.setWebViewRendererClient(lVar != null ? org.chromium.support_lib_boundary.a.a.c(new s(executor, lVar)) : null);
    }
}
