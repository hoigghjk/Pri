package androidx.webkit.m;

import java.lang.reflect.InvocationHandler;
import java.util.concurrent.Callable;
import org.chromium.support_lib_boundary.JsReplyProxyBoundaryInterface;

/* loaded from: classes.dex */
public class d extends androidx.webkit.a {

    /* renamed from: a, reason: collision with root package name */
    private JsReplyProxyBoundaryInterface f683a;

    class a implements Callable<Object> {
        final /* synthetic */ JsReplyProxyBoundaryInterface n;

        a(JsReplyProxyBoundaryInterface jsReplyProxyBoundaryInterface) {
            this.n = jsReplyProxyBoundaryInterface;
        }

        @Override // java.util.concurrent.Callable
        public Object call() {
            return new d(this.n);
        }
    }

    public d(JsReplyProxyBoundaryInterface jsReplyProxyBoundaryInterface) {
        this.f683a = jsReplyProxyBoundaryInterface;
    }

    public static d b(InvocationHandler invocationHandler) {
        JsReplyProxyBoundaryInterface jsReplyProxyBoundaryInterface = (JsReplyProxyBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(JsReplyProxyBoundaryInterface.class, invocationHandler);
        return (d) jsReplyProxyBoundaryInterface.getOrCreatePeer(new a(jsReplyProxyBoundaryInterface));
    }

    @Override // androidx.webkit.a
    public void a(String str) {
        if (!n.WEB_MESSAGE_LISTENER.n()) {
            throw n.h();
        }
        this.f683a.postMessage(str);
    }
}
