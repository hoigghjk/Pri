package androidx.webkit.m;

import androidx.webkit.g;
import java.lang.reflect.InvocationHandler;
import org.chromium.support_lib_boundary.WebMessageBoundaryInterface;
import org.chromium.support_lib_boundary.WebMessageCallbackBoundaryInterface;

/* loaded from: classes.dex */
public class j implements WebMessageCallbackBoundaryInterface {
    g.a n;

    public j(g.a aVar) {
        this.n = aVar;
    }

    @Override // org.chromium.support_lib_boundary.FeatureFlagHolderBoundaryInterface
    public String[] getSupportedFeatures() {
        return new String[]{"WEB_MESSAGE_CALLBACK_ON_MESSAGE"};
    }

    @Override // org.chromium.support_lib_boundary.WebMessageCallbackBoundaryInterface
    public void onMessage(InvocationHandler invocationHandler, InvocationHandler invocationHandler2) {
        this.n.onMessage(new l(invocationHandler), i.b((WebMessageBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(WebMessageBoundaryInterface.class, invocationHandler2)));
    }
}
