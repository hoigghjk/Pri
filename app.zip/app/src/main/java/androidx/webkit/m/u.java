package androidx.webkit.m;

import android.webkit.WebViewRenderProcess;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationHandler;
import java.util.WeakHashMap;
import java.util.concurrent.Callable;
import org.chromium.support_lib_boundary.WebViewRendererBoundaryInterface;

/* loaded from: classes.dex */
public class u extends androidx.webkit.k {

    /* renamed from: c, reason: collision with root package name */
    private static WeakHashMap<WebViewRenderProcess, u> f702c = new WeakHashMap<>();

    /* renamed from: a, reason: collision with root package name */
    private WebViewRendererBoundaryInterface f703a;

    /* renamed from: b, reason: collision with root package name */
    private WeakReference<WebViewRenderProcess> f704b;

    class a implements Callable<Object> {
        final /* synthetic */ WebViewRendererBoundaryInterface n;

        a(WebViewRendererBoundaryInterface webViewRendererBoundaryInterface) {
            this.n = webViewRendererBoundaryInterface;
        }

        @Override // java.util.concurrent.Callable
        public Object call() {
            return new u(this.n);
        }
    }

    public u(WebViewRenderProcess webViewRenderProcess) {
        this.f704b = new WeakReference<>(webViewRenderProcess);
    }

    public u(WebViewRendererBoundaryInterface webViewRendererBoundaryInterface) {
        this.f703a = webViewRendererBoundaryInterface;
    }

    public static u b(WebViewRenderProcess webViewRenderProcess) {
        u uVar = f702c.get(webViewRenderProcess);
        if (uVar != null) {
            return uVar;
        }
        u uVar2 = new u(webViewRenderProcess);
        f702c.put(webViewRenderProcess, uVar2);
        return uVar2;
    }

    public static u c(InvocationHandler invocationHandler) {
        WebViewRendererBoundaryInterface webViewRendererBoundaryInterface = (WebViewRendererBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(WebViewRendererBoundaryInterface.class, invocationHandler);
        return (u) webViewRendererBoundaryInterface.getOrCreatePeer(new a(webViewRendererBoundaryInterface));
    }

    @Override // androidx.webkit.k
    public boolean a() {
        n nVar = n.WEB_VIEW_RENDERER_TERMINATE;
        if (!nVar.m()) {
            if (nVar.n()) {
                return this.f703a.terminate();
            }
            throw n.h();
        }
        WebViewRenderProcess webViewRenderProcess = this.f704b.get();
        if (webViewRenderProcess != null) {
            return webViewRenderProcess.terminate();
        }
        return false;
    }
}
