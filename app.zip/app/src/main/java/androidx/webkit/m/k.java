package androidx.webkit.m;

import android.net.Uri;
import android.webkit.WebView;
import androidx.webkit.i;
import java.lang.reflect.InvocationHandler;
import org.chromium.support_lib_boundary.WebMessageBoundaryInterface;
import org.chromium.support_lib_boundary.WebMessageListenerBoundaryInterface;

/* loaded from: classes.dex */
public class k implements WebMessageListenerBoundaryInterface {
    private i.a n;

    public k(i.a aVar) {
        this.n = aVar;
    }

    @Override // org.chromium.support_lib_boundary.FeatureFlagHolderBoundaryInterface
    public String[] getSupportedFeatures() {
        return new String[]{"WEB_MESSAGE_LISTENER"};
    }

    @Override // org.chromium.support_lib_boundary.WebMessageListenerBoundaryInterface
    public void onPostMessage(WebView webView, InvocationHandler invocationHandler, Uri uri, boolean z, InvocationHandler invocationHandler2) {
        this.n.onPostMessage(webView, i.b((WebMessageBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(WebMessageBoundaryInterface.class, invocationHandler)), uri, z, d.b(invocationHandler2));
    }
}
