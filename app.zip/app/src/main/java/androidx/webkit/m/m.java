package androidx.webkit.m;

import android.webkit.WebResourceError;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.chromium.support_lib_boundary.WebResourceErrorBoundaryInterface;

/* loaded from: classes.dex */
public class m extends androidx.webkit.h {

    /* renamed from: a, reason: collision with root package name */
    private WebResourceError f694a;

    /* renamed from: b, reason: collision with root package name */
    private WebResourceErrorBoundaryInterface f695b;

    public m(WebResourceError webResourceError) {
        this.f694a = webResourceError;
    }

    public m(InvocationHandler invocationHandler) {
        this.f695b = (WebResourceErrorBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(WebResourceErrorBoundaryInterface.class, invocationHandler);
    }

    private WebResourceErrorBoundaryInterface c() {
        if (this.f695b == null) {
            this.f695b = (WebResourceErrorBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(WebResourceErrorBoundaryInterface.class, o.c().h(this.f694a));
        }
        return this.f695b;
    }

    private WebResourceError d() {
        if (this.f694a == null) {
            this.f694a = o.c().g(Proxy.getInvocationHandler(this.f695b));
        }
        return this.f694a;
    }

    @Override // androidx.webkit.h
    public CharSequence a() {
        n nVar = n.WEB_RESOURCE_ERROR_GET_DESCRIPTION;
        if (nVar.m()) {
            return d().getDescription();
        }
        if (nVar.n()) {
            return c().getDescription();
        }
        throw n.h();
    }

    @Override // androidx.webkit.h
    public int b() {
        n nVar = n.WEB_RESOURCE_ERROR_GET_CODE;
        if (nVar.m()) {
            return d().getErrorCode();
        }
        if (nVar.n()) {
            return c().getErrorCode();
        }
        throw n.h();
    }
}
