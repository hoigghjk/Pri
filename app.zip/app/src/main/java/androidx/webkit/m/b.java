package androidx.webkit.m;

import android.webkit.ServiceWorkerClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

/* loaded from: classes.dex */
public class b extends ServiceWorkerClient {

    /* renamed from: a, reason: collision with root package name */
    private final androidx.webkit.c f681a;

    public b(androidx.webkit.c cVar) {
        this.f681a = cVar;
    }

    @Override // android.webkit.ServiceWorkerClient
    public WebResourceResponse shouldInterceptRequest(WebResourceRequest webResourceRequest) {
        return this.f681a.shouldInterceptRequest(webResourceRequest);
    }
}
