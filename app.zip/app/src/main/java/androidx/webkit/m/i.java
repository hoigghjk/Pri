package androidx.webkit.m;

import java.lang.reflect.InvocationHandler;
import org.chromium.support_lib_boundary.WebMessageBoundaryInterface;

/* loaded from: classes.dex */
public class i implements WebMessageBoundaryInterface {
    private androidx.webkit.f n;

    public i(androidx.webkit.f fVar) {
        this.n = fVar;
    }

    private static androidx.webkit.g[] a(InvocationHandler[] invocationHandlerArr) {
        androidx.webkit.g[] gVarArr = new androidx.webkit.g[invocationHandlerArr.length];
        for (int i2 = 0; i2 < invocationHandlerArr.length; i2++) {
            gVarArr[i2] = new l(invocationHandlerArr[i2]);
        }
        return gVarArr;
    }

    public static androidx.webkit.f b(WebMessageBoundaryInterface webMessageBoundaryInterface) {
        return new androidx.webkit.f(webMessageBoundaryInterface.getData(), a(webMessageBoundaryInterface.getPorts()));
    }

    @Override // org.chromium.support_lib_boundary.WebMessageBoundaryInterface
    public String getData() {
        return this.n.a();
    }

    @Override // org.chromium.support_lib_boundary.WebMessageBoundaryInterface
    public InvocationHandler[] getPorts() {
        androidx.webkit.g[] b2 = this.n.b();
        if (b2 == null) {
            return null;
        }
        InvocationHandler[] invocationHandlerArr = new InvocationHandler[b2.length];
        for (int i2 = 0; i2 < b2.length; i2++) {
            invocationHandlerArr[i2] = b2[i2].c();
        }
        return invocationHandlerArr;
    }

    @Override // org.chromium.support_lib_boundary.FeatureFlagHolderBoundaryInterface
    public String[] getSupportedFeatures() {
        return new String[0];
    }
}
