package androidx.webkit.m;

import android.webkit.ServiceWorkerWebSettings;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.chromium.support_lib_boundary.ServiceWorkerWebSettingsBoundaryInterface;

/* loaded from: classes.dex */
public class h extends androidx.webkit.e {

    /* renamed from: a, reason: collision with root package name */
    private ServiceWorkerWebSettings f689a;

    /* renamed from: b, reason: collision with root package name */
    private ServiceWorkerWebSettingsBoundaryInterface f690b;

    public h(ServiceWorkerWebSettings serviceWorkerWebSettings) {
        this.f689a = serviceWorkerWebSettings;
    }

    public h(InvocationHandler invocationHandler) {
        this.f690b = (ServiceWorkerWebSettingsBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(ServiceWorkerWebSettingsBoundaryInterface.class, invocationHandler);
    }

    private ServiceWorkerWebSettingsBoundaryInterface i() {
        if (this.f690b == null) {
            this.f690b = (ServiceWorkerWebSettingsBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(ServiceWorkerWebSettingsBoundaryInterface.class, o.c().d(this.f689a));
        }
        return this.f690b;
    }

    private ServiceWorkerWebSettings j() {
        if (this.f689a == null) {
            this.f689a = o.c().c(Proxy.getInvocationHandler(this.f690b));
        }
        return this.f689a;
    }

    @Override // androidx.webkit.e
    public boolean a() {
        n nVar = n.SERVICE_WORKER_CONTENT_ACCESS;
        if (nVar.m()) {
            return j().getAllowContentAccess();
        }
        if (nVar.n()) {
            return i().getAllowContentAccess();
        }
        throw n.h();
    }

    @Override // androidx.webkit.e
    public boolean b() {
        n nVar = n.SERVICE_WORKER_FILE_ACCESS;
        if (nVar.m()) {
            return j().getAllowFileAccess();
        }
        if (nVar.n()) {
            return i().getAllowFileAccess();
        }
        throw n.h();
    }

    @Override // androidx.webkit.e
    public boolean c() {
        n nVar = n.SERVICE_WORKER_BLOCK_NETWORK_LOADS;
        if (nVar.m()) {
            return j().getBlockNetworkLoads();
        }
        if (nVar.n()) {
            return i().getBlockNetworkLoads();
        }
        throw n.h();
    }

    @Override // androidx.webkit.e
    public int d() {
        n nVar = n.SERVICE_WORKER_CACHE_MODE;
        if (nVar.m()) {
            return j().getCacheMode();
        }
        if (nVar.n()) {
            return i().getCacheMode();
        }
        throw n.h();
    }

    @Override // androidx.webkit.e
    public void e(boolean z) {
        n nVar = n.SERVICE_WORKER_CONTENT_ACCESS;
        if (nVar.m()) {
            j().setAllowContentAccess(z);
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            i().setAllowContentAccess(z);
        }
    }

    @Override // androidx.webkit.e
    public void f(boolean z) {
        n nVar = n.SERVICE_WORKER_FILE_ACCESS;
        if (nVar.m()) {
            j().setAllowFileAccess(z);
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            i().setAllowFileAccess(z);
        }
    }

    @Override // androidx.webkit.e
    public void g(boolean z) {
        n nVar = n.SERVICE_WORKER_BLOCK_NETWORK_LOADS;
        if (nVar.m()) {
            j().setBlockNetworkLoads(z);
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            i().setBlockNetworkLoads(z);
        }
    }

    @Override // androidx.webkit.e
    public void h(int i2) {
        n nVar = n.SERVICE_WORKER_CACHE_MODE;
        if (nVar.m()) {
            j().setCacheMode(i2);
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            i().setCacheMode(i2);
        }
    }
}
