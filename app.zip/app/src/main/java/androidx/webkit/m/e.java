package androidx.webkit.m;

import android.webkit.SafeBrowsingResponse;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.chromium.support_lib_boundary.SafeBrowsingResponseBoundaryInterface;

/* loaded from: classes.dex */
public class e extends androidx.webkit.b {

    /* renamed from: a, reason: collision with root package name */
    private SafeBrowsingResponse f684a;

    /* renamed from: b, reason: collision with root package name */
    private SafeBrowsingResponseBoundaryInterface f685b;

    public e(SafeBrowsingResponse safeBrowsingResponse) {
        this.f684a = safeBrowsingResponse;
    }

    public e(InvocationHandler invocationHandler) {
        this.f685b = (SafeBrowsingResponseBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(SafeBrowsingResponseBoundaryInterface.class, invocationHandler);
    }

    private SafeBrowsingResponseBoundaryInterface b() {
        if (this.f685b == null) {
            this.f685b = (SafeBrowsingResponseBoundaryInterface) org.chromium.support_lib_boundary.a.a.a(SafeBrowsingResponseBoundaryInterface.class, o.c().b(this.f684a));
        }
        return this.f685b;
    }

    private SafeBrowsingResponse c() {
        if (this.f684a == null) {
            this.f684a = o.c().a(Proxy.getInvocationHandler(this.f685b));
        }
        return this.f684a;
    }

    @Override // androidx.webkit.b
    public void a(boolean z) {
        n nVar = n.SAFE_BROWSING_RESPONSE_SHOW_INTERSTITIAL;
        if (nVar.m()) {
            c().showInterstitial(z);
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            b().showInterstitial(z);
        }
    }
}
