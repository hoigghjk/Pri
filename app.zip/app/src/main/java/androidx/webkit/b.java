package androidx.webkit;

/* loaded from: classes.dex */
public abstract class b {
    public abstract void a(boolean z);
}
