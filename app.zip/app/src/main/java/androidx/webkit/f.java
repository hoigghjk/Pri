package androidx.webkit;

/* loaded from: classes.dex */
public class f {

    /* renamed from: a, reason: collision with root package name */
    private String f677a;

    /* renamed from: b, reason: collision with root package name */
    private g[] f678b;

    public f(String str, g[] gVarArr) {
        this.f677a = str;
        this.f678b = gVarArr;
    }

    public String a() {
        return this.f677a;
    }

    public g[] b() {
        return this.f678b;
    }
}
