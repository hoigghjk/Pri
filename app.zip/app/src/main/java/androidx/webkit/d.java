package androidx.webkit;

/* loaded from: classes.dex */
public abstract class d {

    private static class a {

        /* renamed from: a, reason: collision with root package name */
        static final d f676a = new androidx.webkit.m.g();
    }

    public static d a() {
        return a.f676a;
    }

    public abstract e b();

    public abstract void c(c cVar);
}
