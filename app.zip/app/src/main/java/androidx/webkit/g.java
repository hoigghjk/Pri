package androidx.webkit;

import android.webkit.WebMessagePort;
import java.lang.reflect.InvocationHandler;

/* loaded from: classes.dex */
public abstract class g {

    public static abstract class a {
        public void onMessage(g gVar, f fVar) {
        }
    }

    public abstract void a();

    public abstract WebMessagePort b();

    public abstract InvocationHandler c();

    public abstract void d(f fVar);

    public abstract void e(a aVar);
}
