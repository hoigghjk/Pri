package androidx.webkit;

/* loaded from: classes.dex */
public abstract class a {
    public abstract void a(String str);
}
