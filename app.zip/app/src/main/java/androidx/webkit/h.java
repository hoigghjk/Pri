package androidx.webkit;

/* loaded from: classes.dex */
public abstract class h {
    public abstract CharSequence a();

    public abstract int b();
}
