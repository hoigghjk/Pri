package androidx.webkit;

/* loaded from: classes.dex */
public abstract class k {
    public abstract boolean a();
}
