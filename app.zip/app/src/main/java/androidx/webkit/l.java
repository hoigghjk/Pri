package androidx.webkit;

import android.webkit.WebView;

/* loaded from: classes.dex */
public abstract class l {
    public abstract void onRenderProcessResponsive(WebView webView, k kVar);

    public abstract void onRenderProcessUnresponsive(WebView webView, k kVar);
}
