package androidx.webkit;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import androidx.webkit.m.n;
import androidx.webkit.m.o;
import androidx.webkit.m.p;
import androidx.webkit.m.q;
import androidx.webkit.m.t;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.chromium.support_lib_boundary.WebViewProviderBoundaryInterface;

/* loaded from: classes.dex */
public class i {

    /* renamed from: a, reason: collision with root package name */
    private static final Uri f679a = Uri.parse("*");

    /* renamed from: b, reason: collision with root package name */
    private static final Uri f680b = Uri.parse("");

    public interface a {
        void onPostMessage(WebView webView, f fVar, Uri uri, boolean z, androidx.webkit.a aVar);
    }

    public static void a(WebView webView, String str, Set<String> set, a aVar) {
        if (Build.VERSION.SDK_INT < 21) {
            throw new AssertionError("Should be on Lollipop and above.");
        }
        if (!n.WEB_MESSAGE_LISTENER.n()) {
            throw n.h();
        }
        h(webView).a(str, (String[]) set.toArray(new String[0]), aVar);
    }

    private static WebViewProviderBoundaryInterface b(WebView webView) {
        return e().createWebView(webView);
    }

    public static g[] c(WebView webView) {
        n nVar = n.CREATE_WEB_MESSAGE_CHANNEL;
        if (nVar.m()) {
            return androidx.webkit.m.l.k(webView.createWebMessageChannel());
        }
        if (nVar.n()) {
            return h(webView).b();
        }
        throw n.h();
    }

    public static PackageInfo d(Context context) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 < 21) {
            return null;
        }
        if (i2 >= 26) {
            return WebView.getCurrentWebViewPackage();
        }
        try {
            PackageInfo f2 = f();
            return f2 != null ? f2 : g(context);
        } catch (ClassNotFoundException | IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
            return null;
        }
    }

    private static q e() {
        return o.d();
    }

    private static PackageInfo f() {
        return (PackageInfo) Class.forName("android.webkit.WebViewFactory").getMethod("getLoadedPackageInfo", new Class[0]).invoke(null, new Object[0]);
    }

    private static PackageInfo g(Context context) {
        try {
            int i2 = Build.VERSION.SDK_INT;
            String str = (String) ((i2 < 21 || i2 > 23) ? Class.forName("android.webkit.WebViewUpdateService").getMethod("getCurrentWebViewPackageName", new Class[0]).invoke(null, new Object[0]) : Class.forName("android.webkit.WebViewFactory").getMethod("getWebViewPackageName", new Class[0]).invoke(null, new Object[0]));
            if (str == null) {
                return null;
            }
            return context.getPackageManager().getPackageInfo(str, 0);
        } catch (PackageManager.NameNotFoundException | ClassNotFoundException | IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
            return null;
        }
    }

    private static p h(WebView webView) {
        return new p(b(webView));
    }

    public static Uri i() {
        n nVar = n.SAFE_BROWSING_PRIVACY_POLICY_URL;
        if (nVar.m()) {
            return WebView.getSafeBrowsingPrivacyPolicyUrl();
        }
        if (nVar.n()) {
            return e().getStatics().getSafeBrowsingPrivacyPolicyUrl();
        }
        throw n.h();
    }

    public static void j(WebView webView, f fVar, Uri uri) {
        if (f679a.equals(uri)) {
            uri = f680b;
        }
        n nVar = n.POST_WEB_MESSAGE;
        if (nVar.m()) {
            webView.postWebMessage(androidx.webkit.m.l.f(fVar), uri);
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            h(webView).c(fVar, uri);
        }
    }

    public static void k(Set<String> set, ValueCallback<Boolean> valueCallback) {
        n nVar = n.SAFE_BROWSING_ALLOWLIST_PREFERRED_TO_PREFERRED;
        n nVar2 = n.SAFE_BROWSING_ALLOWLIST_PREFERRED_TO_DEPRECATED;
        if (nVar.n()) {
            e().getStatics().setSafeBrowsingAllowlist(set, valueCallback);
            return;
        }
        ArrayList arrayList = new ArrayList(set);
        if (nVar2.m()) {
            WebView.setSafeBrowsingWhitelist(arrayList, valueCallback);
        } else {
            if (!nVar2.n()) {
                throw n.h();
            }
            e().getStatics().setSafeBrowsingWhitelist(arrayList, valueCallback);
        }
    }

    @Deprecated
    public static void l(List<String> list, ValueCallback<Boolean> valueCallback) {
        k(new HashSet(list), valueCallback);
    }

    public static void m(WebView webView, l lVar) {
        n nVar = n.WEB_VIEW_RENDERER_CLIENT_BASIC_USAGE;
        if (nVar.m()) {
            webView.setWebViewRenderProcessClient(lVar != null ? new t(lVar) : null);
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            h(webView).d(null, lVar);
        }
    }

    public static void n(Context context, ValueCallback<Boolean> valueCallback) {
        n nVar = n.START_SAFE_BROWSING;
        if (nVar.m()) {
            WebView.startSafeBrowsing(context, valueCallback);
        } else {
            if (!nVar.n()) {
                throw n.h();
            }
            e().getStatics().initSafeBrowsing(context, valueCallback);
        }
    }
}
