package androidx.webkit;

import androidx.webkit.m.n;

/* loaded from: classes.dex */
public class j {
    public static boolean a(String str) {
        return n.i(str);
    }
}
