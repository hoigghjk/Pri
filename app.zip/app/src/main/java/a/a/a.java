package a.a;

import android.content.Context;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/* loaded from: classes.dex */
public class a {

    /* renamed from: a.a.a$a, reason: collision with other inner class name */
    static class C0000a extends PrintDocumentAdapter.LayoutResultCallback {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ Context f0a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ b f1b;

        /* renamed from: c, reason: collision with root package name */
        final /* synthetic */ PrintDocumentAdapter f2c;

        /* renamed from: a.a.a$a$a, reason: collision with other inner class name */
        class C0001a extends PrintDocumentAdapter.WriteResultCallback {

            /* renamed from: a, reason: collision with root package name */
            final /* synthetic */ File f3a;

            C0001a(File file) {
                this.f3a = file;
            }

            @Override // android.print.PrintDocumentAdapter.WriteResultCallback
            public void onWriteFinished(PageRange[] pageRangeArr) {
                super.onWriteFinished(pageRangeArr);
                if (pageRangeArr.length == 0) {
                    if (!this.f3a.delete()) {
                        Log.e("PDF", "Unable to delete temporary file");
                    }
                    C0000a.this.f1b.a("No page created");
                }
                C0000a.this.f1b.b(this.f3a);
                if (this.f3a.delete()) {
                    return;
                }
                Log.e("PDF", "Unable to delete temporary file");
            }
        }

        C0000a(Context context, b bVar, PrintDocumentAdapter printDocumentAdapter) {
            this.f0a = context;
            this.f1b = bVar;
            this.f2c = printDocumentAdapter;
        }

        @Override // android.print.PrintDocumentAdapter.LayoutResultCallback
        public void onLayoutFinished(PrintDocumentInfo printDocumentInfo, boolean z) {
            try {
                File createTempFile = File.createTempFile("printing", "pdf", this.f0a.getCacheDir());
                try {
                    this.f2c.onWrite(new PageRange[]{PageRange.ALL_PAGES}, ParcelFileDescriptor.open(createTempFile, 805306368), new CancellationSignal(), new C0001a(createTempFile));
                } catch (FileNotFoundException e2) {
                    if (!createTempFile.delete()) {
                        Log.e("PDF", "Unable to delete temporary file");
                    }
                    this.f1b.a(e2.getMessage());
                }
            } catch (IOException e3) {
                this.f1b.a(e3.getMessage());
            }
        }
    }

    public interface b {
        void a(String str);

        void b(File file);
    }

    public static void a(Context context, PrintDocumentAdapter printDocumentAdapter, PrintAttributes printAttributes, b bVar) {
        printDocumentAdapter.onLayout(null, printAttributes, null, new C0000a(context, bVar, printDocumentAdapter), null);
    }

    public static byte[] b(File file) {
        byte[] bArr = new byte[(int) file.length()];
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            if (fileInputStream.read(bArr) == -1) {
                throw new IOException("EOF reached while trying to read the whole file");
            }
            fileInputStream.close();
            return bArr;
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                try {
                    fileInputStream.close();
                } catch (Throwable th3) {
                    th.addSuppressed(th3);
                }
                throw th2;
            }
        }
    }
}
