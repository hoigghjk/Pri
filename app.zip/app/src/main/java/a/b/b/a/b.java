package a.b.b.a;

import a.b.b.a.a;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new a();
    final Handler n = null;
    a.b.b.a.a o;

    class a implements Parcelable.Creator<b> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a, reason: merged with bridge method [inline-methods] */
        public b createFromParcel(Parcel parcel) {
            return new b(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public b[] newArray(int i2) {
            return new b[i2];
        }
    }

    /* renamed from: a.b.b.a.b$b, reason: collision with other inner class name */
    class BinderC0006b extends a.AbstractBinderC0004a {
        BinderC0006b() {
        }

        @Override // a.b.b.a.a
        public void C1(int i2, Bundle bundle) {
            b bVar = b.this;
            Handler handler = bVar.n;
            if (handler != null) {
                handler.post(bVar.new c(i2, bundle));
            } else {
                bVar.a(i2, bundle);
            }
        }
    }

    class c implements Runnable {
        final int n;
        final Bundle o;

        c(int i2, Bundle bundle) {
            this.n = i2;
            this.o = bundle;
        }

        @Override // java.lang.Runnable
        public void run() {
            b.this.a(this.n, this.o);
        }
    }

    b(Parcel parcel) {
        this.o = a.AbstractBinderC0004a.c(parcel.readStrongBinder());
    }

    protected void a(int i2, Bundle bundle) {
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        synchronized (this) {
            if (this.o == null) {
                this.o = new BinderC0006b();
            }
            parcel.writeStrongBinder(this.o.asBinder());
        }
    }
}
