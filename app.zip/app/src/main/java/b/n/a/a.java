package b.n.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: f, reason: collision with root package name */
    private static final Object f1353f = new Object();

    /* renamed from: g, reason: collision with root package name */
    private static a f1354g;

    /* renamed from: a, reason: collision with root package name */
    private final Context f1355a;

    /* renamed from: b, reason: collision with root package name */
    private final HashMap<BroadcastReceiver, ArrayList<c>> f1356b = new HashMap<>();

    /* renamed from: c, reason: collision with root package name */
    private final HashMap<String, ArrayList<c>> f1357c = new HashMap<>();

    /* renamed from: d, reason: collision with root package name */
    private final ArrayList<b> f1358d = new ArrayList<>();

    /* renamed from: e, reason: collision with root package name */
    private final Handler f1359e;

    /* renamed from: b.n.a.a$a, reason: collision with other inner class name */
    class HandlerC0052a extends Handler {
        HandlerC0052a(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (message.what != 1) {
                super.handleMessage(message);
            } else {
                a.this.a();
            }
        }
    }

    private static final class b {

        /* renamed from: a, reason: collision with root package name */
        final Intent f1361a;

        /* renamed from: b, reason: collision with root package name */
        final ArrayList<c> f1362b;

        b(Intent intent, ArrayList<c> arrayList) {
            this.f1361a = intent;
            this.f1362b = arrayList;
        }
    }

    private static final class c {

        /* renamed from: a, reason: collision with root package name */
        final IntentFilter f1363a;

        /* renamed from: b, reason: collision with root package name */
        final BroadcastReceiver f1364b;

        /* renamed from: c, reason: collision with root package name */
        boolean f1365c;

        /* renamed from: d, reason: collision with root package name */
        boolean f1366d;

        c(IntentFilter intentFilter, BroadcastReceiver broadcastReceiver) {
            this.f1363a = intentFilter;
            this.f1364b = broadcastReceiver;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(128);
            sb.append("Receiver{");
            sb.append(this.f1364b);
            sb.append(" filter=");
            sb.append(this.f1363a);
            if (this.f1366d) {
                sb.append(" DEAD");
            }
            sb.append("}");
            return sb.toString();
        }
    }

    private a(Context context) {
        this.f1355a = context;
        this.f1359e = new HandlerC0052a(context.getMainLooper());
    }

    public static a b(Context context) {
        a aVar;
        synchronized (f1353f) {
            if (f1354g == null) {
                f1354g = new a(context.getApplicationContext());
            }
            aVar = f1354g;
        }
        return aVar;
    }

    void a() {
        int size;
        b[] bVarArr;
        while (true) {
            synchronized (this.f1356b) {
                size = this.f1358d.size();
                if (size <= 0) {
                    return;
                }
                bVarArr = new b[size];
                this.f1358d.toArray(bVarArr);
                this.f1358d.clear();
            }
            for (int i2 = 0; i2 < size; i2++) {
                b bVar = bVarArr[i2];
                int size2 = bVar.f1362b.size();
                for (int i3 = 0; i3 < size2; i3++) {
                    c cVar = bVar.f1362b.get(i3);
                    if (!cVar.f1366d) {
                        cVar.f1364b.onReceive(this.f1355a, bVar.f1361a);
                    }
                }
            }
        }
    }

    public void c(BroadcastReceiver broadcastReceiver, IntentFilter intentFilter) {
        synchronized (this.f1356b) {
            c cVar = new c(intentFilter, broadcastReceiver);
            ArrayList<c> arrayList = this.f1356b.get(broadcastReceiver);
            if (arrayList == null) {
                arrayList = new ArrayList<>(1);
                this.f1356b.put(broadcastReceiver, arrayList);
            }
            arrayList.add(cVar);
            for (int i2 = 0; i2 < intentFilter.countActions(); i2++) {
                String action = intentFilter.getAction(i2);
                ArrayList<c> arrayList2 = this.f1357c.get(action);
                if (arrayList2 == null) {
                    arrayList2 = new ArrayList<>(1);
                    this.f1357c.put(action, arrayList2);
                }
                arrayList2.add(cVar);
            }
        }
    }

    public boolean d(Intent intent) {
        int i2;
        String str;
        ArrayList arrayList;
        ArrayList<c> arrayList2;
        String str2;
        synchronized (this.f1356b) {
            String action = intent.getAction();
            String resolveTypeIfNeeded = intent.resolveTypeIfNeeded(this.f1355a.getContentResolver());
            Uri data = intent.getData();
            String scheme = intent.getScheme();
            Set<String> categories = intent.getCategories();
            boolean z = (intent.getFlags() & 8) != 0;
            if (z) {
                Log.v("LocalBroadcastManager", "Resolving type " + resolveTypeIfNeeded + " scheme " + scheme + " of intent " + intent);
            }
            ArrayList<c> arrayList3 = this.f1357c.get(intent.getAction());
            if (arrayList3 != null) {
                if (z) {
                    Log.v("LocalBroadcastManager", "Action list: " + arrayList3);
                }
                ArrayList arrayList4 = null;
                int i3 = 0;
                while (i3 < arrayList3.size()) {
                    c cVar = arrayList3.get(i3);
                    if (z) {
                        Log.v("LocalBroadcastManager", "Matching against filter " + cVar.f1363a);
                    }
                    if (cVar.f1365c) {
                        if (z) {
                            Log.v("LocalBroadcastManager", "  Filter's target already added");
                        }
                        i2 = i3;
                        arrayList2 = arrayList3;
                        str = action;
                        str2 = resolveTypeIfNeeded;
                        arrayList = arrayList4;
                    } else {
                        i2 = i3;
                        str = action;
                        arrayList = arrayList4;
                        arrayList2 = arrayList3;
                        str2 = resolveTypeIfNeeded;
                        int match = cVar.f1363a.match(action, resolveTypeIfNeeded, scheme, data, categories, "LocalBroadcastManager");
                        if (match >= 0) {
                            if (z) {
                                Log.v("LocalBroadcastManager", "  Filter matched!  match=0x" + Integer.toHexString(match));
                            }
                            arrayList4 = arrayList == null ? new ArrayList() : arrayList;
                            arrayList4.add(cVar);
                            cVar.f1365c = true;
                            i3 = i2 + 1;
                            action = str;
                            arrayList3 = arrayList2;
                            resolveTypeIfNeeded = str2;
                        } else if (z) {
                            Log.v("LocalBroadcastManager", "  Filter did not match: " + (match != -4 ? match != -3 ? match != -2 ? match != -1 ? "unknown reason" : "type" : "data" : "action" : "category"));
                        }
                    }
                    arrayList4 = arrayList;
                    i3 = i2 + 1;
                    action = str;
                    arrayList3 = arrayList2;
                    resolveTypeIfNeeded = str2;
                }
                ArrayList arrayList5 = arrayList4;
                if (arrayList5 != null) {
                    for (int i4 = 0; i4 < arrayList5.size(); i4++) {
                        ((c) arrayList5.get(i4)).f1365c = false;
                    }
                    this.f1358d.add(new b(intent, arrayList5));
                    if (!this.f1359e.hasMessages(1)) {
                        this.f1359e.sendEmptyMessage(1);
                    }
                    return true;
                }
            }
            return false;
        }
    }

    public void e(BroadcastReceiver broadcastReceiver) {
        synchronized (this.f1356b) {
            ArrayList<c> remove = this.f1356b.remove(broadcastReceiver);
            if (remove == null) {
                return;
            }
            for (int size = remove.size() - 1; size >= 0; size--) {
                c cVar = remove.get(size);
                cVar.f1366d = true;
                for (int i2 = 0; i2 < cVar.f1363a.countActions(); i2++) {
                    String action = cVar.f1363a.getAction(i2);
                    ArrayList<c> arrayList = this.f1357c.get(action);
                    if (arrayList != null) {
                        for (int size2 = arrayList.size() - 1; size2 >= 0; size2--) {
                            c cVar2 = arrayList.get(size2);
                            if (cVar2.f1364b == broadcastReceiver) {
                                cVar2.f1366d = true;
                                arrayList.remove(size2);
                            }
                        }
                        if (arrayList.size() <= 0) {
                            this.f1357c.remove(action);
                        }
                    }
                }
            }
        }
    }
}
