package b.q.a.a;

import android.graphics.drawable.Drawable;

/* loaded from: classes.dex */
public abstract class b {
    public void a(Drawable drawable) {
    }
}
