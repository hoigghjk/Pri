package b.q.a.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.VectorDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import b.g.f.c;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public class i extends b.q.a.a.h {
    static final PorterDuff.Mode w = PorterDuff.Mode.SRC_IN;
    private h o;
    private PorterDuffColorFilter p;
    private ColorFilter q;
    private boolean r;
    private boolean s;
    private final float[] t;
    private final Matrix u;
    private final Rect v;

    private static class b extends f {
        b() {
        }

        b(b bVar) {
            super(bVar);
        }

        private void f(TypedArray typedArray, XmlPullParser xmlPullParser) {
            String string = typedArray.getString(0);
            if (string != null) {
                this.f1426b = string;
            }
            String string2 = typedArray.getString(1);
            if (string2 != null) {
                this.f1425a = b.g.f.c.d(string2);
            }
            this.f1427c = b.g.e.e.g.g(typedArray, xmlPullParser, "fillType", 2, 0);
        }

        @Override // b.q.a.a.i.f
        public boolean c() {
            return true;
        }

        public void e(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            if (b.g.e.e.g.j(xmlPullParser, "pathData")) {
                TypedArray k2 = b.g.e.e.g.k(resources, theme, attributeSet, b.q.a.a.a.f1389d);
                f(k2, xmlPullParser);
                k2.recycle();
            }
        }
    }

    private static class c extends f {

        /* renamed from: e, reason: collision with root package name */
        private int[] f1407e;

        /* renamed from: f, reason: collision with root package name */
        b.g.e.e.b f1408f;

        /* renamed from: g, reason: collision with root package name */
        float f1409g;

        /* renamed from: h, reason: collision with root package name */
        b.g.e.e.b f1410h;

        /* renamed from: i, reason: collision with root package name */
        float f1411i;

        /* renamed from: j, reason: collision with root package name */
        float f1412j;

        /* renamed from: k, reason: collision with root package name */
        float f1413k;
        float l;
        float m;
        Paint.Cap n;
        Paint.Join o;
        float p;

        c() {
            this.f1409g = 0.0f;
            this.f1411i = 1.0f;
            this.f1412j = 1.0f;
            this.f1413k = 0.0f;
            this.l = 1.0f;
            this.m = 0.0f;
            this.n = Paint.Cap.BUTT;
            this.o = Paint.Join.MITER;
            this.p = 4.0f;
        }

        c(c cVar) {
            super(cVar);
            this.f1409g = 0.0f;
            this.f1411i = 1.0f;
            this.f1412j = 1.0f;
            this.f1413k = 0.0f;
            this.l = 1.0f;
            this.m = 0.0f;
            this.n = Paint.Cap.BUTT;
            this.o = Paint.Join.MITER;
            this.p = 4.0f;
            this.f1407e = cVar.f1407e;
            this.f1408f = cVar.f1408f;
            this.f1409g = cVar.f1409g;
            this.f1411i = cVar.f1411i;
            this.f1410h = cVar.f1410h;
            this.f1427c = cVar.f1427c;
            this.f1412j = cVar.f1412j;
            this.f1413k = cVar.f1413k;
            this.l = cVar.l;
            this.m = cVar.m;
            this.n = cVar.n;
            this.o = cVar.o;
            this.p = cVar.p;
        }

        private Paint.Cap e(int i2, Paint.Cap cap) {
            return i2 != 0 ? i2 != 1 ? i2 != 2 ? cap : Paint.Cap.SQUARE : Paint.Cap.ROUND : Paint.Cap.BUTT;
        }

        private Paint.Join f(int i2, Paint.Join join) {
            return i2 != 0 ? i2 != 1 ? i2 != 2 ? join : Paint.Join.BEVEL : Paint.Join.ROUND : Paint.Join.MITER;
        }

        private void h(TypedArray typedArray, XmlPullParser xmlPullParser, Resources.Theme theme) {
            this.f1407e = null;
            if (b.g.e.e.g.j(xmlPullParser, "pathData")) {
                String string = typedArray.getString(0);
                if (string != null) {
                    this.f1426b = string;
                }
                String string2 = typedArray.getString(2);
                if (string2 != null) {
                    this.f1425a = b.g.f.c.d(string2);
                }
                this.f1410h = b.g.e.e.g.e(typedArray, xmlPullParser, theme, "fillColor", 1, 0);
                this.f1412j = b.g.e.e.g.f(typedArray, xmlPullParser, "fillAlpha", 12, this.f1412j);
                this.n = e(b.g.e.e.g.g(typedArray, xmlPullParser, "strokeLineCap", 8, -1), this.n);
                this.o = f(b.g.e.e.g.g(typedArray, xmlPullParser, "strokeLineJoin", 9, -1), this.o);
                this.p = b.g.e.e.g.f(typedArray, xmlPullParser, "strokeMiterLimit", 10, this.p);
                this.f1408f = b.g.e.e.g.e(typedArray, xmlPullParser, theme, "strokeColor", 3, 0);
                this.f1411i = b.g.e.e.g.f(typedArray, xmlPullParser, "strokeAlpha", 11, this.f1411i);
                this.f1409g = b.g.e.e.g.f(typedArray, xmlPullParser, "strokeWidth", 4, this.f1409g);
                this.l = b.g.e.e.g.f(typedArray, xmlPullParser, "trimPathEnd", 6, this.l);
                this.m = b.g.e.e.g.f(typedArray, xmlPullParser, "trimPathOffset", 7, this.m);
                this.f1413k = b.g.e.e.g.f(typedArray, xmlPullParser, "trimPathStart", 5, this.f1413k);
                this.f1427c = b.g.e.e.g.g(typedArray, xmlPullParser, "fillType", 13, this.f1427c);
            }
        }

        @Override // b.q.a.a.i.e
        public boolean a() {
            return this.f1410h.i() || this.f1408f.i();
        }

        @Override // b.q.a.a.i.e
        public boolean b(int[] iArr) {
            return this.f1408f.j(iArr) | this.f1410h.j(iArr);
        }

        public void g(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            TypedArray k2 = b.g.e.e.g.k(resources, theme, attributeSet, b.q.a.a.a.f1388c);
            h(k2, xmlPullParser, theme);
            k2.recycle();
        }

        float getFillAlpha() {
            return this.f1412j;
        }

        int getFillColor() {
            return this.f1410h.e();
        }

        float getStrokeAlpha() {
            return this.f1411i;
        }

        int getStrokeColor() {
            return this.f1408f.e();
        }

        float getStrokeWidth() {
            return this.f1409g;
        }

        float getTrimPathEnd() {
            return this.l;
        }

        float getTrimPathOffset() {
            return this.m;
        }

        float getTrimPathStart() {
            return this.f1413k;
        }

        void setFillAlpha(float f2) {
            this.f1412j = f2;
        }

        void setFillColor(int i2) {
            this.f1410h.k(i2);
        }

        void setStrokeAlpha(float f2) {
            this.f1411i = f2;
        }

        void setStrokeColor(int i2) {
            this.f1408f.k(i2);
        }

        void setStrokeWidth(float f2) {
            this.f1409g = f2;
        }

        void setTrimPathEnd(float f2) {
            this.l = f2;
        }

        void setTrimPathOffset(float f2) {
            this.m = f2;
        }

        void setTrimPathStart(float f2) {
            this.f1413k = f2;
        }
    }

    private static class d extends e {

        /* renamed from: a, reason: collision with root package name */
        final Matrix f1414a;

        /* renamed from: b, reason: collision with root package name */
        final ArrayList<e> f1415b;

        /* renamed from: c, reason: collision with root package name */
        float f1416c;

        /* renamed from: d, reason: collision with root package name */
        private float f1417d;

        /* renamed from: e, reason: collision with root package name */
        private float f1418e;

        /* renamed from: f, reason: collision with root package name */
        private float f1419f;

        /* renamed from: g, reason: collision with root package name */
        private float f1420g;

        /* renamed from: h, reason: collision with root package name */
        private float f1421h;

        /* renamed from: i, reason: collision with root package name */
        private float f1422i;

        /* renamed from: j, reason: collision with root package name */
        final Matrix f1423j;

        /* renamed from: k, reason: collision with root package name */
        int f1424k;
        private int[] l;
        private String m;

        public d() {
            super();
            this.f1414a = new Matrix();
            this.f1415b = new ArrayList<>();
            this.f1416c = 0.0f;
            this.f1417d = 0.0f;
            this.f1418e = 0.0f;
            this.f1419f = 1.0f;
            this.f1420g = 1.0f;
            this.f1421h = 0.0f;
            this.f1422i = 0.0f;
            this.f1423j = new Matrix();
            this.m = null;
        }

        public d(d dVar, b.e.a<String, Object> aVar) {
            super();
            f bVar;
            this.f1414a = new Matrix();
            this.f1415b = new ArrayList<>();
            this.f1416c = 0.0f;
            this.f1417d = 0.0f;
            this.f1418e = 0.0f;
            this.f1419f = 1.0f;
            this.f1420g = 1.0f;
            this.f1421h = 0.0f;
            this.f1422i = 0.0f;
            Matrix matrix = new Matrix();
            this.f1423j = matrix;
            this.m = null;
            this.f1416c = dVar.f1416c;
            this.f1417d = dVar.f1417d;
            this.f1418e = dVar.f1418e;
            this.f1419f = dVar.f1419f;
            this.f1420g = dVar.f1420g;
            this.f1421h = dVar.f1421h;
            this.f1422i = dVar.f1422i;
            this.l = dVar.l;
            String str = dVar.m;
            this.m = str;
            this.f1424k = dVar.f1424k;
            if (str != null) {
                aVar.put(str, this);
            }
            matrix.set(dVar.f1423j);
            ArrayList<e> arrayList = dVar.f1415b;
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                e eVar = arrayList.get(i2);
                if (eVar instanceof d) {
                    this.f1415b.add(new d((d) eVar, aVar));
                } else {
                    if (eVar instanceof c) {
                        bVar = new c((c) eVar);
                    } else {
                        if (!(eVar instanceof b)) {
                            throw new IllegalStateException("Unknown object in the tree!");
                        }
                        bVar = new b((b) eVar);
                    }
                    this.f1415b.add(bVar);
                    String str2 = bVar.f1426b;
                    if (str2 != null) {
                        aVar.put(str2, bVar);
                    }
                }
            }
        }

        private void d() {
            this.f1423j.reset();
            this.f1423j.postTranslate(-this.f1417d, -this.f1418e);
            this.f1423j.postScale(this.f1419f, this.f1420g);
            this.f1423j.postRotate(this.f1416c, 0.0f, 0.0f);
            this.f1423j.postTranslate(this.f1421h + this.f1417d, this.f1422i + this.f1418e);
        }

        private void e(TypedArray typedArray, XmlPullParser xmlPullParser) {
            this.l = null;
            this.f1416c = b.g.e.e.g.f(typedArray, xmlPullParser, "rotation", 5, this.f1416c);
            this.f1417d = typedArray.getFloat(1, this.f1417d);
            this.f1418e = typedArray.getFloat(2, this.f1418e);
            this.f1419f = b.g.e.e.g.f(typedArray, xmlPullParser, "scaleX", 3, this.f1419f);
            this.f1420g = b.g.e.e.g.f(typedArray, xmlPullParser, "scaleY", 4, this.f1420g);
            this.f1421h = b.g.e.e.g.f(typedArray, xmlPullParser, "translateX", 6, this.f1421h);
            this.f1422i = b.g.e.e.g.f(typedArray, xmlPullParser, "translateY", 7, this.f1422i);
            String string = typedArray.getString(0);
            if (string != null) {
                this.m = string;
            }
            d();
        }

        @Override // b.q.a.a.i.e
        public boolean a() {
            for (int i2 = 0; i2 < this.f1415b.size(); i2++) {
                if (this.f1415b.get(i2).a()) {
                    return true;
                }
            }
            return false;
        }

        @Override // b.q.a.a.i.e
        public boolean b(int[] iArr) {
            boolean z = false;
            for (int i2 = 0; i2 < this.f1415b.size(); i2++) {
                z |= this.f1415b.get(i2).b(iArr);
            }
            return z;
        }

        public void c(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            TypedArray k2 = b.g.e.e.g.k(resources, theme, attributeSet, b.q.a.a.a.f1387b);
            e(k2, xmlPullParser);
            k2.recycle();
        }

        public String getGroupName() {
            return this.m;
        }

        public Matrix getLocalMatrix() {
            return this.f1423j;
        }

        public float getPivotX() {
            return this.f1417d;
        }

        public float getPivotY() {
            return this.f1418e;
        }

        public float getRotation() {
            return this.f1416c;
        }

        public float getScaleX() {
            return this.f1419f;
        }

        public float getScaleY() {
            return this.f1420g;
        }

        public float getTranslateX() {
            return this.f1421h;
        }

        public float getTranslateY() {
            return this.f1422i;
        }

        public void setPivotX(float f2) {
            if (f2 != this.f1417d) {
                this.f1417d = f2;
                d();
            }
        }

        public void setPivotY(float f2) {
            if (f2 != this.f1418e) {
                this.f1418e = f2;
                d();
            }
        }

        public void setRotation(float f2) {
            if (f2 != this.f1416c) {
                this.f1416c = f2;
                d();
            }
        }

        public void setScaleX(float f2) {
            if (f2 != this.f1419f) {
                this.f1419f = f2;
                d();
            }
        }

        public void setScaleY(float f2) {
            if (f2 != this.f1420g) {
                this.f1420g = f2;
                d();
            }
        }

        public void setTranslateX(float f2) {
            if (f2 != this.f1421h) {
                this.f1421h = f2;
                d();
            }
        }

        public void setTranslateY(float f2) {
            if (f2 != this.f1422i) {
                this.f1422i = f2;
                d();
            }
        }
    }

    private static abstract class e {
        private e() {
        }

        public boolean a() {
            return false;
        }

        public boolean b(int[] iArr) {
            return false;
        }
    }

    private static abstract class f extends e {

        /* renamed from: a, reason: collision with root package name */
        protected c.b[] f1425a;

        /* renamed from: b, reason: collision with root package name */
        String f1426b;

        /* renamed from: c, reason: collision with root package name */
        int f1427c;

        /* renamed from: d, reason: collision with root package name */
        int f1428d;

        public f() {
            super();
            this.f1425a = null;
            this.f1427c = 0;
        }

        public f(f fVar) {
            super();
            this.f1425a = null;
            this.f1427c = 0;
            this.f1426b = fVar.f1426b;
            this.f1428d = fVar.f1428d;
            this.f1425a = b.g.f.c.f(fVar.f1425a);
        }

        public boolean c() {
            return false;
        }

        public void d(Path path) {
            path.reset();
            c.b[] bVarArr = this.f1425a;
            if (bVarArr != null) {
                c.b.e(bVarArr, path);
            }
        }

        public c.b[] getPathData() {
            return this.f1425a;
        }

        public String getPathName() {
            return this.f1426b;
        }

        public void setPathData(c.b[] bVarArr) {
            if (b.g.f.c.b(this.f1425a, bVarArr)) {
                b.g.f.c.j(this.f1425a, bVarArr);
            } else {
                this.f1425a = b.g.f.c.f(bVarArr);
            }
        }
    }

    private static class g {
        private static final Matrix q = new Matrix();

        /* renamed from: a, reason: collision with root package name */
        private final Path f1429a;

        /* renamed from: b, reason: collision with root package name */
        private final Path f1430b;

        /* renamed from: c, reason: collision with root package name */
        private final Matrix f1431c;

        /* renamed from: d, reason: collision with root package name */
        Paint f1432d;

        /* renamed from: e, reason: collision with root package name */
        Paint f1433e;

        /* renamed from: f, reason: collision with root package name */
        private PathMeasure f1434f;

        /* renamed from: g, reason: collision with root package name */
        private int f1435g;

        /* renamed from: h, reason: collision with root package name */
        final d f1436h;

        /* renamed from: i, reason: collision with root package name */
        float f1437i;

        /* renamed from: j, reason: collision with root package name */
        float f1438j;

        /* renamed from: k, reason: collision with root package name */
        float f1439k;
        float l;
        int m;
        String n;
        Boolean o;
        final b.e.a<String, Object> p;

        public g() {
            this.f1431c = new Matrix();
            this.f1437i = 0.0f;
            this.f1438j = 0.0f;
            this.f1439k = 0.0f;
            this.l = 0.0f;
            this.m = 255;
            this.n = null;
            this.o = null;
            this.p = new b.e.a<>();
            this.f1436h = new d();
            this.f1429a = new Path();
            this.f1430b = new Path();
        }

        public g(g gVar) {
            this.f1431c = new Matrix();
            this.f1437i = 0.0f;
            this.f1438j = 0.0f;
            this.f1439k = 0.0f;
            this.l = 0.0f;
            this.m = 255;
            this.n = null;
            this.o = null;
            b.e.a<String, Object> aVar = new b.e.a<>();
            this.p = aVar;
            this.f1436h = new d(gVar.f1436h, aVar);
            this.f1429a = new Path(gVar.f1429a);
            this.f1430b = new Path(gVar.f1430b);
            this.f1437i = gVar.f1437i;
            this.f1438j = gVar.f1438j;
            this.f1439k = gVar.f1439k;
            this.l = gVar.l;
            this.f1435g = gVar.f1435g;
            this.m = gVar.m;
            this.n = gVar.n;
            String str = gVar.n;
            if (str != null) {
                aVar.put(str, this);
            }
            this.o = gVar.o;
        }

        private static float a(float f2, float f3, float f4, float f5) {
            return (f2 * f5) - (f3 * f4);
        }

        private void c(d dVar, Matrix matrix, Canvas canvas, int i2, int i3, ColorFilter colorFilter) {
            dVar.f1414a.set(matrix);
            dVar.f1414a.preConcat(dVar.f1423j);
            canvas.save();
            for (int i4 = 0; i4 < dVar.f1415b.size(); i4++) {
                e eVar = dVar.f1415b.get(i4);
                if (eVar instanceof d) {
                    c((d) eVar, dVar.f1414a, canvas, i2, i3, colorFilter);
                } else if (eVar instanceof f) {
                    d(dVar, (f) eVar, canvas, i2, i3, colorFilter);
                }
            }
            canvas.restore();
        }

        private void d(d dVar, f fVar, Canvas canvas, int i2, int i3, ColorFilter colorFilter) {
            float f2 = i2 / this.f1439k;
            float f3 = i3 / this.l;
            float min = Math.min(f2, f3);
            Matrix matrix = dVar.f1414a;
            this.f1431c.set(matrix);
            this.f1431c.postScale(f2, f3);
            float e2 = e(matrix);
            if (e2 == 0.0f) {
                return;
            }
            fVar.d(this.f1429a);
            Path path = this.f1429a;
            this.f1430b.reset();
            if (fVar.c()) {
                this.f1430b.setFillType(fVar.f1427c == 0 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD);
                this.f1430b.addPath(path, this.f1431c);
                canvas.clipPath(this.f1430b);
                return;
            }
            c cVar = (c) fVar;
            float f4 = cVar.f1413k;
            if (f4 != 0.0f || cVar.l != 1.0f) {
                float f5 = cVar.m;
                float f6 = (f4 + f5) % 1.0f;
                float f7 = (cVar.l + f5) % 1.0f;
                if (this.f1434f == null) {
                    this.f1434f = new PathMeasure();
                }
                this.f1434f.setPath(this.f1429a, false);
                float length = this.f1434f.getLength();
                float f8 = f6 * length;
                float f9 = f7 * length;
                path.reset();
                if (f8 > f9) {
                    this.f1434f.getSegment(f8, length, path, true);
                    this.f1434f.getSegment(0.0f, f9, path, true);
                } else {
                    this.f1434f.getSegment(f8, f9, path, true);
                }
                path.rLineTo(0.0f, 0.0f);
            }
            this.f1430b.addPath(path, this.f1431c);
            if (cVar.f1410h.l()) {
                b.g.e.e.b bVar = cVar.f1410h;
                if (this.f1433e == null) {
                    Paint paint = new Paint(1);
                    this.f1433e = paint;
                    paint.setStyle(Paint.Style.FILL);
                }
                Paint paint2 = this.f1433e;
                if (bVar.h()) {
                    Shader f10 = bVar.f();
                    f10.setLocalMatrix(this.f1431c);
                    paint2.setShader(f10);
                    paint2.setAlpha(Math.round(cVar.f1412j * 255.0f));
                } else {
                    paint2.setShader(null);
                    paint2.setAlpha(255);
                    paint2.setColor(i.a(bVar.e(), cVar.f1412j));
                }
                paint2.setColorFilter(colorFilter);
                this.f1430b.setFillType(cVar.f1427c == 0 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD);
                canvas.drawPath(this.f1430b, paint2);
            }
            if (cVar.f1408f.l()) {
                b.g.e.e.b bVar2 = cVar.f1408f;
                if (this.f1432d == null) {
                    Paint paint3 = new Paint(1);
                    this.f1432d = paint3;
                    paint3.setStyle(Paint.Style.STROKE);
                }
                Paint paint4 = this.f1432d;
                Paint.Join join = cVar.o;
                if (join != null) {
                    paint4.setStrokeJoin(join);
                }
                Paint.Cap cap = cVar.n;
                if (cap != null) {
                    paint4.setStrokeCap(cap);
                }
                paint4.setStrokeMiter(cVar.p);
                if (bVar2.h()) {
                    Shader f11 = bVar2.f();
                    f11.setLocalMatrix(this.f1431c);
                    paint4.setShader(f11);
                    paint4.setAlpha(Math.round(cVar.f1411i * 255.0f));
                } else {
                    paint4.setShader(null);
                    paint4.setAlpha(255);
                    paint4.setColor(i.a(bVar2.e(), cVar.f1411i));
                }
                paint4.setColorFilter(colorFilter);
                paint4.setStrokeWidth(cVar.f1409g * min * e2);
                canvas.drawPath(this.f1430b, paint4);
            }
        }

        private float e(Matrix matrix) {
            float[] fArr = {0.0f, 1.0f, 1.0f, 0.0f};
            matrix.mapVectors(fArr);
            float hypot = (float) Math.hypot(fArr[0], fArr[1]);
            float hypot2 = (float) Math.hypot(fArr[2], fArr[3]);
            float a2 = a(fArr[0], fArr[1], fArr[2], fArr[3]);
            float max = Math.max(hypot, hypot2);
            if (max > 0.0f) {
                return Math.abs(a2) / max;
            }
            return 0.0f;
        }

        public void b(Canvas canvas, int i2, int i3, ColorFilter colorFilter) {
            c(this.f1436h, q, canvas, i2, i3, colorFilter);
        }

        public boolean f() {
            if (this.o == null) {
                this.o = Boolean.valueOf(this.f1436h.a());
            }
            return this.o.booleanValue();
        }

        public boolean g(int[] iArr) {
            return this.f1436h.b(iArr);
        }

        public float getAlpha() {
            return getRootAlpha() / 255.0f;
        }

        public int getRootAlpha() {
            return this.m;
        }

        public void setAlpha(float f2) {
            setRootAlpha((int) (f2 * 255.0f));
        }

        public void setRootAlpha(int i2) {
            this.m = i2;
        }
    }

    private static class h extends Drawable.ConstantState {

        /* renamed from: a, reason: collision with root package name */
        int f1440a;

        /* renamed from: b, reason: collision with root package name */
        g f1441b;

        /* renamed from: c, reason: collision with root package name */
        ColorStateList f1442c;

        /* renamed from: d, reason: collision with root package name */
        PorterDuff.Mode f1443d;

        /* renamed from: e, reason: collision with root package name */
        boolean f1444e;

        /* renamed from: f, reason: collision with root package name */
        Bitmap f1445f;

        /* renamed from: g, reason: collision with root package name */
        ColorStateList f1446g;

        /* renamed from: h, reason: collision with root package name */
        PorterDuff.Mode f1447h;

        /* renamed from: i, reason: collision with root package name */
        int f1448i;

        /* renamed from: j, reason: collision with root package name */
        boolean f1449j;

        /* renamed from: k, reason: collision with root package name */
        boolean f1450k;
        Paint l;

        public h() {
            this.f1442c = null;
            this.f1443d = i.w;
            this.f1441b = new g();
        }

        public h(h hVar) {
            this.f1442c = null;
            this.f1443d = i.w;
            if (hVar != null) {
                this.f1440a = hVar.f1440a;
                g gVar = new g(hVar.f1441b);
                this.f1441b = gVar;
                if (hVar.f1441b.f1433e != null) {
                    gVar.f1433e = new Paint(hVar.f1441b.f1433e);
                }
                if (hVar.f1441b.f1432d != null) {
                    this.f1441b.f1432d = new Paint(hVar.f1441b.f1432d);
                }
                this.f1442c = hVar.f1442c;
                this.f1443d = hVar.f1443d;
                this.f1444e = hVar.f1444e;
            }
        }

        public boolean a(int i2, int i3) {
            return i2 == this.f1445f.getWidth() && i3 == this.f1445f.getHeight();
        }

        public boolean b() {
            return !this.f1450k && this.f1446g == this.f1442c && this.f1447h == this.f1443d && this.f1449j == this.f1444e && this.f1448i == this.f1441b.getRootAlpha();
        }

        public void c(int i2, int i3) {
            if (this.f1445f == null || !a(i2, i3)) {
                this.f1445f = Bitmap.createBitmap(i2, i3, Bitmap.Config.ARGB_8888);
                this.f1450k = true;
            }
        }

        public void d(Canvas canvas, ColorFilter colorFilter, Rect rect) {
            canvas.drawBitmap(this.f1445f, (Rect) null, rect, e(colorFilter));
        }

        public Paint e(ColorFilter colorFilter) {
            if (!f() && colorFilter == null) {
                return null;
            }
            if (this.l == null) {
                Paint paint = new Paint();
                this.l = paint;
                paint.setFilterBitmap(true);
            }
            this.l.setAlpha(this.f1441b.getRootAlpha());
            this.l.setColorFilter(colorFilter);
            return this.l;
        }

        public boolean f() {
            return this.f1441b.getRootAlpha() < 255;
        }

        public boolean g() {
            return this.f1441b.f();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f1440a;
        }

        public boolean h(int[] iArr) {
            boolean g2 = this.f1441b.g(iArr);
            this.f1450k |= g2;
            return g2;
        }

        public void i() {
            this.f1446g = this.f1442c;
            this.f1447h = this.f1443d;
            this.f1448i = this.f1441b.getRootAlpha();
            this.f1449j = this.f1444e;
            this.f1450k = false;
        }

        public void j(int i2, int i3) {
            this.f1445f.eraseColor(0);
            this.f1441b.b(new Canvas(this.f1445f), i2, i3, null);
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            return new i(this);
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            return new i(this);
        }
    }

    /* renamed from: b.q.a.a.i$i, reason: collision with other inner class name */
    private static class C0057i extends Drawable.ConstantState {

        /* renamed from: a, reason: collision with root package name */
        private final Drawable.ConstantState f1451a;

        public C0057i(Drawable.ConstantState constantState) {
            this.f1451a = constantState;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public boolean canApplyTheme() {
            return this.f1451a.canApplyTheme();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f1451a.getChangingConfigurations();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            i iVar = new i();
            iVar.n = (VectorDrawable) this.f1451a.newDrawable();
            return iVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            i iVar = new i();
            iVar.n = (VectorDrawable) this.f1451a.newDrawable(resources);
            return iVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources, Resources.Theme theme) {
            i iVar = new i();
            iVar.n = (VectorDrawable) this.f1451a.newDrawable(resources, theme);
            return iVar;
        }
    }

    i() {
        this.s = true;
        this.t = new float[9];
        this.u = new Matrix();
        this.v = new Rect();
        this.o = new h();
    }

    i(h hVar) {
        this.s = true;
        this.t = new float[9];
        this.u = new Matrix();
        this.v = new Rect();
        this.o = hVar;
        this.p = j(this.p, hVar.f1442c, hVar.f1443d);
    }

    static int a(int i2, float f2) {
        return (i2 & 16777215) | (((int) (Color.alpha(i2) * f2)) << 24);
    }

    public static i b(Resources resources, int i2, Resources.Theme theme) {
        int next;
        if (Build.VERSION.SDK_INT >= 24) {
            i iVar = new i();
            iVar.n = b.g.e.e.f.d(resources, i2, theme);
            new C0057i(iVar.n.getConstantState());
            return iVar;
        }
        try {
            XmlResourceParser xml = resources.getXml(i2);
            AttributeSet asAttributeSet = Xml.asAttributeSet(xml);
            do {
                next = xml.next();
                if (next == 2) {
                    break;
                }
            } while (next != 1);
            if (next == 2) {
                return c(resources, xml, asAttributeSet, theme);
            }
            throw new XmlPullParserException("No start tag found");
        } catch (IOException | XmlPullParserException e2) {
            Log.e("VectorDrawableCompat", "parser error", e2);
            return null;
        }
    }

    public static i c(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        i iVar = new i();
        iVar.inflate(resources, xmlPullParser, attributeSet, theme);
        return iVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void e(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        int i2;
        int i3;
        b bVar;
        h hVar = this.o;
        g gVar = hVar.f1441b;
        ArrayDeque arrayDeque = new ArrayDeque();
        arrayDeque.push(gVar.f1436h);
        int eventType = xmlPullParser.getEventType();
        int depth = xmlPullParser.getDepth() + 1;
        boolean z = true;
        while (eventType != 1 && (xmlPullParser.getDepth() >= depth || eventType != 3)) {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                d dVar = (d) arrayDeque.peek();
                if ("path".equals(name)) {
                    c cVar = new c();
                    cVar.g(resources, attributeSet, theme, xmlPullParser);
                    dVar.f1415b.add(cVar);
                    if (cVar.getPathName() != null) {
                        gVar.p.put(cVar.getPathName(), cVar);
                    }
                    z = false;
                    bVar = cVar;
                } else if ("clip-path".equals(name)) {
                    b bVar2 = new b();
                    bVar2.e(resources, attributeSet, theme, xmlPullParser);
                    dVar.f1415b.add(bVar2);
                    String pathName = bVar2.getPathName();
                    bVar = bVar2;
                    if (pathName != null) {
                        gVar.p.put(bVar2.getPathName(), bVar2);
                        bVar = bVar2;
                    }
                } else if ("group".equals(name)) {
                    d dVar2 = new d();
                    dVar2.c(resources, attributeSet, theme, xmlPullParser);
                    dVar.f1415b.add(dVar2);
                    arrayDeque.push(dVar2);
                    if (dVar2.getGroupName() != null) {
                        gVar.p.put(dVar2.getGroupName(), dVar2);
                    }
                    i2 = hVar.f1440a;
                    i3 = dVar2.f1424k;
                    hVar.f1440a = i3 | i2;
                }
                i2 = hVar.f1440a;
                i3 = bVar.f1428d;
                hVar.f1440a = i3 | i2;
            } else if (eventType == 3 && "group".equals(xmlPullParser.getName())) {
                arrayDeque.pop();
            }
            eventType = xmlPullParser.next();
        }
        if (z) {
            throw new XmlPullParserException("no path defined");
        }
    }

    private boolean f() {
        return Build.VERSION.SDK_INT >= 17 && isAutoMirrored() && androidx.core.graphics.drawable.a.e(this) == 1;
    }

    private static PorterDuff.Mode g(int i2, PorterDuff.Mode mode) {
        if (i2 == 3) {
            return PorterDuff.Mode.SRC_OVER;
        }
        if (i2 == 5) {
            return PorterDuff.Mode.SRC_IN;
        }
        if (i2 == 9) {
            return PorterDuff.Mode.SRC_ATOP;
        }
        switch (i2) {
            case 14:
                return PorterDuff.Mode.MULTIPLY;
            case 15:
                return PorterDuff.Mode.SCREEN;
            case 16:
                return PorterDuff.Mode.ADD;
            default:
                return mode;
        }
    }

    private void i(TypedArray typedArray, XmlPullParser xmlPullParser, Resources.Theme theme) {
        h hVar = this.o;
        g gVar = hVar.f1441b;
        hVar.f1443d = g(b.g.e.e.g.g(typedArray, xmlPullParser, "tintMode", 6, -1), PorterDuff.Mode.SRC_IN);
        ColorStateList c2 = b.g.e.e.g.c(typedArray, xmlPullParser, theme, "tint", 1);
        if (c2 != null) {
            hVar.f1442c = c2;
        }
        hVar.f1444e = b.g.e.e.g.a(typedArray, xmlPullParser, "autoMirrored", 5, hVar.f1444e);
        gVar.f1439k = b.g.e.e.g.f(typedArray, xmlPullParser, "viewportWidth", 7, gVar.f1439k);
        float f2 = b.g.e.e.g.f(typedArray, xmlPullParser, "viewportHeight", 8, gVar.l);
        gVar.l = f2;
        if (gVar.f1439k <= 0.0f) {
            throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires viewportWidth > 0");
        }
        if (f2 <= 0.0f) {
            throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires viewportHeight > 0");
        }
        gVar.f1437i = typedArray.getDimension(3, gVar.f1437i);
        float dimension = typedArray.getDimension(2, gVar.f1438j);
        gVar.f1438j = dimension;
        if (gVar.f1437i <= 0.0f) {
            throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires width > 0");
        }
        if (dimension <= 0.0f) {
            throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires height > 0");
        }
        gVar.setAlpha(b.g.e.e.g.f(typedArray, xmlPullParser, "alpha", 4, gVar.getAlpha()));
        String string = typedArray.getString(0);
        if (string != null) {
            gVar.n = string;
            gVar.p.put(string, gVar);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean canApplyTheme() {
        Drawable drawable = this.n;
        if (drawable == null) {
            return false;
        }
        androidx.core.graphics.drawable.a.b(drawable);
        return false;
    }

    Object d(String str) {
        return this.o.f1441b.p.get(str);
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Drawable drawable = this.n;
        if (drawable != null) {
            drawable.draw(canvas);
            return;
        }
        copyBounds(this.v);
        if (this.v.width() <= 0 || this.v.height() <= 0) {
            return;
        }
        ColorFilter colorFilter = this.q;
        if (colorFilter == null) {
            colorFilter = this.p;
        }
        canvas.getMatrix(this.u);
        this.u.getValues(this.t);
        float abs = Math.abs(this.t[0]);
        float abs2 = Math.abs(this.t[4]);
        float abs3 = Math.abs(this.t[1]);
        float abs4 = Math.abs(this.t[3]);
        if (abs3 != 0.0f || abs4 != 0.0f) {
            abs = 1.0f;
            abs2 = 1.0f;
        }
        int min = Math.min(2048, (int) (this.v.width() * abs));
        int min2 = Math.min(2048, (int) (this.v.height() * abs2));
        if (min <= 0 || min2 <= 0) {
            return;
        }
        int save = canvas.save();
        Rect rect = this.v;
        canvas.translate(rect.left, rect.top);
        if (f()) {
            canvas.translate(this.v.width(), 0.0f);
            canvas.scale(-1.0f, 1.0f);
        }
        this.v.offsetTo(0, 0);
        this.o.c(min, min2);
        if (!this.s) {
            this.o.j(min, min2);
        } else if (!this.o.b()) {
            this.o.j(min, min2);
            this.o.i();
        }
        this.o.d(canvas, colorFilter, this.v);
        canvas.restoreToCount(save);
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        Drawable drawable = this.n;
        return drawable != null ? androidx.core.graphics.drawable.a.c(drawable) : this.o.f1441b.getRootAlpha();
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        Drawable drawable = this.n;
        return drawable != null ? drawable.getChangingConfigurations() : super.getChangingConfigurations() | this.o.getChangingConfigurations();
    }

    @Override // android.graphics.drawable.Drawable
    public ColorFilter getColorFilter() {
        Drawable drawable = this.n;
        return drawable != null ? androidx.core.graphics.drawable.a.d(drawable) : this.q;
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        if (this.n != null && Build.VERSION.SDK_INT >= 24) {
            return new C0057i(this.n.getConstantState());
        }
        this.o.f1440a = getChangingConfigurations();
        return this.o;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        Drawable drawable = this.n;
        return drawable != null ? drawable.getIntrinsicHeight() : (int) this.o.f1441b.f1438j;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        Drawable drawable = this.n;
        return drawable != null ? drawable.getIntrinsicWidth() : (int) this.o.f1441b.f1437i;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        Drawable drawable = this.n;
        if (drawable != null) {
            return drawable.getOpacity();
        }
        return -3;
    }

    void h(boolean z) {
        this.s = z;
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        Drawable drawable = this.n;
        if (drawable != null) {
            drawable.inflate(resources, xmlPullParser, attributeSet);
        } else {
            inflate(resources, xmlPullParser, attributeSet, null);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        Drawable drawable = this.n;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.f(drawable, resources, xmlPullParser, attributeSet, theme);
            return;
        }
        h hVar = this.o;
        hVar.f1441b = new g();
        TypedArray k2 = b.g.e.e.g.k(resources, theme, attributeSet, b.q.a.a.a.f1386a);
        i(k2, xmlPullParser, theme);
        k2.recycle();
        hVar.f1440a = getChangingConfigurations();
        hVar.f1450k = true;
        e(resources, xmlPullParser, attributeSet, theme);
        this.p = j(this.p, hVar.f1442c, hVar.f1443d);
    }

    @Override // android.graphics.drawable.Drawable
    public void invalidateSelf() {
        Drawable drawable = this.n;
        if (drawable != null) {
            drawable.invalidateSelf();
        } else {
            super.invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isAutoMirrored() {
        Drawable drawable = this.n;
        return drawable != null ? androidx.core.graphics.drawable.a.g(drawable) : this.o.f1444e;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        h hVar;
        ColorStateList colorStateList;
        Drawable drawable = this.n;
        return drawable != null ? drawable.isStateful() : super.isStateful() || ((hVar = this.o) != null && (hVar.g() || ((colorStateList = this.o.f1442c) != null && colorStateList.isStateful())));
    }

    PorterDuffColorFilter j(PorterDuffColorFilter porterDuffColorFilter, ColorStateList colorStateList, PorterDuff.Mode mode) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        Drawable drawable = this.n;
        if (drawable != null) {
            drawable.mutate();
            return this;
        }
        if (!this.r && super.mutate() == this) {
            this.o = new h(this.o);
            this.r = true;
        }
        return this;
    }

    @Override // android.graphics.drawable.Drawable
    protected void onBoundsChange(Rect rect) {
        Drawable drawable = this.n;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    @Override // android.graphics.drawable.Drawable
    protected boolean onStateChange(int[] iArr) {
        PorterDuff.Mode mode;
        Drawable drawable = this.n;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        boolean z = false;
        h hVar = this.o;
        ColorStateList colorStateList = hVar.f1442c;
        if (colorStateList != null && (mode = hVar.f1443d) != null) {
            this.p = j(this.p, colorStateList, mode);
            invalidateSelf();
            z = true;
        }
        if (!hVar.g() || !hVar.h(iArr)) {
            return z;
        }
        invalidateSelf();
        return true;
    }

    @Override // android.graphics.drawable.Drawable
    public void scheduleSelf(Runnable runnable, long j2) {
        Drawable drawable = this.n;
        if (drawable != null) {
            drawable.scheduleSelf(runnable, j2);
        } else {
            super.scheduleSelf(runnable, j2);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        Drawable drawable = this.n;
        if (drawable != null) {
            drawable.setAlpha(i2);
        } else if (this.o.f1441b.getRootAlpha() != i2) {
            this.o.f1441b.setRootAlpha(i2);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAutoMirrored(boolean z) {
        Drawable drawable = this.n;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.i(drawable, z);
        } else {
            this.o.f1444e = z;
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.n;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
        } else {
            this.q = colorFilter;
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable, androidx.core.graphics.drawable.b
    public void setTint(int i2) {
        Drawable drawable = this.n;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.m(drawable, i2);
        } else {
            setTintList(ColorStateList.valueOf(i2));
        }
    }

    @Override // android.graphics.drawable.Drawable, androidx.core.graphics.drawable.b
    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.n;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.n(drawable, colorStateList);
            return;
        }
        h hVar = this.o;
        if (hVar.f1442c != colorStateList) {
            hVar.f1442c = colorStateList;
            this.p = j(this.p, colorStateList, hVar.f1443d);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable, androidx.core.graphics.drawable.b
    public void setTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.n;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.o(drawable, mode);
            return;
        }
        h hVar = this.o;
        if (hVar.f1443d != mode) {
            hVar.f1443d = mode;
            this.p = j(this.p, hVar.f1442c, mode);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z, boolean z2) {
        Drawable drawable = this.n;
        return drawable != null ? drawable.setVisible(z, z2) : super.setVisible(z, z2);
    }

    @Override // android.graphics.drawable.Drawable
    public void unscheduleSelf(Runnable runnable) {
        Drawable drawable = this.n;
        if (drawable != null) {
            drawable.unscheduleSelf(runnable);
        } else {
            super.unscheduleSelf(runnable);
        }
    }
}
