package b.g.e;

import android.content.LocusId;

/* loaded from: classes.dex */
public final class c {
    public LocusId a() {
        throw null;
    }
}
