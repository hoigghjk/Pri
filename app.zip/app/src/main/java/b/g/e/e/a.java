package b.g.e.e;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    private static final ThreadLocal<TypedValue> f1121a = new ThreadLocal<>();

    public static ColorStateList a(Resources resources, XmlPullParser xmlPullParser, Resources.Theme theme) {
        int next;
        AttributeSet asAttributeSet = Xml.asAttributeSet(xmlPullParser);
        do {
            next = xmlPullParser.next();
            if (next == 2) {
                break;
            }
        } while (next != 1);
        if (next == 2) {
            return b(resources, xmlPullParser, asAttributeSet, theme);
        }
        throw new XmlPullParserException("No start tag found");
    }

    public static ColorStateList b(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        String name = xmlPullParser.getName();
        if (name.equals("selector")) {
            return e(resources, xmlPullParser, attributeSet, theme);
        }
        throw new XmlPullParserException(xmlPullParser.getPositionDescription() + ": invalid color state list tag " + name);
    }

    private static TypedValue c() {
        ThreadLocal<TypedValue> threadLocal = f1121a;
        TypedValue typedValue = threadLocal.get();
        if (typedValue != null) {
            return typedValue;
        }
        TypedValue typedValue2 = new TypedValue();
        threadLocal.set(typedValue2);
        return typedValue2;
    }

    public static ColorStateList d(Resources resources, int i2, Resources.Theme theme) {
        try {
            return a(resources, resources.getXml(i2), theme);
        } catch (Exception e2) {
            Log.e("CSLCompat", "Failed to inflate ColorStateList.", e2);
            return null;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:48:0x0076, code lost:
    
        if (r9.hasValue(r12) != false) goto L25;
     */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0070  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static android.content.res.ColorStateList e(android.content.res.Resources r17, org.xmlpull.v1.XmlPullParser r18, android.util.AttributeSet r19, android.content.res.Resources.Theme r20) {
        /*
            r0 = r17
            r1 = r19
            r2 = r20
            int r3 = r18.getDepth()
            r4 = 1
            int r3 = r3 + r4
            r5 = 20
            int[][] r6 = new int[r5][]
            int[] r5 = new int[r5]
            r7 = 0
            r8 = 0
        L14:
            int r9 = r18.next()
            if (r9 == r4) goto Lc1
            int r10 = r18.getDepth()
            if (r10 >= r3) goto L23
            r11 = 3
            if (r9 == r11) goto Lc1
        L23:
            r11 = 2
            if (r9 != r11) goto Lbe
            if (r10 > r3) goto Lbe
            java.lang.String r9 = r18.getName()
            java.lang.String r10 = "item"
            boolean r9 = r9.equals(r10)
            if (r9 != 0) goto L36
            goto Lbe
        L36:
            int[] r9 = b.g.d.f1105a
            android.content.res.TypedArray r9 = h(r0, r2, r1, r9)
            int r10 = b.g.d.f1106b
            r11 = -1
            int r12 = r9.getResourceId(r10, r11)
            r13 = -65281(0xffffffffffff00ff, float:NaN)
            if (r12 == r11) goto L5d
            boolean r11 = f(r0, r12)
            if (r11 != 0) goto L5d
            android.content.res.XmlResourceParser r10 = r0.getXml(r12)     // Catch: java.lang.Exception -> L5b
            android.content.res.ColorStateList r10 = a(r0, r10, r2)     // Catch: java.lang.Exception -> L5b
            int r10 = r10.getDefaultColor()     // Catch: java.lang.Exception -> L5b
            goto L61
        L5b:
            int r10 = b.g.d.f1106b
        L5d:
            int r10 = r9.getColor(r10, r13)
        L61:
            r11 = 1065353216(0x3f800000, float:1.0)
            int r12 = b.g.d.f1107c
            boolean r13 = r9.hasValue(r12)
            if (r13 == 0) goto L70
        L6b:
            float r11 = r9.getFloat(r12, r11)
            goto L79
        L70:
            int r12 = b.g.d.f1108d
            boolean r13 = r9.hasValue(r12)
            if (r13 == 0) goto L79
            goto L6b
        L79:
            r9.recycle()
            int r9 = r19.getAttributeCount()
            int[] r12 = new int[r9]
            r13 = 0
            r14 = 0
        L84:
            if (r13 >= r9) goto La9
            int r15 = r1.getAttributeNameResource(r13)
            r4 = 16843173(0x10101a5, float:2.3694738E-38)
            if (r15 == r4) goto La5
            r4 = 16843551(0x101031f, float:2.3695797E-38)
            if (r15 == r4) goto La5
            int r4 = b.g.a.f1090a
            if (r15 == r4) goto La5
            int r4 = r14 + 1
            boolean r16 = r1.getAttributeBooleanValue(r13, r7)
            if (r16 == 0) goto La1
            goto La2
        La1:
            int r15 = -r15
        La2:
            r12[r14] = r15
            r14 = r4
        La5:
            int r13 = r13 + 1
            r4 = 1
            goto L84
        La9:
            int[] r4 = android.util.StateSet.trimStateSet(r12, r14)
            int r9 = g(r10, r11)
            int[] r5 = b.g.e.e.e.a(r5, r8, r9)
            java.lang.Object[] r4 = b.g.e.e.e.b(r6, r8, r4)
            r6 = r4
            int[][] r6 = (int[][]) r6
            int r8 = r8 + 1
        Lbe:
            r4 = 1
            goto L14
        Lc1:
            int[] r0 = new int[r8]
            int[][] r1 = new int[r8][]
            java.lang.System.arraycopy(r5, r7, r0, r7, r8)
            java.lang.System.arraycopy(r6, r7, r1, r7, r8)
            android.content.res.ColorStateList r2 = new android.content.res.ColorStateList
            r2.<init>(r1, r0)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: b.g.e.e.a.e(android.content.res.Resources, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.content.res.Resources$Theme):android.content.res.ColorStateList");
    }

    private static boolean f(Resources resources, int i2) {
        TypedValue c2 = c();
        resources.getValue(i2, c2, true);
        int i3 = c2.type;
        return i3 >= 28 && i3 <= 31;
    }

    private static int g(int i2, float f2) {
        return (i2 & 16777215) | (Math.round(Color.alpha(i2) * f2) << 24);
    }

    private static TypedArray h(Resources resources, Resources.Theme theme, AttributeSet attributeSet, int[] iArr) {
        return theme == null ? resources.obtainAttributes(attributeSet, iArr) : theme.obtainStyledAttributes(attributeSet, iArr, 0, 0);
    }
}
