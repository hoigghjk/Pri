package b.g;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public static final int f1094a = 2131165190;

    /* renamed from: b, reason: collision with root package name */
    public static final int f1095b = 2131165394;

    /* renamed from: c, reason: collision with root package name */
    public static final int f1096c = 2131165395;

    /* renamed from: d, reason: collision with root package name */
    public static final int f1097d = 2131165396;

    /* renamed from: e, reason: collision with root package name */
    public static final int f1098e = 2131165397;

    /* renamed from: f, reason: collision with root package name */
    public static final int f1099f = 2131165398;

    /* renamed from: g, reason: collision with root package name */
    public static final int f1100g = 2131165401;

    /* renamed from: h, reason: collision with root package name */
    public static final int f1101h = 2131165402;

    /* renamed from: i, reason: collision with root package name */
    public static final int f1102i = 2131165403;

    /* renamed from: j, reason: collision with root package name */
    public static final int f1103j = 2131165404;

    /* renamed from: k, reason: collision with root package name */
    public static final int f1104k = 2131165405;
    public static final int l = 2131165406;
}
