package b.g.j;

import android.os.Build;
import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;
import b.g.k.d;

/* loaded from: classes.dex */
public class a implements Spannable {
    private final Spannable n;
    private final C0039a o;
    private final PrecomputedText p;

    /* renamed from: b.g.j.a$a, reason: collision with other inner class name */
    public static final class C0039a {

        /* renamed from: a, reason: collision with root package name */
        private final TextPaint f1199a;

        /* renamed from: b, reason: collision with root package name */
        private final TextDirectionHeuristic f1200b;

        /* renamed from: c, reason: collision with root package name */
        private final int f1201c;

        /* renamed from: d, reason: collision with root package name */
        private final int f1202d;

        /* renamed from: b.g.j.a$a$a, reason: collision with other inner class name */
        public static class C0040a {

            /* renamed from: a, reason: collision with root package name */
            private final TextPaint f1203a;

            /* renamed from: b, reason: collision with root package name */
            private TextDirectionHeuristic f1204b;

            /* renamed from: c, reason: collision with root package name */
            private int f1205c;

            /* renamed from: d, reason: collision with root package name */
            private int f1206d;

            public C0040a(TextPaint textPaint) {
                this.f1203a = textPaint;
                int i2 = Build.VERSION.SDK_INT;
                if (i2 >= 23) {
                    this.f1205c = 1;
                    this.f1206d = 1;
                } else {
                    this.f1206d = 0;
                    this.f1205c = 0;
                }
                this.f1204b = i2 >= 18 ? TextDirectionHeuristics.FIRSTSTRONG_LTR : null;
            }

            public C0039a a() {
                return new C0039a(this.f1203a, this.f1204b, this.f1205c, this.f1206d);
            }

            public C0040a b(int i2) {
                this.f1205c = i2;
                return this;
            }

            public C0040a c(int i2) {
                this.f1206d = i2;
                return this;
            }

            public C0040a d(TextDirectionHeuristic textDirectionHeuristic) {
                this.f1204b = textDirectionHeuristic;
                return this;
            }
        }

        public C0039a(PrecomputedText.Params params) {
            this.f1199a = params.getTextPaint();
            this.f1200b = params.getTextDirection();
            this.f1201c = params.getBreakStrategy();
            this.f1202d = params.getHyphenationFrequency();
            int i2 = Build.VERSION.SDK_INT;
        }

        C0039a(TextPaint textPaint, TextDirectionHeuristic textDirectionHeuristic, int i2, int i3) {
            if (Build.VERSION.SDK_INT >= 29) {
                new PrecomputedText.Params.Builder(textPaint).setBreakStrategy(i2).setHyphenationFrequency(i3).setTextDirection(textDirectionHeuristic).build();
            }
            this.f1199a = textPaint;
            this.f1200b = textDirectionHeuristic;
            this.f1201c = i2;
            this.f1202d = i3;
        }

        public boolean a(C0039a c0039a) {
            int i2 = Build.VERSION.SDK_INT;
            if ((i2 >= 23 && (this.f1201c != c0039a.b() || this.f1202d != c0039a.c())) || this.f1199a.getTextSize() != c0039a.e().getTextSize() || this.f1199a.getTextScaleX() != c0039a.e().getTextScaleX() || this.f1199a.getTextSkewX() != c0039a.e().getTextSkewX()) {
                return false;
            }
            if ((i2 >= 21 && (this.f1199a.getLetterSpacing() != c0039a.e().getLetterSpacing() || !TextUtils.equals(this.f1199a.getFontFeatureSettings(), c0039a.e().getFontFeatureSettings()))) || this.f1199a.getFlags() != c0039a.e().getFlags()) {
                return false;
            }
            if (i2 >= 24) {
                if (!this.f1199a.getTextLocales().equals(c0039a.e().getTextLocales())) {
                    return false;
                }
            } else if (i2 >= 17 && !this.f1199a.getTextLocale().equals(c0039a.e().getTextLocale())) {
                return false;
            }
            return this.f1199a.getTypeface() == null ? c0039a.e().getTypeface() == null : this.f1199a.getTypeface().equals(c0039a.e().getTypeface());
        }

        public int b() {
            return this.f1201c;
        }

        public int c() {
            return this.f1202d;
        }

        public TextDirectionHeuristic d() {
            return this.f1200b;
        }

        public TextPaint e() {
            return this.f1199a;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C0039a)) {
                return false;
            }
            C0039a c0039a = (C0039a) obj;
            if (a(c0039a)) {
                return Build.VERSION.SDK_INT < 18 || this.f1200b == c0039a.d();
            }
            return false;
        }

        public int hashCode() {
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 24) {
                return d.b(Float.valueOf(this.f1199a.getTextSize()), Float.valueOf(this.f1199a.getTextScaleX()), Float.valueOf(this.f1199a.getTextSkewX()), Float.valueOf(this.f1199a.getLetterSpacing()), Integer.valueOf(this.f1199a.getFlags()), this.f1199a.getTextLocales(), this.f1199a.getTypeface(), Boolean.valueOf(this.f1199a.isElegantTextHeight()), this.f1200b, Integer.valueOf(this.f1201c), Integer.valueOf(this.f1202d));
            }
            if (i2 >= 21) {
                return d.b(Float.valueOf(this.f1199a.getTextSize()), Float.valueOf(this.f1199a.getTextScaleX()), Float.valueOf(this.f1199a.getTextSkewX()), Float.valueOf(this.f1199a.getLetterSpacing()), Integer.valueOf(this.f1199a.getFlags()), this.f1199a.getTextLocale(), this.f1199a.getTypeface(), Boolean.valueOf(this.f1199a.isElegantTextHeight()), this.f1200b, Integer.valueOf(this.f1201c), Integer.valueOf(this.f1202d));
            }
            if (i2 < 18 && i2 < 17) {
                return d.b(Float.valueOf(this.f1199a.getTextSize()), Float.valueOf(this.f1199a.getTextScaleX()), Float.valueOf(this.f1199a.getTextSkewX()), Integer.valueOf(this.f1199a.getFlags()), this.f1199a.getTypeface(), this.f1200b, Integer.valueOf(this.f1201c), Integer.valueOf(this.f1202d));
            }
            return d.b(Float.valueOf(this.f1199a.getTextSize()), Float.valueOf(this.f1199a.getTextScaleX()), Float.valueOf(this.f1199a.getTextSkewX()), Integer.valueOf(this.f1199a.getFlags()), this.f1199a.getTextLocale(), this.f1199a.getTypeface(), this.f1200b, Integer.valueOf(this.f1201c), Integer.valueOf(this.f1202d));
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x00df  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.String toString() {
            /*
                Method dump skipped, instructions count: 325
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: b.g.j.a.C0039a.toString():java.lang.String");
        }
    }

    public C0039a a() {
        return this.o;
    }

    public PrecomputedText b() {
        Spannable spannable = this.n;
        if (spannable instanceof PrecomputedText) {
            return (PrecomputedText) spannable;
        }
        return null;
    }

    @Override // java.lang.CharSequence
    public char charAt(int i2) {
        return this.n.charAt(i2);
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        return this.n.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        return this.n.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        return this.n.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    public <T> T[] getSpans(int i2, int i3, Class<T> cls) {
        return Build.VERSION.SDK_INT >= 29 ? (T[]) this.p.getSpans(i2, i3, cls) : (T[]) this.n.getSpans(i2, i3, cls);
    }

    @Override // java.lang.CharSequence
    public int length() {
        return this.n.length();
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i2, int i3, Class cls) {
        return this.n.nextSpanTransition(i2, i3, cls);
    }

    @Override // android.text.Spannable
    public void removeSpan(Object obj) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT >= 29) {
            this.p.removeSpan(obj);
        } else {
            this.n.removeSpan(obj);
        }
    }

    @Override // android.text.Spannable
    public void setSpan(Object obj, int i2, int i3, int i4) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT >= 29) {
            this.p.setSpan(obj, i2, i3, i4);
        } else {
            this.n.setSpan(obj, i2, i3, i4);
        }
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i2, int i3) {
        return this.n.subSequence(i2, i3);
    }

    @Override // java.lang.CharSequence
    public String toString() {
        return this.n.toString();
    }
}
