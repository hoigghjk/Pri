package b.g.f;

import android.graphics.Insets;
import android.graphics.Rect;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: e, reason: collision with root package name */
    public static final b f1148e = new b(0, 0, 0, 0);

    /* renamed from: a, reason: collision with root package name */
    public final int f1149a;

    /* renamed from: b, reason: collision with root package name */
    public final int f1150b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1151c;

    /* renamed from: d, reason: collision with root package name */
    public final int f1152d;

    private b(int i2, int i3, int i4, int i5) {
        this.f1149a = i2;
        this.f1150b = i3;
        this.f1151c = i4;
        this.f1152d = i5;
    }

    public static b a(b bVar, b bVar2) {
        return b(Math.max(bVar.f1149a, bVar2.f1149a), Math.max(bVar.f1150b, bVar2.f1150b), Math.max(bVar.f1151c, bVar2.f1151c), Math.max(bVar.f1152d, bVar2.f1152d));
    }

    public static b b(int i2, int i3, int i4, int i5) {
        return (i2 == 0 && i3 == 0 && i4 == 0 && i5 == 0) ? f1148e : new b(i2, i3, i4, i5);
    }

    public static b c(Rect rect) {
        return b(rect.left, rect.top, rect.right, rect.bottom);
    }

    public static b d(Insets insets) {
        return b(insets.left, insets.top, insets.right, insets.bottom);
    }

    public Insets e() {
        return Insets.of(this.f1149a, this.f1150b, this.f1151c, this.f1152d);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || b.class != obj.getClass()) {
            return false;
        }
        b bVar = (b) obj;
        return this.f1152d == bVar.f1152d && this.f1149a == bVar.f1149a && this.f1151c == bVar.f1151c && this.f1150b == bVar.f1150b;
    }

    public int hashCode() {
        return (((((this.f1149a * 31) + this.f1150b) * 31) + this.f1151c) * 31) + this.f1152d;
    }

    public String toString() {
        return "Insets{left=" + this.f1149a + ", top=" + this.f1150b + ", right=" + this.f1151c + ", bottom=" + this.f1152d + '}';
    }
}
