package b.g.f;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import b.g.e.e.c;
import b.g.e.e.f;
import b.g.i.f;

/* loaded from: classes.dex */
public class d {

    /* renamed from: a, reason: collision with root package name */
    private static final j f1157a;

    /* renamed from: b, reason: collision with root package name */
    private static final b.e.e<String, Typeface> f1158b;

    public static class a extends f.c {

        /* renamed from: a, reason: collision with root package name */
        private f.c f1159a;

        public a(f.c cVar) {
            this.f1159a = cVar;
        }

        @Override // b.g.i.f.c
        public void a(int i2) {
            f.c cVar = this.f1159a;
            if (cVar != null) {
                cVar.d(i2);
            }
        }

        @Override // b.g.i.f.c
        public void b(Typeface typeface) {
            f.c cVar = this.f1159a;
            if (cVar != null) {
                cVar.e(typeface);
            }
        }
    }

    static {
        int i2 = Build.VERSION.SDK_INT;
        f1157a = i2 >= 29 ? new i() : i2 >= 28 ? new h() : i2 >= 26 ? new g() : (i2 < 24 || !f.m()) ? i2 >= 21 ? new e() : new j() : new f();
        f1158b = new b.e.e<>(16);
    }

    public static Typeface a(Context context, Typeface typeface, int i2) {
        Typeface g2;
        if (context != null) {
            return (Build.VERSION.SDK_INT >= 21 || (g2 = g(context, typeface, i2)) == null) ? Typeface.create(typeface, i2) : g2;
        }
        throw new IllegalArgumentException("Context cannot be null");
    }

    public static Typeface b(Context context, CancellationSignal cancellationSignal, f.b[] bVarArr, int i2) {
        return f1157a.c(context, cancellationSignal, bVarArr, i2);
    }

    public static Typeface c(Context context, c.a aVar, Resources resources, int i2, int i3, f.c cVar, Handler handler, boolean z) {
        Typeface b2;
        if (aVar instanceof c.d) {
            c.d dVar = (c.d) aVar;
            Typeface h2 = h(dVar.c());
            if (h2 != null) {
                if (cVar != null) {
                    cVar.b(h2, handler);
                }
                return h2;
            }
            b2 = b.g.i.f.a(context, dVar.b(), i3, !z ? cVar != null : dVar.a() != 0, z ? dVar.d() : -1, f.c.c(handler), new a(cVar));
        } else {
            b2 = f1157a.b(context, (c.b) aVar, resources, i3);
            if (cVar != null) {
                if (b2 != null) {
                    cVar.b(b2, handler);
                } else {
                    cVar.a(-3, handler);
                }
            }
        }
        if (b2 != null) {
            f1158b.d(e(resources, i2, i3), b2);
        }
        return b2;
    }

    public static Typeface d(Context context, Resources resources, int i2, String str, int i3) {
        Typeface e2 = f1157a.e(context, resources, i2, str, i3);
        if (e2 != null) {
            f1158b.d(e(resources, i2, i3), e2);
        }
        return e2;
    }

    private static String e(Resources resources, int i2, int i3) {
        return resources.getResourcePackageName(i2) + "-" + i2 + "-" + i3;
    }

    public static Typeface f(Resources resources, int i2, int i3) {
        return f1158b.c(e(resources, i2, i3));
    }

    private static Typeface g(Context context, Typeface typeface, int i2) {
        j jVar = f1157a;
        c.b i3 = jVar.i(typeface);
        if (i3 == null) {
            return null;
        }
        return jVar.b(context, i3, context.getResources(), i2);
    }

    private static Typeface h(String str) {
        if (str == null || str.isEmpty()) {
            return null;
        }
        Typeface create = Typeface.create(str, 0);
        Typeface create2 = Typeface.create(Typeface.DEFAULT, 0);
        if (create == null || create.equals(create2)) {
            return null;
        }
        return create;
    }
}
