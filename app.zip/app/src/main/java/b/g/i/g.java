package b.g.i;

import android.os.Handler;
import android.os.Process;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: classes.dex */
class g {

    private static class a implements ThreadFactory {
        private String n;
        private int o;

        /* renamed from: b.g.i.g$a$a, reason: collision with other inner class name */
        private static class C0038a extends Thread {
            private final int n;

            C0038a(Runnable runnable, String str, int i2) {
                super(runnable, str);
                this.n = i2;
            }

            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                Process.setThreadPriority(this.n);
                super.run();
            }
        }

        a(String str, int i2) {
            this.n = str;
            this.o = i2;
        }

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(Runnable runnable) {
            return new C0038a(runnable, this.n, this.o);
        }
    }

    private static class b<T> implements Runnable {
        private Callable<T> n;
        private b.g.k.a<T> o;
        private Handler p;

        class a implements Runnable {
            final /* synthetic */ b.g.k.a n;
            final /* synthetic */ Object o;

            a(b bVar, b.g.k.a aVar, Object obj) {
                this.n = aVar;
                this.o = obj;
            }

            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.lang.Runnable
            public void run() {
                this.n.c(this.o);
            }
        }

        b(Handler handler, Callable<T> callable, b.g.k.a<T> aVar) {
            this.n = callable;
            this.o = aVar;
            this.p = handler;
        }

        @Override // java.lang.Runnable
        public void run() {
            T t;
            try {
                t = this.n.call();
            } catch (Exception unused) {
                t = null;
            }
            this.p.post(new a(this, this.o, t));
        }
    }

    static ThreadPoolExecutor a(String str, int i2, int i3) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, i3, TimeUnit.MILLISECONDS, new LinkedBlockingDeque(), new a(str, i2));
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        return threadPoolExecutor;
    }

    static <T> void b(Executor executor, Callable<T> callable, b.g.k.a<T> aVar) {
        executor.execute(new b(b.g.i.b.a(), callable, aVar));
    }

    static <T> T c(ExecutorService executorService, Callable<T> callable, int i2) {
        try {
            return executorService.submit(callable).get(i2, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e2) {
            throw e2;
        } catch (ExecutionException e3) {
            throw new RuntimeException(e3);
        } catch (TimeoutException unused) {
            throw new InterruptedException("timeout");
        }
    }
}
