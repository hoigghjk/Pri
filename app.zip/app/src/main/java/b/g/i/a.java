package b.g.i;

import android.graphics.Typeface;
import android.os.Handler;
import b.g.i.e;
import b.g.i.f;

/* loaded from: classes.dex */
class a {

    /* renamed from: a, reason: collision with root package name */
    private final f.c f1175a;

    /* renamed from: b, reason: collision with root package name */
    private final Handler f1176b;

    /* renamed from: b.g.i.a$a, reason: collision with other inner class name */
    class RunnableC0036a implements Runnable {
        final /* synthetic */ f.c n;
        final /* synthetic */ Typeface o;

        RunnableC0036a(a aVar, f.c cVar, Typeface typeface) {
            this.n = cVar;
            this.o = typeface;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.n.b(this.o);
        }
    }

    class b implements Runnable {
        final /* synthetic */ f.c n;
        final /* synthetic */ int o;

        b(a aVar, f.c cVar, int i2) {
            this.n = cVar;
            this.o = i2;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.n.a(this.o);
        }
    }

    a(f.c cVar, Handler handler) {
        this.f1175a = cVar;
        this.f1176b = handler;
    }

    private void a(int i2) {
        this.f1176b.post(new b(this, this.f1175a, i2));
    }

    private void c(Typeface typeface) {
        this.f1176b.post(new RunnableC0036a(this, this.f1175a, typeface));
    }

    void b(e.C0037e c0037e) {
        if (c0037e.a()) {
            c(c0037e.f1190a);
        } else {
            a(c0037e.f1191b);
        }
    }
}
