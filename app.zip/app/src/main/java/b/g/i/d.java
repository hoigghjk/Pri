package b.g.i;

import android.util.Base64;
import b.g.k.h;
import java.util.List;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    private final String f1178a;

    /* renamed from: b, reason: collision with root package name */
    private final String f1179b;

    /* renamed from: c, reason: collision with root package name */
    private final String f1180c;

    /* renamed from: d, reason: collision with root package name */
    private final List<List<byte[]>> f1181d;

    /* renamed from: e, reason: collision with root package name */
    private final int f1182e;

    /* renamed from: f, reason: collision with root package name */
    private final String f1183f;

    public d(String str, String str2, String str3, List<List<byte[]>> list) {
        h.b(str);
        this.f1178a = str;
        h.b(str2);
        this.f1179b = str2;
        h.b(str3);
        this.f1180c = str3;
        h.b(list);
        this.f1181d = list;
        this.f1182e = 0;
        this.f1183f = a(str, str2, str3);
    }

    private String a(String str, String str2, String str3) {
        return str + "-" + str2 + "-" + str3;
    }

    public List<List<byte[]>> b() {
        return this.f1181d;
    }

    public int c() {
        return this.f1182e;
    }

    String d() {
        return this.f1183f;
    }

    public String e() {
        return this.f1178a;
    }

    public String f() {
        return this.f1179b;
    }

    public String g() {
        return this.f1180c;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("FontRequest {mProviderAuthority: " + this.f1178a + ", mProviderPackage: " + this.f1179b + ", mQuery: " + this.f1180c + ", mCertificates:");
        for (int i2 = 0; i2 < this.f1181d.size(); i2++) {
            sb.append(" [");
            List<byte[]> list = this.f1181d.get(i2);
            for (int i3 = 0; i3 < list.size(); i3++) {
                sb.append(" \"");
                sb.append(Base64.encodeToString(list.get(i3), 0));
                sb.append("\"");
            }
            sb.append(" ]");
        }
        sb.append("}");
        sb.append("mCertificatesArray: " + this.f1182e);
        return sb.toString();
    }
}
