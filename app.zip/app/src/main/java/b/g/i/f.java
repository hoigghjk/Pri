package b.g.i;

import android.content.Context;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Handler;
import b.g.k.h;

/* loaded from: classes.dex */
public class f {

    public static class a {

        /* renamed from: a, reason: collision with root package name */
        private final int f1192a;

        /* renamed from: b, reason: collision with root package name */
        private final b[] f1193b;

        @Deprecated
        public a(int i2, b[] bVarArr) {
            this.f1192a = i2;
            this.f1193b = bVarArr;
        }

        static a a(int i2, b[] bVarArr) {
            return new a(i2, bVarArr);
        }

        public b[] b() {
            return this.f1193b;
        }

        public int c() {
            return this.f1192a;
        }
    }

    public static class b {

        /* renamed from: a, reason: collision with root package name */
        private final Uri f1194a;

        /* renamed from: b, reason: collision with root package name */
        private final int f1195b;

        /* renamed from: c, reason: collision with root package name */
        private final int f1196c;

        /* renamed from: d, reason: collision with root package name */
        private final boolean f1197d;

        /* renamed from: e, reason: collision with root package name */
        private final int f1198e;

        @Deprecated
        public b(Uri uri, int i2, int i3, boolean z, int i4) {
            h.b(uri);
            this.f1194a = uri;
            this.f1195b = i2;
            this.f1196c = i3;
            this.f1197d = z;
            this.f1198e = i4;
        }

        static b a(Uri uri, int i2, int i3, boolean z, int i4) {
            return new b(uri, i2, i3, z, i4);
        }

        public int b() {
            return this.f1198e;
        }

        public int c() {
            return this.f1195b;
        }

        public Uri d() {
            return this.f1194a;
        }

        public int e() {
            return this.f1196c;
        }

        public boolean f() {
            return this.f1197d;
        }
    }

    public static class c {
        public void a(int i2) {
            throw null;
        }

        public void b(Typeface typeface) {
            throw null;
        }
    }

    public static Typeface a(Context context, d dVar, int i2, boolean z, int i3, Handler handler, c cVar) {
        b.g.i.a aVar = new b.g.i.a(cVar, handler);
        return z ? e.e(context, dVar, aVar, i2, i3) : e.d(context, dVar, i2, null, aVar);
    }
}
