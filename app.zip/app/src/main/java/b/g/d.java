package b.g;

import android.R;

/* loaded from: classes.dex */
public final class d {
    public static final int A = 2;
    public static final int B = 3;
    public static final int C = 4;
    public static final int D = 5;
    public static final int E = 6;
    public static final int F = 7;
    public static final int G = 8;
    public static final int H = 9;
    public static final int I = 10;
    public static final int J = 11;
    public static final int L = 0;
    public static final int M = 1;

    /* renamed from: b, reason: collision with root package name */
    public static final int f1106b = 0;

    /* renamed from: c, reason: collision with root package name */
    public static final int f1107c = 1;

    /* renamed from: d, reason: collision with root package name */
    public static final int f1108d = 2;

    /* renamed from: f, reason: collision with root package name */
    public static final int f1110f = 0;

    /* renamed from: g, reason: collision with root package name */
    public static final int f1111g = 1;

    /* renamed from: h, reason: collision with root package name */
    public static final int f1112h = 2;

    /* renamed from: i, reason: collision with root package name */
    public static final int f1113i = 3;

    /* renamed from: j, reason: collision with root package name */
    public static final int f1114j = 4;

    /* renamed from: k, reason: collision with root package name */
    public static final int f1115k = 5;
    public static final int l = 6;
    public static final int n = 0;
    public static final int o = 1;
    public static final int p = 2;
    public static final int q = 3;
    public static final int r = 4;
    public static final int s = 5;
    public static final int t = 6;
    public static final int u = 7;
    public static final int v = 8;
    public static final int w = 9;
    public static final int y = 0;
    public static final int z = 1;

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f1105a = {R.attr.color, R.attr.alpha, com.pichillilorenzo.flutter_inappwebview.R.attr.alpha};

    /* renamed from: e, reason: collision with root package name */
    public static final int[] f1109e = {com.pichillilorenzo.flutter_inappwebview.R.attr.fontProviderAuthority, com.pichillilorenzo.flutter_inappwebview.R.attr.fontProviderCerts, com.pichillilorenzo.flutter_inappwebview.R.attr.fontProviderFetchStrategy, com.pichillilorenzo.flutter_inappwebview.R.attr.fontProviderFetchTimeout, com.pichillilorenzo.flutter_inappwebview.R.attr.fontProviderPackage, com.pichillilorenzo.flutter_inappwebview.R.attr.fontProviderQuery, com.pichillilorenzo.flutter_inappwebview.R.attr.fontProviderSystemFontFamily};
    public static final int[] m = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, com.pichillilorenzo.flutter_inappwebview.R.attr.font, com.pichillilorenzo.flutter_inappwebview.R.attr.fontStyle, com.pichillilorenzo.flutter_inappwebview.R.attr.fontVariationSettings, com.pichillilorenzo.flutter_inappwebview.R.attr.fontWeight, com.pichillilorenzo.flutter_inappwebview.R.attr.ttcIndex};
    public static final int[] x = {R.attr.startColor, R.attr.endColor, R.attr.type, R.attr.centerX, R.attr.centerY, R.attr.gradientRadius, R.attr.tileMode, R.attr.centerColor, R.attr.startX, R.attr.startY, R.attr.endX, R.attr.endY};
    public static final int[] K = {R.attr.color, R.attr.offset};
}
