package b.g.l;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

/* loaded from: classes.dex */
public class z {

    /* renamed from: b, reason: collision with root package name */
    public static final z f1273b;

    /* renamed from: a, reason: collision with root package name */
    private final l f1274a;

    static class a {

        /* renamed from: a, reason: collision with root package name */
        private static Field f1275a;

        /* renamed from: b, reason: collision with root package name */
        private static Field f1276b;

        /* renamed from: c, reason: collision with root package name */
        private static Field f1277c;

        /* renamed from: d, reason: collision with root package name */
        private static boolean f1278d;

        static {
            try {
                Field declaredField = View.class.getDeclaredField("mAttachInfo");
                f1275a = declaredField;
                declaredField.setAccessible(true);
                Class<?> cls = Class.forName("android.view.View$AttachInfo");
                Field declaredField2 = cls.getDeclaredField("mStableInsets");
                f1276b = declaredField2;
                declaredField2.setAccessible(true);
                Field declaredField3 = cls.getDeclaredField("mContentInsets");
                f1277c = declaredField3;
                declaredField3.setAccessible(true);
                f1278d = true;
            } catch (ReflectiveOperationException e2) {
                Log.w("WindowInsetsCompat", "Failed to get visible insets from AttachInfo " + e2.getMessage(), e2);
            }
        }

        public static z a(View view) {
            if (f1278d && view.isAttachedToWindow()) {
                try {
                    Object obj = f1275a.get(view.getRootView());
                    if (obj != null) {
                        Rect rect = (Rect) f1276b.get(obj);
                        Rect rect2 = (Rect) f1277c.get(obj);
                        if (rect != null && rect2 != null) {
                            b bVar = new b();
                            bVar.b(b.g.f.b.c(rect));
                            bVar.c(b.g.f.b.c(rect2));
                            z a2 = bVar.a();
                            a2.q(a2);
                            a2.d(view.getRootView());
                            return a2;
                        }
                    }
                } catch (IllegalAccessException e2) {
                    Log.w("WindowInsetsCompat", "Failed to get insets from AttachInfo. " + e2.getMessage(), e2);
                }
            }
            return null;
        }
    }

    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        private final f f1279a;

        public b() {
            int i2 = Build.VERSION.SDK_INT;
            this.f1279a = i2 >= 30 ? new e() : i2 >= 29 ? new d() : i2 >= 20 ? new c() : new f();
        }

        public b(z zVar) {
            int i2 = Build.VERSION.SDK_INT;
            this.f1279a = i2 >= 30 ? new e(zVar) : i2 >= 29 ? new d(zVar) : i2 >= 20 ? new c(zVar) : new f(zVar);
        }

        public z a() {
            return this.f1279a.b();
        }

        @Deprecated
        public b b(b.g.f.b bVar) {
            this.f1279a.d(bVar);
            return this;
        }

        @Deprecated
        public b c(b.g.f.b bVar) {
            this.f1279a.f(bVar);
            return this;
        }
    }

    private static class c extends f {

        /* renamed from: e, reason: collision with root package name */
        private static Field f1280e = null;

        /* renamed from: f, reason: collision with root package name */
        private static boolean f1281f = false;

        /* renamed from: g, reason: collision with root package name */
        private static Constructor<WindowInsets> f1282g = null;

        /* renamed from: h, reason: collision with root package name */
        private static boolean f1283h = false;

        /* renamed from: c, reason: collision with root package name */
        private WindowInsets f1284c;

        /* renamed from: d, reason: collision with root package name */
        private b.g.f.b f1285d;

        c() {
            this.f1284c = h();
        }

        c(z zVar) {
            super(zVar);
            this.f1284c = zVar.s();
        }

        private static WindowInsets h() {
            if (!f1281f) {
                try {
                    f1280e = WindowInsets.class.getDeclaredField("CONSUMED");
                } catch (ReflectiveOperationException e2) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e2);
                }
                f1281f = true;
            }
            Field field = f1280e;
            if (field != null) {
                try {
                    WindowInsets windowInsets = (WindowInsets) field.get(null);
                    if (windowInsets != null) {
                        return new WindowInsets(windowInsets);
                    }
                } catch (ReflectiveOperationException e3) {
                    Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e3);
                }
            }
            if (!f1283h) {
                try {
                    f1282g = WindowInsets.class.getConstructor(Rect.class);
                } catch (ReflectiveOperationException e4) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e4);
                }
                f1283h = true;
            }
            Constructor<WindowInsets> constructor = f1282g;
            if (constructor != null) {
                try {
                    return constructor.newInstance(new Rect());
                } catch (ReflectiveOperationException e5) {
                    Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e5);
                }
            }
            return null;
        }

        @Override // b.g.l.z.f
        z b() {
            a();
            z t = z.t(this.f1284c);
            t.o(this.f1288b);
            t.r(this.f1285d);
            return t;
        }

        @Override // b.g.l.z.f
        void d(b.g.f.b bVar) {
            this.f1285d = bVar;
        }

        @Override // b.g.l.z.f
        void f(b.g.f.b bVar) {
            WindowInsets windowInsets = this.f1284c;
            if (windowInsets != null) {
                this.f1284c = windowInsets.replaceSystemWindowInsets(bVar.f1149a, bVar.f1150b, bVar.f1151c, bVar.f1152d);
            }
        }
    }

    private static class d extends f {

        /* renamed from: c, reason: collision with root package name */
        final WindowInsets.Builder f1286c;

        d() {
            this.f1286c = new WindowInsets.Builder();
        }

        d(z zVar) {
            super(zVar);
            WindowInsets s = zVar.s();
            this.f1286c = s != null ? new WindowInsets.Builder(s) : new WindowInsets.Builder();
        }

        @Override // b.g.l.z.f
        z b() {
            a();
            z t = z.t(this.f1286c.build());
            t.o(this.f1288b);
            return t;
        }

        @Override // b.g.l.z.f
        void c(b.g.f.b bVar) {
            this.f1286c.setMandatorySystemGestureInsets(bVar.e());
        }

        @Override // b.g.l.z.f
        void d(b.g.f.b bVar) {
            this.f1286c.setStableInsets(bVar.e());
        }

        @Override // b.g.l.z.f
        void e(b.g.f.b bVar) {
            this.f1286c.setSystemGestureInsets(bVar.e());
        }

        @Override // b.g.l.z.f
        void f(b.g.f.b bVar) {
            this.f1286c.setSystemWindowInsets(bVar.e());
        }

        @Override // b.g.l.z.f
        void g(b.g.f.b bVar) {
            this.f1286c.setTappableElementInsets(bVar.e());
        }
    }

    private static class e extends d {
        e() {
        }

        e(z zVar) {
            super(zVar);
        }
    }

    private static class f {

        /* renamed from: a, reason: collision with root package name */
        private final z f1287a;

        /* renamed from: b, reason: collision with root package name */
        b.g.f.b[] f1288b;

        f() {
            this(new z((z) null));
        }

        f(z zVar) {
            this.f1287a = zVar;
        }

        protected final void a() {
            b.g.f.b[] bVarArr = this.f1288b;
            if (bVarArr != null) {
                b.g.f.b bVar = bVarArr[m.a(1)];
                b.g.f.b bVar2 = this.f1288b[m.a(2)];
                if (bVar2 == null) {
                    bVar2 = this.f1287a.f(2);
                }
                if (bVar == null) {
                    bVar = this.f1287a.f(1);
                }
                f(b.g.f.b.a(bVar, bVar2));
                b.g.f.b bVar3 = this.f1288b[m.a(16)];
                if (bVar3 != null) {
                    e(bVar3);
                }
                b.g.f.b bVar4 = this.f1288b[m.a(32)];
                if (bVar4 != null) {
                    c(bVar4);
                }
                b.g.f.b bVar5 = this.f1288b[m.a(64)];
                if (bVar5 != null) {
                    g(bVar5);
                }
            }
        }

        z b() {
            a();
            return this.f1287a;
        }

        void c(b.g.f.b bVar) {
        }

        void d(b.g.f.b bVar) {
        }

        void e(b.g.f.b bVar) {
        }

        void f(b.g.f.b bVar) {
        }

        void g(b.g.f.b bVar) {
        }
    }

    private static class g extends l {

        /* renamed from: h, reason: collision with root package name */
        private static boolean f1289h = false;

        /* renamed from: i, reason: collision with root package name */
        private static Method f1290i;

        /* renamed from: j, reason: collision with root package name */
        private static Class<?> f1291j;

        /* renamed from: k, reason: collision with root package name */
        private static Class<?> f1292k;
        private static Field l;
        private static Field m;

        /* renamed from: c, reason: collision with root package name */
        final WindowInsets f1293c;

        /* renamed from: d, reason: collision with root package name */
        private b.g.f.b[] f1294d;

        /* renamed from: e, reason: collision with root package name */
        private b.g.f.b f1295e;

        /* renamed from: f, reason: collision with root package name */
        private z f1296f;

        /* renamed from: g, reason: collision with root package name */
        b.g.f.b f1297g;

        g(z zVar, WindowInsets windowInsets) {
            super(zVar);
            this.f1295e = null;
            this.f1293c = windowInsets;
        }

        g(z zVar, g gVar) {
            this(zVar, new WindowInsets(gVar.f1293c));
        }

        private b.g.f.b t(int i2, boolean z) {
            b.g.f.b bVar = b.g.f.b.f1148e;
            for (int i3 = 1; i3 <= 256; i3 <<= 1) {
                if ((i2 & i3) != 0) {
                    bVar = b.g.f.b.a(bVar, u(i3, z));
                }
            }
            return bVar;
        }

        private b.g.f.b v() {
            z zVar = this.f1296f;
            return zVar != null ? zVar.g() : b.g.f.b.f1148e;
        }

        private b.g.f.b w(View view) {
            if (Build.VERSION.SDK_INT >= 30) {
                throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
            }
            if (!f1289h) {
                x();
            }
            Method method = f1290i;
            if (method != null && f1292k != null && l != null) {
                try {
                    Object invoke = method.invoke(view, new Object[0]);
                    if (invoke == null) {
                        Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                        return null;
                    }
                    Rect rect = (Rect) l.get(m.get(invoke));
                    if (rect != null) {
                        return b.g.f.b.c(rect);
                    }
                    return null;
                } catch (ReflectiveOperationException e2) {
                    Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
                }
            }
            return null;
        }

        private static void x() {
            try {
                f1290i = View.class.getDeclaredMethod("getViewRootImpl", new Class[0]);
                f1291j = Class.forName("android.view.ViewRootImpl");
                Class<?> cls = Class.forName("android.view.View$AttachInfo");
                f1292k = cls;
                l = cls.getDeclaredField("mVisibleInsets");
                m = f1291j.getDeclaredField("mAttachInfo");
                l.setAccessible(true);
                m.setAccessible(true);
            } catch (ReflectiveOperationException e2) {
                Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
            }
            f1289h = true;
        }

        @Override // b.g.l.z.l
        void d(View view) {
            b.g.f.b w = w(view);
            if (w == null) {
                w = b.g.f.b.f1148e;
            }
            q(w);
        }

        @Override // b.g.l.z.l
        void e(z zVar) {
            zVar.q(this.f1296f);
            zVar.p(this.f1297g);
        }

        @Override // b.g.l.z.l
        public boolean equals(Object obj) {
            if (super.equals(obj)) {
                return Objects.equals(this.f1297g, ((g) obj).f1297g);
            }
            return false;
        }

        @Override // b.g.l.z.l
        public b.g.f.b g(int i2) {
            return t(i2, false);
        }

        @Override // b.g.l.z.l
        final b.g.f.b k() {
            if (this.f1295e == null) {
                this.f1295e = b.g.f.b.b(this.f1293c.getSystemWindowInsetLeft(), this.f1293c.getSystemWindowInsetTop(), this.f1293c.getSystemWindowInsetRight(), this.f1293c.getSystemWindowInsetBottom());
            }
            return this.f1295e;
        }

        @Override // b.g.l.z.l
        z m(int i2, int i3, int i4, int i5) {
            b bVar = new b(z.t(this.f1293c));
            bVar.c(z.m(k(), i2, i3, i4, i5));
            bVar.b(z.m(i(), i2, i3, i4, i5));
            return bVar.a();
        }

        @Override // b.g.l.z.l
        boolean o() {
            return this.f1293c.isRound();
        }

        @Override // b.g.l.z.l
        public void p(b.g.f.b[] bVarArr) {
            this.f1294d = bVarArr;
        }

        @Override // b.g.l.z.l
        void q(b.g.f.b bVar) {
            this.f1297g = bVar;
        }

        @Override // b.g.l.z.l
        void r(z zVar) {
            this.f1296f = zVar;
        }

        protected b.g.f.b u(int i2, boolean z) {
            b.g.f.b g2;
            int i3;
            if (i2 == 1) {
                return z ? b.g.f.b.b(0, Math.max(v().f1150b, k().f1150b), 0, 0) : b.g.f.b.b(0, k().f1150b, 0, 0);
            }
            if (i2 == 2) {
                if (z) {
                    b.g.f.b v = v();
                    b.g.f.b i4 = i();
                    return b.g.f.b.b(Math.max(v.f1149a, i4.f1149a), 0, Math.max(v.f1151c, i4.f1151c), Math.max(v.f1152d, i4.f1152d));
                }
                b.g.f.b k2 = k();
                z zVar = this.f1296f;
                g2 = zVar != null ? zVar.g() : null;
                int i5 = k2.f1152d;
                if (g2 != null) {
                    i5 = Math.min(i5, g2.f1152d);
                }
                return b.g.f.b.b(k2.f1149a, 0, k2.f1151c, i5);
            }
            if (i2 != 8) {
                if (i2 == 16) {
                    return j();
                }
                if (i2 == 32) {
                    return h();
                }
                if (i2 == 64) {
                    return l();
                }
                if (i2 != 128) {
                    return b.g.f.b.f1148e;
                }
                z zVar2 = this.f1296f;
                b.g.l.c e2 = zVar2 != null ? zVar2.e() : f();
                return e2 != null ? b.g.f.b.b(e2.b(), e2.d(), e2.c(), e2.a()) : b.g.f.b.f1148e;
            }
            b.g.f.b[] bVarArr = this.f1294d;
            g2 = bVarArr != null ? bVarArr[m.a(8)] : null;
            if (g2 != null) {
                return g2;
            }
            b.g.f.b k3 = k();
            b.g.f.b v2 = v();
            int i6 = k3.f1152d;
            if (i6 > v2.f1152d) {
                return b.g.f.b.b(0, 0, 0, i6);
            }
            b.g.f.b bVar = this.f1297g;
            return (bVar == null || bVar.equals(b.g.f.b.f1148e) || (i3 = this.f1297g.f1152d) <= v2.f1152d) ? b.g.f.b.f1148e : b.g.f.b.b(0, 0, 0, i3);
        }
    }

    private static class h extends g {
        private b.g.f.b n;

        h(z zVar, WindowInsets windowInsets) {
            super(zVar, windowInsets);
            this.n = null;
        }

        h(z zVar, h hVar) {
            super(zVar, hVar);
            this.n = null;
            this.n = hVar.n;
        }

        @Override // b.g.l.z.l
        z b() {
            return z.t(this.f1293c.consumeStableInsets());
        }

        @Override // b.g.l.z.l
        z c() {
            return z.t(this.f1293c.consumeSystemWindowInsets());
        }

        @Override // b.g.l.z.l
        final b.g.f.b i() {
            if (this.n == null) {
                this.n = b.g.f.b.b(this.f1293c.getStableInsetLeft(), this.f1293c.getStableInsetTop(), this.f1293c.getStableInsetRight(), this.f1293c.getStableInsetBottom());
            }
            return this.n;
        }

        @Override // b.g.l.z.l
        boolean n() {
            return this.f1293c.isConsumed();
        }

        @Override // b.g.l.z.l
        public void s(b.g.f.b bVar) {
            this.n = bVar;
        }
    }

    private static class i extends h {
        i(z zVar, WindowInsets windowInsets) {
            super(zVar, windowInsets);
        }

        i(z zVar, i iVar) {
            super(zVar, iVar);
        }

        @Override // b.g.l.z.l
        z a() {
            return z.t(this.f1293c.consumeDisplayCutout());
        }

        @Override // b.g.l.z.g, b.g.l.z.l
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof i)) {
                return false;
            }
            i iVar = (i) obj;
            return Objects.equals(this.f1293c, iVar.f1293c) && Objects.equals(this.f1297g, iVar.f1297g);
        }

        @Override // b.g.l.z.l
        b.g.l.c f() {
            return b.g.l.c.e(this.f1293c.getDisplayCutout());
        }

        @Override // b.g.l.z.l
        public int hashCode() {
            return this.f1293c.hashCode();
        }
    }

    private static class j extends i {
        private b.g.f.b o;
        private b.g.f.b p;
        private b.g.f.b q;

        j(z zVar, WindowInsets windowInsets) {
            super(zVar, windowInsets);
            this.o = null;
            this.p = null;
            this.q = null;
        }

        j(z zVar, j jVar) {
            super(zVar, jVar);
            this.o = null;
            this.p = null;
            this.q = null;
        }

        @Override // b.g.l.z.l
        b.g.f.b h() {
            if (this.p == null) {
                this.p = b.g.f.b.d(this.f1293c.getMandatorySystemGestureInsets());
            }
            return this.p;
        }

        @Override // b.g.l.z.l
        b.g.f.b j() {
            if (this.o == null) {
                this.o = b.g.f.b.d(this.f1293c.getSystemGestureInsets());
            }
            return this.o;
        }

        @Override // b.g.l.z.l
        b.g.f.b l() {
            if (this.q == null) {
                this.q = b.g.f.b.d(this.f1293c.getTappableElementInsets());
            }
            return this.q;
        }

        @Override // b.g.l.z.g, b.g.l.z.l
        z m(int i2, int i3, int i4, int i5) {
            return z.t(this.f1293c.inset(i2, i3, i4, i5));
        }

        @Override // b.g.l.z.h, b.g.l.z.l
        public void s(b.g.f.b bVar) {
        }
    }

    private static class k extends j {
        static final z r = z.t(WindowInsets.CONSUMED);

        k(z zVar, WindowInsets windowInsets) {
            super(zVar, windowInsets);
        }

        k(z zVar, k kVar) {
            super(zVar, kVar);
        }

        @Override // b.g.l.z.g, b.g.l.z.l
        final void d(View view) {
        }

        @Override // b.g.l.z.g, b.g.l.z.l
        public b.g.f.b g(int i2) {
            return b.g.f.b.d(this.f1293c.getInsets(n.a(i2)));
        }
    }

    private static class l {

        /* renamed from: b, reason: collision with root package name */
        static final z f1298b = new b().a().a().b().c();

        /* renamed from: a, reason: collision with root package name */
        final z f1299a;

        l(z zVar) {
            this.f1299a = zVar;
        }

        z a() {
            return this.f1299a;
        }

        z b() {
            return this.f1299a;
        }

        z c() {
            return this.f1299a;
        }

        void d(View view) {
        }

        void e(z zVar) {
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof l)) {
                return false;
            }
            l lVar = (l) obj;
            return o() == lVar.o() && n() == lVar.n() && b.g.k.d.a(k(), lVar.k()) && b.g.k.d.a(i(), lVar.i()) && b.g.k.d.a(f(), lVar.f());
        }

        b.g.l.c f() {
            return null;
        }

        b.g.f.b g(int i2) {
            return b.g.f.b.f1148e;
        }

        b.g.f.b h() {
            return k();
        }

        public int hashCode() {
            return b.g.k.d.b(Boolean.valueOf(o()), Boolean.valueOf(n()), k(), i(), f());
        }

        b.g.f.b i() {
            return b.g.f.b.f1148e;
        }

        b.g.f.b j() {
            return k();
        }

        b.g.f.b k() {
            return b.g.f.b.f1148e;
        }

        b.g.f.b l() {
            return k();
        }

        z m(int i2, int i3, int i4, int i5) {
            return f1298b;
        }

        boolean n() {
            return false;
        }

        boolean o() {
            return false;
        }

        public void p(b.g.f.b[] bVarArr) {
        }

        void q(b.g.f.b bVar) {
        }

        void r(z zVar) {
        }

        public void s(b.g.f.b bVar) {
        }
    }

    public static final class m {
        static int a(int i2) {
            if (i2 == 1) {
                return 0;
            }
            if (i2 == 2) {
                return 1;
            }
            if (i2 == 4) {
                return 2;
            }
            if (i2 == 8) {
                return 3;
            }
            if (i2 == 16) {
                return 4;
            }
            if (i2 == 32) {
                return 5;
            }
            if (i2 == 64) {
                return 6;
            }
            if (i2 == 128) {
                return 7;
            }
            if (i2 == 256) {
                return 8;
            }
            throw new IllegalArgumentException("type needs to be >= FIRST and <= LAST, type=" + i2);
        }
    }

    private static final class n {
        static int a(int i2) {
            int statusBars;
            int i3 = 0;
            for (int i4 = 1; i4 <= 256; i4 <<= 1) {
                if ((i2 & i4) != 0) {
                    if (i4 == 1) {
                        statusBars = WindowInsets.Type.statusBars();
                    } else if (i4 == 2) {
                        statusBars = WindowInsets.Type.navigationBars();
                    } else if (i4 == 4) {
                        statusBars = WindowInsets.Type.captionBar();
                    } else if (i4 == 8) {
                        statusBars = WindowInsets.Type.ime();
                    } else if (i4 == 16) {
                        statusBars = WindowInsets.Type.systemGestures();
                    } else if (i4 == 32) {
                        statusBars = WindowInsets.Type.mandatorySystemGestures();
                    } else if (i4 == 64) {
                        statusBars = WindowInsets.Type.tappableElement();
                    } else if (i4 == 128) {
                        statusBars = WindowInsets.Type.displayCutout();
                    }
                    i3 |= statusBars;
                }
            }
            return i3;
        }
    }

    static {
        f1273b = Build.VERSION.SDK_INT >= 30 ? k.r : l.f1298b;
    }

    private z(WindowInsets windowInsets) {
        l gVar;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            gVar = new k(this, windowInsets);
        } else if (i2 >= 29) {
            gVar = new j(this, windowInsets);
        } else if (i2 >= 28) {
            gVar = new i(this, windowInsets);
        } else if (i2 >= 21) {
            gVar = new h(this, windowInsets);
        } else {
            if (i2 < 20) {
                this.f1274a = new l(this);
                return;
            }
            gVar = new g(this, windowInsets);
        }
        this.f1274a = gVar;
    }

    public z(z zVar) {
        if (zVar == null) {
            this.f1274a = new l(this);
            return;
        }
        l lVar = zVar.f1274a;
        int i2 = Build.VERSION.SDK_INT;
        this.f1274a = (i2 < 30 || !(lVar instanceof k)) ? (i2 < 29 || !(lVar instanceof j)) ? (i2 < 28 || !(lVar instanceof i)) ? (i2 < 21 || !(lVar instanceof h)) ? (i2 < 20 || !(lVar instanceof g)) ? new l(this) : new g(this, (g) lVar) : new h(this, (h) lVar) : new i(this, (i) lVar) : new j(this, (j) lVar) : new k(this, (k) lVar);
        lVar.e(this);
    }

    static b.g.f.b m(b.g.f.b bVar, int i2, int i3, int i4, int i5) {
        int max = Math.max(0, bVar.f1149a - i2);
        int max2 = Math.max(0, bVar.f1150b - i3);
        int max3 = Math.max(0, bVar.f1151c - i4);
        int max4 = Math.max(0, bVar.f1152d - i5);
        return (max == i2 && max2 == i3 && max3 == i4 && max4 == i5) ? bVar : b.g.f.b.b(max, max2, max3, max4);
    }

    public static z t(WindowInsets windowInsets) {
        return u(windowInsets, null);
    }

    public static z u(WindowInsets windowInsets, View view) {
        b.g.k.h.b(windowInsets);
        z zVar = new z(windowInsets);
        if (view != null && view.isAttachedToWindow()) {
            zVar.q(r.r(view));
            zVar.d(view.getRootView());
        }
        return zVar;
    }

    @Deprecated
    public z a() {
        return this.f1274a.a();
    }

    @Deprecated
    public z b() {
        return this.f1274a.b();
    }

    @Deprecated
    public z c() {
        return this.f1274a.c();
    }

    void d(View view) {
        this.f1274a.d(view);
    }

    public b.g.l.c e() {
        return this.f1274a.f();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof z) {
            return b.g.k.d.a(this.f1274a, ((z) obj).f1274a);
        }
        return false;
    }

    public b.g.f.b f(int i2) {
        return this.f1274a.g(i2);
    }

    @Deprecated
    public b.g.f.b g() {
        return this.f1274a.i();
    }

    @Deprecated
    public int h() {
        return this.f1274a.k().f1152d;
    }

    public int hashCode() {
        l lVar = this.f1274a;
        if (lVar == null) {
            return 0;
        }
        return lVar.hashCode();
    }

    @Deprecated
    public int i() {
        return this.f1274a.k().f1149a;
    }

    @Deprecated
    public int j() {
        return this.f1274a.k().f1151c;
    }

    @Deprecated
    public int k() {
        return this.f1274a.k().f1150b;
    }

    public z l(int i2, int i3, int i4, int i5) {
        return this.f1274a.m(i2, i3, i4, i5);
    }

    @Deprecated
    public z n(int i2, int i3, int i4, int i5) {
        b bVar = new b(this);
        bVar.c(b.g.f.b.b(i2, i3, i4, i5));
        return bVar.a();
    }

    void o(b.g.f.b[] bVarArr) {
        this.f1274a.p(bVarArr);
    }

    void p(b.g.f.b bVar) {
        this.f1274a.q(bVar);
    }

    void q(z zVar) {
        this.f1274a.r(zVar);
    }

    void r(b.g.f.b bVar) {
        this.f1274a.s(bVar);
    }

    public WindowInsets s() {
        l lVar = this.f1274a;
        if (lVar instanceof g) {
            return ((g) lVar).f1293c;
        }
        return null;
    }
}
