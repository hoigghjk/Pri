package b.g.l;

import android.view.View;

/* loaded from: classes.dex */
public interface l extends k {
    void onNestedScroll(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr);
}
