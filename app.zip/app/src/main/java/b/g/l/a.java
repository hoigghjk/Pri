package b.g.l;

import android.os.Build;
import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import b.g.l.b0.b;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public class a {

    /* renamed from: c, reason: collision with root package name */
    private static final View.AccessibilityDelegate f1212c = new View.AccessibilityDelegate();

    /* renamed from: a, reason: collision with root package name */
    private final View.AccessibilityDelegate f1213a;

    /* renamed from: b, reason: collision with root package name */
    private final View.AccessibilityDelegate f1214b;

    /* renamed from: b.g.l.a$a, reason: collision with other inner class name */
    static final class C0041a extends View.AccessibilityDelegate {

        /* renamed from: a, reason: collision with root package name */
        final a f1215a;

        C0041a(a aVar) {
            this.f1215a = aVar;
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            return this.f1215a.a(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public AccessibilityNodeProvider getAccessibilityNodeProvider(View view) {
            b.g.l.b0.c b2 = this.f1215a.b(view);
            if (b2 != null) {
                return (AccessibilityNodeProvider) b2.a();
            }
            return null;
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f1215a.f(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            b.g.l.b0.b P = b.g.l.b0.b.P(accessibilityNodeInfo);
            P.L(r.A(view));
            P.J(r.w(view));
            P.K(r.k(view));
            P.N(r.s(view));
            this.f1215a.g(view, P);
            P.c(accessibilityNodeInfo.getText(), view);
            List<b.a> c2 = a.c(view);
            for (int i2 = 0; i2 < c2.size(); i2++) {
                P.a(c2.get(i2));
            }
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f1215a.h(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return this.f1215a.i(viewGroup, view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean performAccessibilityAction(View view, int i2, Bundle bundle) {
            return this.f1215a.j(view, i2, bundle);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void sendAccessibilityEvent(View view, int i2) {
            this.f1215a.l(view, i2);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void sendAccessibilityEventUnchecked(View view, AccessibilityEvent accessibilityEvent) {
            this.f1215a.m(view, accessibilityEvent);
        }
    }

    public a() {
        this(f1212c);
    }

    public a(View.AccessibilityDelegate accessibilityDelegate) {
        this.f1213a = accessibilityDelegate;
        this.f1214b = new C0041a(this);
    }

    static List<b.a> c(View view) {
        List<b.a> list = (List) view.getTag(b.g.c.f1095b);
        return list == null ? Collections.emptyList() : list;
    }

    private boolean e(ClickableSpan clickableSpan, View view) {
        if (clickableSpan != null) {
            ClickableSpan[] l = b.g.l.b0.b.l(view.createAccessibilityNodeInfo().getText());
            for (int i2 = 0; l != null && i2 < l.length; i2++) {
                if (clickableSpan.equals(l[i2])) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean k(int i2, View view) {
        WeakReference weakReference;
        SparseArray sparseArray = (SparseArray) view.getTag(b.g.c.f1096c);
        if (sparseArray == null || (weakReference = (WeakReference) sparseArray.get(i2)) == null) {
            return false;
        }
        ClickableSpan clickableSpan = (ClickableSpan) weakReference.get();
        if (!e(clickableSpan, view)) {
            return false;
        }
        clickableSpan.onClick(view);
        return true;
    }

    public boolean a(View view, AccessibilityEvent accessibilityEvent) {
        return this.f1213a.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public b.g.l.b0.c b(View view) {
        AccessibilityNodeProvider accessibilityNodeProvider;
        if (Build.VERSION.SDK_INT < 16 || (accessibilityNodeProvider = this.f1213a.getAccessibilityNodeProvider(view)) == null) {
            return null;
        }
        return new b.g.l.b0.c(accessibilityNodeProvider);
    }

    View.AccessibilityDelegate d() {
        return this.f1214b;
    }

    public void f(View view, AccessibilityEvent accessibilityEvent) {
        this.f1213a.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    public void g(View view, b.g.l.b0.b bVar) {
        this.f1213a.onInitializeAccessibilityNodeInfo(view, bVar.O());
    }

    public void h(View view, AccessibilityEvent accessibilityEvent) {
        this.f1213a.onPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public boolean i(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return this.f1213a.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
    }

    public boolean j(View view, int i2, Bundle bundle) {
        List<b.a> c2 = c(view);
        boolean z = false;
        int i3 = 0;
        while (true) {
            if (i3 >= c2.size()) {
                break;
            }
            b.a aVar = c2.get(i3);
            if (aVar.a() == i2) {
                z = aVar.c(view, bundle);
                break;
            }
            i3++;
        }
        if (!z && Build.VERSION.SDK_INT >= 16) {
            z = this.f1213a.performAccessibilityAction(view, i2, bundle);
        }
        return (z || i2 != b.g.c.f1094a) ? z : k(bundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1), view);
    }

    public void l(View view, int i2) {
        this.f1213a.sendAccessibilityEvent(view, i2);
    }

    public void m(View view, AccessibilityEvent accessibilityEvent) {
        this.f1213a.sendAccessibilityEventUnchecked(view, accessibilityEvent);
    }
}
