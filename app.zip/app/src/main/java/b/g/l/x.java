package b.g.l;

import android.view.View;

/* loaded from: classes.dex */
public class x implements w {
    @Override // b.g.l.w
    public void a(View view) {
    }

    @Override // b.g.l.w
    public void c(View view) {
    }
}
