package b.g.l.b0;

import android.os.Bundle;
import android.view.View;

/* loaded from: classes.dex */
public interface e {

    public static abstract class a {
        public void a(Bundle bundle) {
        }
    }

    public static final class b extends a {
    }

    public static final class c extends a {
    }

    public static final class d extends a {
    }

    /* renamed from: b.g.l.b0.e$e, reason: collision with other inner class name */
    public static final class C0043e extends a {
    }

    public static final class f extends a {
    }

    public static final class g extends a {
    }

    public static final class h extends a {
    }

    boolean a(View view, a aVar);
}
