package b.g.l.b0;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;

/* loaded from: classes.dex */
public final class a extends ClickableSpan {
    private final int n;
    private final b o;
    private final int p;

    public a(int i2, b bVar, int i3) {
        this.n = i2;
        this.o = bVar;
        this.p = i3;
    }

    @Override // android.text.style.ClickableSpan
    public void onClick(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.n);
        this.o.F(this.p, bundle);
    }
}
