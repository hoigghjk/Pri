package b.g.l;

/* loaded from: classes.dex */
public interface i {
    boolean isNestedScrollingEnabled();

    void stopNestedScroll();
}
