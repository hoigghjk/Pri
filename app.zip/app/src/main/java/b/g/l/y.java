package b.g.l;

import android.view.View;

/* loaded from: classes.dex */
public interface y {
    void a(View view);
}
