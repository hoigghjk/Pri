package b.g.l;

import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;

/* loaded from: classes.dex */
public final class a0 {

    /* renamed from: a, reason: collision with root package name */
    private final e f1216a;

    private static class a extends e {

        /* renamed from: a, reason: collision with root package name */
        protected final Window f1217a;

        a(Window window, View view) {
            this.f1217a = window;
        }

        protected void c(int i2) {
            View decorView = this.f1217a.getDecorView();
            decorView.setSystemUiVisibility(i2 | decorView.getSystemUiVisibility());
        }

        protected void d(int i2) {
            this.f1217a.addFlags(i2);
        }

        protected void e(int i2) {
            View decorView = this.f1217a.getDecorView();
            decorView.setSystemUiVisibility((~i2) & decorView.getSystemUiVisibility());
        }

        protected void f(int i2) {
            this.f1217a.clearFlags(i2);
        }
    }

    private static class b extends a {
        b(Window window, View view) {
            super(window, view);
        }

        @Override // b.g.l.a0.e
        public void b(boolean z) {
            if (!z) {
                e(8192);
                return;
            }
            f(67108864);
            d(Integer.MIN_VALUE);
            c(8192);
        }
    }

    private static class c extends b {
        c(Window window, View view) {
            super(window, view);
        }

        @Override // b.g.l.a0.e
        public void a(boolean z) {
            if (!z) {
                e(16);
                return;
            }
            f(134217728);
            d(Integer.MIN_VALUE);
            c(16);
        }
    }

    private static class d extends e {

        /* renamed from: a, reason: collision with root package name */
        final WindowInsetsController f1218a;

        d(Window window, a0 a0Var) {
            this(window.getInsetsController(), a0Var);
        }

        d(WindowInsetsController windowInsetsController, a0 a0Var) {
            new b.e.g();
            this.f1218a = windowInsetsController;
        }

        @Override // b.g.l.a0.e
        public void a(boolean z) {
            if (z) {
                this.f1218a.setSystemBarsAppearance(16, 16);
            } else {
                this.f1218a.setSystemBarsAppearance(0, 16);
            }
        }

        @Override // b.g.l.a0.e
        public void b(boolean z) {
            if (z) {
                this.f1218a.setSystemBarsAppearance(8, 8);
            } else {
                this.f1218a.setSystemBarsAppearance(0, 8);
            }
        }
    }

    private static class e {
        e() {
        }

        public void a(boolean z) {
        }

        public void b(boolean z) {
        }
    }

    public a0(Window window, View view) {
        e aVar;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            this.f1216a = new d(window, this);
            return;
        }
        if (i2 >= 26) {
            aVar = new c(window, view);
        } else if (i2 >= 23) {
            aVar = new b(window, view);
        } else {
            if (i2 < 20) {
                this.f1216a = new e();
                return;
            }
            aVar = new a(window, view);
        }
        this.f1216a = aVar;
    }

    public void a(boolean z) {
        this.f1216a.a(z);
    }

    public void b(boolean z) {
        this.f1216a.b(z);
    }
}
