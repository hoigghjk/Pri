package b.g.l;

import android.view.View;

/* loaded from: classes.dex */
public interface o {
    z a(View view, z zVar);
}
