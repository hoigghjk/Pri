package b.g.l.b0;

/* loaded from: classes.dex */
public class c {

    /* renamed from: a, reason: collision with root package name */
    private final Object f1231a;

    public c(Object obj) {
        this.f1231a = obj;
    }

    public Object a() {
        return this.f1231a;
    }
}
