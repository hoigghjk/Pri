package b.g.l;

import android.view.View;
import android.view.ViewGroup;

/* loaded from: classes.dex */
public class n {

    /* renamed from: a, reason: collision with root package name */
    private int f1244a;

    /* renamed from: b, reason: collision with root package name */
    private int f1245b;

    public n(ViewGroup viewGroup) {
    }

    public int a() {
        return this.f1244a | this.f1245b;
    }

    public void b(View view, View view2, int i2) {
        c(view, view2, i2, 0);
    }

    public void c(View view, View view2, int i2, int i3) {
        if (i3 == 1) {
            this.f1245b = i2;
        } else {
            this.f1244a = i2;
        }
    }

    public void d(View view) {
        e(view, 0);
    }

    public void e(View view, int i2) {
        if (i2 == 1) {
            this.f1245b = 0;
        } else {
            this.f1244a = 0;
        }
    }
}
