package b.g.l;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.os.Build;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public final class v {

    /* renamed from: a, reason: collision with root package name */
    private WeakReference<View> f1263a;

    /* renamed from: b, reason: collision with root package name */
    Runnable f1264b = null;

    /* renamed from: c, reason: collision with root package name */
    Runnable f1265c = null;

    /* renamed from: d, reason: collision with root package name */
    int f1266d = -1;

    class a extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ w f1267a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f1268b;

        a(v vVar, w wVar, View view) {
            this.f1267a = wVar;
            this.f1268b = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f1267a.a(this.f1268b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f1267a.b(this.f1268b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            this.f1267a.c(this.f1268b);
        }
    }

    class b implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ y f1269a;

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f1270b;

        b(v vVar, y yVar, View view) {
            this.f1269a = yVar;
            this.f1270b = view;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            this.f1269a.a(this.f1270b);
        }
    }

    static class c implements w {

        /* renamed from: a, reason: collision with root package name */
        v f1271a;

        /* renamed from: b, reason: collision with root package name */
        boolean f1272b;

        c(v vVar) {
            this.f1271a = vVar;
        }

        @Override // b.g.l.w
        public void a(View view) {
            Object tag = view.getTag(2113929216);
            w wVar = tag instanceof w ? (w) tag : null;
            if (wVar != null) {
                wVar.a(view);
            }
        }

        @Override // b.g.l.w
        public void b(View view) {
            int i2 = this.f1271a.f1266d;
            if (i2 > -1) {
                view.setLayerType(i2, null);
                this.f1271a.f1266d = -1;
            }
            if (Build.VERSION.SDK_INT >= 16 || !this.f1272b) {
                v vVar = this.f1271a;
                Runnable runnable = vVar.f1265c;
                if (runnable != null) {
                    vVar.f1265c = null;
                    runnable.run();
                }
                Object tag = view.getTag(2113929216);
                w wVar = tag instanceof w ? (w) tag : null;
                if (wVar != null) {
                    wVar.b(view);
                }
                this.f1272b = true;
            }
        }

        @Override // b.g.l.w
        public void c(View view) {
            this.f1272b = false;
            if (this.f1271a.f1266d > -1) {
                view.setLayerType(2, null);
            }
            v vVar = this.f1271a;
            Runnable runnable = vVar.f1264b;
            if (runnable != null) {
                vVar.f1264b = null;
                runnable.run();
            }
            Object tag = view.getTag(2113929216);
            w wVar = tag instanceof w ? (w) tag : null;
            if (wVar != null) {
                wVar.c(view);
            }
        }
    }

    v(View view) {
        this.f1263a = new WeakReference<>(view);
    }

    private void g(View view, w wVar) {
        if (wVar != null) {
            view.animate().setListener(new a(this, wVar, view));
        } else {
            view.animate().setListener(null);
        }
    }

    public v a(float f2) {
        View view = this.f1263a.get();
        if (view != null) {
            view.animate().alpha(f2);
        }
        return this;
    }

    public void b() {
        View view = this.f1263a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    public long c() {
        View view = this.f1263a.get();
        if (view != null) {
            return view.animate().getDuration();
        }
        return 0L;
    }

    public v d(long j2) {
        View view = this.f1263a.get();
        if (view != null) {
            view.animate().setDuration(j2);
        }
        return this;
    }

    public v e(Interpolator interpolator) {
        View view = this.f1263a.get();
        if (view != null) {
            view.animate().setInterpolator(interpolator);
        }
        return this;
    }

    public v f(w wVar) {
        View view = this.f1263a.get();
        if (view != null) {
            if (Build.VERSION.SDK_INT < 16) {
                view.setTag(2113929216, wVar);
                wVar = new c(this);
            }
            g(view, wVar);
        }
        return this;
    }

    public v h(long j2) {
        View view = this.f1263a.get();
        if (view != null) {
            view.animate().setStartDelay(j2);
        }
        return this;
    }

    public v i(y yVar) {
        View view = this.f1263a.get();
        if (view != null && Build.VERSION.SDK_INT >= 19) {
            view.animate().setUpdateListener(yVar != null ? new b(this, yVar, view) : null);
        }
        return this;
    }

    public void j() {
        View view = this.f1263a.get();
        if (view != null) {
            view.animate().start();
        }
    }

    public v k(float f2) {
        View view = this.f1263a.get();
        if (view != null) {
            view.animate().translationY(f2);
        }
        return this;
    }
}
