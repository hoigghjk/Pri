package b.g.l;

import android.view.View;

/* loaded from: classes.dex */
public interface w {
    void a(View view);

    void b(View view);

    void c(View view);
}
