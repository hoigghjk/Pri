package b.g.k;

/* loaded from: classes.dex */
public interface a<T> {
    void c(T t);
}
