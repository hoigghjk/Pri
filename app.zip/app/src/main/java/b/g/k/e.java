package b.g.k;

/* loaded from: classes.dex */
public interface e<T> {
    boolean a(T t);

    T b();
}
