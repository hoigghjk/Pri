package b.g.k;

/* loaded from: classes.dex */
public class g<T> extends f<T> {

    /* renamed from: c, reason: collision with root package name */
    private final Object f1209c;

    public g(int i2) {
        super(i2);
        this.f1209c = new Object();
    }

    @Override // b.g.k.f, b.g.k.e
    public boolean a(T t) {
        boolean a2;
        synchronized (this.f1209c) {
            a2 = super.a(t);
        }
        return a2;
    }

    @Override // b.g.k.f, b.g.k.e
    public T b() {
        T t;
        synchronized (this.f1209c) {
            t = (T) super.b();
        }
        return t;
    }
}
