package b.g.k;

import android.util.Log;
import java.io.Writer;

@Deprecated
/* loaded from: classes.dex */
public class c extends Writer {
    private final String n;
    private StringBuilder o = new StringBuilder(128);

    public c(String str) {
        this.n = str;
    }

    private void a() {
        if (this.o.length() > 0) {
            Log.d(this.n, this.o.toString());
            StringBuilder sb = this.o;
            sb.delete(0, sb.length());
        }
    }

    @Override // java.io.Writer, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        a();
    }

    @Override // java.io.Writer, java.io.Flushable
    public void flush() {
        a();
    }

    @Override // java.io.Writer
    public void write(char[] cArr, int i2, int i3) {
        for (int i4 = 0; i4 < i3; i4++) {
            char c2 = cArr[i2 + i4];
            if (c2 == '\n') {
                a();
            } else {
                this.o.append(c2);
            }
        }
    }
}
