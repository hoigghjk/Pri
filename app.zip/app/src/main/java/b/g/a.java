package b.g;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static final int f1090a = 2130837543;

    /* renamed from: b, reason: collision with root package name */
    public static final int f1091b = 2130837765;
}
