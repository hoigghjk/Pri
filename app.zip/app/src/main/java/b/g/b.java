package b.g;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public static final int f1092a = 2131034202;

    /* renamed from: b, reason: collision with root package name */
    public static final int f1093b = 2131034203;
}
