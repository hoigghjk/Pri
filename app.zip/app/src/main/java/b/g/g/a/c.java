package b.g.g.a;

import android.view.SubMenu;

/* loaded from: classes.dex */
public interface c extends a, SubMenu {
}
