package b.g.g.a;

import android.view.Menu;

/* loaded from: classes.dex */
public interface a extends Menu {
}
