package b.g.h;

/* loaded from: classes.dex */
public class b extends RuntimeException {
}
