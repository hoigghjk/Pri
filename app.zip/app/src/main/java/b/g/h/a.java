package b.g.h;

import android.os.Build;

/* loaded from: classes.dex */
public class a {
    @Deprecated
    public static boolean a() {
        return Build.VERSION.SDK_INT >= 30;
    }
}
