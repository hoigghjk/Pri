package b.a;

/* loaded from: classes.dex */
public final class h {

    /* renamed from: a, reason: collision with root package name */
    public static final int f770a = 2131492865;

    /* renamed from: b, reason: collision with root package name */
    public static final int f771b = 2131492872;

    /* renamed from: c, reason: collision with root package name */
    public static final int f772c = 2131492873;

    /* renamed from: d, reason: collision with root package name */
    public static final int f773d = 2131492874;

    /* renamed from: e, reason: collision with root package name */
    public static final int f774e = 2131492875;

    /* renamed from: f, reason: collision with root package name */
    public static final int f775f = 2131492876;

    /* renamed from: g, reason: collision with root package name */
    public static final int f776g = 2131492877;

    /* renamed from: h, reason: collision with root package name */
    public static final int f777h = 2131492878;

    /* renamed from: i, reason: collision with root package name */
    public static final int f778i = 2131492879;

    /* renamed from: j, reason: collision with root package name */
    public static final int f779j = 2131492880;

    /* renamed from: k, reason: collision with root package name */
    public static final int f780k = 2131492881;
    public static final int l = 2131492885;
}
