package b.a.n;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.view.LayoutInflater;

/* loaded from: classes.dex */
public class d extends ContextWrapper {

    /* renamed from: a, reason: collision with root package name */
    private int f832a;

    /* renamed from: b, reason: collision with root package name */
    private Resources.Theme f833b;

    /* renamed from: c, reason: collision with root package name */
    private LayoutInflater f834c;

    /* renamed from: d, reason: collision with root package name */
    private Configuration f835d;

    /* renamed from: e, reason: collision with root package name */
    private Resources f836e;

    public d() {
        super(null);
    }

    public d(Context context, int i2) {
        super(context);
        this.f832a = i2;
    }

    public d(Context context, Resources.Theme theme) {
        super(context);
        this.f833b = theme;
    }

    private Resources b() {
        Resources resources;
        if (this.f836e == null) {
            Configuration configuration = this.f835d;
            if (configuration == null) {
                resources = super.getResources();
            } else if (Build.VERSION.SDK_INT >= 17) {
                resources = createConfigurationContext(configuration).getResources();
            } else {
                Resources resources2 = super.getResources();
                Configuration configuration2 = new Configuration(resources2.getConfiguration());
                configuration2.updateFrom(this.f835d);
                this.f836e = new Resources(resources2.getAssets(), resources2.getDisplayMetrics(), configuration2);
            }
            this.f836e = resources;
        }
        return this.f836e;
    }

    private void d() {
        boolean z = this.f833b == null;
        if (z) {
            this.f833b = getResources().newTheme();
            Resources.Theme theme = getBaseContext().getTheme();
            if (theme != null) {
                this.f833b.setTo(theme);
            }
        }
        e(this.f833b, this.f832a, z);
    }

    public void a(Configuration configuration) {
        if (this.f836e != null) {
            throw new IllegalStateException("getResources() or getAssets() has already been called");
        }
        if (this.f835d != null) {
            throw new IllegalStateException("Override configuration has already been set");
        }
        this.f835d = new Configuration(configuration);
    }

    @Override // android.content.ContextWrapper
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    public int c() {
        return this.f832a;
    }

    protected void e(Resources.Theme theme, int i2, boolean z) {
        theme.applyStyle(i2, true);
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public AssetManager getAssets() {
        return getResources().getAssets();
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources getResources() {
        return b();
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Object getSystemService(String str) {
        if (!"layout_inflater".equals(str)) {
            return getBaseContext().getSystemService(str);
        }
        if (this.f834c == null) {
            this.f834c = LayoutInflater.from(getBaseContext()).cloneInContext(this);
        }
        return this.f834c;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources.Theme getTheme() {
        Resources.Theme theme = this.f833b;
        if (theme != null) {
            return theme;
        }
        if (this.f832a == 0) {
            this.f832a = b.a.i.f784d;
        }
        d();
        return this.f833b;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public void setTheme(int i2) {
        if (this.f832a != i2) {
            this.f832a = i2;
            d();
        }
    }
}
