package b.a.n;

@Deprecated
/* loaded from: classes.dex */
public interface c {
    void c();

    void d();
}
