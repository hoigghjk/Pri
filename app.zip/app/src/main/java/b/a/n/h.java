package b.a.n;

import android.view.View;
import android.view.animation.Interpolator;
import b.g.l.v;
import b.g.l.w;
import b.g.l.x;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public class h {

    /* renamed from: c, reason: collision with root package name */
    private Interpolator f865c;

    /* renamed from: d, reason: collision with root package name */
    w f866d;

    /* renamed from: e, reason: collision with root package name */
    private boolean f867e;

    /* renamed from: b, reason: collision with root package name */
    private long f864b = -1;

    /* renamed from: f, reason: collision with root package name */
    private final x f868f = new a();

    /* renamed from: a, reason: collision with root package name */
    final ArrayList<v> f863a = new ArrayList<>();

    class a extends x {

        /* renamed from: a, reason: collision with root package name */
        private boolean f869a = false;

        /* renamed from: b, reason: collision with root package name */
        private int f870b = 0;

        a() {
        }

        @Override // b.g.l.w
        public void b(View view) {
            int i2 = this.f870b + 1;
            this.f870b = i2;
            if (i2 == h.this.f863a.size()) {
                w wVar = h.this.f866d;
                if (wVar != null) {
                    wVar.b(null);
                }
                d();
            }
        }

        @Override // b.g.l.x, b.g.l.w
        public void c(View view) {
            if (this.f869a) {
                return;
            }
            this.f869a = true;
            w wVar = h.this.f866d;
            if (wVar != null) {
                wVar.c(null);
            }
        }

        void d() {
            this.f870b = 0;
            this.f869a = false;
            h.this.b();
        }
    }

    public void a() {
        if (this.f867e) {
            Iterator<v> it = this.f863a.iterator();
            while (it.hasNext()) {
                it.next().b();
            }
            this.f867e = false;
        }
    }

    void b() {
        this.f867e = false;
    }

    public h c(v vVar) {
        if (!this.f867e) {
            this.f863a.add(vVar);
        }
        return this;
    }

    public h d(v vVar, v vVar2) {
        this.f863a.add(vVar);
        vVar2.h(vVar.c());
        this.f863a.add(vVar2);
        return this;
    }

    public h e(long j2) {
        if (!this.f867e) {
            this.f864b = j2;
        }
        return this;
    }

    public h f(Interpolator interpolator) {
        if (!this.f867e) {
            this.f865c = interpolator;
        }
        return this;
    }

    public h g(w wVar) {
        if (!this.f867e) {
            this.f866d = wVar;
        }
        return this;
    }

    public void h() {
        if (this.f867e) {
            return;
        }
        Iterator<v> it = this.f863a.iterator();
        while (it.hasNext()) {
            v next = it.next();
            long j2 = this.f864b;
            if (j2 >= 0) {
                next.d(j2);
            }
            Interpolator interpolator = this.f865c;
            if (interpolator != null) {
                next.e(interpolator);
            }
            if (this.f866d != null) {
                next.f(this.f868f);
            }
            next.j();
        }
        this.f867e = true;
    }
}
