package b.a.n;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContextView;
import b.a.n.b;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public class e extends b implements g.a {
    private Context p;
    private ActionBarContextView q;
    private b.a r;
    private WeakReference<View> s;
    private boolean t;
    private androidx.appcompat.view.menu.g u;

    public e(Context context, ActionBarContextView actionBarContextView, b.a aVar, boolean z) {
        this.p = context;
        this.q = actionBarContextView;
        this.r = aVar;
        androidx.appcompat.view.menu.g gVar = new androidx.appcompat.view.menu.g(actionBarContextView.getContext());
        gVar.S(1);
        this.u = gVar;
        gVar.R(this);
    }

    @Override // androidx.appcompat.view.menu.g.a
    public boolean a(androidx.appcompat.view.menu.g gVar, MenuItem menuItem) {
        return this.r.c(this, menuItem);
    }

    @Override // androidx.appcompat.view.menu.g.a
    public void b(androidx.appcompat.view.menu.g gVar) {
        k();
        this.q.l();
    }

    @Override // b.a.n.b
    public void c() {
        if (this.t) {
            return;
        }
        this.t = true;
        this.q.sendAccessibilityEvent(32);
        this.r.b(this);
    }

    @Override // b.a.n.b
    public View d() {
        WeakReference<View> weakReference = this.s;
        if (weakReference != null) {
            return weakReference.get();
        }
        return null;
    }

    @Override // b.a.n.b
    public Menu e() {
        return this.u;
    }

    @Override // b.a.n.b
    public MenuInflater f() {
        return new g(this.q.getContext());
    }

    @Override // b.a.n.b
    public CharSequence g() {
        return this.q.getSubtitle();
    }

    @Override // b.a.n.b
    public CharSequence i() {
        return this.q.getTitle();
    }

    @Override // b.a.n.b
    public void k() {
        this.r.a(this, this.u);
    }

    @Override // b.a.n.b
    public boolean l() {
        return this.q.j();
    }

    @Override // b.a.n.b
    public void m(View view) {
        this.q.setCustomView(view);
        this.s = view != null ? new WeakReference<>(view) : null;
    }

    @Override // b.a.n.b
    public void n(int i2) {
        o(this.p.getString(i2));
    }

    @Override // b.a.n.b
    public void o(CharSequence charSequence) {
        this.q.setSubtitle(charSequence);
    }

    @Override // b.a.n.b
    public void q(int i2) {
        r(this.p.getString(i2));
    }

    @Override // b.a.n.b
    public void r(CharSequence charSequence) {
        this.q.setTitle(charSequence);
    }

    @Override // b.a.n.b
    public void s(boolean z) {
        super.s(z);
        this.q.setTitleOptional(z);
    }
}
