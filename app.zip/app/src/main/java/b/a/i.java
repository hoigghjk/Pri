package b.a;

/* loaded from: classes.dex */
public final class i {

    /* renamed from: a, reason: collision with root package name */
    public static final int f781a = 2131558404;

    /* renamed from: b, reason: collision with root package name */
    public static final int f782b = 2131558673;

    /* renamed from: c, reason: collision with root package name */
    public static final int f783c = 2131558685;

    /* renamed from: d, reason: collision with root package name */
    public static final int f784d = 2131558686;
}
