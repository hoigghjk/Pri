package b.a;

import com.pichillilorenzo.flutter_inappwebview.R;

/* loaded from: classes.dex */
public final class j {
    public static final int A = 3;
    public static final int A0 = 116;
    public static final int A1 = 12;
    public static final int A2 = 5;
    public static final int B = 4;
    public static final int B0 = 117;
    public static final int B1 = 13;
    public static final int B2 = 10;
    public static final int C = 5;
    public static final int C0 = 118;
    public static final int C1 = 14;
    public static final int C2 = 11;
    public static final int D0 = 119;
    public static final int D1 = 15;
    public static final int D2 = 12;
    public static final int E = 0;
    public static final int E0 = 120;
    public static final int E1 = 16;
    public static final int E2 = 13;
    public static final int F = 1;
    public static final int F0 = 121;
    public static final int F1 = 17;
    public static final int F2 = 14;
    public static final int G = 2;
    public static final int G0 = 122;
    public static final int G1 = 18;
    public static final int G2 = 15;
    public static final int H = 3;
    public static final int H0 = 123;
    public static final int H1 = 19;
    public static final int I = 4;
    public static final int I0 = 124;
    public static final int I1 = 20;
    public static final int I2 = 0;
    public static final int J = 5;
    public static final int J1 = 21;
    public static final int J2 = 2;
    public static final int K = 6;
    public static final int K0 = 0;
    public static final int K1 = 22;
    public static final int K2 = 3;
    public static final int L = 7;
    public static final int L2 = 4;
    public static final int M0 = 0;
    public static final int M1 = 1;
    public static final int M2 = 5;
    public static final int N = 1;
    public static final int N0 = 1;
    public static final int N1 = 5;
    public static final int N2 = 6;
    public static final int O = 2;
    public static final int O0 = 2;
    public static final int O1 = 7;
    public static final int O2 = 7;
    public static final int P = 3;
    public static final int P0 = 3;
    public static final int P1 = 8;
    public static final int P2 = 8;
    public static final int Q2 = 9;
    public static final int R = 0;
    public static final int R0 = 0;
    public static final int R1 = 0;
    public static final int R2 = 10;
    public static final int S = 1;
    public static final int S0 = 1;
    public static final int S1 = 2;
    public static final int S2 = 11;
    public static final int T = 2;
    public static final int T0 = 2;
    public static final int T2 = 12;
    public static final int U = 3;
    public static final int U0 = 3;
    public static final int U1 = 0;
    public static final int U2 = 13;
    public static final int V0 = 4;
    public static final int V1 = 1;
    public static final int V2 = 14;
    public static final int W = 0;
    public static final int W0 = 5;
    public static final int W2 = 15;
    public static final int X = 1;
    public static final int X0 = 6;
    public static final int X1 = 0;
    public static final int X2 = 16;
    public static final int Y = 2;
    public static final int Y0 = 7;
    public static final int Y1 = 1;
    public static final int Y2 = 17;
    public static final int Z = 3;
    public static final int Z0 = 8;
    public static final int Z1 = 2;
    public static final int Z2 = 18;
    public static final int a0 = 4;
    public static final int a2 = 3;
    public static final int a3 = 19;

    /* renamed from: b, reason: collision with root package name */
    public static final int f786b = 0;
    public static final int b0 = 5;
    public static final int b1 = 0;
    public static final int b2 = 4;
    public static final int b3 = 20;

    /* renamed from: c, reason: collision with root package name */
    public static final int f787c = 1;
    public static final int c0 = 6;
    public static final int c1 = 3;
    public static final int c2 = 5;
    public static final int c3 = 21;

    /* renamed from: d, reason: collision with root package name */
    public static final int f788d = 2;
    public static final int d2 = 6;
    public static final int d3 = 22;

    /* renamed from: e, reason: collision with root package name */
    public static final int f789e = 3;
    public static final int e0 = 1;
    public static final int e1 = 0;
    public static final int e2 = 7;
    public static final int e3 = 23;

    /* renamed from: f, reason: collision with root package name */
    public static final int f790f = 7;
    public static final int f0 = 2;
    public static final int f1 = 1;
    public static final int f2 = 8;
    public static final int f3 = 24;

    /* renamed from: g, reason: collision with root package name */
    public static final int f791g = 9;
    public static final int g0 = 3;
    public static final int g2 = 9;
    public static final int g3 = 25;

    /* renamed from: h, reason: collision with root package name */
    public static final int f792h = 10;
    public static final int h0 = 4;
    public static final int h1 = 0;
    public static final int h2 = 10;
    public static final int h3 = 26;

    /* renamed from: i, reason: collision with root package name */
    public static final int f793i = 12;
    public static final int i0 = 5;
    public static final int i1 = 1;
    public static final int i2 = 11;
    public static final int i3 = 27;

    /* renamed from: j, reason: collision with root package name */
    public static final int f794j = 13;
    public static final int j0 = 6;
    public static final int j1 = 2;
    public static final int j2 = 12;
    public static final int j3 = 28;

    /* renamed from: k, reason: collision with root package name */
    public static final int f795k = 14;
    public static final int k0 = 7;
    public static final int k1 = 3;
    public static final int k2 = 13;
    public static final int k3 = 29;
    public static final int l = 15;
    public static final int l0 = 8;
    public static final int l1 = 4;
    public static final int l2 = 14;
    public static final int m = 17;
    public static final int m0 = 9;
    public static final int m1 = 5;
    public static final int m2 = 15;
    public static final int m3 = 0;
    public static final int n = 20;
    public static final int n0 = 10;
    public static final int n2 = 16;
    public static final int n3 = 4;
    public static final int o = 22;
    public static final int o0 = 11;
    public static final int o1 = 0;
    public static final int p = 25;
    public static final int p0 = 12;
    public static final int p1 = 1;
    public static final int p2 = 0;
    public static final int p3 = 0;
    public static final int q = 26;
    public static final int q0 = 13;
    public static final int q1 = 2;
    public static final int q2 = 1;
    public static final int q3 = 1;
    public static final int r = 27;
    public static final int r0 = 14;
    public static final int r1 = 3;
    public static final int r2 = 2;
    public static final int r3 = 2;
    public static final int s = 28;
    public static final int s0 = 17;
    public static final int s1 = 4;
    public static final int s2 = 3;
    public static final int t0 = 18;
    public static final int t1 = 5;
    public static final int t2 = 4;
    public static final int t3 = 0;
    public static final int u = 0;
    public static final int u1 = 6;
    public static final int u3 = 1;
    public static final int v0 = 0;
    public static final int v1 = 7;
    public static final int v2 = 0;
    public static final int v3 = 2;
    public static final int w = 0;
    public static final int w0 = 1;
    public static final int w1 = 8;
    public static final int w2 = 1;
    public static final int x0 = 84;
    public static final int x1 = 9;
    public static final int x2 = 2;
    public static final int y = 0;
    public static final int y0 = 114;
    public static final int y1 = 10;
    public static final int y2 = 3;
    public static final int z = 2;
    public static final int z0 = 115;
    public static final int z1 = 11;
    public static final int z2 = 4;

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f785a = {R.attr.background, R.attr.backgroundSplit, R.attr.backgroundStacked, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.customNavigationLayout, R.attr.displayOptions, R.attr.divider, R.attr.elevation, R.attr.height, R.attr.hideOnContentScroll, R.attr.homeAsUpIndicator, R.attr.homeLayout, R.attr.icon, R.attr.indeterminateProgressStyle, R.attr.itemPadding, R.attr.logo, R.attr.navigationMode, R.attr.popupTheme, R.attr.progressBarPadding, R.attr.progressBarStyle, R.attr.subtitle, R.attr.subtitleTextStyle, R.attr.title, R.attr.titleTextStyle};
    public static final int[] t = {android.R.attr.layout_gravity};
    public static final int[] v = {android.R.attr.minWidth};
    public static final int[] x = {R.attr.background, R.attr.backgroundSplit, R.attr.closeItemLayout, R.attr.height, R.attr.subtitleTextStyle, R.attr.titleTextStyle};
    public static final int[] D = {android.R.attr.layout, R.attr.buttonIconDimen, R.attr.buttonPanelSideLayout, R.attr.listItemLayout, R.attr.listLayout, R.attr.multiChoiceItemLayout, R.attr.showTitle, R.attr.singleChoiceItemLayout};
    public static final int[] M = {android.R.attr.src, R.attr.srcCompat, R.attr.tint, R.attr.tintMode};
    public static final int[] Q = {android.R.attr.thumb, R.attr.tickMark, R.attr.tickMarkTint, R.attr.tickMarkTintMode};
    public static final int[] V = {android.R.attr.textAppearance, android.R.attr.drawableTop, android.R.attr.drawableBottom, android.R.attr.drawableLeft, android.R.attr.drawableRight, android.R.attr.drawableStart, android.R.attr.drawableEnd};
    public static final int[] d0 = {android.R.attr.textAppearance, R.attr.autoSizeMaxTextSize, R.attr.autoSizeMinTextSize, R.attr.autoSizePresetSizes, R.attr.autoSizeStepGranularity, R.attr.autoSizeTextType, R.attr.drawableBottomCompat, R.attr.drawableEndCompat, R.attr.drawableLeftCompat, R.attr.drawableRightCompat, R.attr.drawableStartCompat, R.attr.drawableTint, R.attr.drawableTintMode, R.attr.drawableTopCompat, R.attr.firstBaselineToTopHeight, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.lastBaselineToBottomHeight, R.attr.lineHeight, R.attr.textAllCaps, R.attr.textLocale};
    public static final int[] u0 = {android.R.attr.windowIsFloating, android.R.attr.windowAnimationStyle, R.attr.actionBarDivider, R.attr.actionBarItemBackground, R.attr.actionBarPopupTheme, R.attr.actionBarSize, R.attr.actionBarSplitStyle, R.attr.actionBarStyle, R.attr.actionBarTabBarStyle, R.attr.actionBarTabStyle, R.attr.actionBarTabTextStyle, R.attr.actionBarTheme, R.attr.actionBarWidgetTheme, R.attr.actionButtonStyle, R.attr.actionDropDownStyle, R.attr.actionMenuTextAppearance, R.attr.actionMenuTextColor, R.attr.actionModeBackground, R.attr.actionModeCloseButtonStyle, R.attr.actionModeCloseDrawable, R.attr.actionModeCopyDrawable, R.attr.actionModeCutDrawable, R.attr.actionModeFindDrawable, R.attr.actionModePasteDrawable, R.attr.actionModePopupWindowStyle, R.attr.actionModeSelectAllDrawable, R.attr.actionModeShareDrawable, R.attr.actionModeSplitBackground, R.attr.actionModeStyle, R.attr.actionModeWebSearchDrawable, R.attr.actionOverflowButtonStyle, R.attr.actionOverflowMenuStyle, R.attr.activityChooserViewStyle, R.attr.alertDialogButtonGroupStyle, R.attr.alertDialogCenterButtons, R.attr.alertDialogStyle, R.attr.alertDialogTheme, R.attr.autoCompleteTextViewStyle, R.attr.borderlessButtonStyle, R.attr.buttonBarButtonStyle, R.attr.buttonBarNegativeButtonStyle, R.attr.buttonBarNeutralButtonStyle, R.attr.buttonBarPositiveButtonStyle, R.attr.buttonBarStyle, R.attr.buttonStyle, R.attr.buttonStyleSmall, R.attr.checkboxStyle, R.attr.checkedTextViewStyle, R.attr.colorAccent, R.attr.colorBackgroundFloating, R.attr.colorButtonNormal, R.attr.colorControlActivated, R.attr.colorControlHighlight, R.attr.colorControlNormal, R.attr.colorError, R.attr.colorPrimary, R.attr.colorPrimaryDark, R.attr.colorSwitchThumbNormal, R.attr.controlBackground, R.attr.dialogCornerRadius, R.attr.dialogPreferredPadding, R.attr.dialogTheme, R.attr.dividerHorizontal, R.attr.dividerVertical, R.attr.dropDownListViewStyle, R.attr.dropdownListPreferredItemHeight, R.attr.editTextBackground, R.attr.editTextColor, R.attr.editTextStyle, R.attr.homeAsUpIndicator, R.attr.imageButtonStyle, R.attr.listChoiceBackgroundIndicator, R.attr.listChoiceIndicatorMultipleAnimated, R.attr.listChoiceIndicatorSingleAnimated, R.attr.listDividerAlertDialog, R.attr.listMenuViewStyle, R.attr.listPopupWindowStyle, R.attr.listPreferredItemHeight, R.attr.listPreferredItemHeightLarge, R.attr.listPreferredItemHeightSmall, R.attr.listPreferredItemPaddingEnd, R.attr.listPreferredItemPaddingLeft, R.attr.listPreferredItemPaddingRight, R.attr.listPreferredItemPaddingStart, R.attr.panelBackground, R.attr.panelMenuListTheme, R.attr.panelMenuListWidth, R.attr.popupMenuStyle, R.attr.popupWindowStyle, R.attr.radioButtonStyle, R.attr.ratingBarStyle, R.attr.ratingBarStyleIndicator, R.attr.ratingBarStyleSmall, R.attr.searchViewStyle, R.attr.seekBarStyle, R.attr.selectableItemBackground, R.attr.selectableItemBackgroundBorderless, R.attr.spinnerDropDownItemStyle, R.attr.spinnerStyle, R.attr.switchStyle, R.attr.textAppearanceLargePopupMenu, R.attr.textAppearanceListItem, R.attr.textAppearanceListItemSecondary, R.attr.textAppearanceListItemSmall, R.attr.textAppearancePopupMenuHeader, R.attr.textAppearanceSearchResultSubtitle, R.attr.textAppearanceSearchResultTitle, R.attr.textAppearanceSmallPopupMenu, R.attr.textColorAlertDialogListItem, R.attr.textColorSearchUrl, R.attr.toolbarNavigationButtonStyle, R.attr.toolbarStyle, R.attr.tooltipForegroundColor, R.attr.tooltipFrameBackground, R.attr.viewInflaterClass, R.attr.windowActionBar, R.attr.windowActionBarOverlay, R.attr.windowActionModeOverlay, R.attr.windowFixedHeightMajor, R.attr.windowFixedHeightMinor, R.attr.windowFixedWidthMajor, R.attr.windowFixedWidthMinor, R.attr.windowMinWidthMajor, R.attr.windowMinWidthMinor, R.attr.windowNoTitle};
    public static final int[] J0 = {R.attr.allowStacking};
    public static final int[] L0 = {android.R.attr.button, R.attr.buttonCompat, R.attr.buttonTint, R.attr.buttonTintMode};
    public static final int[] Q0 = {android.R.attr.gravity, android.R.attr.orientation, android.R.attr.baselineAligned, android.R.attr.baselineAlignedChildIndex, android.R.attr.weightSum, R.attr.divider, R.attr.dividerPadding, R.attr.measureWithLargestChild, R.attr.showDividers};
    public static final int[] a1 = {android.R.attr.layout_gravity, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_weight};
    public static final int[] d1 = {android.R.attr.dropDownHorizontalOffset, android.R.attr.dropDownVerticalOffset};
    public static final int[] g1 = {android.R.attr.enabled, android.R.attr.id, android.R.attr.visible, android.R.attr.menuCategory, android.R.attr.orderInCategory, android.R.attr.checkableBehavior};
    public static final int[] n1 = {android.R.attr.icon, android.R.attr.enabled, android.R.attr.id, android.R.attr.checked, android.R.attr.visible, android.R.attr.menuCategory, android.R.attr.orderInCategory, android.R.attr.title, android.R.attr.titleCondensed, android.R.attr.alphabeticShortcut, android.R.attr.numericShortcut, android.R.attr.checkable, android.R.attr.onClick, R.attr.actionLayout, R.attr.actionProviderClass, R.attr.actionViewClass, R.attr.alphabeticModifiers, R.attr.contentDescription, R.attr.iconTint, R.attr.iconTintMode, R.attr.numericModifiers, R.attr.showAsAction, R.attr.tooltipText};
    public static final int[] L1 = {android.R.attr.windowAnimationStyle, android.R.attr.itemTextAppearance, android.R.attr.horizontalDivider, android.R.attr.verticalDivider, android.R.attr.headerBackground, android.R.attr.itemBackground, android.R.attr.itemIconDisabledAlpha, R.attr.preserveIconSpacing, R.attr.subMenuArrow};
    public static final int[] Q1 = {android.R.attr.popupBackground, android.R.attr.popupAnimationStyle, R.attr.overlapAnchor};
    public static final int[] T1 = {R.attr.paddingBottomNoButtons, R.attr.paddingTopNoTitle};
    public static final int[] W1 = {android.R.attr.focusable, android.R.attr.maxWidth, android.R.attr.inputType, android.R.attr.imeOptions, R.attr.closeIcon, R.attr.commitIcon, R.attr.defaultQueryHint, R.attr.goIcon, R.attr.iconifiedByDefault, R.attr.layout, R.attr.queryBackground, R.attr.queryHint, R.attr.searchHintIcon, R.attr.searchIcon, R.attr.submitBackground, R.attr.suggestionRowLayout, R.attr.voiceIcon};
    public static final int[] o2 = {android.R.attr.entries, android.R.attr.popupBackground, android.R.attr.prompt, android.R.attr.dropDownWidth, R.attr.popupTheme};
    public static final int[] u2 = {android.R.attr.textSize, android.R.attr.typeface, android.R.attr.textStyle, android.R.attr.textColor, android.R.attr.textColorHint, android.R.attr.textColorLink, android.R.attr.shadowColor, android.R.attr.shadowDx, android.R.attr.shadowDy, android.R.attr.shadowRadius, android.R.attr.fontFamily, android.R.attr.textFontWeight, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.textAllCaps, R.attr.textLocale};
    public static final int[] H2 = {android.R.attr.gravity, android.R.attr.minHeight, R.attr.buttonGravity, R.attr.collapseContentDescription, R.attr.collapseIcon, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.logo, R.attr.logoDescription, R.attr.maxButtonHeight, R.attr.menu, R.attr.navigationContentDescription, R.attr.navigationIcon, R.attr.popupTheme, R.attr.subtitle, R.attr.subtitleTextAppearance, R.attr.subtitleTextColor, R.attr.title, R.attr.titleMargin, R.attr.titleMarginBottom, R.attr.titleMarginEnd, R.attr.titleMarginStart, R.attr.titleMarginTop, R.attr.titleMargins, R.attr.titleTextAppearance, R.attr.titleTextColor};
    public static final int[] l3 = {android.R.attr.theme, android.R.attr.focusable, R.attr.paddingEnd, R.attr.paddingStart, R.attr.theme};
    public static final int[] o3 = {android.R.attr.background, R.attr.backgroundTint, R.attr.backgroundTintMode};
    public static final int[] s3 = {android.R.attr.id, android.R.attr.layout, android.R.attr.inflatedId};
}
