package b.a;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public static final int f759a = 2131361792;

    /* renamed from: b, reason: collision with root package name */
    public static final int f760b = 2131361794;

    /* renamed from: c, reason: collision with root package name */
    public static final int f761c = 2131361795;

    /* renamed from: d, reason: collision with root package name */
    public static final int f762d = 2131361797;

    /* renamed from: e, reason: collision with root package name */
    public static final int f763e = 2131361803;

    /* renamed from: f, reason: collision with root package name */
    public static final int f764f = 2131361804;

    /* renamed from: g, reason: collision with root package name */
    public static final int f765g = 2131361805;

    /* renamed from: h, reason: collision with root package name */
    public static final int f766h = 2131361806;

    /* renamed from: i, reason: collision with root package name */
    public static final int f767i = 2131361807;

    /* renamed from: j, reason: collision with root package name */
    public static final int f768j = 2131361808;

    /* renamed from: k, reason: collision with root package name */
    public static final int f769k = 2131361809;
    public static final int l = 2131361810;
    public static final int m = 2131361811;
    public static final int n = 2131361813;
    public static final int o = 2131361814;
    public static final int p = 2131361815;
    public static final int q = 2131361816;
    public static final int r = 2131361817;
    public static final int s = 2131361819;
    public static final int t = 2131361852;
}
