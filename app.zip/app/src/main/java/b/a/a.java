package b.a;

/* loaded from: classes.dex */
public final class a {
    public static final int A = 2130837645;
    public static final int B = 2130837674;
    public static final int C = 2130837745;
    public static final int D = 2130837773;
    public static final int E = 2130837784;
    public static final int F = 2130837785;
    public static final int G = 2130837791;
    public static final int H = 2130837792;
    public static final int I = 2130837803;
    public static final int J = 2130837830;
    public static final int K = 2130837852;
    public static final int L = 2130837853;

    /* renamed from: a, reason: collision with root package name */
    public static final int f706a = 2130837506;

    /* renamed from: b, reason: collision with root package name */
    public static final int f707b = 2130837507;

    /* renamed from: c, reason: collision with root package name */
    public static final int f708c = 2130837509;

    /* renamed from: d, reason: collision with root package name */
    public static final int f709d = 2130837511;

    /* renamed from: e, reason: collision with root package name */
    public static final int f710e = 2130837512;

    /* renamed from: f, reason: collision with root package name */
    public static final int f711f = 2130837513;

    /* renamed from: g, reason: collision with root package name */
    public static final int f712g = 2130837514;

    /* renamed from: h, reason: collision with root package name */
    public static final int f713h = 2130837516;

    /* renamed from: i, reason: collision with root package name */
    public static final int f714i = 2130837527;

    /* renamed from: j, reason: collision with root package name */
    public static final int f715j = 2130837531;

    /* renamed from: k, reason: collision with root package name */
    public static final int f716k = 2130837533;
    public static final int l = 2130837534;
    public static final int m = 2130837539;
    public static final int n = 2130837540;
    public static final int o = 2130837541;
    public static final int p = 2130837547;
    public static final int q = 2130837572;
    public static final int r = 2130837584;
    public static final int s = 2130837592;
    public static final int t = 2130837594;
    public static final int u = 2130837595;
    public static final int v = 2130837596;
    public static final int w = 2130837597;
    public static final int x = 2130837602;
    public static final int y = 2130837625;
    public static final int z = 2130837641;
}
