package b.a.l.a;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.StateSet;
import androidx.appcompat.widget.m0;
import b.a.l.a.b;
import b.a.l.a.d;
import b.e.h;
import b.q.a.a.i;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public class a extends b.a.l.a.d implements androidx.core.graphics.drawable.b {
    private c B;
    private g C;
    private int D;
    private int E;
    private boolean F;

    private static class b extends g {

        /* renamed from: a, reason: collision with root package name */
        private final Animatable f801a;

        b(Animatable animatable) {
            super();
            this.f801a = animatable;
        }

        @Override // b.a.l.a.a.g
        public void c() {
            this.f801a.start();
        }

        @Override // b.a.l.a.a.g
        public void d() {
            this.f801a.stop();
        }
    }

    static class c extends d.a {
        b.e.d<Long> K;
        h<Integer> L;

        c(c cVar, a aVar, Resources resources) {
            super(cVar, aVar, resources);
            h<Integer> hVar;
            if (cVar != null) {
                this.K = cVar.K;
                hVar = cVar.L;
            } else {
                this.K = new b.e.d<>();
                hVar = new h<>();
            }
            this.L = hVar;
        }

        private static long D(int i2, int i3) {
            return i3 | (i2 << 32);
        }

        int B(int[] iArr, Drawable drawable, int i2) {
            int z = super.z(iArr, drawable);
            this.L.j(z, Integer.valueOf(i2));
            return z;
        }

        int C(int i2, int i3, Drawable drawable, boolean z) {
            int a2 = super.a(drawable);
            long D = D(i2, i3);
            long j2 = z ? 8589934592L : 0L;
            long j3 = a2;
            this.K.a(D, Long.valueOf(j3 | j2));
            if (z) {
                this.K.a(D(i3, i2), Long.valueOf(4294967296L | j3 | j2));
            }
            return a2;
        }

        int E(int i2) {
            if (i2 < 0) {
                return 0;
            }
            return this.L.g(i2, 0).intValue();
        }

        int F(int[] iArr) {
            int A = super.A(iArr);
            return A >= 0 ? A : super.A(StateSet.WILD_CARD);
        }

        int G(int i2, int i3) {
            return (int) this.K.g(D(i2, i3), -1L).longValue();
        }

        boolean H(int i2, int i3) {
            return (this.K.g(D(i2, i3), -1L).longValue() & 4294967296L) != 0;
        }

        boolean I(int i2, int i3) {
            return (this.K.g(D(i2, i3), -1L).longValue() & 8589934592L) != 0;
        }

        @Override // b.a.l.a.d.a, android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            return new a(this, null);
        }

        @Override // b.a.l.a.d.a, android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            return new a(this, resources);
        }

        @Override // b.a.l.a.d.a, b.a.l.a.b.c
        void r() {
            this.K = this.K.clone();
            this.L = this.L.clone();
        }
    }

    private static class d extends g {

        /* renamed from: a, reason: collision with root package name */
        private final b.q.a.a.c f802a;

        d(b.q.a.a.c cVar) {
            super();
            this.f802a = cVar;
        }

        @Override // b.a.l.a.a.g
        public void c() {
            this.f802a.start();
        }

        @Override // b.a.l.a.a.g
        public void d() {
            this.f802a.stop();
        }
    }

    private static class e extends g {

        /* renamed from: a, reason: collision with root package name */
        private final ObjectAnimator f803a;

        /* renamed from: b, reason: collision with root package name */
        private final boolean f804b;

        e(AnimationDrawable animationDrawable, boolean z, boolean z2) {
            super();
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            int i2 = z ? numberOfFrames - 1 : 0;
            int i3 = z ? 0 : numberOfFrames - 1;
            f fVar = new f(animationDrawable, z);
            ObjectAnimator ofInt = ObjectAnimator.ofInt(animationDrawable, "currentIndex", i2, i3);
            if (Build.VERSION.SDK_INT >= 18) {
                ofInt.setAutoCancel(true);
            }
            ofInt.setDuration(fVar.a());
            ofInt.setInterpolator(fVar);
            this.f804b = z2;
            this.f803a = ofInt;
        }

        @Override // b.a.l.a.a.g
        public boolean a() {
            return this.f804b;
        }

        @Override // b.a.l.a.a.g
        public void b() {
            this.f803a.reverse();
        }

        @Override // b.a.l.a.a.g
        public void c() {
            this.f803a.start();
        }

        @Override // b.a.l.a.a.g
        public void d() {
            this.f803a.cancel();
        }
    }

    private static class f implements TimeInterpolator {

        /* renamed from: a, reason: collision with root package name */
        private int[] f805a;

        /* renamed from: b, reason: collision with root package name */
        private int f806b;

        /* renamed from: c, reason: collision with root package name */
        private int f807c;

        f(AnimationDrawable animationDrawable, boolean z) {
            b(animationDrawable, z);
        }

        int a() {
            return this.f807c;
        }

        int b(AnimationDrawable animationDrawable, boolean z) {
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            this.f806b = numberOfFrames;
            int[] iArr = this.f805a;
            if (iArr == null || iArr.length < numberOfFrames) {
                this.f805a = new int[numberOfFrames];
            }
            int[] iArr2 = this.f805a;
            int i2 = 0;
            for (int i3 = 0; i3 < numberOfFrames; i3++) {
                int duration = animationDrawable.getDuration(z ? (numberOfFrames - i3) - 1 : i3);
                iArr2[i3] = duration;
                i2 += duration;
            }
            this.f807c = i2;
            return i2;
        }

        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f2) {
            int i2 = (int) ((f2 * this.f807c) + 0.5f);
            int i3 = this.f806b;
            int[] iArr = this.f805a;
            int i4 = 0;
            while (i4 < i3 && i2 >= iArr[i4]) {
                i2 -= iArr[i4];
                i4++;
            }
            return (i4 / i3) + (i4 < i3 ? i2 / this.f807c : 0.0f);
        }
    }

    private static abstract class g {
        private g() {
        }

        public boolean a() {
            return false;
        }

        public void b() {
        }

        public abstract void c();

        public abstract void d();
    }

    public a() {
        this(null, null);
    }

    a(c cVar, Resources resources) {
        super(null);
        this.D = -1;
        this.E = -1;
        h(new c(cVar, this, resources));
        onStateChange(getState());
        jumpToCurrentState();
    }

    public static a m(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        String name = xmlPullParser.getName();
        if (name.equals("animated-selector")) {
            a aVar = new a();
            aVar.n(context, resources, xmlPullParser, attributeSet, theme);
            return aVar;
        }
        throw new XmlPullParserException(xmlPullParser.getPositionDescription() + ": invalid animated-selector tag " + name);
    }

    private void o(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        int depth = xmlPullParser.getDepth() + 1;
        while (true) {
            int next = xmlPullParser.next();
            if (next == 1) {
                return;
            }
            int depth2 = xmlPullParser.getDepth();
            if (depth2 < depth && next == 3) {
                return;
            }
            if (next == 2 && depth2 <= depth) {
                if (xmlPullParser.getName().equals("item")) {
                    q(context, resources, xmlPullParser, attributeSet, theme);
                } else if (xmlPullParser.getName().equals("transition")) {
                    r(context, resources, xmlPullParser, attributeSet, theme);
                }
            }
        }
    }

    private void p() {
        onStateChange(getState());
    }

    private int q(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        int next;
        TypedArray k2 = b.g.e.e.g.k(resources, theme, attributeSet, b.a.m.b.f827h);
        int resourceId = k2.getResourceId(b.a.m.b.f828i, 0);
        int resourceId2 = k2.getResourceId(b.a.m.b.f829j, -1);
        Drawable j2 = resourceId2 > 0 ? m0.h().j(context, resourceId2) : null;
        k2.recycle();
        int[] k3 = k(attributeSet);
        if (j2 == null) {
            do {
                next = xmlPullParser.next();
            } while (next == 4);
            if (next != 2) {
                throw new XmlPullParserException(xmlPullParser.getPositionDescription() + ": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
            }
            j2 = xmlPullParser.getName().equals("vector") ? i.c(resources, xmlPullParser, attributeSet, theme) : Build.VERSION.SDK_INT >= 21 ? Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet, theme) : Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet);
        }
        if (j2 != null) {
            return this.B.B(k3, j2, resourceId);
        }
        throw new XmlPullParserException(xmlPullParser.getPositionDescription() + ": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
    }

    private int r(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        int next;
        TypedArray k2 = b.g.e.e.g.k(resources, theme, attributeSet, b.a.m.b.f830k);
        int resourceId = k2.getResourceId(b.a.m.b.n, -1);
        int resourceId2 = k2.getResourceId(b.a.m.b.m, -1);
        int resourceId3 = k2.getResourceId(b.a.m.b.l, -1);
        Drawable j2 = resourceId3 > 0 ? m0.h().j(context, resourceId3) : null;
        boolean z = k2.getBoolean(b.a.m.b.o, false);
        k2.recycle();
        if (j2 == null) {
            do {
                next = xmlPullParser.next();
            } while (next == 4);
            if (next != 2) {
                throw new XmlPullParserException(xmlPullParser.getPositionDescription() + ": <transition> tag requires a 'drawable' attribute or child tag defining a drawable");
            }
            j2 = xmlPullParser.getName().equals("animated-vector") ? b.q.a.a.c.a(context, resources, xmlPullParser, attributeSet, theme) : Build.VERSION.SDK_INT >= 21 ? Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet, theme) : Drawable.createFromXmlInner(resources, xmlPullParser, attributeSet);
        }
        if (j2 == null) {
            throw new XmlPullParserException(xmlPullParser.getPositionDescription() + ": <transition> tag requires a 'drawable' attribute or child tag defining a drawable");
        }
        if (resourceId != -1 && resourceId2 != -1) {
            return this.B.C(resourceId, resourceId2, j2, z);
        }
        throw new XmlPullParserException(xmlPullParser.getPositionDescription() + ": <transition> tag requires 'fromId' & 'toId' attributes");
    }

    private boolean s(int i2) {
        int c2;
        int G;
        g bVar;
        g gVar = this.C;
        if (gVar == null) {
            c2 = c();
        } else {
            if (i2 == this.D) {
                return true;
            }
            if (i2 == this.E && gVar.a()) {
                gVar.b();
                this.D = this.E;
                this.E = i2;
                return true;
            }
            c2 = this.D;
            gVar.d();
        }
        this.C = null;
        this.E = -1;
        this.D = -1;
        c cVar = this.B;
        int E = cVar.E(c2);
        int E2 = cVar.E(i2);
        if (E2 == 0 || E == 0 || (G = cVar.G(E, E2)) < 0) {
            return false;
        }
        boolean I = cVar.I(E, E2);
        g(G);
        Object current = getCurrent();
        if (current instanceof AnimationDrawable) {
            bVar = new e((AnimationDrawable) current, cVar.H(E, E2), I);
        } else {
            if (!(current instanceof b.q.a.a.c)) {
                if (current instanceof Animatable) {
                    bVar = new b((Animatable) current);
                }
                return false;
            }
            bVar = new d((b.q.a.a.c) current);
        }
        bVar.c();
        this.C = bVar;
        this.E = c2;
        this.D = i2;
        return true;
    }

    private void t(TypedArray typedArray) {
        c cVar = this.B;
        if (Build.VERSION.SDK_INT >= 21) {
            cVar.f811d |= typedArray.getChangingConfigurations();
        }
        cVar.x(typedArray.getBoolean(b.a.m.b.f823d, cVar.f816i));
        cVar.t(typedArray.getBoolean(b.a.m.b.f824e, cVar.l));
        cVar.u(typedArray.getInt(b.a.m.b.f825f, cVar.A));
        cVar.v(typedArray.getInt(b.a.m.b.f826g, cVar.B));
        setDither(typedArray.getBoolean(b.a.m.b.f821b, cVar.x));
    }

    @Override // b.a.l.a.d, b.a.l.a.b
    void h(b.c cVar) {
        super.h(cVar);
        if (cVar instanceof c) {
            this.B = (c) cVar;
        }
    }

    @Override // b.a.l.a.d, android.graphics.drawable.Drawable
    public boolean isStateful() {
        return true;
    }

    @Override // b.a.l.a.b, android.graphics.drawable.Drawable
    public void jumpToCurrentState() {
        super.jumpToCurrentState();
        g gVar = this.C;
        if (gVar != null) {
            gVar.d();
            this.C = null;
            g(this.D);
            this.D = -1;
            this.E = -1;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // b.a.l.a.d
    /* renamed from: l, reason: merged with bridge method [inline-methods] */
    public c b() {
        return new c(this.B, this, null);
    }

    @Override // b.a.l.a.d, b.a.l.a.b, android.graphics.drawable.Drawable
    public Drawable mutate() {
        if (!this.F) {
            super.mutate();
            if (this == this) {
                this.B.r();
                this.F = true;
            }
        }
        return this;
    }

    public void n(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        TypedArray k2 = b.g.e.e.g.k(resources, theme, attributeSet, b.a.m.b.f820a);
        setVisible(k2.getBoolean(b.a.m.b.f822c, true), true);
        t(k2);
        i(resources);
        k2.recycle();
        o(context, resources, xmlPullParser, attributeSet, theme);
        p();
    }

    @Override // b.a.l.a.d, b.a.l.a.b, android.graphics.drawable.Drawable
    protected boolean onStateChange(int[] iArr) {
        int F = this.B.F(iArr);
        boolean z = F != c() && (s(F) || g(F));
        Drawable current = getCurrent();
        return current != null ? z | current.setState(iArr) : z;
    }

    @Override // b.a.l.a.b, android.graphics.drawable.Drawable
    public boolean setVisible(boolean z, boolean z2) {
        boolean visible = super.setVisible(z, z2);
        g gVar = this.C;
        if (gVar != null && (visible || z2)) {
            if (z) {
                gVar.c();
            } else {
                jumpToCurrentState();
            }
        }
        return visible;
    }
}
