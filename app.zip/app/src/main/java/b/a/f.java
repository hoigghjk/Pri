package b.a;

/* loaded from: classes.dex */
public final class f {
    public static final int A = 2131165370;
    public static final int B = 2131165371;
    public static final int C = 2131165372;
    public static final int D = 2131165373;
    public static final int E = 2131165374;
    public static final int F = 2131165377;
    public static final int G = 2131165381;
    public static final int H = 2131165382;
    public static final int I = 2131165391;
    public static final int J = 2131165392;
    public static final int K = 2131165409;
    public static final int L = 2131165410;
    public static final int M = 2131165412;
    public static final int N = 2131165413;
    public static final int O = 2131165414;
    public static final int P = 2131165416;

    /* renamed from: a, reason: collision with root package name */
    public static final int f748a = 2131165224;

    /* renamed from: b, reason: collision with root package name */
    public static final int f749b = 2131165225;

    /* renamed from: c, reason: collision with root package name */
    public static final int f750c = 2131165226;

    /* renamed from: d, reason: collision with root package name */
    public static final int f751d = 2131165229;

    /* renamed from: e, reason: collision with root package name */
    public static final int f752e = 2131165230;

    /* renamed from: f, reason: collision with root package name */
    public static final int f753f = 2131165233;

    /* renamed from: g, reason: collision with root package name */
    public static final int f754g = 2131165239;

    /* renamed from: h, reason: collision with root package name */
    public static final int f755h = 2131165241;

    /* renamed from: i, reason: collision with root package name */
    public static final int f756i = 2131165242;

    /* renamed from: j, reason: collision with root package name */
    public static final int f757j = 2131165251;

    /* renamed from: k, reason: collision with root package name */
    public static final int f758k = 2131165272;
    public static final int l = 2131165288;
    public static final int m = 2131165289;
    public static final int n = 2131165290;
    public static final int o = 2131165291;
    public static final int p = 2131165293;
    public static final int q = 2131165299;
    public static final int r = 2131165310;
    public static final int s = 2131165333;
    public static final int t = 2131165350;
    public static final int u = 2131165362;
    public static final int v = 2131165363;
    public static final int w = 2131165364;
    public static final int x = 2131165367;
    public static final int y = 2131165368;
    public static final int z = 2131165369;
}
