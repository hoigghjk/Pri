package b.a.m;

import android.R;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: b, reason: collision with root package name */
    public static final int f821b = 0;

    /* renamed from: c, reason: collision with root package name */
    public static final int f822c = 1;

    /* renamed from: d, reason: collision with root package name */
    public static final int f823d = 2;

    /* renamed from: e, reason: collision with root package name */
    public static final int f824e = 3;

    /* renamed from: f, reason: collision with root package name */
    public static final int f825f = 4;

    /* renamed from: g, reason: collision with root package name */
    public static final int f826g = 5;

    /* renamed from: i, reason: collision with root package name */
    public static final int f828i = 0;

    /* renamed from: j, reason: collision with root package name */
    public static final int f829j = 1;
    public static final int l = 0;
    public static final int m = 1;
    public static final int n = 2;
    public static final int o = 3;

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f820a = {R.attr.dither, R.attr.visible, R.attr.variablePadding, R.attr.constantSize, R.attr.enterFadeDuration, R.attr.exitFadeDuration};

    /* renamed from: h, reason: collision with root package name */
    public static final int[] f827h = {R.attr.id, R.attr.drawable};

    /* renamed from: k, reason: collision with root package name */
    public static final int[] f830k = {R.attr.drawable, R.attr.toId, R.attr.fromId, R.attr.reversible};
}
