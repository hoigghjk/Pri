package b.a;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public static final int f718a = 2130968581;

    /* renamed from: b, reason: collision with root package name */
    public static final int f719b = 2130968582;

    /* renamed from: c, reason: collision with root package name */
    public static final int f720c = 2130968595;

    /* renamed from: d, reason: collision with root package name */
    public static final int f721d = 2130968596;

    /* renamed from: e, reason: collision with root package name */
    public static final int f722e = 2130968597;

    /* renamed from: f, reason: collision with root package name */
    public static final int f723f = 2130968598;

    /* renamed from: g, reason: collision with root package name */
    public static final int f724g = 2130968599;

    /* renamed from: h, reason: collision with root package name */
    public static final int f725h = 2130968600;
}
