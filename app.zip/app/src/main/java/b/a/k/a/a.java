package b.a.k.a;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import androidx.appcompat.widget.m0;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    private static final ThreadLocal<TypedValue> f796a = new ThreadLocal<>();

    /* renamed from: b, reason: collision with root package name */
    private static final WeakHashMap<Context, SparseArray<C0024a>> f797b = new WeakHashMap<>(0);

    /* renamed from: c, reason: collision with root package name */
    private static final Object f798c = new Object();

    /* renamed from: b.a.k.a.a$a, reason: collision with other inner class name */
    private static class C0024a {

        /* renamed from: a, reason: collision with root package name */
        final ColorStateList f799a;

        /* renamed from: b, reason: collision with root package name */
        final Configuration f800b;

        C0024a(ColorStateList colorStateList, Configuration configuration) {
            this.f799a = colorStateList;
            this.f800b = configuration;
        }
    }

    private static void a(Context context, int i2, ColorStateList colorStateList) {
        synchronized (f798c) {
            WeakHashMap<Context, SparseArray<C0024a>> weakHashMap = f797b;
            SparseArray<C0024a> sparseArray = weakHashMap.get(context);
            if (sparseArray == null) {
                sparseArray = new SparseArray<>();
                weakHashMap.put(context, sparseArray);
            }
            sparseArray.append(i2, new C0024a(colorStateList, context.getResources().getConfiguration()));
        }
    }

    private static ColorStateList b(Context context, int i2) {
        C0024a c0024a;
        synchronized (f798c) {
            SparseArray<C0024a> sparseArray = f797b.get(context);
            if (sparseArray != null && sparseArray.size() > 0 && (c0024a = sparseArray.get(i2)) != null) {
                if (c0024a.f800b.equals(context.getResources().getConfiguration())) {
                    return c0024a.f799a;
                }
                sparseArray.remove(i2);
            }
            return null;
        }
    }

    public static ColorStateList c(Context context, int i2) {
        if (Build.VERSION.SDK_INT >= 23) {
            return context.getColorStateList(i2);
        }
        ColorStateList b2 = b(context, i2);
        if (b2 != null) {
            return b2;
        }
        ColorStateList f2 = f(context, i2);
        if (f2 == null) {
            return b.g.e.a.e(context, i2);
        }
        a(context, i2, f2);
        return f2;
    }

    public static Drawable d(Context context, int i2) {
        return m0.h().j(context, i2);
    }

    private static TypedValue e() {
        ThreadLocal<TypedValue> threadLocal = f796a;
        TypedValue typedValue = threadLocal.get();
        if (typedValue != null) {
            return typedValue;
        }
        TypedValue typedValue2 = new TypedValue();
        threadLocal.set(typedValue2);
        return typedValue2;
    }

    private static ColorStateList f(Context context, int i2) {
        if (g(context, i2)) {
            return null;
        }
        Resources resources = context.getResources();
        try {
            return b.g.e.e.a.a(resources, resources.getXml(i2), context.getTheme());
        } catch (Exception e2) {
            Log.e("AppCompatResources", "Failed to inflate ColorStateList, leaving it to the framework", e2);
            return null;
        }
    }

    private static boolean g(Context context, int i2) {
        Resources resources = context.getResources();
        TypedValue e2 = e();
        resources.getValue(i2, e2, true);
        int i3 = e2.type;
        return i3 >= 28 && i3 <= 31;
    }
}
