package b.h.a;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/* loaded from: classes.dex */
public abstract class c extends a {
    private int v;
    private int w;
    private LayoutInflater x;

    @Deprecated
    public c(Context context, int i2, Cursor cursor, boolean z) {
        super(context, cursor, z);
        this.w = i2;
        this.v = i2;
        this.x = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    @Override // b.h.a.a
    public View g(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.x.inflate(this.w, viewGroup, false);
    }

    @Override // b.h.a.a
    public View h(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.x.inflate(this.v, viewGroup, false);
    }
}
