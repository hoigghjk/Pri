package b.h.a;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import b.h.a.b;

/* loaded from: classes.dex */
public abstract class a extends BaseAdapter implements Filterable, b.a {
    protected boolean n;
    protected boolean o;
    protected Cursor p;
    protected Context q;
    protected int r;
    protected C0044a s;
    protected DataSetObserver t;
    protected b.h.a.b u;

    /* renamed from: b.h.a.a$a, reason: collision with other inner class name */
    private class C0044a extends ContentObserver {
        C0044a() {
            super(new Handler());
        }

        @Override // android.database.ContentObserver
        public boolean deliverSelfNotifications() {
            return true;
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean z) {
            a.this.i();
        }
    }

    private class b extends DataSetObserver {
        b() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            a aVar = a.this;
            aVar.n = true;
            aVar.notifyDataSetChanged();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            a aVar = a.this;
            aVar.n = false;
            aVar.notifyDataSetInvalidated();
        }
    }

    public a(Context context, Cursor cursor, boolean z) {
        f(context, cursor, z ? 1 : 2);
    }

    public void a(Cursor cursor) {
        Cursor j2 = j(cursor);
        if (j2 != null) {
            j2.close();
        }
    }

    @Override // b.h.a.b.a
    public Cursor b() {
        return this.p;
    }

    public abstract CharSequence c(Cursor cursor);

    public abstract void e(View view, Context context, Cursor cursor);

    void f(Context context, Cursor cursor, int i2) {
        b bVar;
        if ((i2 & 1) == 1) {
            i2 |= 2;
            this.o = true;
        } else {
            this.o = false;
        }
        boolean z = cursor != null;
        this.p = cursor;
        this.n = z;
        this.q = context;
        this.r = z ? cursor.getColumnIndexOrThrow("_id") : -1;
        if ((i2 & 2) == 2) {
            this.s = new C0044a();
            bVar = new b();
        } else {
            bVar = null;
            this.s = null;
        }
        this.t = bVar;
        if (z) {
            C0044a c0044a = this.s;
            if (c0044a != null) {
                cursor.registerContentObserver(c0044a);
            }
            DataSetObserver dataSetObserver = this.t;
            if (dataSetObserver != null) {
                cursor.registerDataSetObserver(dataSetObserver);
            }
        }
    }

    public abstract View g(Context context, Cursor cursor, ViewGroup viewGroup);

    @Override // android.widget.Adapter
    public int getCount() {
        Cursor cursor;
        if (!this.n || (cursor = this.p) == null) {
            return 0;
        }
        return cursor.getCount();
    }

    @Override // android.widget.BaseAdapter, android.widget.SpinnerAdapter
    public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
        if (!this.n) {
            return null;
        }
        this.p.moveToPosition(i2);
        if (view == null) {
            view = g(this.q, this.p, viewGroup);
        }
        e(view, this.q, this.p);
        return view;
    }

    @Override // android.widget.Filterable
    public Filter getFilter() {
        if (this.u == null) {
            this.u = new b.h.a.b(this);
        }
        return this.u;
    }

    @Override // android.widget.Adapter
    public Object getItem(int i2) {
        Cursor cursor;
        if (!this.n || (cursor = this.p) == null) {
            return null;
        }
        cursor.moveToPosition(i2);
        return this.p;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i2) {
        Cursor cursor;
        if (this.n && (cursor = this.p) != null && cursor.moveToPosition(i2)) {
            return this.p.getLong(this.r);
        }
        return 0L;
    }

    @Override // android.widget.Adapter
    public View getView(int i2, View view, ViewGroup viewGroup) {
        if (!this.n) {
            throw new IllegalStateException("this should only be called when the cursor is valid");
        }
        if (this.p.moveToPosition(i2)) {
            if (view == null) {
                view = h(this.q, this.p, viewGroup);
            }
            e(view, this.q, this.p);
            return view;
        }
        throw new IllegalStateException("couldn't move cursor to position " + i2);
    }

    public abstract View h(Context context, Cursor cursor, ViewGroup viewGroup);

    protected void i() {
        Cursor cursor;
        if (!this.o || (cursor = this.p) == null || cursor.isClosed()) {
            return;
        }
        this.n = this.p.requery();
    }

    public Cursor j(Cursor cursor) {
        Cursor cursor2 = this.p;
        if (cursor == cursor2) {
            return null;
        }
        if (cursor2 != null) {
            C0044a c0044a = this.s;
            if (c0044a != null) {
                cursor2.unregisterContentObserver(c0044a);
            }
            DataSetObserver dataSetObserver = this.t;
            if (dataSetObserver != null) {
                cursor2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.p = cursor;
        if (cursor != null) {
            C0044a c0044a2 = this.s;
            if (c0044a2 != null) {
                cursor.registerContentObserver(c0044a2);
            }
            DataSetObserver dataSetObserver2 = this.t;
            if (dataSetObserver2 != null) {
                cursor.registerDataSetObserver(dataSetObserver2);
            }
            this.r = cursor.getColumnIndexOrThrow("_id");
            this.n = true;
            notifyDataSetChanged();
        } else {
            this.r = -1;
            this.n = false;
            notifyDataSetInvalidated();
        }
        return cursor2;
    }
}
