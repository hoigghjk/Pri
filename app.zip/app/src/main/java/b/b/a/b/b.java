package b.b.a.b;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public class b<K, V> implements Iterable<Map.Entry<K, V>> {
    c<K, V> n;
    private c<K, V> o;
    private WeakHashMap<f<K, V>, Boolean> p = new WeakHashMap<>();
    private int q = 0;

    static class a<K, V> extends e<K, V> {
        a(c<K, V> cVar, c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        @Override // b.b.a.b.b.e
        c<K, V> b(c<K, V> cVar) {
            return cVar.q;
        }

        @Override // b.b.a.b.b.e
        c<K, V> d(c<K, V> cVar) {
            return cVar.p;
        }
    }

    /* renamed from: b.b.a.b.b$b, reason: collision with other inner class name */
    private static class C0027b<K, V> extends e<K, V> {
        C0027b(c<K, V> cVar, c<K, V> cVar2) {
            super(cVar, cVar2);
        }

        @Override // b.b.a.b.b.e
        c<K, V> b(c<K, V> cVar) {
            return cVar.p;
        }

        @Override // b.b.a.b.b.e
        c<K, V> d(c<K, V> cVar) {
            return cVar.q;
        }
    }

    static class c<K, V> implements Map.Entry<K, V> {
        final K n;
        final V o;
        c<K, V> p;
        c<K, V> q;

        c(K k2, V v) {
            this.n = k2;
            this.o = v;
        }

        @Override // java.util.Map.Entry
        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            return this.n.equals(cVar.n) && this.o.equals(cVar.o);
        }

        @Override // java.util.Map.Entry
        public K getKey() {
            return this.n;
        }

        @Override // java.util.Map.Entry
        public V getValue() {
            return this.o;
        }

        @Override // java.util.Map.Entry
        public int hashCode() {
            return this.n.hashCode() ^ this.o.hashCode();
        }

        @Override // java.util.Map.Entry
        public V setValue(V v) {
            throw new UnsupportedOperationException("An entry modification is not supported");
        }

        public String toString() {
            return this.n + "=" + this.o;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public class d implements Iterator<Map.Entry<K, V>>, f<K, V> {
        private c<K, V> n;
        private boolean o = true;

        d() {
        }

        @Override // b.b.a.b.b.f
        public void a(c<K, V> cVar) {
            c<K, V> cVar2 = this.n;
            if (cVar == cVar2) {
                c<K, V> cVar3 = cVar2.q;
                this.n = cVar3;
                this.o = cVar3 == null;
            }
        }

        @Override // java.util.Iterator
        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public Map.Entry<K, V> next() {
            c<K, V> cVar;
            if (this.o) {
                this.o = false;
                cVar = b.this.n;
            } else {
                c<K, V> cVar2 = this.n;
                cVar = cVar2 != null ? cVar2.p : null;
            }
            this.n = cVar;
            return this.n;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            if (this.o) {
                return b.this.n != null;
            }
            c<K, V> cVar = this.n;
            return (cVar == null || cVar.p == null) ? false : true;
        }
    }

    private static abstract class e<K, V> implements Iterator<Map.Entry<K, V>>, f<K, V> {
        c<K, V> n;
        c<K, V> o;

        e(c<K, V> cVar, c<K, V> cVar2) {
            this.n = cVar2;
            this.o = cVar;
        }

        private c<K, V> f() {
            c<K, V> cVar = this.o;
            c<K, V> cVar2 = this.n;
            if (cVar == cVar2 || cVar2 == null) {
                return null;
            }
            return d(cVar);
        }

        @Override // b.b.a.b.b.f
        public void a(c<K, V> cVar) {
            if (this.n == cVar && cVar == this.o) {
                this.o = null;
                this.n = null;
            }
            c<K, V> cVar2 = this.n;
            if (cVar2 == cVar) {
                this.n = b(cVar2);
            }
            if (this.o == cVar) {
                this.o = f();
            }
        }

        abstract c<K, V> b(c<K, V> cVar);

        abstract c<K, V> d(c<K, V> cVar);

        @Override // java.util.Iterator
        /* renamed from: e, reason: merged with bridge method [inline-methods] */
        public Map.Entry<K, V> next() {
            c<K, V> cVar = this.o;
            this.o = f();
            return cVar;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.o != null;
        }
    }

    interface f<K, V> {
        void a(c<K, V> cVar);
    }

    public Map.Entry<K, V> b() {
        return this.n;
    }

    public Iterator<Map.Entry<K, V>> descendingIterator() {
        C0027b c0027b = new C0027b(this.o, this.n);
        this.p.put(c0027b, Boolean.FALSE);
        return c0027b;
    }

    protected c<K, V> e(K k2) {
        c<K, V> cVar = this.n;
        while (cVar != null && !cVar.n.equals(k2)) {
            cVar = cVar.p;
        }
        return cVar;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        if (size() != bVar.size()) {
            return false;
        }
        Iterator<Map.Entry<K, V>> it = iterator();
        Iterator<Map.Entry<K, V>> it2 = bVar.iterator();
        while (it.hasNext() && it2.hasNext()) {
            Map.Entry<K, V> next = it.next();
            Map.Entry<K, V> next2 = it2.next();
            if ((next == null && next2 != null) || (next != null && !next.equals(next2))) {
                return false;
            }
        }
        return (it.hasNext() || it2.hasNext()) ? false : true;
    }

    public b<K, V>.d f() {
        b<K, V>.d dVar = new d();
        this.p.put(dVar, Boolean.FALSE);
        return dVar;
    }

    public Map.Entry<K, V> g() {
        return this.o;
    }

    public int hashCode() {
        Iterator<Map.Entry<K, V>> it = iterator();
        int i2 = 0;
        while (it.hasNext()) {
            i2 += it.next().hashCode();
        }
        return i2;
    }

    protected c<K, V> i(K k2, V v) {
        c<K, V> cVar = new c<>(k2, v);
        this.q++;
        c<K, V> cVar2 = this.o;
        if (cVar2 == null) {
            this.n = cVar;
        } else {
            cVar2.p = cVar;
            cVar.q = cVar2;
        }
        this.o = cVar;
        return cVar;
    }

    @Override // java.lang.Iterable
    public Iterator<Map.Entry<K, V>> iterator() {
        a aVar = new a(this.n, this.o);
        this.p.put(aVar, Boolean.FALSE);
        return aVar;
    }

    public V j(K k2, V v) {
        c<K, V> e2 = e(k2);
        if (e2 != null) {
            return e2.o;
        }
        i(k2, v);
        return null;
    }

    public V k(K k2) {
        c<K, V> e2 = e(k2);
        if (e2 == null) {
            return null;
        }
        this.q--;
        if (!this.p.isEmpty()) {
            Iterator<f<K, V>> it = this.p.keySet().iterator();
            while (it.hasNext()) {
                it.next().a(e2);
            }
        }
        c<K, V> cVar = e2.q;
        c<K, V> cVar2 = e2.p;
        if (cVar != null) {
            cVar.p = cVar2;
        } else {
            this.n = cVar2;
        }
        c<K, V> cVar3 = e2.p;
        if (cVar3 != null) {
            cVar3.q = cVar;
        } else {
            this.o = cVar;
        }
        e2.p = null;
        e2.q = null;
        return e2.o;
    }

    public int size() {
        return this.q;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Iterator<Map.Entry<K, V>> it = iterator();
        while (it.hasNext()) {
            sb.append(it.next().toString());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
