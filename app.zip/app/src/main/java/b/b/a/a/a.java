package b.b.a.a;

/* loaded from: classes.dex */
public class a extends c {

    /* renamed from: c, reason: collision with root package name */
    private static volatile a f872c;

    /* renamed from: a, reason: collision with root package name */
    private c f873a;

    /* renamed from: b, reason: collision with root package name */
    private c f874b;

    private a() {
        b bVar = new b();
        this.f874b = bVar;
        this.f873a = bVar;
    }

    public static a c() {
        if (f872c != null) {
            return f872c;
        }
        synchronized (a.class) {
            if (f872c == null) {
                f872c = new a();
            }
        }
        return f872c;
    }

    @Override // b.b.a.a.c
    public boolean a() {
        return this.f873a.a();
    }

    @Override // b.b.a.a.c
    public void b(Runnable runnable) {
        this.f873a.b(runnable);
    }
}
