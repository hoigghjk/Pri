package b.b.a.a;

/* loaded from: classes.dex */
public abstract class c {
    public abstract boolean a();

    public abstract void b(Runnable runnable);
}
