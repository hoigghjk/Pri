package b.b.a.b;

import b.b.a.b.b;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public class a<K, V> extends b<K, V> {
    private HashMap<K, b.c<K, V>> r = new HashMap<>();

    public boolean contains(K k2) {
        return this.r.containsKey(k2);
    }

    @Override // b.b.a.b.b
    protected b.c<K, V> e(K k2) {
        return this.r.get(k2);
    }

    @Override // b.b.a.b.b
    public V j(K k2, V v) {
        b.c<K, V> e2 = e(k2);
        if (e2 != null) {
            return e2.o;
        }
        this.r.put(k2, i(k2, v));
        return null;
    }

    @Override // b.b.a.b.b
    public V k(K k2) {
        V v = (V) super.k(k2);
        this.r.remove(k2);
        return v;
    }

    public Map.Entry<K, V> l(K k2) {
        if (contains(k2)) {
            return this.r.get(k2).q;
        }
        return null;
    }
}
