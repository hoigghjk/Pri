package b.b.a.a;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.dex */
public class b extends c {

    /* renamed from: a, reason: collision with root package name */
    private final Object f875a = new Object();

    /* renamed from: b, reason: collision with root package name */
    private final ExecutorService f876b = Executors.newFixedThreadPool(2, new a(this));

    /* renamed from: c, reason: collision with root package name */
    private volatile Handler f877c;

    class a implements ThreadFactory {
        private final AtomicInteger n = new AtomicInteger(0);

        a(b bVar) {
        }

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable);
            thread.setName(String.format("arch_disk_io_%d", Integer.valueOf(this.n.getAndIncrement())));
            return thread;
        }
    }

    @Override // b.b.a.a.c
    public boolean a() {
        return Looper.getMainLooper().getThread() == Thread.currentThread();
    }

    @Override // b.b.a.a.c
    public void b(Runnable runnable) {
        if (this.f877c == null) {
            synchronized (this.f875a) {
                if (this.f877c == null) {
                    this.f877c = new Handler(Looper.getMainLooper());
                }
            }
        }
        this.f877c.post(runnable);
    }
}
