package b.m.a;

import android.os.Bundle;
import androidx.lifecycle.g;
import androidx.lifecycle.s;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: b.m.a.a$a, reason: collision with other inner class name */
    public interface InterfaceC0047a<D> {
        void a(b.m.b.b<D> bVar, D d2);

        b.m.b.b<D> b(int i2, Bundle bundle);

        void c(b.m.b.b<D> bVar);
    }

    public static <T extends g & s> a b(T t) {
        return new b(t, t.getViewModelStore());
    }

    @Deprecated
    public abstract void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract <D> b.m.b.b<D> c(int i2, Bundle bundle, InterfaceC0047a<D> interfaceC0047a);

    public abstract void d();
}
