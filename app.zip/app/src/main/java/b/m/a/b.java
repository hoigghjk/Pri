package b.m.a;

import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import androidx.lifecycle.g;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.p;
import androidx.lifecycle.q;
import androidx.lifecycle.r;
import b.e.h;
import b.m.a.a;
import b.m.b.b;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;

/* loaded from: classes.dex */
class b extends b.m.a.a {

    /* renamed from: c, reason: collision with root package name */
    static boolean f1329c = false;

    /* renamed from: a, reason: collision with root package name */
    private final g f1330a;

    /* renamed from: b, reason: collision with root package name */
    private final c f1331b;

    public static class a<D> extends l<D> implements b.InterfaceC0050b<D> {

        /* renamed from: k, reason: collision with root package name */
        private final int f1332k;
        private final Bundle l;
        private final b.m.b.b<D> m;
        private g n;
        private C0048b<D> o;
        private b.m.b.b<D> p;

        a(int i2, Bundle bundle, b.m.b.b<D> bVar, b.m.b.b<D> bVar2) {
            this.f1332k = i2;
            this.l = bundle;
            this.m = bVar;
            this.p = bVar2;
            bVar.r(i2, this);
        }

        @Override // b.m.b.b.InterfaceC0050b
        public void a(b.m.b.b<D> bVar, D d2) {
            if (b.f1329c) {
                Log.v("LoaderManager", "onLoadComplete: " + this);
            }
            if (Looper.myLooper() == Looper.getMainLooper()) {
                l(d2);
                return;
            }
            if (b.f1329c) {
                Log.w("LoaderManager", "onLoadComplete was incorrectly called on a background thread");
            }
            j(d2);
        }

        @Override // androidx.lifecycle.LiveData
        protected void h() {
            if (b.f1329c) {
                Log.v("LoaderManager", "  Starting: " + this);
            }
            this.m.u();
        }

        @Override // androidx.lifecycle.LiveData
        protected void i() {
            if (b.f1329c) {
                Log.v("LoaderManager", "  Stopping: " + this);
            }
            this.m.v();
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // androidx.lifecycle.LiveData
        public void k(m<? super D> mVar) {
            super.k(mVar);
            this.n = null;
            this.o = null;
        }

        @Override // androidx.lifecycle.l, androidx.lifecycle.LiveData
        public void l(D d2) {
            super.l(d2);
            b.m.b.b<D> bVar = this.p;
            if (bVar != null) {
                bVar.s();
                this.p = null;
            }
        }

        b.m.b.b<D> m(boolean z) {
            if (b.f1329c) {
                Log.v("LoaderManager", "  Destroying: " + this);
            }
            this.m.c();
            this.m.b();
            C0048b<D> c0048b = this.o;
            if (c0048b != null) {
                k(c0048b);
                if (z) {
                    c0048b.d();
                }
            }
            this.m.w(this);
            if ((c0048b == null || c0048b.c()) && !z) {
                return this.m;
            }
            this.m.s();
            return this.p;
        }

        public void n(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            printWriter.print(str);
            printWriter.print("mId=");
            printWriter.print(this.f1332k);
            printWriter.print(" mArgs=");
            printWriter.println(this.l);
            printWriter.print(str);
            printWriter.print("mLoader=");
            printWriter.println(this.m);
            this.m.h(str + "  ", fileDescriptor, printWriter, strArr);
            if (this.o != null) {
                printWriter.print(str);
                printWriter.print("mCallbacks=");
                printWriter.println(this.o);
                this.o.b(str + "  ", printWriter);
            }
            printWriter.print(str);
            printWriter.print("mData=");
            printWriter.println(o().e(e()));
            printWriter.print(str);
            printWriter.print("mStarted=");
            printWriter.println(f());
        }

        b.m.b.b<D> o() {
            return this.m;
        }

        void p() {
            g gVar = this.n;
            C0048b<D> c0048b = this.o;
            if (gVar == null || c0048b == null) {
                return;
            }
            super.k(c0048b);
            g(gVar, c0048b);
        }

        b.m.b.b<D> q(g gVar, a.InterfaceC0047a<D> interfaceC0047a) {
            C0048b<D> c0048b = new C0048b<>(this.m, interfaceC0047a);
            g(gVar, c0048b);
            C0048b<D> c0048b2 = this.o;
            if (c0048b2 != null) {
                k(c0048b2);
            }
            this.n = gVar;
            this.o = c0048b;
            return this.m;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(64);
            sb.append("LoaderInfo{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" #");
            sb.append(this.f1332k);
            sb.append(" : ");
            b.g.k.b.a(this.m, sb);
            sb.append("}}");
            return sb.toString();
        }
    }

    /* renamed from: b.m.a.b$b, reason: collision with other inner class name */
    static class C0048b<D> implements m<D> {

        /* renamed from: a, reason: collision with root package name */
        private final b.m.b.b<D> f1333a;

        /* renamed from: b, reason: collision with root package name */
        private final a.InterfaceC0047a<D> f1334b;

        /* renamed from: c, reason: collision with root package name */
        private boolean f1335c = false;

        C0048b(b.m.b.b<D> bVar, a.InterfaceC0047a<D> interfaceC0047a) {
            this.f1333a = bVar;
            this.f1334b = interfaceC0047a;
        }

        @Override // androidx.lifecycle.m
        public void a(D d2) {
            if (b.f1329c) {
                Log.v("LoaderManager", "  onLoadFinished in " + this.f1333a + ": " + this.f1333a.e(d2));
            }
            this.f1334b.a(this.f1333a, d2);
            this.f1335c = true;
        }

        public void b(String str, PrintWriter printWriter) {
            printWriter.print(str);
            printWriter.print("mDeliveredData=");
            printWriter.println(this.f1335c);
        }

        boolean c() {
            return this.f1335c;
        }

        void d() {
            if (this.f1335c) {
                if (b.f1329c) {
                    Log.v("LoaderManager", "  Resetting: " + this.f1333a);
                }
                this.f1334b.c(this.f1333a);
            }
        }

        public String toString() {
            return this.f1334b.toString();
        }
    }

    static class c extends p {

        /* renamed from: d, reason: collision with root package name */
        private static final q.a f1336d = new a();

        /* renamed from: b, reason: collision with root package name */
        private h<a> f1337b = new h<>();

        /* renamed from: c, reason: collision with root package name */
        private boolean f1338c = false;

        static class a implements q.a {
            a() {
            }

            @Override // androidx.lifecycle.q.a
            public <T extends p> T a(Class<T> cls) {
                return new c();
            }
        }

        c() {
        }

        static c f(r rVar) {
            return (c) new q(rVar, f1336d).a(c.class);
        }

        @Override // androidx.lifecycle.p
        protected void c() {
            super.c();
            int m = this.f1337b.m();
            for (int i2 = 0; i2 < m; i2++) {
                this.f1337b.n(i2).m(true);
            }
            this.f1337b.c();
        }

        public void d(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            if (this.f1337b.m() > 0) {
                printWriter.print(str);
                printWriter.println("Loaders:");
                String str2 = str + "    ";
                for (int i2 = 0; i2 < this.f1337b.m(); i2++) {
                    a n = this.f1337b.n(i2);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(this.f1337b.i(i2));
                    printWriter.print(": ");
                    printWriter.println(n.toString());
                    n.n(str2, fileDescriptor, printWriter, strArr);
                }
            }
        }

        void e() {
            this.f1338c = false;
        }

        <D> a<D> g(int i2) {
            return this.f1337b.f(i2);
        }

        boolean h() {
            return this.f1338c;
        }

        void i() {
            int m = this.f1337b.m();
            for (int i2 = 0; i2 < m; i2++) {
                this.f1337b.n(i2).p();
            }
        }

        void j(int i2, a aVar) {
            this.f1337b.j(i2, aVar);
        }

        void k() {
            this.f1338c = true;
        }
    }

    b(g gVar, r rVar) {
        this.f1330a = gVar;
        this.f1331b = c.f(rVar);
    }

    private <D> b.m.b.b<D> e(int i2, Bundle bundle, a.InterfaceC0047a<D> interfaceC0047a, b.m.b.b<D> bVar) {
        try {
            this.f1331b.k();
            b.m.b.b<D> b2 = interfaceC0047a.b(i2, bundle);
            if (b2 == null) {
                throw new IllegalArgumentException("Object returned from onCreateLoader must not be null");
            }
            if (b2.getClass().isMemberClass() && !Modifier.isStatic(b2.getClass().getModifiers())) {
                throw new IllegalArgumentException("Object returned from onCreateLoader must not be a non-static inner member class: " + b2);
            }
            a aVar = new a(i2, bundle, b2, bVar);
            if (f1329c) {
                Log.v("LoaderManager", "  Created new loader " + aVar);
            }
            this.f1331b.j(i2, aVar);
            this.f1331b.e();
            return aVar.q(this.f1330a, interfaceC0047a);
        } catch (Throwable th) {
            this.f1331b.e();
            throw th;
        }
    }

    @Override // b.m.a.a
    @Deprecated
    public void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        this.f1331b.d(str, fileDescriptor, printWriter, strArr);
    }

    @Override // b.m.a.a
    public <D> b.m.b.b<D> c(int i2, Bundle bundle, a.InterfaceC0047a<D> interfaceC0047a) {
        if (this.f1331b.h()) {
            throw new IllegalStateException("Called while creating a loader");
        }
        if (Looper.getMainLooper() != Looper.myLooper()) {
            throw new IllegalStateException("initLoader must be called on the main thread");
        }
        a<D> g2 = this.f1331b.g(i2);
        if (f1329c) {
            Log.v("LoaderManager", "initLoader in " + this + ": args=" + bundle);
        }
        if (g2 == null) {
            return e(i2, bundle, interfaceC0047a, null);
        }
        if (f1329c) {
            Log.v("LoaderManager", "  Re-using existing loader " + g2);
        }
        return g2.q(this.f1330a, interfaceC0047a);
    }

    @Override // b.m.a.a
    public void d() {
        this.f1331b.i();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("LoaderManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        b.g.k.b.a(this.f1330a, sb);
        sb.append("}}");
        return sb.toString();
    }
}
