package b.m.b;

import android.content.Context;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* loaded from: classes.dex */
public class b<D> {

    /* renamed from: a, reason: collision with root package name */
    int f1342a;

    /* renamed from: b, reason: collision with root package name */
    InterfaceC0050b<D> f1343b;

    /* renamed from: c, reason: collision with root package name */
    a<D> f1344c;

    /* renamed from: d, reason: collision with root package name */
    boolean f1345d = false;

    /* renamed from: e, reason: collision with root package name */
    boolean f1346e = false;

    /* renamed from: f, reason: collision with root package name */
    boolean f1347f = true;

    /* renamed from: g, reason: collision with root package name */
    boolean f1348g = false;

    /* renamed from: h, reason: collision with root package name */
    boolean f1349h = false;

    public interface a<D> {
        void a(b<D> bVar);
    }

    /* renamed from: b.m.b.b$b, reason: collision with other inner class name */
    public interface InterfaceC0050b<D> {
        void a(b<D> bVar, D d2);
    }

    public b(Context context) {
        context.getApplicationContext();
    }

    public void b() {
        this.f1346e = true;
        k();
    }

    public boolean c() {
        return l();
    }

    public void d() {
        this.f1349h = false;
    }

    public String e(D d2) {
        StringBuilder sb = new StringBuilder(64);
        b.g.k.b.a(d2, sb);
        sb.append("}");
        return sb.toString();
    }

    public void f() {
        a<D> aVar = this.f1344c;
        if (aVar != null) {
            aVar.a(this);
        }
    }

    public void g(D d2) {
        InterfaceC0050b<D> interfaceC0050b = this.f1343b;
        if (interfaceC0050b != null) {
            interfaceC0050b.a(this, d2);
        }
    }

    @Deprecated
    public void h(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mId=");
        printWriter.print(this.f1342a);
        printWriter.print(" mListener=");
        printWriter.println(this.f1343b);
        if (this.f1345d || this.f1348g || this.f1349h) {
            printWriter.print(str);
            printWriter.print("mStarted=");
            printWriter.print(this.f1345d);
            printWriter.print(" mContentChanged=");
            printWriter.print(this.f1348g);
            printWriter.print(" mProcessingChange=");
            printWriter.println(this.f1349h);
        }
        if (this.f1346e || this.f1347f) {
            printWriter.print(str);
            printWriter.print("mAbandoned=");
            printWriter.print(this.f1346e);
            printWriter.print(" mReset=");
            printWriter.println(this.f1347f);
        }
    }

    public void i() {
        n();
    }

    public boolean j() {
        return this.f1346e;
    }

    protected void k() {
    }

    protected boolean l() {
        throw null;
    }

    public void m() {
        if (this.f1345d) {
            i();
        } else {
            this.f1348g = true;
        }
    }

    protected void n() {
    }

    protected void o() {
    }

    protected void p() {
        throw null;
    }

    protected void q() {
    }

    public void r(int i2, InterfaceC0050b<D> interfaceC0050b) {
        if (this.f1343b != null) {
            throw new IllegalStateException("There is already a listener registered");
        }
        this.f1343b = interfaceC0050b;
        this.f1342a = i2;
    }

    public void s() {
        o();
        this.f1347f = true;
        this.f1345d = false;
        this.f1346e = false;
        this.f1348g = false;
        this.f1349h = false;
    }

    public void t() {
        if (this.f1349h) {
            m();
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(64);
        b.g.k.b.a(this, sb);
        sb.append(" id=");
        sb.append(this.f1342a);
        sb.append("}");
        return sb.toString();
    }

    public final void u() {
        this.f1345d = true;
        this.f1347f = false;
        this.f1346e = false;
        p();
    }

    public void v() {
        this.f1345d = false;
        q();
    }

    public void w(InterfaceC0050b<D> interfaceC0050b) {
        InterfaceC0050b<D> interfaceC0050b2 = this.f1343b;
        if (interfaceC0050b2 == null) {
            throw new IllegalStateException("No listener register");
        }
        if (interfaceC0050b2 != interfaceC0050b) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        }
        this.f1343b = null;
    }
}
