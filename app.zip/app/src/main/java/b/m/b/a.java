package b.m.b;

import android.content.Context;
import android.os.Handler;
import android.os.SystemClock;
import b.g.k.i;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public abstract class a<D> extends b<D> {

    /* renamed from: i, reason: collision with root package name */
    private final Executor f1339i;

    /* renamed from: j, reason: collision with root package name */
    volatile a<D>.RunnableC0049a f1340j;

    /* renamed from: k, reason: collision with root package name */
    volatile a<D>.RunnableC0049a f1341k;
    long l;
    long m;
    Handler n;

    /* renamed from: b.m.b.a$a, reason: collision with other inner class name */
    final class RunnableC0049a extends c<Void, Void, D> implements Runnable {
        private final CountDownLatch w = new CountDownLatch(1);
        boolean x;

        RunnableC0049a() {
        }

        @Override // b.m.b.c
        protected void h(D d2) {
            try {
                a.this.y(this, d2);
            } finally {
                this.w.countDown();
            }
        }

        @Override // b.m.b.c
        protected void i(D d2) {
            try {
                a.this.z(this, d2);
            } finally {
                this.w.countDown();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // b.m.b.c
        /* renamed from: n, reason: merged with bridge method [inline-methods] */
        public D b(Void... voidArr) {
            try {
                return (D) a.this.D();
            } catch (b.g.h.b e2) {
                if (f()) {
                    return null;
                }
                throw e2;
            }
        }

        @Override // java.lang.Runnable
        public void run() {
            this.x = false;
            a.this.A();
        }
    }

    public a(Context context) {
        this(context, c.u);
    }

    private a(Context context, Executor executor) {
        super(context);
        this.m = -10000L;
        this.f1339i = executor;
    }

    void A() {
        if (this.f1341k != null || this.f1340j == null) {
            return;
        }
        if (this.f1340j.x) {
            this.f1340j.x = false;
            this.n.removeCallbacks(this.f1340j);
        }
        if (this.l <= 0 || SystemClock.uptimeMillis() >= this.m + this.l) {
            this.f1340j.c(this.f1339i, null);
        } else {
            this.f1340j.x = true;
            this.n.postAtTime(this.f1340j, this.m + this.l);
        }
    }

    public abstract D B();

    public void C(D d2) {
    }

    protected D D() {
        return B();
    }

    @Override // b.m.b.b
    @Deprecated
    public void h(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.h(str, fileDescriptor, printWriter, strArr);
        if (this.f1340j != null) {
            printWriter.print(str);
            printWriter.print("mTask=");
            printWriter.print(this.f1340j);
            printWriter.print(" waiting=");
            printWriter.println(this.f1340j.x);
        }
        if (this.f1341k != null) {
            printWriter.print(str);
            printWriter.print("mCancellingTask=");
            printWriter.print(this.f1341k);
            printWriter.print(" waiting=");
            printWriter.println(this.f1341k.x);
        }
        if (this.l != 0) {
            printWriter.print(str);
            printWriter.print("mUpdateThrottle=");
            i.c(this.l, printWriter);
            printWriter.print(" mLastLoadCompleteTime=");
            i.b(this.m, SystemClock.uptimeMillis(), printWriter);
            printWriter.println();
        }
    }

    @Override // b.m.b.b
    protected boolean l() {
        if (this.f1340j == null) {
            return false;
        }
        if (!this.f1345d) {
            this.f1348g = true;
        }
        if (this.f1341k != null) {
            if (this.f1340j.x) {
                this.f1340j.x = false;
                this.n.removeCallbacks(this.f1340j);
            }
            this.f1340j = null;
            return false;
        }
        if (this.f1340j.x) {
            this.f1340j.x = false;
            this.n.removeCallbacks(this.f1340j);
            this.f1340j = null;
            return false;
        }
        boolean a2 = this.f1340j.a(false);
        if (a2) {
            this.f1341k = this.f1340j;
            x();
        }
        this.f1340j = null;
        return a2;
    }

    @Override // b.m.b.b
    protected void n() {
        super.n();
        c();
        this.f1340j = new RunnableC0049a();
        A();
    }

    public void x() {
    }

    void y(a<D>.RunnableC0049a runnableC0049a, D d2) {
        C(d2);
        if (this.f1341k == runnableC0049a) {
            t();
            this.m = SystemClock.uptimeMillis();
            this.f1341k = null;
            f();
            A();
        }
    }

    void z(a<D>.RunnableC0049a runnableC0049a, D d2) {
        if (this.f1340j != runnableC0049a) {
            y(runnableC0049a, d2);
            return;
        }
        if (j()) {
            C(d2);
            return;
        }
        d();
        this.m = SystemClock.uptimeMillis();
        this.f1340j = null;
        g(d2);
    }
}
