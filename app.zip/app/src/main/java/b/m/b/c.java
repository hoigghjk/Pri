package b.m.b;

import android.os.Binder;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.util.Log;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.dex */
abstract class c<Params, Progress, Result> {
    private static final ThreadFactory s;
    private static final BlockingQueue<Runnable> t;
    public static final Executor u;
    private static f v;
    private final h<Params, Result> n;
    private final FutureTask<Result> o;
    private volatile g p = g.PENDING;
    final AtomicBoolean q = new AtomicBoolean();
    final AtomicBoolean r = new AtomicBoolean();

    static class a implements ThreadFactory {
        private final AtomicInteger n = new AtomicInteger(1);

        a() {
        }

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(Runnable runnable) {
            return new Thread(runnable, "ModernAsyncTask #" + this.n.getAndIncrement());
        }
    }

    class b extends h<Params, Result> {
        b() {
        }

        @Override // java.util.concurrent.Callable
        public Result call() {
            c.this.r.set(true);
            Result result = null;
            try {
                Process.setThreadPriority(10);
                result = (Result) c.this.b(this.n);
                Binder.flushPendingCommands();
                return result;
            } finally {
            }
        }
    }

    /* renamed from: b.m.b.c$c, reason: collision with other inner class name */
    class C0051c extends FutureTask<Result> {
        C0051c(Callable callable) {
            super(callable);
        }

        @Override // java.util.concurrent.FutureTask
        protected void done() {
            try {
                c.this.m(get());
            } catch (InterruptedException e2) {
                Log.w("AsyncTask", e2);
            } catch (CancellationException unused) {
                c.this.m(null);
            } catch (ExecutionException e3) {
                throw new RuntimeException("An error occurred while executing doInBackground()", e3.getCause());
            } catch (Throwable th) {
                throw new RuntimeException("An error occurred while executing doInBackground()", th);
            }
        }
    }

    static /* synthetic */ class d {

        /* renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f1350a;

        static {
            int[] iArr = new int[g.values().length];
            f1350a = iArr;
            try {
                iArr[g.RUNNING.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1350a[g.FINISHED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    private static class e<Data> {

        /* renamed from: a, reason: collision with root package name */
        final c f1351a;

        /* renamed from: b, reason: collision with root package name */
        final Data[] f1352b;

        e(c cVar, Data... dataArr) {
            this.f1351a = cVar;
            this.f1352b = dataArr;
        }
    }

    private static class f extends Handler {
        f() {
            super(Looper.getMainLooper());
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // android.os.Handler
        public void handleMessage(Message message) {
            e eVar = (e) message.obj;
            int i2 = message.what;
            if (i2 == 1) {
                eVar.f1351a.d(eVar.f1352b[0]);
            } else {
                if (i2 != 2) {
                    return;
                }
                eVar.f1351a.k(eVar.f1352b);
            }
        }
    }

    public enum g {
        PENDING,
        RUNNING,
        FINISHED
    }

    private static abstract class h<Params, Result> implements Callable<Result> {
        Params[] n;

        h() {
        }
    }

    static {
        a aVar = new a();
        s = aVar;
        LinkedBlockingQueue linkedBlockingQueue = new LinkedBlockingQueue(10);
        t = linkedBlockingQueue;
        u = new ThreadPoolExecutor(5, 128, 1L, TimeUnit.SECONDS, linkedBlockingQueue, aVar);
    }

    c() {
        b bVar = new b();
        this.n = bVar;
        this.o = new C0051c(bVar);
    }

    private static Handler e() {
        f fVar;
        synchronized (c.class) {
            if (v == null) {
                v = new f();
            }
            fVar = v;
        }
        return fVar;
    }

    public final boolean a(boolean z) {
        this.q.set(true);
        return this.o.cancel(z);
    }

    protected abstract Result b(Params... paramsArr);

    public final c<Params, Progress, Result> c(Executor executor, Params... paramsArr) {
        if (this.p == g.PENDING) {
            this.p = g.RUNNING;
            j();
            this.n.n = paramsArr;
            executor.execute(this.o);
            return this;
        }
        int i2 = d.f1350a[this.p.ordinal()];
        if (i2 == 1) {
            throw new IllegalStateException("Cannot execute task: the task is already running.");
        }
        if (i2 != 2) {
            throw new IllegalStateException("We should never reach this state");
        }
        throw new IllegalStateException("Cannot execute task: the task has already been executed (a task can be executed only once)");
    }

    void d(Result result) {
        if (f()) {
            h(result);
        } else {
            i(result);
        }
        this.p = g.FINISHED;
    }

    public final boolean f() {
        return this.q.get();
    }

    protected void g() {
    }

    protected void h(Result result) {
        g();
    }

    protected void i(Result result) {
    }

    protected void j() {
    }

    protected void k(Progress... progressArr) {
    }

    Result l(Result result) {
        e().obtainMessage(1, new e(this, result)).sendToTarget();
        return result;
    }

    void m(Result result) {
        if (this.r.get()) {
            return;
        }
        l(result);
    }
}
