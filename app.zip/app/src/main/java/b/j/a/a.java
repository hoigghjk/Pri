package b.j.a;

import android.content.res.AssetManager;
import android.media.MediaDataSource;
import android.media.MediaMetadataRetriever;
import android.os.Build;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import android.util.Pair;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

/* loaded from: classes.dex */
public class a {
    private static SimpleDateFormat R;
    private static final e[] V;
    private static final e[] W;
    private static final e[] X;
    private static final e[] Y;
    private static final e[] Z;
    private static final e a0;
    private static final e[] b0;
    private static final e[] c0;
    private static final e[] d0;
    private static final e[] e0;
    static final e[][] f0;
    private static final e[] g0;
    private static final e h0;
    private static final e i0;
    private static final HashMap<Integer, e>[] j0;
    private static final HashMap<String, e>[] k0;
    private static final HashSet<String> l0;
    private static final HashMap<Integer, Integer> m0;
    static final Charset n0;
    static final byte[] o0;
    private static final byte[] p0;
    private static final Pattern q0;

    /* renamed from: a, reason: collision with root package name */
    private String f1303a;

    /* renamed from: b, reason: collision with root package name */
    private FileDescriptor f1304b;

    /* renamed from: c, reason: collision with root package name */
    private AssetManager.AssetInputStream f1305c;

    /* renamed from: d, reason: collision with root package name */
    private int f1306d;

    /* renamed from: e, reason: collision with root package name */
    private boolean f1307e;

    /* renamed from: f, reason: collision with root package name */
    private final HashMap<String, d>[] f1308f;

    /* renamed from: g, reason: collision with root package name */
    private Set<Integer> f1309g;

    /* renamed from: h, reason: collision with root package name */
    private ByteOrder f1310h;

    /* renamed from: i, reason: collision with root package name */
    private boolean f1311i;

    /* renamed from: j, reason: collision with root package name */
    private boolean f1312j;

    /* renamed from: k, reason: collision with root package name */
    private int f1313k;
    private int l;
    private byte[] m;
    private int n;
    private int o;
    private int p;
    private int q;
    private int r;
    private boolean s;
    private static final boolean t = Log.isLoggable("ExifInterface", 3);
    private static final List<Integer> u = Arrays.asList(1, 6, 3, 8);
    private static final List<Integer> v = Arrays.asList(2, 7, 4, 5);
    public static final int[] w = {8, 8, 8};
    public static final int[] x = {8};
    static final byte[] y = {-1, -40, -1};
    private static final byte[] z = {102, 116, 121, 112};
    private static final byte[] A = {109, 105, 102, 49};
    private static final byte[] B = {104, 101, 105, 99};
    private static final byte[] C = {79, 76, 89, 77, 80, 0};
    private static final byte[] D = {79, 76, 89, 77, 80, 85, 83, 0, 73, 73};
    private static final byte[] E = {-119, 80, 78, 71, 13, 10, 26, 10};
    private static final byte[] F = {101, 88, 73, 102};
    private static final byte[] G = {73, 72, 68, 82};
    private static final byte[] H = {73, 69, 78, 68};
    private static final byte[] I = {82, 73, 70, 70};
    private static final byte[] J = {87, 69, 66, 80};
    private static final byte[] K = {69, 88, 73, 70};
    private static final byte[] L = {-99, 1, 42};
    private static final byte[] M = "VP8X".getBytes(Charset.defaultCharset());
    private static final byte[] N = "VP8L".getBytes(Charset.defaultCharset());
    private static final byte[] O = "VP8 ".getBytes(Charset.defaultCharset());
    private static final byte[] P = "ANIM".getBytes(Charset.defaultCharset());
    private static final byte[] Q = "ANMF".getBytes(Charset.defaultCharset());
    static final String[] S = {"", "BYTE", "STRING", "USHORT", "ULONG", "URATIONAL", "SBYTE", "UNDEFINED", "SSHORT", "SLONG", "SRATIONAL", "SINGLE", "DOUBLE", "IFD"};
    static final int[] T = {0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8, 1};
    static final byte[] U = {65, 83, 67, 73, 73, 0, 0, 0};

    /* renamed from: b.j.a.a$a, reason: collision with other inner class name */
    class C0046a extends MediaDataSource {
        long n;
        final /* synthetic */ b o;

        C0046a(a aVar, b bVar) {
            this.o = bVar;
        }

        @Override // java.io.Closeable, java.lang.AutoCloseable
        public void close() {
        }

        @Override // android.media.MediaDataSource
        public long getSize() {
            return -1L;
        }

        @Override // android.media.MediaDataSource
        public int readAt(long j2, byte[] bArr, int i2, int i3) {
            if (i3 == 0) {
                return 0;
            }
            if (j2 < 0) {
                return -1;
            }
            try {
                long j3 = this.n;
                if (j3 != j2) {
                    if (j3 >= 0 && j2 >= j3 + this.o.available()) {
                        return -1;
                    }
                    this.o.d(j2);
                    this.n = j2;
                }
                if (i3 > this.o.available()) {
                    i3 = this.o.available();
                }
                int read = this.o.read(bArr, i2, i3);
                if (read >= 0) {
                    this.n += read;
                    return read;
                }
            } catch (IOException unused) {
            }
            this.n = -1L;
            return -1;
        }
    }

    private static class b extends InputStream implements DataInput {
        private static final ByteOrder r = ByteOrder.LITTLE_ENDIAN;
        private static final ByteOrder s = ByteOrder.BIG_ENDIAN;
        private DataInputStream n;
        private ByteOrder o;
        final int p;
        int q;

        public b(InputStream inputStream) {
            this(inputStream, ByteOrder.BIG_ENDIAN);
        }

        b(InputStream inputStream, ByteOrder byteOrder) {
            this.o = ByteOrder.BIG_ENDIAN;
            DataInputStream dataInputStream = new DataInputStream(inputStream);
            this.n = dataInputStream;
            int available = dataInputStream.available();
            this.p = available;
            this.q = 0;
            this.n.mark(available);
            this.o = byteOrder;
        }

        public b(byte[] bArr) {
            this(new ByteArrayInputStream(bArr));
        }

        public int a() {
            return this.p;
        }

        @Override // java.io.InputStream
        public int available() {
            return this.n.available();
        }

        public int b() {
            return this.q;
        }

        public long c() {
            return readInt() & 4294967295L;
        }

        public void d(long j2) {
            int i2 = this.q;
            if (i2 > j2) {
                this.q = 0;
                this.n.reset();
                this.n.mark(this.p);
            } else {
                j2 -= i2;
            }
            int i3 = (int) j2;
            if (skipBytes(i3) != i3) {
                throw new IOException("Couldn't seek up to the byteCount");
            }
        }

        public void e(ByteOrder byteOrder) {
            this.o = byteOrder;
        }

        @Override // java.io.InputStream
        public synchronized void mark(int i2) {
            this.n.mark(i2);
        }

        @Override // java.io.InputStream
        public int read() {
            this.q++;
            return this.n.read();
        }

        @Override // java.io.InputStream
        public int read(byte[] bArr, int i2, int i3) {
            int read = this.n.read(bArr, i2, i3);
            this.q += read;
            return read;
        }

        @Override // java.io.DataInput
        public boolean readBoolean() {
            this.q++;
            return this.n.readBoolean();
        }

        @Override // java.io.DataInput
        public byte readByte() {
            int i2 = this.q + 1;
            this.q = i2;
            if (i2 > this.p) {
                throw new EOFException();
            }
            int read = this.n.read();
            if (read >= 0) {
                return (byte) read;
            }
            throw new EOFException();
        }

        @Override // java.io.DataInput
        public char readChar() {
            this.q += 2;
            return this.n.readChar();
        }

        @Override // java.io.DataInput
        public double readDouble() {
            return Double.longBitsToDouble(readLong());
        }

        @Override // java.io.DataInput
        public float readFloat() {
            return Float.intBitsToFloat(readInt());
        }

        @Override // java.io.DataInput
        public void readFully(byte[] bArr) {
            int length = this.q + bArr.length;
            this.q = length;
            if (length > this.p) {
                throw new EOFException();
            }
            if (this.n.read(bArr, 0, bArr.length) != bArr.length) {
                throw new IOException("Couldn't read up to the length of buffer");
            }
        }

        @Override // java.io.DataInput
        public void readFully(byte[] bArr, int i2, int i3) {
            int i4 = this.q + i3;
            this.q = i4;
            if (i4 > this.p) {
                throw new EOFException();
            }
            if (this.n.read(bArr, i2, i3) != i3) {
                throw new IOException("Couldn't read up to the length of buffer");
            }
        }

        @Override // java.io.DataInput
        public int readInt() {
            int i2 = this.q + 4;
            this.q = i2;
            if (i2 > this.p) {
                throw new EOFException();
            }
            int read = this.n.read();
            int read2 = this.n.read();
            int read3 = this.n.read();
            int read4 = this.n.read();
            if ((read | read2 | read3 | read4) < 0) {
                throw new EOFException();
            }
            ByteOrder byteOrder = this.o;
            if (byteOrder == r) {
                return (read4 << 24) + (read3 << 16) + (read2 << 8) + read;
            }
            if (byteOrder == s) {
                return (read << 24) + (read2 << 16) + (read3 << 8) + read4;
            }
            throw new IOException("Invalid byte order: " + this.o);
        }

        @Override // java.io.DataInput
        public String readLine() {
            Log.d("ExifInterface", "Currently unsupported");
            return null;
        }

        @Override // java.io.DataInput
        public long readLong() {
            int i2 = this.q + 8;
            this.q = i2;
            if (i2 > this.p) {
                throw new EOFException();
            }
            int read = this.n.read();
            int read2 = this.n.read();
            int read3 = this.n.read();
            int read4 = this.n.read();
            int read5 = this.n.read();
            int read6 = this.n.read();
            int read7 = this.n.read();
            int read8 = this.n.read();
            if ((read | read2 | read3 | read4 | read5 | read6 | read7 | read8) < 0) {
                throw new EOFException();
            }
            ByteOrder byteOrder = this.o;
            if (byteOrder == r) {
                return (read8 << 56) + (read7 << 48) + (read6 << 40) + (read5 << 32) + (read4 << 24) + (read3 << 16) + (read2 << 8) + read;
            }
            if (byteOrder == s) {
                return (read << 56) + (read2 << 48) + (read3 << 40) + (read4 << 32) + (read5 << 24) + (read6 << 16) + (read7 << 8) + read8;
            }
            throw new IOException("Invalid byte order: " + this.o);
        }

        @Override // java.io.DataInput
        public short readShort() {
            int i2 = this.q + 2;
            this.q = i2;
            if (i2 > this.p) {
                throw new EOFException();
            }
            int read = this.n.read();
            int read2 = this.n.read();
            if ((read | read2) < 0) {
                throw new EOFException();
            }
            ByteOrder byteOrder = this.o;
            if (byteOrder == r) {
                return (short) ((read2 << 8) + read);
            }
            if (byteOrder == s) {
                return (short) ((read << 8) + read2);
            }
            throw new IOException("Invalid byte order: " + this.o);
        }

        @Override // java.io.DataInput
        public String readUTF() {
            this.q += 2;
            return this.n.readUTF();
        }

        @Override // java.io.DataInput
        public int readUnsignedByte() {
            this.q++;
            return this.n.readUnsignedByte();
        }

        @Override // java.io.DataInput
        public int readUnsignedShort() {
            int i2 = this.q + 2;
            this.q = i2;
            if (i2 > this.p) {
                throw new EOFException();
            }
            int read = this.n.read();
            int read2 = this.n.read();
            if ((read | read2) < 0) {
                throw new EOFException();
            }
            ByteOrder byteOrder = this.o;
            if (byteOrder == r) {
                return (read2 << 8) + read;
            }
            if (byteOrder == s) {
                return (read << 8) + read2;
            }
            throw new IOException("Invalid byte order: " + this.o);
        }

        @Override // java.io.DataInput
        public int skipBytes(int i2) {
            int min = Math.min(i2, this.p - this.q);
            int i3 = 0;
            while (i3 < min) {
                i3 += this.n.skipBytes(min - i3);
            }
            this.q += i3;
            return i3;
        }
    }

    private static class c extends FilterOutputStream {
        final OutputStream n;
        private ByteOrder o;

        public c(OutputStream outputStream, ByteOrder byteOrder) {
            super(outputStream);
            this.n = outputStream;
            this.o = byteOrder;
        }

        public void a(ByteOrder byteOrder) {
            this.o = byteOrder;
        }

        public void b(int i2) {
            this.n.write(i2);
        }

        public void c(int i2) {
            OutputStream outputStream;
            int i3;
            ByteOrder byteOrder = this.o;
            if (byteOrder == ByteOrder.LITTLE_ENDIAN) {
                this.n.write((i2 >>> 0) & 255);
                this.n.write((i2 >>> 8) & 255);
                this.n.write((i2 >>> 16) & 255);
                outputStream = this.n;
                i3 = i2 >>> 24;
            } else {
                if (byteOrder != ByteOrder.BIG_ENDIAN) {
                    return;
                }
                this.n.write((i2 >>> 24) & 255);
                this.n.write((i2 >>> 16) & 255);
                this.n.write((i2 >>> 8) & 255);
                outputStream = this.n;
                i3 = i2 >>> 0;
            }
            outputStream.write(i3 & 255);
        }

        public void d(short s) {
            OutputStream outputStream;
            int i2;
            ByteOrder byteOrder = this.o;
            if (byteOrder == ByteOrder.LITTLE_ENDIAN) {
                this.n.write((s >>> 0) & 255);
                outputStream = this.n;
                i2 = s >>> 8;
            } else {
                if (byteOrder != ByteOrder.BIG_ENDIAN) {
                    return;
                }
                this.n.write((s >>> 8) & 255);
                outputStream = this.n;
                i2 = s >>> 0;
            }
            outputStream.write(i2 & 255);
        }

        public void e(long j2) {
            c((int) j2);
        }

        public void f(int i2) {
            d((short) i2);
        }

        @Override // java.io.FilterOutputStream, java.io.OutputStream
        public void write(byte[] bArr) {
            this.n.write(bArr);
        }

        @Override // java.io.FilterOutputStream, java.io.OutputStream
        public void write(byte[] bArr, int i2, int i3) {
            this.n.write(bArr, i2, i3);
        }
    }

    private static class d {

        /* renamed from: a, reason: collision with root package name */
        public final int f1314a;

        /* renamed from: b, reason: collision with root package name */
        public final int f1315b;

        /* renamed from: c, reason: collision with root package name */
        public final long f1316c;

        /* renamed from: d, reason: collision with root package name */
        public final byte[] f1317d;

        d(int i2, int i3, long j2, byte[] bArr) {
            this.f1314a = i2;
            this.f1315b = i3;
            this.f1316c = j2;
            this.f1317d = bArr;
        }

        d(int i2, int i3, byte[] bArr) {
            this(i2, i3, -1L, bArr);
        }

        public static d a(String str) {
            if (str.length() == 1 && str.charAt(0) >= '0' && str.charAt(0) <= '1') {
                return new d(1, 1, new byte[]{(byte) (str.charAt(0) - '0')});
            }
            byte[] bytes = str.getBytes(a.n0);
            return new d(1, bytes.length, bytes);
        }

        public static d b(double[] dArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[a.T[12] * dArr.length]);
            wrap.order(byteOrder);
            for (double d2 : dArr) {
                wrap.putDouble(d2);
            }
            return new d(12, dArr.length, wrap.array());
        }

        public static d c(int[] iArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[a.T[9] * iArr.length]);
            wrap.order(byteOrder);
            for (int i2 : iArr) {
                wrap.putInt(i2);
            }
            return new d(9, iArr.length, wrap.array());
        }

        public static d d(f[] fVarArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[a.T[10] * fVarArr.length]);
            wrap.order(byteOrder);
            for (f fVar : fVarArr) {
                wrap.putInt((int) fVar.f1322a);
                wrap.putInt((int) fVar.f1323b);
            }
            return new d(10, fVarArr.length, wrap.array());
        }

        public static d e(String str) {
            byte[] bytes = (str + (char) 0).getBytes(a.n0);
            return new d(2, bytes.length, bytes);
        }

        public static d f(long j2, ByteOrder byteOrder) {
            return g(new long[]{j2}, byteOrder);
        }

        public static d g(long[] jArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[a.T[4] * jArr.length]);
            wrap.order(byteOrder);
            for (long j2 : jArr) {
                wrap.putInt((int) j2);
            }
            return new d(4, jArr.length, wrap.array());
        }

        public static d h(f fVar, ByteOrder byteOrder) {
            return i(new f[]{fVar}, byteOrder);
        }

        public static d i(f[] fVarArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[a.T[5] * fVarArr.length]);
            wrap.order(byteOrder);
            for (f fVar : fVarArr) {
                wrap.putInt((int) fVar.f1322a);
                wrap.putInt((int) fVar.f1323b);
            }
            return new d(5, fVarArr.length, wrap.array());
        }

        public static d j(int i2, ByteOrder byteOrder) {
            return k(new int[]{i2}, byteOrder);
        }

        public static d k(int[] iArr, ByteOrder byteOrder) {
            ByteBuffer wrap = ByteBuffer.wrap(new byte[a.T[3] * iArr.length]);
            wrap.order(byteOrder);
            for (int i2 : iArr) {
                wrap.putShort((short) i2);
            }
            return new d(3, iArr.length, wrap.array());
        }

        public double l(ByteOrder byteOrder) {
            Object o = o(byteOrder);
            if (o == null) {
                throw new NumberFormatException("NULL can't be converted to a double value");
            }
            if (o instanceof String) {
                return Double.parseDouble((String) o);
            }
            if (o instanceof long[]) {
                if (((long[]) o).length == 1) {
                    return r5[0];
                }
                throw new NumberFormatException("There are more than one component");
            }
            if (o instanceof int[]) {
                if (((int[]) o).length == 1) {
                    return r5[0];
                }
                throw new NumberFormatException("There are more than one component");
            }
            if (o instanceof double[]) {
                double[] dArr = (double[]) o;
                if (dArr.length == 1) {
                    return dArr[0];
                }
                throw new NumberFormatException("There are more than one component");
            }
            if (!(o instanceof f[])) {
                throw new NumberFormatException("Couldn't find a double value");
            }
            f[] fVarArr = (f[]) o;
            if (fVarArr.length == 1) {
                return fVarArr[0].a();
            }
            throw new NumberFormatException("There are more than one component");
        }

        public int m(ByteOrder byteOrder) {
            Object o = o(byteOrder);
            if (o == null) {
                throw new NumberFormatException("NULL can't be converted to a integer value");
            }
            if (o instanceof String) {
                return Integer.parseInt((String) o);
            }
            if (o instanceof long[]) {
                long[] jArr = (long[]) o;
                if (jArr.length == 1) {
                    return (int) jArr[0];
                }
                throw new NumberFormatException("There are more than one component");
            }
            if (!(o instanceof int[])) {
                throw new NumberFormatException("Couldn't find a integer value");
            }
            int[] iArr = (int[]) o;
            if (iArr.length == 1) {
                return iArr[0];
            }
            throw new NumberFormatException("There are more than one component");
        }

        public String n(ByteOrder byteOrder) {
            Object o = o(byteOrder);
            if (o == null) {
                return null;
            }
            if (o instanceof String) {
                return (String) o;
            }
            StringBuilder sb = new StringBuilder();
            int i2 = 0;
            if (o instanceof long[]) {
                long[] jArr = (long[]) o;
                while (i2 < jArr.length) {
                    sb.append(jArr[i2]);
                    i2++;
                    if (i2 != jArr.length) {
                        sb.append(",");
                    }
                }
                return sb.toString();
            }
            if (o instanceof int[]) {
                int[] iArr = (int[]) o;
                while (i2 < iArr.length) {
                    sb.append(iArr[i2]);
                    i2++;
                    if (i2 != iArr.length) {
                        sb.append(",");
                    }
                }
                return sb.toString();
            }
            if (o instanceof double[]) {
                double[] dArr = (double[]) o;
                while (i2 < dArr.length) {
                    sb.append(dArr[i2]);
                    i2++;
                    if (i2 != dArr.length) {
                        sb.append(",");
                    }
                }
                return sb.toString();
            }
            if (!(o instanceof f[])) {
                return null;
            }
            f[] fVarArr = (f[]) o;
            while (i2 < fVarArr.length) {
                sb.append(fVarArr[i2].f1322a);
                sb.append('/');
                sb.append(fVarArr[i2].f1323b);
                i2++;
                if (i2 != fVarArr.length) {
                    sb.append(",");
                }
            }
            return sb.toString();
        }

        /* JADX WARN: Not initialized variable reg: 3, insn: 0x01a0: MOVE (r2 I:??[OBJECT, ARRAY]) = (r3 I:??[OBJECT, ARRAY]), block:B:169:0x01a0 */
        /* JADX WARN: Removed duplicated region for block: B:172:0x01a3 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        java.lang.Object o(java.nio.ByteOrder r11) {
            /*
                Method dump skipped, instructions count: 456
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: b.j.a.a.d.o(java.nio.ByteOrder):java.lang.Object");
        }

        public int p() {
            return a.T[this.f1314a] * this.f1315b;
        }

        public String toString() {
            return "(" + a.S[this.f1314a] + ", data length:" + this.f1317d.length + ")";
        }
    }

    static class e {

        /* renamed from: a, reason: collision with root package name */
        public final int f1318a;

        /* renamed from: b, reason: collision with root package name */
        public final String f1319b;

        /* renamed from: c, reason: collision with root package name */
        public final int f1320c;

        /* renamed from: d, reason: collision with root package name */
        public final int f1321d;

        e(String str, int i2, int i3) {
            this.f1319b = str;
            this.f1318a = i2;
            this.f1320c = i3;
            this.f1321d = -1;
        }

        e(String str, int i2, int i3, int i4) {
            this.f1319b = str;
            this.f1318a = i2;
            this.f1320c = i3;
            this.f1321d = i4;
        }

        boolean a(int i2) {
            int i3;
            int i4 = this.f1320c;
            if (i4 == 7 || i2 == 7 || i4 == i2 || (i3 = this.f1321d) == i2) {
                return true;
            }
            if ((i4 == 4 || i3 == 4) && i2 == 3) {
                return true;
            }
            if ((i4 == 9 || i3 == 9) && i2 == 8) {
                return true;
            }
            return (i4 == 12 || i3 == 12) && i2 == 11;
        }
    }

    private static class f {

        /* renamed from: a, reason: collision with root package name */
        public final long f1322a;

        /* renamed from: b, reason: collision with root package name */
        public final long f1323b;

        f(double d2) {
            this((long) (d2 * 10000.0d), 10000L);
        }

        f(long j2, long j3) {
            if (j3 == 0) {
                this.f1322a = 0L;
                this.f1323b = 1L;
            } else {
                this.f1322a = j2;
                this.f1323b = j3;
            }
        }

        public double a() {
            return this.f1322a / this.f1323b;
        }

        public String toString() {
            return this.f1322a + "/" + this.f1323b;
        }
    }

    static {
        e[] eVarArr = {new e("NewSubfileType", 254, 4), new e("SubfileType", 255, 4), new e("ImageWidth", 256, 3, 4), new e("ImageLength", 257, 3, 4), new e("BitsPerSample", 258, 3), new e("Compression", 259, 3), new e("PhotometricInterpretation", 262, 3), new e("ImageDescription", 270, 2), new e("Make", 271, 2), new e("Model", 272, 2), new e("StripOffsets", 273, 3, 4), new e("Orientation", 274, 3), new e("SamplesPerPixel", 277, 3), new e("RowsPerStrip", 278, 3, 4), new e("StripByteCounts", 279, 3, 4), new e("XResolution", 282, 5), new e("YResolution", 283, 5), new e("PlanarConfiguration", 284, 3), new e("ResolutionUnit", 296, 3), new e("TransferFunction", 301, 3), new e("Software", 305, 2), new e("DateTime", 306, 2), new e("Artist", 315, 2), new e("WhitePoint", 318, 5), new e("PrimaryChromaticities", 319, 5), new e("SubIFDPointer", 330, 4), new e("JPEGInterchangeFormat", 513, 4), new e("JPEGInterchangeFormatLength", 514, 4), new e("YCbCrCoefficients", 529, 5), new e("YCbCrSubSampling", 530, 3), new e("YCbCrPositioning", 531, 3), new e("ReferenceBlackWhite", 532, 5), new e("Copyright", 33432, 2), new e("ExifIFDPointer", 34665, 4), new e("GPSInfoIFDPointer", 34853, 4), new e("SensorTopBorder", 4, 4), new e("SensorLeftBorder", 5, 4), new e("SensorBottomBorder", 6, 4), new e("SensorRightBorder", 7, 4), new e("ISO", 23, 3), new e("JpgFromRaw", 46, 7), new e("Xmp", 700, 1)};
        V = eVarArr;
        e[] eVarArr2 = {new e("ExposureTime", 33434, 5), new e("FNumber", 33437, 5), new e("ExposureProgram", 34850, 3), new e("SpectralSensitivity", 34852, 2), new e("PhotographicSensitivity", 34855, 3), new e("OECF", 34856, 7), new e("SensitivityType", 34864, 3), new e("StandardOutputSensitivity", 34865, 4), new e("RecommendedExposureIndex", 34866, 4), new e("ISOSpeed", 34867, 4), new e("ISOSpeedLatitudeyyy", 34868, 4), new e("ISOSpeedLatitudezzz", 34869, 4), new e("ExifVersion", 36864, 2), new e("DateTimeOriginal", 36867, 2), new e("DateTimeDigitized", 36868, 2), new e("OffsetTime", 36880, 2), new e("OffsetTimeOriginal", 36881, 2), new e("OffsetTimeDigitized", 36882, 2), new e("ComponentsConfiguration", 37121, 7), new e("CompressedBitsPerPixel", 37122, 5), new e("ShutterSpeedValue", 37377, 10), new e("ApertureValue", 37378, 5), new e("BrightnessValue", 37379, 10), new e("ExposureBiasValue", 37380, 10), new e("MaxApertureValue", 37381, 5), new e("SubjectDistance", 37382, 5), new e("MeteringMode", 37383, 3), new e("LightSource", 37384, 3), new e("Flash", 37385, 3), new e("FocalLength", 37386, 5), new e("SubjectArea", 37396, 3), new e("MakerNote", 37500, 7), new e("UserComment", 37510, 7), new e("SubSecTime", 37520, 2), new e("SubSecTimeOriginal", 37521, 2), new e("SubSecTimeDigitized", 37522, 2), new e("FlashpixVersion", 40960, 7), new e("ColorSpace", 40961, 3), new e("PixelXDimension", 40962, 3, 4), new e("PixelYDimension", 40963, 3, 4), new e("RelatedSoundFile", 40964, 2), new e("InteroperabilityIFDPointer", 40965, 4), new e("FlashEnergy", 41483, 5), new e("SpatialFrequencyResponse", 41484, 7), new e("FocalPlaneXResolution", 41486, 5), new e("FocalPlaneYResolution", 41487, 5), new e("FocalPlaneResolutionUnit", 41488, 3), new e("SubjectLocation", 41492, 3), new e("ExposureIndex", 41493, 5), new e("SensingMethod", 41495, 3), new e("FileSource", 41728, 7), new e("SceneType", 41729, 7), new e("CFAPattern", 41730, 7), new e("CustomRendered", 41985, 3), new e("ExposureMode", 41986, 3), new e("WhiteBalance", 41987, 3), new e("DigitalZoomRatio", 41988, 5), new e("FocalLengthIn35mmFilm", 41989, 3), new e("SceneCaptureType", 41990, 3), new e("GainControl", 41991, 3), new e("Contrast", 41992, 3), new e("Saturation", 41993, 3), new e("Sharpness", 41994, 3), new e("DeviceSettingDescription", 41995, 7), new e("SubjectDistanceRange", 41996, 3), new e("ImageUniqueID", 42016, 2), new e("CameraOwnerName", 42032, 2), new e("BodySerialNumber", 42033, 2), new e("LensSpecification", 42034, 5), new e("LensMake", 42035, 2), new e("LensModel", 42036, 2), new e("Gamma", 42240, 5), new e("DNGVersion", 50706, 1), new e("DefaultCropSize", 50720, 3, 4)};
        W = eVarArr2;
        e[] eVarArr3 = {new e("GPSVersionID", 0, 1), new e("GPSLatitudeRef", 1, 2), new e("GPSLatitude", 2, 5), new e("GPSLongitudeRef", 3, 2), new e("GPSLongitude", 4, 5), new e("GPSAltitudeRef", 5, 1), new e("GPSAltitude", 6, 5), new e("GPSTimeStamp", 7, 5), new e("GPSSatellites", 8, 2), new e("GPSStatus", 9, 2), new e("GPSMeasureMode", 10, 2), new e("GPSDOP", 11, 5), new e("GPSSpeedRef", 12, 2), new e("GPSSpeed", 13, 5), new e("GPSTrackRef", 14, 2), new e("GPSTrack", 15, 5), new e("GPSImgDirectionRef", 16, 2), new e("GPSImgDirection", 17, 5), new e("GPSMapDatum", 18, 2), new e("GPSDestLatitudeRef", 19, 2), new e("GPSDestLatitude", 20, 5), new e("GPSDestLongitudeRef", 21, 2), new e("GPSDestLongitude", 22, 5), new e("GPSDestBearingRef", 23, 2), new e("GPSDestBearing", 24, 5), new e("GPSDestDistanceRef", 25, 2), new e("GPSDestDistance", 26, 5), new e("GPSProcessingMethod", 27, 7), new e("GPSAreaInformation", 28, 7), new e("GPSDateStamp", 29, 2), new e("GPSDifferential", 30, 3), new e("GPSHPositioningError", 31, 5)};
        X = eVarArr3;
        e[] eVarArr4 = {new e("InteroperabilityIndex", 1, 2)};
        Y = eVarArr4;
        e[] eVarArr5 = {new e("NewSubfileType", 254, 4), new e("SubfileType", 255, 4), new e("ThumbnailImageWidth", 256, 3, 4), new e("ThumbnailImageLength", 257, 3, 4), new e("BitsPerSample", 258, 3), new e("Compression", 259, 3), new e("PhotometricInterpretation", 262, 3), new e("ImageDescription", 270, 2), new e("Make", 271, 2), new e("Model", 272, 2), new e("StripOffsets", 273, 3, 4), new e("ThumbnailOrientation", 274, 3), new e("SamplesPerPixel", 277, 3), new e("RowsPerStrip", 278, 3, 4), new e("StripByteCounts", 279, 3, 4), new e("XResolution", 282, 5), new e("YResolution", 283, 5), new e("PlanarConfiguration", 284, 3), new e("ResolutionUnit", 296, 3), new e("TransferFunction", 301, 3), new e("Software", 305, 2), new e("DateTime", 306, 2), new e("Artist", 315, 2), new e("WhitePoint", 318, 5), new e("PrimaryChromaticities", 319, 5), new e("SubIFDPointer", 330, 4), new e("JPEGInterchangeFormat", 513, 4), new e("JPEGInterchangeFormatLength", 514, 4), new e("YCbCrCoefficients", 529, 5), new e("YCbCrSubSampling", 530, 3), new e("YCbCrPositioning", 531, 3), new e("ReferenceBlackWhite", 532, 5), new e("Copyright", 33432, 2), new e("ExifIFDPointer", 34665, 4), new e("GPSInfoIFDPointer", 34853, 4), new e("DNGVersion", 50706, 1), new e("DefaultCropSize", 50720, 3, 4)};
        Z = eVarArr5;
        a0 = new e("StripOffsets", 273, 3);
        e[] eVarArr6 = {new e("ThumbnailImage", 256, 7), new e("CameraSettingsIFDPointer", 8224, 4), new e("ImageProcessingIFDPointer", 8256, 4)};
        b0 = eVarArr6;
        e[] eVarArr7 = {new e("PreviewImageStart", 257, 4), new e("PreviewImageLength", 258, 4)};
        c0 = eVarArr7;
        e[] eVarArr8 = {new e("AspectFrame", 4371, 3)};
        d0 = eVarArr8;
        e[] eVarArr9 = {new e("ColorSpace", 55, 3)};
        e0 = eVarArr9;
        e[][] eVarArr10 = {eVarArr, eVarArr2, eVarArr3, eVarArr4, eVarArr5, eVarArr, eVarArr6, eVarArr7, eVarArr8, eVarArr9};
        f0 = eVarArr10;
        g0 = new e[]{new e("SubIFDPointer", 330, 4), new e("ExifIFDPointer", 34665, 4), new e("GPSInfoIFDPointer", 34853, 4), new e("InteroperabilityIFDPointer", 40965, 4), new e("CameraSettingsIFDPointer", 8224, 1), new e("ImageProcessingIFDPointer", 8256, 1)};
        h0 = new e("JPEGInterchangeFormat", 513, 4);
        i0 = new e("JPEGInterchangeFormatLength", 514, 4);
        j0 = new HashMap[eVarArr10.length];
        k0 = new HashMap[eVarArr10.length];
        l0 = new HashSet<>(Arrays.asList("FNumber", "DigitalZoomRatio", "ExposureTime", "SubjectDistance", "GPSTimeStamp"));
        m0 = new HashMap<>();
        Charset forName = Charset.forName("US-ASCII");
        n0 = forName;
        o0 = "Exif\u0000\u0000".getBytes(forName);
        p0 = "http://ns.adobe.com/xap/1.0/\u0000".getBytes(forName);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US);
        R = simpleDateFormat;
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        int i2 = 0;
        while (true) {
            e[][] eVarArr11 = f0;
            if (i2 >= eVarArr11.length) {
                HashMap<Integer, Integer> hashMap = m0;
                e[] eVarArr12 = g0;
                hashMap.put(Integer.valueOf(eVarArr12[0].f1318a), 5);
                hashMap.put(Integer.valueOf(eVarArr12[1].f1318a), 1);
                hashMap.put(Integer.valueOf(eVarArr12[2].f1318a), 2);
                hashMap.put(Integer.valueOf(eVarArr12[3].f1318a), 3);
                hashMap.put(Integer.valueOf(eVarArr12[4].f1318a), 7);
                hashMap.put(Integer.valueOf(eVarArr12[5].f1318a), 8);
                Pattern.compile(".*[1-9].*");
                q0 = Pattern.compile("^([0-9][0-9]):([0-9][0-9]):([0-9][0-9])$");
                return;
            }
            j0[i2] = new HashMap<>();
            k0[i2] = new HashMap<>();
            for (e eVar : eVarArr11[i2]) {
                j0[i2].put(Integer.valueOf(eVar.f1318a), eVar);
                k0[i2].put(eVar.f1319b, eVar);
            }
            i2++;
        }
    }

    public a(InputStream inputStream) {
        this(inputStream, 0);
    }

    public a(InputStream inputStream, int i2) {
        e[][] eVarArr = f0;
        this.f1308f = new HashMap[eVarArr.length];
        this.f1309g = new HashSet(eVarArr.length);
        this.f1310h = ByteOrder.BIG_ENDIAN;
        Objects.requireNonNull(inputStream, "inputStream cannot be null");
        this.f1303a = null;
        if (i2 == 1) {
            BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream, 5000);
            if (!C(bufferedInputStream)) {
                Log.w("ExifInterface", "Given data does not follow the structure of an Exif-only data.");
                return;
            }
            this.f1307e = true;
            this.f1305c = null;
            this.f1304b = null;
            inputStream = bufferedInputStream;
        } else {
            if (inputStream instanceof AssetManager.AssetInputStream) {
                this.f1305c = (AssetManager.AssetInputStream) inputStream;
            } else {
                if (inputStream instanceof FileInputStream) {
                    FileInputStream fileInputStream = (FileInputStream) inputStream;
                    if (J(fileInputStream.getFD())) {
                        this.f1305c = null;
                        this.f1304b = fileInputStream.getFD();
                    }
                }
                this.f1305c = null;
            }
            this.f1304b = null;
        }
        O(inputStream);
    }

    public a(String str) {
        e[][] eVarArr = f0;
        this.f1308f = new HashMap[eVarArr.length];
        this.f1309g = new HashSet(eVarArr.length);
        this.f1310h = ByteOrder.BIG_ENDIAN;
        Objects.requireNonNull(str, "filename cannot be null");
        B(str);
    }

    private void A(b bVar, HashMap hashMap) {
        d dVar = (d) hashMap.get("StripOffsets");
        d dVar2 = (d) hashMap.get("StripByteCounts");
        if (dVar == null || dVar2 == null) {
            return;
        }
        long[] e2 = e(dVar.o(this.f1310h));
        long[] e3 = e(dVar2.o(this.f1310h));
        if (e2 == null || e2.length == 0) {
            Log.w("ExifInterface", "stripOffsets should not be null or have zero length.");
            return;
        }
        if (e3 == null || e3.length == 0) {
            Log.w("ExifInterface", "stripByteCounts should not be null or have zero length.");
            return;
        }
        if (e2.length != e3.length) {
            Log.w("ExifInterface", "stripOffsets and stripByteCounts should have same length.");
            return;
        }
        long j2 = 0;
        for (long j3 : e3) {
            j2 += j3;
        }
        int i2 = (int) j2;
        byte[] bArr = new byte[i2];
        int i3 = 1;
        this.f1312j = true;
        this.f1311i = true;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        while (i4 < e2.length) {
            int i7 = (int) e2[i4];
            int i8 = (int) e3[i4];
            if (i4 < e2.length - i3 && i7 + i8 != e2[i4 + 1]) {
                this.f1312j = false;
            }
            int i9 = i7 - i5;
            if (i9 < 0) {
                Log.d("ExifInterface", "Invalid strip offset value");
                return;
            }
            long j4 = i9;
            if (bVar.skip(j4) != j4) {
                Log.d("ExifInterface", "Failed to skip " + i9 + " bytes.");
                return;
            }
            int i10 = i5 + i9;
            byte[] bArr2 = new byte[i8];
            if (bVar.read(bArr2) != i8) {
                Log.d("ExifInterface", "Failed to read " + i8 + " bytes.");
                return;
            }
            i5 = i10 + i8;
            System.arraycopy(bArr2, 0, bArr, i6, i8);
            i6 += i8;
            i4++;
            i3 = 1;
        }
        this.m = bArr;
        if (this.f1312j) {
            this.f1313k = (int) e2[0];
            this.l = i2;
        }
    }

    private void B(String str) {
        Objects.requireNonNull(str, "filename cannot be null");
        FileInputStream fileInputStream = null;
        this.f1305c = null;
        this.f1303a = str;
        try {
            FileInputStream fileInputStream2 = new FileInputStream(str);
            try {
                if (J(fileInputStream2.getFD())) {
                    this.f1304b = fileInputStream2.getFD();
                } else {
                    this.f1304b = null;
                }
                O(fileInputStream2);
                d(fileInputStream2);
            } catch (Throwable th) {
                th = th;
                fileInputStream = fileInputStream2;
                d(fileInputStream);
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }

    private static boolean C(BufferedInputStream bufferedInputStream) {
        byte[] bArr = o0;
        bufferedInputStream.mark(bArr.length);
        byte[] bArr2 = new byte[bArr.length];
        bufferedInputStream.read(bArr2);
        bufferedInputStream.reset();
        int i2 = 0;
        while (true) {
            byte[] bArr3 = o0;
            if (i2 >= bArr3.length) {
                return true;
            }
            if (bArr2[i2] != bArr3[i2]) {
                return false;
            }
            i2++;
        }
    }

    private boolean D(byte[] bArr) {
        b bVar;
        long readInt;
        byte[] bArr2;
        b bVar2 = null;
        try {
            try {
                bVar = new b(bArr);
            } catch (Exception e2) {
                e = e2;
            }
        } catch (Throwable th) {
            th = th;
        }
        try {
            readInt = bVar.readInt();
            bArr2 = new byte[4];
            bVar.read(bArr2);
        } catch (Exception e3) {
            e = e3;
            bVar2 = bVar;
            if (t) {
                Log.d("ExifInterface", "Exception parsing HEIF file type box.", e);
            }
            if (bVar2 != null) {
                bVar2.close();
            }
            return false;
        } catch (Throwable th2) {
            th = th2;
            bVar2 = bVar;
            if (bVar2 != null) {
                bVar2.close();
            }
            throw th;
        }
        if (!Arrays.equals(bArr2, z)) {
            bVar.close();
            return false;
        }
        long j2 = 16;
        if (readInt == 1) {
            readInt = bVar.readLong();
            if (readInt < 16) {
                bVar.close();
                return false;
            }
        } else {
            j2 = 8;
        }
        if (readInt > bArr.length) {
            readInt = bArr.length;
        }
        long j3 = readInt - j2;
        if (j3 < 8) {
            bVar.close();
            return false;
        }
        byte[] bArr3 = new byte[4];
        boolean z2 = false;
        boolean z3 = false;
        for (long j4 = 0; j4 < j3 / 4; j4++) {
            if (bVar.read(bArr3) != 4) {
                bVar.close();
                return false;
            }
            if (j4 != 1) {
                if (Arrays.equals(bArr3, A)) {
                    z2 = true;
                } else if (Arrays.equals(bArr3, B)) {
                    z3 = true;
                }
                if (z2 && z3) {
                    bVar.close();
                    return true;
                }
            }
        }
        bVar.close();
        return false;
    }

    private static boolean E(byte[] bArr) {
        int i2 = 0;
        while (true) {
            byte[] bArr2 = y;
            if (i2 >= bArr2.length) {
                return true;
            }
            if (bArr[i2] != bArr2[i2]) {
                return false;
            }
            i2++;
        }
    }

    private boolean F(byte[] bArr) {
        b bVar = null;
        try {
            b bVar2 = new b(bArr);
            try {
                ByteOrder R2 = R(bVar2);
                this.f1310h = R2;
                bVar2.e(R2);
                short readShort = bVar2.readShort();
                boolean z2 = readShort == 20306 || readShort == 21330;
                bVar2.close();
                return z2;
            } catch (Exception unused) {
                bVar = bVar2;
                if (bVar != null) {
                    bVar.close();
                }
                return false;
            } catch (Throwable th) {
                th = th;
                bVar = bVar2;
                if (bVar != null) {
                    bVar.close();
                }
                throw th;
            }
        } catch (Exception unused2) {
        } catch (Throwable th2) {
            th = th2;
        }
    }

    private boolean G(byte[] bArr) {
        int i2 = 0;
        while (true) {
            byte[] bArr2 = E;
            if (i2 >= bArr2.length) {
                return true;
            }
            if (bArr[i2] != bArr2[i2]) {
                return false;
            }
            i2++;
        }
    }

    private boolean H(byte[] bArr) {
        byte[] bytes = "FUJIFILMCCD-RAW".getBytes(Charset.defaultCharset());
        for (int i2 = 0; i2 < bytes.length; i2++) {
            if (bArr[i2] != bytes[i2]) {
                return false;
            }
        }
        return true;
    }

    private boolean I(byte[] bArr) {
        b bVar = null;
        try {
            b bVar2 = new b(bArr);
            try {
                ByteOrder R2 = R(bVar2);
                this.f1310h = R2;
                bVar2.e(R2);
                boolean z2 = bVar2.readShort() == 85;
                bVar2.close();
                return z2;
            } catch (Exception unused) {
                bVar = bVar2;
                if (bVar != null) {
                    bVar.close();
                }
                return false;
            } catch (Throwable th) {
                th = th;
                bVar = bVar2;
                if (bVar != null) {
                    bVar.close();
                }
                throw th;
            }
        } catch (Exception unused2) {
        } catch (Throwable th2) {
            th = th2;
        }
    }

    private static boolean J(FileDescriptor fileDescriptor) {
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Os.lseek(fileDescriptor, 0L, OsConstants.SEEK_CUR);
                return true;
            } catch (Exception unused) {
                if (t) {
                    Log.d("ExifInterface", "The file descriptor for the given input is not seekable");
                }
            }
        }
        return false;
    }

    private boolean K(HashMap hashMap) {
        d dVar;
        int m;
        d dVar2 = (d) hashMap.get("BitsPerSample");
        if (dVar2 != null) {
            int[] iArr = (int[]) dVar2.o(this.f1310h);
            int[] iArr2 = w;
            if (Arrays.equals(iArr2, iArr)) {
                return true;
            }
            if (this.f1306d == 3 && (dVar = (d) hashMap.get("PhotometricInterpretation")) != null && (((m = dVar.m(this.f1310h)) == 1 && Arrays.equals(iArr, x)) || (m == 6 && Arrays.equals(iArr, iArr2)))) {
                return true;
            }
        }
        if (!t) {
            return false;
        }
        Log.d("ExifInterface", "Unsupported data type value");
        return false;
    }

    private boolean L() {
        int i2 = this.f1306d;
        return i2 == 4 || i2 == 13 || i2 == 14;
    }

    private boolean M(HashMap hashMap) {
        d dVar = (d) hashMap.get("ImageLength");
        d dVar2 = (d) hashMap.get("ImageWidth");
        if (dVar == null || dVar2 == null) {
            return false;
        }
        return dVar.m(this.f1310h) <= 512 && dVar2.m(this.f1310h) <= 512;
    }

    private boolean N(byte[] bArr) {
        int i2 = 0;
        while (true) {
            byte[] bArr2 = I;
            if (i2 >= bArr2.length) {
                int i3 = 0;
                while (true) {
                    byte[] bArr3 = J;
                    if (i3 >= bArr3.length) {
                        return true;
                    }
                    if (bArr[I.length + i3 + 4] != bArr3[i3]) {
                        return false;
                    }
                    i3++;
                }
            } else {
                if (bArr[i2] != bArr2[i2]) {
                    return false;
                }
                i2++;
            }
        }
    }

    private void O(InputStream inputStream) {
        Objects.requireNonNull(inputStream, "inputstream shouldn't be null");
        for (int i2 = 0; i2 < f0.length; i2++) {
            try {
                try {
                    this.f1308f[i2] = new HashMap<>();
                } catch (IOException e2) {
                    boolean z2 = t;
                    if (z2) {
                        Log.w("ExifInterface", "Invalid image: ExifInterface got an unsupported image format file(ExifInterface supports JPEG and some RAW image formats only) or a corrupted JPEG file to ExifInterface.", e2);
                    }
                    a();
                    if (!z2) {
                        return;
                    }
                }
            } finally {
                a();
                if (t) {
                    Q();
                }
            }
        }
        if (!this.f1307e) {
            BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream, 5000);
            this.f1306d = o(bufferedInputStream);
            inputStream = bufferedInputStream;
        }
        b bVar = new b(inputStream);
        if (this.f1307e) {
            u(bVar);
        } else {
            switch (this.f1306d) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 5:
                case 6:
                case 8:
                case 11:
                    s(bVar);
                    break;
                case 4:
                    n(bVar, 0, 0);
                    a();
                    if (t) {
                        Q();
                        return;
                    }
                    return;
                case 7:
                    p(bVar);
                    break;
                case 9:
                    r(bVar);
                    a();
                    if (t) {
                        Q();
                        return;
                    }
                    return;
                case 10:
                    t(bVar);
                    a();
                    if (t) {
                        Q();
                        return;
                    }
                    return;
                case 12:
                    m(bVar);
                    break;
                case 13:
                    q(bVar);
                    a();
                    if (t) {
                        Q();
                        return;
                    }
                    return;
                case 14:
                    x(bVar);
                    a();
                    if (t) {
                        Q();
                        return;
                    }
                    return;
            }
        }
        bVar.d(this.o);
        b0(bVar);
    }

    private void P(b bVar, int i2) {
        ByteOrder R2 = R(bVar);
        this.f1310h = R2;
        bVar.e(R2);
        int readUnsignedShort = bVar.readUnsignedShort();
        int i3 = this.f1306d;
        if (i3 != 7 && i3 != 10 && readUnsignedShort != 42) {
            throw new IOException("Invalid start code: " + Integer.toHexString(readUnsignedShort));
        }
        int readInt = bVar.readInt();
        if (readInt < 8 || readInt >= i2) {
            throw new IOException("Invalid first Ifd offset: " + readInt);
        }
        int i4 = readInt - 8;
        if (i4 <= 0 || bVar.skipBytes(i4) == i4) {
            return;
        }
        throw new IOException("Couldn't jump to first Ifd: " + i4);
    }

    private void Q() {
        for (int i2 = 0; i2 < this.f1308f.length; i2++) {
            Log.d("ExifInterface", "The size of tag group[" + i2 + "]: " + this.f1308f[i2].size());
            for (Map.Entry<String, d> entry : this.f1308f[i2].entrySet()) {
                d value = entry.getValue();
                Log.d("ExifInterface", "tagName: " + entry.getKey() + ", tagType: " + value.toString() + ", tagValue: '" + value.n(this.f1310h) + "'");
            }
        }
    }

    private ByteOrder R(b bVar) {
        short readShort = bVar.readShort();
        if (readShort == 18761) {
            if (t) {
                Log.d("ExifInterface", "readExifSegment: Byte Align II");
            }
            return ByteOrder.LITTLE_ENDIAN;
        }
        if (readShort == 19789) {
            if (t) {
                Log.d("ExifInterface", "readExifSegment: Byte Align MM");
            }
            return ByteOrder.BIG_ENDIAN;
        }
        throw new IOException("Invalid byte order: " + Integer.toHexString(readShort));
    }

    private void S(byte[] bArr, int i2) {
        b bVar = new b(bArr);
        P(bVar, bArr.length);
        T(bVar, i2);
    }

    /* JADX WARN: Removed duplicated region for block: B:106:0x01dd  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x013f  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0147  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x01d9  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x0261  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x02c2  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void T(b.j.a.a.b r30, int r31) {
        /*
            Method dump skipped, instructions count: 995
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.a.a.T(b.j.a.a$b, int):void");
    }

    private void U(String str) {
        for (int i2 = 0; i2 < f0.length; i2++) {
            this.f1308f[i2].remove(str);
        }
    }

    private void V(b bVar, int i2) {
        d dVar = this.f1308f[i2].get("ImageLength");
        d dVar2 = this.f1308f[i2].get("ImageWidth");
        if (dVar == null || dVar2 == null) {
            d dVar3 = this.f1308f[i2].get("JPEGInterchangeFormat");
            d dVar4 = this.f1308f[i2].get("JPEGInterchangeFormatLength");
            if (dVar3 == null || dVar4 == null) {
                return;
            }
            int m = dVar3.m(this.f1310h);
            int m2 = dVar3.m(this.f1310h);
            bVar.d(m);
            byte[] bArr = new byte[m2];
            bVar.read(bArr);
            n(new b(bArr), m, i2);
        }
    }

    private void X(InputStream inputStream, OutputStream outputStream) {
        if (t) {
            Log.d("ExifInterface", "saveJpegAttributes starting with (inputStream: " + inputStream + ", outputStream: " + outputStream + ")");
        }
        DataInputStream dataInputStream = new DataInputStream(inputStream);
        c cVar = new c(outputStream, ByteOrder.BIG_ENDIAN);
        if (dataInputStream.readByte() != -1) {
            throw new IOException("Invalid marker");
        }
        cVar.b(-1);
        if (dataInputStream.readByte() != -40) {
            throw new IOException("Invalid marker");
        }
        cVar.b(-40);
        d dVar = null;
        if (j("Xmp") != null && this.s) {
            dVar = this.f1308f[0].remove("Xmp");
        }
        cVar.b(-1);
        cVar.b(-31);
        g0(cVar);
        if (dVar != null) {
            this.f1308f[0].put("Xmp", dVar);
        }
        byte[] bArr = new byte[4096];
        while (dataInputStream.readByte() == -1) {
            byte readByte = dataInputStream.readByte();
            if (readByte == -39 || readByte == -38) {
                cVar.b(-1);
                cVar.b(readByte);
                f(dataInputStream, cVar);
                return;
            }
            if (readByte != -31) {
                cVar.b(-1);
                cVar.b(readByte);
                int readUnsignedShort = dataInputStream.readUnsignedShort();
                cVar.f(readUnsignedShort);
                int i2 = readUnsignedShort - 2;
                if (i2 < 0) {
                    throw new IOException("Invalid length");
                }
                while (i2 > 0) {
                    int read = dataInputStream.read(bArr, 0, Math.min(i2, 4096));
                    if (read >= 0) {
                        cVar.write(bArr, 0, read);
                        i2 -= read;
                    }
                }
            } else {
                int readUnsignedShort2 = dataInputStream.readUnsignedShort() - 2;
                if (readUnsignedShort2 < 0) {
                    throw new IOException("Invalid length");
                }
                byte[] bArr2 = new byte[6];
                if (readUnsignedShort2 >= 6) {
                    if (dataInputStream.read(bArr2) != 6) {
                        throw new IOException("Invalid exif");
                    }
                    if (Arrays.equals(bArr2, o0)) {
                        int i3 = readUnsignedShort2 - 6;
                        if (dataInputStream.skipBytes(i3) != i3) {
                            throw new IOException("Invalid length");
                        }
                    }
                }
                cVar.b(-1);
                cVar.b(readByte);
                cVar.f(readUnsignedShort2 + 2);
                if (readUnsignedShort2 >= 6) {
                    readUnsignedShort2 -= 6;
                    cVar.write(bArr2);
                }
                while (readUnsignedShort2 > 0) {
                    int read2 = dataInputStream.read(bArr, 0, Math.min(readUnsignedShort2, 4096));
                    if (read2 >= 0) {
                        cVar.write(bArr, 0, read2);
                        readUnsignedShort2 -= read2;
                    }
                }
            }
        }
        throw new IOException("Invalid marker");
    }

    private void Y(InputStream inputStream, OutputStream outputStream) {
        ByteArrayOutputStream byteArrayOutputStream;
        if (t) {
            Log.d("ExifInterface", "savePngAttributes starting with (inputStream: " + inputStream + ", outputStream: " + outputStream + ")");
        }
        DataInputStream dataInputStream = new DataInputStream(inputStream);
        ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
        c cVar = new c(outputStream, byteOrder);
        byte[] bArr = E;
        g(dataInputStream, cVar, bArr.length);
        int i2 = this.o;
        if (i2 == 0) {
            int readInt = dataInputStream.readInt();
            cVar.c(readInt);
            g(dataInputStream, cVar, readInt + 4 + 4);
        } else {
            g(dataInputStream, cVar, ((i2 - bArr.length) - 4) - 4);
            dataInputStream.skipBytes(dataInputStream.readInt() + 4 + 4);
        }
        ByteArrayOutputStream byteArrayOutputStream2 = null;
        try {
            byteArrayOutputStream = new ByteArrayOutputStream();
        } catch (Throwable th) {
            th = th;
        }
        try {
            c cVar2 = new c(byteArrayOutputStream, byteOrder);
            g0(cVar2);
            byte[] byteArray = ((ByteArrayOutputStream) cVar2.n).toByteArray();
            cVar.write(byteArray);
            CRC32 crc32 = new CRC32();
            crc32.update(byteArray, 4, byteArray.length - 4);
            cVar.c((int) crc32.getValue());
            d(byteArrayOutputStream);
            f(dataInputStream, cVar);
        } catch (Throwable th2) {
            th = th2;
            byteArrayOutputStream2 = byteArrayOutputStream;
            d(byteArrayOutputStream2);
            throw th;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:55:0x01a3 A[Catch: all -> 0x01e2, Exception -> 0x01e5, TryCatch #4 {Exception -> 0x01e5, all -> 0x01e2, blocks: (B:9:0x004d, B:11:0x0056, B:12:0x006a, B:13:0x01c2, B:17:0x006f, B:19:0x0077, B:21:0x0083, B:23:0x008b, B:24:0x008f, B:27:0x00a2, B:29:0x00ad, B:30:0x00b2, B:32:0x00c0, B:35:0x00c4, B:38:0x00cc, B:40:0x00d4, B:42:0x00dc, B:44:0x00e4, B:45:0x00e8, B:47:0x00f3, B:49:0x00fe, B:51:0x0106, B:53:0x0151, B:55:0x01a3, B:56:0x01ab, B:57:0x01bd, B:58:0x01af, B:60:0x01b7, B:61:0x0115, B:62:0x011c, B:63:0x011d, B:65:0x0125, B:67:0x012b, B:68:0x0144, B:69:0x014b, B:72:0x01da, B:73:0x01e1), top: B:8:0x004d }] */
    /* JADX WARN: Removed duplicated region for block: B:58:0x01af A[Catch: all -> 0x01e2, Exception -> 0x01e5, TryCatch #4 {Exception -> 0x01e5, all -> 0x01e2, blocks: (B:9:0x004d, B:11:0x0056, B:12:0x006a, B:13:0x01c2, B:17:0x006f, B:19:0x0077, B:21:0x0083, B:23:0x008b, B:24:0x008f, B:27:0x00a2, B:29:0x00ad, B:30:0x00b2, B:32:0x00c0, B:35:0x00c4, B:38:0x00cc, B:40:0x00d4, B:42:0x00dc, B:44:0x00e4, B:45:0x00e8, B:47:0x00f3, B:49:0x00fe, B:51:0x0106, B:53:0x0151, B:55:0x01a3, B:56:0x01ab, B:57:0x01bd, B:58:0x01af, B:60:0x01b7, B:61:0x0115, B:62:0x011c, B:63:0x011d, B:65:0x0125, B:67:0x012b, B:68:0x0144, B:69:0x014b, B:72:0x01da, B:73:0x01e1), top: B:8:0x004d }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void Z(java.io.InputStream r21, java.io.OutputStream r22) {
        /*
            Method dump skipped, instructions count: 503
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.a.a.Z(java.io.InputStream, java.io.OutputStream):void");
    }

    private void a() {
        String j2 = j("DateTimeOriginal");
        if (j2 != null && j("DateTime") == null) {
            this.f1308f[0].put("DateTime", d.e(j2));
        }
        if (j("ImageWidth") == null) {
            this.f1308f[0].put("ImageWidth", d.f(0L, this.f1310h));
        }
        if (j("ImageLength") == null) {
            this.f1308f[0].put("ImageLength", d.f(0L, this.f1310h));
        }
        if (j("Orientation") == null) {
            this.f1308f[0].put("Orientation", d.f(0L, this.f1310h));
        }
        if (j("LightSource") == null) {
            this.f1308f[1].put("LightSource", d.f(0L, this.f1310h));
        }
    }

    private static String b(byte[] bArr) {
        StringBuilder sb = new StringBuilder(bArr.length * 2);
        for (byte b2 : bArr) {
            sb.append(String.format("%02x", Byte.valueOf(b2)));
        }
        return sb.toString();
    }

    private void b0(b bVar) {
        HashMap<String, d> hashMap = this.f1308f[4];
        d dVar = hashMap.get("Compression");
        if (dVar != null) {
            int m = dVar.m(this.f1310h);
            this.n = m;
            if (m != 1) {
                if (m != 6) {
                    if (m != 7) {
                        return;
                    }
                }
            }
            if (K(hashMap)) {
                A(bVar, hashMap);
                return;
            }
            return;
        }
        this.n = 6;
        z(bVar, hashMap);
    }

    private static void c(FileDescriptor fileDescriptor) {
        String str;
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Os.close(fileDescriptor);
                return;
            } catch (Exception unused) {
                str = "Error closing fd.";
            }
        } else {
            str = "closeFileDescriptor is called in API < 21, which must be wrong.";
        }
        Log.e("ExifInterface", str);
    }

    private static boolean c0(byte[] bArr, byte[] bArr2) {
        if (bArr == null || bArr2 == null || bArr.length < bArr2.length) {
            return false;
        }
        for (int i2 = 0; i2 < bArr2.length; i2++) {
            if (bArr[i2] != bArr2[i2]) {
                return false;
            }
        }
        return true;
    }

    private static void d(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (RuntimeException e2) {
                throw e2;
            } catch (Exception unused) {
            }
        }
    }

    private void d0(int i2, int i3) {
        String str;
        if (this.f1308f[i2].isEmpty() || this.f1308f[i3].isEmpty()) {
            if (t) {
                Log.d("ExifInterface", "Cannot perform swap since only one image data exists");
                return;
            }
            return;
        }
        d dVar = this.f1308f[i2].get("ImageLength");
        d dVar2 = this.f1308f[i2].get("ImageWidth");
        d dVar3 = this.f1308f[i3].get("ImageLength");
        d dVar4 = this.f1308f[i3].get("ImageWidth");
        if (dVar == null || dVar2 == null) {
            if (!t) {
                return;
            } else {
                str = "First image does not contain valid size information";
            }
        } else {
            if (dVar3 != null && dVar4 != null) {
                int m = dVar.m(this.f1310h);
                int m2 = dVar2.m(this.f1310h);
                int m3 = dVar3.m(this.f1310h);
                int m4 = dVar4.m(this.f1310h);
                if (m >= m3 || m2 >= m4) {
                    return;
                }
                HashMap<String, d>[] hashMapArr = this.f1308f;
                HashMap<String, d> hashMap = hashMapArr[i2];
                hashMapArr[i2] = hashMapArr[i3];
                hashMapArr[i3] = hashMap;
                return;
            }
            if (!t) {
                return;
            } else {
                str = "Second image does not contain valid size information";
            }
        }
        Log.d("ExifInterface", str);
    }

    private static long[] e(Object obj) {
        if (!(obj instanceof int[])) {
            if (obj instanceof long[]) {
                return (long[]) obj;
            }
            return null;
        }
        int[] iArr = (int[]) obj;
        long[] jArr = new long[iArr.length];
        for (int i2 = 0; i2 < iArr.length; i2++) {
            jArr[i2] = iArr[i2];
        }
        return jArr;
    }

    private void e0(b bVar, int i2) {
        StringBuilder sb;
        String arrays;
        d j2;
        d j3;
        d dVar = this.f1308f[i2].get("DefaultCropSize");
        d dVar2 = this.f1308f[i2].get("SensorTopBorder");
        d dVar3 = this.f1308f[i2].get("SensorLeftBorder");
        d dVar4 = this.f1308f[i2].get("SensorBottomBorder");
        d dVar5 = this.f1308f[i2].get("SensorRightBorder");
        if (dVar == null) {
            if (dVar2 == null || dVar3 == null || dVar4 == null || dVar5 == null) {
                V(bVar, i2);
                return;
            }
            int m = dVar2.m(this.f1310h);
            int m2 = dVar4.m(this.f1310h);
            int m3 = dVar5.m(this.f1310h);
            int m4 = dVar3.m(this.f1310h);
            if (m2 <= m || m3 <= m4) {
                return;
            }
            d j4 = d.j(m2 - m, this.f1310h);
            d j5 = d.j(m3 - m4, this.f1310h);
            this.f1308f[i2].put("ImageLength", j4);
            this.f1308f[i2].put("ImageWidth", j5);
            return;
        }
        if (dVar.f1314a == 5) {
            f[] fVarArr = (f[]) dVar.o(this.f1310h);
            if (fVarArr != null && fVarArr.length == 2) {
                j2 = d.h(fVarArr[0], this.f1310h);
                j3 = d.h(fVarArr[1], this.f1310h);
                this.f1308f[i2].put("ImageWidth", j2);
                this.f1308f[i2].put("ImageLength", j3);
                return;
            }
            sb = new StringBuilder();
            sb.append("Invalid crop size values. cropSize=");
            arrays = Arrays.toString(fVarArr);
            sb.append(arrays);
            Log.w("ExifInterface", sb.toString());
        }
        int[] iArr = (int[]) dVar.o(this.f1310h);
        if (iArr != null && iArr.length == 2) {
            j2 = d.j(iArr[0], this.f1310h);
            j3 = d.j(iArr[1], this.f1310h);
            this.f1308f[i2].put("ImageWidth", j2);
            this.f1308f[i2].put("ImageLength", j3);
            return;
        }
        sb = new StringBuilder();
        sb.append("Invalid crop size values. cropSize=");
        arrays = Arrays.toString(iArr);
        sb.append(arrays);
        Log.w("ExifInterface", sb.toString());
    }

    private static int f(InputStream inputStream, OutputStream outputStream) {
        byte[] bArr = new byte[8192];
        int i2 = 0;
        while (true) {
            int read = inputStream.read(bArr);
            if (read == -1) {
                return i2;
            }
            i2 += read;
            outputStream.write(bArr, 0, read);
        }
    }

    private void f0() {
        d0(0, 5);
        d0(0, 4);
        d0(5, 4);
        d dVar = this.f1308f[1].get("PixelXDimension");
        d dVar2 = this.f1308f[1].get("PixelYDimension");
        if (dVar != null && dVar2 != null) {
            this.f1308f[0].put("ImageWidth", dVar);
            this.f1308f[0].put("ImageLength", dVar2);
        }
        if (this.f1308f[4].isEmpty() && M(this.f1308f[5])) {
            HashMap<String, d>[] hashMapArr = this.f1308f;
            hashMapArr[4] = hashMapArr[5];
            hashMapArr[5] = new HashMap<>();
        }
        if (M(this.f1308f[4])) {
            return;
        }
        Log.d("ExifInterface", "No image meets the size requirements of a thumbnail image.");
    }

    private static void g(InputStream inputStream, OutputStream outputStream, int i2) {
        byte[] bArr = new byte[8192];
        while (i2 > 0) {
            int min = Math.min(i2, 8192);
            int read = inputStream.read(bArr, 0, min);
            if (read != min) {
                throw new IOException("Failed to copy the given amount of bytes from the inputstream to the output stream.");
            }
            i2 -= read;
            outputStream.write(bArr, 0, read);
        }
    }

    private int g0(c cVar) {
        e[][] eVarArr = f0;
        int[] iArr = new int[eVarArr.length];
        int[] iArr2 = new int[eVarArr.length];
        for (e eVar : g0) {
            U(eVar.f1319b);
        }
        U(h0.f1319b);
        U(i0.f1319b);
        for (int i2 = 0; i2 < f0.length; i2++) {
            for (Object obj : this.f1308f[i2].entrySet().toArray()) {
                Map.Entry entry = (Map.Entry) obj;
                if (entry.getValue() == null) {
                    this.f1308f[i2].remove(entry.getKey());
                }
            }
        }
        if (!this.f1308f[1].isEmpty()) {
            this.f1308f[0].put(g0[1].f1319b, d.f(0L, this.f1310h));
        }
        if (!this.f1308f[2].isEmpty()) {
            this.f1308f[0].put(g0[2].f1319b, d.f(0L, this.f1310h));
        }
        if (!this.f1308f[3].isEmpty()) {
            this.f1308f[1].put(g0[3].f1319b, d.f(0L, this.f1310h));
        }
        if (this.f1311i) {
            this.f1308f[4].put(h0.f1319b, d.f(0L, this.f1310h));
            this.f1308f[4].put(i0.f1319b, d.f(this.l, this.f1310h));
        }
        for (int i3 = 0; i3 < f0.length; i3++) {
            Iterator<Map.Entry<String, d>> it = this.f1308f[i3].entrySet().iterator();
            int i4 = 0;
            while (it.hasNext()) {
                int p = it.next().getValue().p();
                if (p > 4) {
                    i4 += p;
                }
            }
            iArr2[i3] = iArr2[i3] + i4;
        }
        int i5 = 8;
        for (int i6 = 0; i6 < f0.length; i6++) {
            if (!this.f1308f[i6].isEmpty()) {
                iArr[i6] = i5;
                i5 += (this.f1308f[i6].size() * 12) + 2 + 4 + iArr2[i6];
            }
        }
        if (this.f1311i) {
            this.f1308f[4].put(h0.f1319b, d.f(i5, this.f1310h));
            this.f1313k = i5;
            i5 += this.l;
        }
        if (this.f1306d == 4) {
            i5 += 8;
        }
        if (t) {
            for (int i7 = 0; i7 < f0.length; i7++) {
                Log.d("ExifInterface", String.format("index: %d, offsets: %d, tag count: %d, data sizes: %d, total size: %d", Integer.valueOf(i7), Integer.valueOf(iArr[i7]), Integer.valueOf(this.f1308f[i7].size()), Integer.valueOf(iArr2[i7]), Integer.valueOf(i5)));
            }
        }
        if (!this.f1308f[1].isEmpty()) {
            this.f1308f[0].put(g0[1].f1319b, d.f(iArr[1], this.f1310h));
        }
        if (!this.f1308f[2].isEmpty()) {
            this.f1308f[0].put(g0[2].f1319b, d.f(iArr[2], this.f1310h));
        }
        if (!this.f1308f[3].isEmpty()) {
            this.f1308f[1].put(g0[3].f1319b, d.f(iArr[3], this.f1310h));
        }
        int i8 = this.f1306d;
        if (i8 == 4) {
            cVar.f(i5);
            cVar.write(o0);
        } else if (i8 == 13) {
            cVar.c(i5);
            cVar.write(F);
        } else if (i8 == 14) {
            cVar.write(K);
            cVar.c(i5);
        }
        cVar.d(this.f1310h == ByteOrder.BIG_ENDIAN ? (short) 19789 : (short) 18761);
        cVar.a(this.f1310h);
        cVar.f(42);
        cVar.e(8L);
        for (int i9 = 0; i9 < f0.length; i9++) {
            if (!this.f1308f[i9].isEmpty()) {
                cVar.f(this.f1308f[i9].size());
                int size = iArr[i9] + 2 + (this.f1308f[i9].size() * 12) + 4;
                for (Map.Entry<String, d> entry2 : this.f1308f[i9].entrySet()) {
                    int i10 = k0[i9].get(entry2.getKey()).f1318a;
                    d value = entry2.getValue();
                    int p2 = value.p();
                    cVar.f(i10);
                    cVar.f(value.f1314a);
                    cVar.c(value.f1315b);
                    if (p2 > 4) {
                        cVar.e(size);
                        size += p2;
                    } else {
                        cVar.write(value.f1317d);
                        if (p2 < 4) {
                            while (p2 < 4) {
                                cVar.b(0);
                                p2++;
                            }
                        }
                    }
                }
                if (i9 != 0 || this.f1308f[4].isEmpty()) {
                    cVar.e(0L);
                } else {
                    cVar.e(iArr[4]);
                }
                Iterator<Map.Entry<String, d>> it2 = this.f1308f[i9].entrySet().iterator();
                while (it2.hasNext()) {
                    byte[] bArr = it2.next().getValue().f1317d;
                    if (bArr.length > 4) {
                        cVar.write(bArr, 0, bArr.length);
                    }
                }
            }
        }
        if (this.f1311i) {
            cVar.write(w());
        }
        if (this.f1306d == 14 && i5 % 2 == 1) {
            cVar.b(0);
        }
        cVar.a(ByteOrder.BIG_ENDIAN);
        return i5;
    }

    private void h(b bVar, c cVar, byte[] bArr, byte[] bArr2) {
        String str;
        while (true) {
            byte[] bArr3 = new byte[4];
            if (bVar.read(bArr3) != 4) {
                StringBuilder sb = new StringBuilder();
                sb.append("Encountered invalid length while copying WebP chunks up tochunk type ");
                Charset charset = n0;
                sb.append(new String(bArr, charset));
                if (bArr2 == null) {
                    str = "";
                } else {
                    str = " or " + new String(bArr2, charset);
                }
                sb.append(str);
                throw new IOException(sb.toString());
            }
            i(bVar, cVar, bArr3);
            if (Arrays.equals(bArr3, bArr)) {
                return;
            }
            if (bArr2 != null && Arrays.equals(bArr3, bArr2)) {
                return;
            }
        }
    }

    private void i(b bVar, c cVar, byte[] bArr) {
        int readInt = bVar.readInt();
        cVar.write(bArr);
        cVar.c(readInt);
        if (readInt % 2 == 1) {
            readInt++;
        }
        g(bVar, cVar, readInt);
    }

    private d l(String str) {
        Objects.requireNonNull(str, "tag shouldn't be null");
        if ("ISOSpeedRatings".equals(str)) {
            if (t) {
                Log.d("ExifInterface", "getExifAttribute: Replacing TAG_ISO_SPEED_RATINGS with TAG_PHOTOGRAPHIC_SENSITIVITY.");
            }
            str = "PhotographicSensitivity";
        }
        for (int i2 = 0; i2 < f0.length; i2++) {
            d dVar = this.f1308f[i2].get(str);
            if (dVar != null) {
                return dVar;
            }
        }
        return null;
    }

    private void m(b bVar) {
        String str;
        String str2;
        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                mediaMetadataRetriever.setDataSource(new C0046a(this, bVar));
            } else {
                FileDescriptor fileDescriptor = this.f1304b;
                if (fileDescriptor != null) {
                    mediaMetadataRetriever.setDataSource(fileDescriptor);
                } else {
                    String str3 = this.f1303a;
                    if (str3 == null) {
                        return;
                    } else {
                        mediaMetadataRetriever.setDataSource(str3);
                    }
                }
            }
            String extractMetadata = mediaMetadataRetriever.extractMetadata(33);
            String extractMetadata2 = mediaMetadataRetriever.extractMetadata(34);
            String extractMetadata3 = mediaMetadataRetriever.extractMetadata(26);
            String extractMetadata4 = mediaMetadataRetriever.extractMetadata(17);
            String str4 = null;
            if ("yes".equals(extractMetadata3)) {
                str4 = mediaMetadataRetriever.extractMetadata(29);
                str = mediaMetadataRetriever.extractMetadata(30);
                str2 = mediaMetadataRetriever.extractMetadata(31);
            } else if ("yes".equals(extractMetadata4)) {
                str4 = mediaMetadataRetriever.extractMetadata(18);
                str = mediaMetadataRetriever.extractMetadata(19);
                str2 = mediaMetadataRetriever.extractMetadata(24);
            } else {
                str = null;
                str2 = null;
            }
            if (str4 != null) {
                this.f1308f[0].put("ImageWidth", d.j(Integer.parseInt(str4), this.f1310h));
            }
            if (str != null) {
                this.f1308f[0].put("ImageLength", d.j(Integer.parseInt(str), this.f1310h));
            }
            if (str2 != null) {
                int i2 = 1;
                int parseInt = Integer.parseInt(str2);
                if (parseInt == 90) {
                    i2 = 6;
                } else if (parseInt == 180) {
                    i2 = 3;
                } else if (parseInt == 270) {
                    i2 = 8;
                }
                this.f1308f[0].put("Orientation", d.j(i2, this.f1310h));
            }
            if (extractMetadata != null && extractMetadata2 != null) {
                int parseInt2 = Integer.parseInt(extractMetadata);
                int parseInt3 = Integer.parseInt(extractMetadata2);
                if (parseInt3 <= 6) {
                    throw new IOException("Invalid exif length");
                }
                bVar.d(parseInt2);
                byte[] bArr = new byte[6];
                if (bVar.read(bArr) != 6) {
                    throw new IOException("Can't read identifier");
                }
                int i3 = parseInt2 + 6;
                int i4 = parseInt3 - 6;
                if (!Arrays.equals(bArr, o0)) {
                    throw new IOException("Invalid identifier");
                }
                byte[] bArr2 = new byte[i4];
                if (bVar.read(bArr2) != i4) {
                    throw new IOException("Can't read exif");
                }
                this.o = i3;
                S(bArr2, 0);
            }
            if (t) {
                Log.d("ExifInterface", "Heif meta: " + str4 + "x" + str + ", rotation " + str2);
            }
        } finally {
            mediaMetadataRetriever.release();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:73:0x01a8, code lost:
    
        r22.e(r21.f1310h);
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x01ad, code lost:
    
        return;
     */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0187  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x019c A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00bd A[FALL_THROUGH] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void n(b.j.a.a.b r22, int r23, int r24) {
        /*
            Method dump skipped, instructions count: 556
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.a.a.n(b.j.a.a$b, int, int):void");
    }

    private int o(BufferedInputStream bufferedInputStream) {
        bufferedInputStream.mark(5000);
        byte[] bArr = new byte[5000];
        bufferedInputStream.read(bArr);
        bufferedInputStream.reset();
        if (E(bArr)) {
            return 4;
        }
        if (H(bArr)) {
            return 9;
        }
        if (D(bArr)) {
            return 12;
        }
        if (F(bArr)) {
            return 7;
        }
        if (I(bArr)) {
            return 10;
        }
        if (G(bArr)) {
            return 13;
        }
        return N(bArr) ? 14 : 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:31:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void p(b.j.a.a.b r7) {
        /*
            Method dump skipped, instructions count: 246
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.a.a.p(b.j.a.a$b):void");
    }

    private void q(b bVar) {
        if (t) {
            Log.d("ExifInterface", "getPngAttributes starting with: " + bVar);
        }
        bVar.mark(0);
        bVar.e(ByteOrder.BIG_ENDIAN);
        byte[] bArr = E;
        bVar.skipBytes(bArr.length);
        int length = bArr.length + 0;
        while (true) {
            try {
                int readInt = bVar.readInt();
                int i2 = length + 4;
                byte[] bArr2 = new byte[4];
                if (bVar.read(bArr2) != 4) {
                    throw new IOException("Encountered invalid length while parsing PNG chunktype");
                }
                int i3 = i2 + 4;
                if (i3 == 16 && !Arrays.equals(bArr2, G)) {
                    throw new IOException("Encountered invalid PNG file--IHDR chunk should appearas the first chunk");
                }
                if (Arrays.equals(bArr2, H)) {
                    return;
                }
                if (Arrays.equals(bArr2, F)) {
                    byte[] bArr3 = new byte[readInt];
                    if (bVar.read(bArr3) != readInt) {
                        throw new IOException("Failed to read given length for given PNG chunk type: " + b(bArr2));
                    }
                    int readInt2 = bVar.readInt();
                    CRC32 crc32 = new CRC32();
                    crc32.update(bArr2);
                    crc32.update(bArr3);
                    if (((int) crc32.getValue()) == readInt2) {
                        this.o = i3;
                        S(bArr3, 0);
                        f0();
                        b0(new b(bArr3));
                        return;
                    }
                    throw new IOException("Encountered invalid CRC value for PNG-EXIF chunk.\n recorded CRC value: " + readInt2 + ", calculated CRC value: " + crc32.getValue());
                }
                int i4 = readInt + 4;
                bVar.skipBytes(i4);
                length = i3 + i4;
            } catch (EOFException unused) {
                throw new IOException("Encountered corrupt PNG file.");
            }
        }
    }

    private void r(b bVar) {
        boolean z2 = t;
        if (z2) {
            Log.d("ExifInterface", "getRafAttributes starting with: " + bVar);
        }
        bVar.mark(0);
        bVar.skipBytes(84);
        byte[] bArr = new byte[4];
        byte[] bArr2 = new byte[4];
        byte[] bArr3 = new byte[4];
        bVar.read(bArr);
        bVar.read(bArr2);
        bVar.read(bArr3);
        int i2 = ByteBuffer.wrap(bArr).getInt();
        int i3 = ByteBuffer.wrap(bArr2).getInt();
        int i4 = ByteBuffer.wrap(bArr3).getInt();
        byte[] bArr4 = new byte[i3];
        bVar.d(i2);
        bVar.read(bArr4);
        n(new b(bArr4), i2, 5);
        bVar.d(i4);
        bVar.e(ByteOrder.BIG_ENDIAN);
        int readInt = bVar.readInt();
        if (z2) {
            Log.d("ExifInterface", "numberOfDirectoryEntry: " + readInt);
        }
        for (int i5 = 0; i5 < readInt; i5++) {
            int readUnsignedShort = bVar.readUnsignedShort();
            int readUnsignedShort2 = bVar.readUnsignedShort();
            if (readUnsignedShort == a0.f1318a) {
                short readShort = bVar.readShort();
                short readShort2 = bVar.readShort();
                d j2 = d.j(readShort, this.f1310h);
                d j3 = d.j(readShort2, this.f1310h);
                this.f1308f[0].put("ImageLength", j2);
                this.f1308f[0].put("ImageWidth", j3);
                if (t) {
                    Log.d("ExifInterface", "Updated to length: " + ((int) readShort) + ", width: " + ((int) readShort2));
                    return;
                }
                return;
            }
            bVar.skipBytes(readUnsignedShort2);
        }
    }

    private void s(b bVar) {
        d dVar;
        P(bVar, bVar.available());
        T(bVar, 0);
        e0(bVar, 0);
        e0(bVar, 5);
        e0(bVar, 4);
        f0();
        if (this.f1306d != 8 || (dVar = this.f1308f[1].get("MakerNote")) == null) {
            return;
        }
        b bVar2 = new b(dVar.f1317d);
        bVar2.e(this.f1310h);
        bVar2.d(6L);
        T(bVar2, 9);
        d dVar2 = this.f1308f[9].get("ColorSpace");
        if (dVar2 != null) {
            this.f1308f[1].put("ColorSpace", dVar2);
        }
    }

    private void t(b bVar) {
        if (t) {
            Log.d("ExifInterface", "getRw2Attributes starting with: " + bVar);
        }
        s(bVar);
        d dVar = this.f1308f[0].get("JpgFromRaw");
        if (dVar != null) {
            n(new b(dVar.f1317d), (int) dVar.f1316c, 5);
        }
        d dVar2 = this.f1308f[0].get("ISO");
        d dVar3 = this.f1308f[1].get("PhotographicSensitivity");
        if (dVar2 == null || dVar3 != null) {
            return;
        }
        this.f1308f[1].put("PhotographicSensitivity", dVar2);
    }

    private void u(b bVar) {
        byte[] bArr = o0;
        bVar.skipBytes(bArr.length);
        byte[] bArr2 = new byte[bVar.available()];
        bVar.readFully(bArr2);
        this.o = bArr.length;
        S(bArr2, 0);
    }

    private void x(b bVar) {
        if (t) {
            Log.d("ExifInterface", "getWebpAttributes starting with: " + bVar);
        }
        bVar.mark(0);
        bVar.e(ByteOrder.LITTLE_ENDIAN);
        bVar.skipBytes(I.length);
        int readInt = bVar.readInt() + 8;
        int skipBytes = bVar.skipBytes(J.length) + 8;
        while (true) {
            try {
                byte[] bArr = new byte[4];
                if (bVar.read(bArr) != 4) {
                    throw new IOException("Encountered invalid length while parsing WebP chunktype");
                }
                int readInt2 = bVar.readInt();
                int i2 = skipBytes + 4 + 4;
                if (Arrays.equals(K, bArr)) {
                    byte[] bArr2 = new byte[readInt2];
                    if (bVar.read(bArr2) == readInt2) {
                        this.o = i2;
                        S(bArr2, 0);
                        b0(new b(bArr2));
                        return;
                    } else {
                        throw new IOException("Failed to read given length for given PNG chunk type: " + b(bArr));
                    }
                }
                if (readInt2 % 2 == 1) {
                    readInt2++;
                }
                int i3 = i2 + readInt2;
                if (i3 == readInt) {
                    return;
                }
                if (i3 > readInt) {
                    throw new IOException("Encountered WebP file with invalid chunk size");
                }
                int skipBytes2 = bVar.skipBytes(readInt2);
                if (skipBytes2 != readInt2) {
                    throw new IOException("Encountered WebP file with invalid chunk size");
                }
                skipBytes = i2 + skipBytes2;
            } catch (EOFException unused) {
                throw new IOException("Encountered corrupt WebP file.");
            }
        }
    }

    private static Pair<Integer, Integer> y(String str) {
        if (str.contains(",")) {
            String[] split = str.split(",", -1);
            Pair<Integer, Integer> y2 = y(split[0]);
            if (((Integer) y2.first).intValue() == 2) {
                return y2;
            }
            for (int i2 = 1; i2 < split.length; i2++) {
                Pair<Integer, Integer> y3 = y(split[i2]);
                int intValue = (((Integer) y3.first).equals(y2.first) || ((Integer) y3.second).equals(y2.first)) ? ((Integer) y2.first).intValue() : -1;
                int intValue2 = (((Integer) y2.second).intValue() == -1 || !(((Integer) y3.first).equals(y2.second) || ((Integer) y3.second).equals(y2.second))) ? -1 : ((Integer) y2.second).intValue();
                if (intValue == -1 && intValue2 == -1) {
                    return new Pair<>(2, -1);
                }
                if (intValue == -1) {
                    y2 = new Pair<>(Integer.valueOf(intValue2), -1);
                } else if (intValue2 == -1) {
                    y2 = new Pair<>(Integer.valueOf(intValue), -1);
                }
            }
            return y2;
        }
        if (!str.contains("/")) {
            try {
                try {
                    Long valueOf = Long.valueOf(Long.parseLong(str));
                    return (valueOf.longValue() < 0 || valueOf.longValue() > 65535) ? valueOf.longValue() < 0 ? new Pair<>(9, -1) : new Pair<>(4, -1) : new Pair<>(3, 4);
                } catch (NumberFormatException unused) {
                    return new Pair<>(2, -1);
                }
            } catch (NumberFormatException unused2) {
                Double.parseDouble(str);
                return new Pair<>(12, -1);
            }
        }
        String[] split2 = str.split("/", -1);
        if (split2.length == 2) {
            try {
                long parseDouble = (long) Double.parseDouble(split2[0]);
                long parseDouble2 = (long) Double.parseDouble(split2[1]);
                if (parseDouble >= 0 && parseDouble2 >= 0) {
                    if (parseDouble <= 2147483647L && parseDouble2 <= 2147483647L) {
                        return new Pair<>(10, 5);
                    }
                    return new Pair<>(5, -1);
                }
                return new Pair<>(10, -1);
            } catch (NumberFormatException unused3) {
            }
        }
        return new Pair<>(2, -1);
    }

    private void z(b bVar, HashMap hashMap) {
        d dVar = (d) hashMap.get("JPEGInterchangeFormat");
        d dVar2 = (d) hashMap.get("JPEGInterchangeFormatLength");
        if (dVar == null || dVar2 == null) {
            return;
        }
        int m = dVar.m(this.f1310h);
        int m2 = dVar2.m(this.f1310h);
        if (this.f1306d == 7) {
            m += this.p;
        }
        int min = Math.min(m2, bVar.a() - m);
        if (m > 0 && min > 0) {
            this.f1311i = true;
            if (this.f1303a == null && this.f1305c == null && this.f1304b == null) {
                byte[] bArr = new byte[min];
                bVar.skip(m);
                bVar.read(bArr);
                this.m = bArr;
            }
            this.f1313k = m;
            this.l = min;
        }
        if (t) {
            Log.d("ExifInterface", "Setting thumbnail attributes with offset: " + m + ", length: " + min);
        }
    }

    public void W() {
        FileOutputStream fileOutputStream;
        FileInputStream fileInputStream;
        File file;
        BufferedOutputStream bufferedOutputStream;
        Exception exc;
        FileOutputStream fileOutputStream2;
        FileDescriptor fileDescriptor;
        BufferedInputStream bufferedInputStream;
        if (!L()) {
            throw new IOException("ExifInterface only supports saving attributes on JPEG, PNG, or WebP formats.");
        }
        if (this.f1304b == null && this.f1303a == null) {
            throw new IOException("ExifInterface does not support saving attributes for the current input.");
        }
        this.m = v();
        InputStream inputStream = null;
        File file2 = this.f1303a != null ? new File(this.f1303a) : null;
        try {
            if (this.f1303a != null) {
                String parent = file2.getParent();
                String name = file2.getName();
                file = new File(parent, (UUID.randomUUID().toString() + "_") + name);
                if (!file2.renameTo(file)) {
                    throw new IOException("Couldn't rename to " + file.getAbsolutePath());
                }
                fileInputStream = null;
                fileOutputStream = null;
            } else if (Build.VERSION.SDK_INT < 21 || this.f1304b == null) {
                fileInputStream = null;
                fileOutputStream = null;
                file = null;
            } else {
                file = File.createTempFile("temp", "tmp");
                Os.lseek(this.f1304b, 0L, OsConstants.SEEK_SET);
                fileInputStream = new FileInputStream(this.f1304b);
                try {
                    fileOutputStream = new FileOutputStream(file);
                    try {
                        f(fileInputStream, fileOutputStream);
                    } catch (Exception e2) {
                        e = e2;
                        inputStream = fileInputStream;
                        try {
                            throw new IOException("Failed to copy original file to temp file", e);
                        } catch (Throwable th) {
                            th = th;
                            d(inputStream);
                            d(fileOutputStream);
                            throw th;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        inputStream = fileInputStream;
                        d(inputStream);
                        d(fileOutputStream);
                        throw th;
                    }
                } catch (Exception e3) {
                    e = e3;
                    fileOutputStream = null;
                } catch (Throwable th3) {
                    th = th3;
                    fileOutputStream = null;
                }
            }
            d(fileInputStream);
            d(fileOutputStream);
            try {
                FileInputStream fileInputStream2 = new FileInputStream(file);
                if (this.f1303a != null) {
                    fileOutputStream2 = new FileOutputStream(this.f1303a);
                } else if (Build.VERSION.SDK_INT < 21 || (fileDescriptor = this.f1304b) == null) {
                    fileOutputStream2 = null;
                } else {
                    Os.lseek(fileDescriptor, 0L, OsConstants.SEEK_SET);
                    fileOutputStream2 = new FileOutputStream(this.f1304b);
                }
                bufferedInputStream = new BufferedInputStream(fileInputStream2);
                try {
                    bufferedOutputStream = new BufferedOutputStream(fileOutputStream2);
                } catch (Exception e4) {
                    exc = e4;
                    bufferedOutputStream = null;
                } catch (Throwable th4) {
                    th = th4;
                    bufferedOutputStream = null;
                }
            } catch (Exception e5) {
                exc = e5;
                bufferedOutputStream = null;
            } catch (Throwable th5) {
                th = th5;
                bufferedOutputStream = null;
            }
            try {
                int i2 = this.f1306d;
                if (i2 == 4) {
                    X(bufferedInputStream, bufferedOutputStream);
                } else if (i2 == 13) {
                    Y(bufferedInputStream, bufferedOutputStream);
                } else if (i2 == 14) {
                    Z(bufferedInputStream, bufferedOutputStream);
                }
                d(bufferedInputStream);
                d(bufferedOutputStream);
                file.delete();
                this.m = null;
            } catch (Exception e6) {
                exc = e6;
                inputStream = bufferedInputStream;
                try {
                    if (this.f1303a == null || file.renameTo(file2)) {
                        throw new IOException("Failed to save new file", exc);
                    }
                    throw new IOException("Couldn't restore original file: " + file2.getAbsolutePath());
                } catch (Throwable th6) {
                    th = th6;
                    d(inputStream);
                    d(bufferedOutputStream);
                    file.delete();
                    throw th;
                }
            } catch (Throwable th7) {
                th = th7;
                inputStream = bufferedInputStream;
                d(inputStream);
                d(bufferedOutputStream);
                file.delete();
                throw th;
            }
        } catch (Exception e7) {
            e = e7;
            fileOutputStream = null;
        } catch (Throwable th8) {
            th = th8;
            fileOutputStream = null;
        }
    }

    public void a0(String str, String str2) {
        e eVar;
        int i2;
        String str3;
        HashMap<String, d> hashMap;
        d a2;
        String str4;
        HashMap<String, d> hashMap2;
        d c2;
        StringBuilder sb;
        String str5 = str;
        String str6 = str2;
        Objects.requireNonNull(str5, "tag shouldn't be null");
        String str7 = "ExifInterface";
        if ("ISOSpeedRatings".equals(str5)) {
            if (t) {
                Log.d("ExifInterface", "setAttribute: Replacing TAG_ISO_SPEED_RATINGS with TAG_PHOTOGRAPHIC_SENSITIVITY.");
            }
            str5 = "PhotographicSensitivity";
        }
        int i3 = 2;
        int i4 = 1;
        if (str6 != null && l0.contains(str5)) {
            if (str5.equals("GPSTimeStamp")) {
                Matcher matcher = q0.matcher(str6);
                if (!matcher.find()) {
                    sb = new StringBuilder();
                    sb.append("Invalid value for ");
                    sb.append(str5);
                    sb.append(" : ");
                    sb.append(str6);
                    Log.w("ExifInterface", sb.toString());
                    return;
                }
                str6 = Integer.parseInt(matcher.group(1)) + "/1," + Integer.parseInt(matcher.group(2)) + "/1," + Integer.parseInt(matcher.group(3)) + "/1";
            } else {
                try {
                    str6 = new f(Double.parseDouble(str2)).toString();
                } catch (NumberFormatException unused) {
                    sb = new StringBuilder();
                }
            }
        }
        char c3 = 0;
        int i5 = 0;
        while (i5 < f0.length) {
            if ((i5 != 4 || this.f1311i) && (eVar = k0[i5].get(str5)) != null) {
                if (str6 == null) {
                    this.f1308f[i5].remove(str5);
                } else {
                    Pair<Integer, Integer> y2 = y(str6);
                    int i6 = -1;
                    if (eVar.f1320c == ((Integer) y2.first).intValue() || eVar.f1320c == ((Integer) y2.second).intValue()) {
                        i2 = eVar.f1320c;
                    } else {
                        int i7 = eVar.f1321d;
                        if (i7 == -1 || !(i7 == ((Integer) y2.first).intValue() || eVar.f1321d == ((Integer) y2.second).intValue())) {
                            int i8 = eVar.f1320c;
                            if (i8 == i4 || i8 == 7 || i8 == i3) {
                                i2 = i8;
                            } else if (t) {
                                StringBuilder sb2 = new StringBuilder();
                                sb2.append("Given tag (");
                                sb2.append(str5);
                                sb2.append(") value didn't match with one of expected formats: ");
                                String[] strArr = S;
                                sb2.append(strArr[eVar.f1320c]);
                                sb2.append(eVar.f1321d == -1 ? "" : ", " + strArr[eVar.f1321d]);
                                sb2.append(" (guess: ");
                                sb2.append(strArr[((Integer) y2.first).intValue()]);
                                sb2.append(((Integer) y2.second).intValue() != -1 ? ", " + strArr[((Integer) y2.second).intValue()] : "");
                                sb2.append(")");
                                Log.d(str7, sb2.toString());
                            }
                        } else {
                            i2 = eVar.f1321d;
                        }
                    }
                    switch (i2) {
                        case 1:
                            str3 = str7;
                            hashMap = this.f1308f[i5];
                            a2 = d.a(str6);
                            hashMap.put(str5, a2);
                            str7 = str3;
                            break;
                        case 2:
                        case 7:
                            str3 = str7;
                            hashMap = this.f1308f[i5];
                            a2 = d.e(str6);
                            hashMap.put(str5, a2);
                            str7 = str3;
                            break;
                        case 3:
                            str3 = str7;
                            String[] split = str6.split(",", -1);
                            int[] iArr = new int[split.length];
                            for (int i9 = 0; i9 < split.length; i9++) {
                                iArr[i9] = Integer.parseInt(split[i9]);
                            }
                            hashMap = this.f1308f[i5];
                            a2 = d.k(iArr, this.f1310h);
                            hashMap.put(str5, a2);
                            str7 = str3;
                            break;
                        case 4:
                            str3 = str7;
                            String[] split2 = str6.split(",", -1);
                            long[] jArr = new long[split2.length];
                            for (int i10 = 0; i10 < split2.length; i10++) {
                                jArr[i10] = Long.parseLong(split2[i10]);
                            }
                            hashMap = this.f1308f[i5];
                            a2 = d.g(jArr, this.f1310h);
                            hashMap.put(str5, a2);
                            str7 = str3;
                            break;
                        case 5:
                            str3 = str7;
                            String[] split3 = str6.split(",", -1);
                            f[] fVarArr = new f[split3.length];
                            int i11 = 0;
                            while (i11 < split3.length) {
                                String[] split4 = split3[i11].split("/", i6);
                                fVarArr[i11] = new f((long) Double.parseDouble(split4[0]), (long) Double.parseDouble(split4[1]));
                                i11++;
                                i6 = -1;
                            }
                            hashMap = this.f1308f[i5];
                            a2 = d.i(fVarArr, this.f1310h);
                            hashMap.put(str5, a2);
                            str7 = str3;
                            break;
                        case 6:
                        case 8:
                        case 11:
                        default:
                            str3 = str7;
                            if (t) {
                                str7 = str3;
                                Log.d(str7, "Data format isn't one of expected formats: " + i2);
                                break;
                            }
                            str7 = str3;
                            break;
                        case 9:
                            str4 = str7;
                            String[] split5 = str6.split(",", -1);
                            int[] iArr2 = new int[split5.length];
                            for (int i12 = 0; i12 < split5.length; i12++) {
                                iArr2[i12] = Integer.parseInt(split5[i12]);
                            }
                            hashMap2 = this.f1308f[i5];
                            c2 = d.c(iArr2, this.f1310h);
                            hashMap2.put(str5, c2);
                            str7 = str4;
                            break;
                        case 10:
                            String[] split6 = str6.split(",", -1);
                            f[] fVarArr2 = new f[split6.length];
                            int i13 = 0;
                            while (i13 < split6.length) {
                                String[] split7 = split6[i13].split("/", -1);
                                fVarArr2[i13] = new f((long) Double.parseDouble(split7[c3]), (long) Double.parseDouble(split7[i4]));
                                i13++;
                                str7 = str7;
                                i4 = 1;
                                c3 = 0;
                            }
                            str4 = str7;
                            hashMap2 = this.f1308f[i5];
                            c2 = d.d(fVarArr2, this.f1310h);
                            hashMap2.put(str5, c2);
                            str7 = str4;
                            break;
                        case 12:
                            String[] split8 = str6.split(",", -1);
                            double[] dArr = new double[split8.length];
                            for (int i14 = 0; i14 < split8.length; i14++) {
                                dArr[i14] = Double.parseDouble(split8[i14]);
                            }
                            this.f1308f[i5].put(str5, d.b(dArr, this.f1310h));
                            break;
                    }
                    i5++;
                    i3 = 2;
                    i4 = 1;
                    c3 = 0;
                }
            }
            i5++;
            i3 = 2;
            i4 = 1;
            c3 = 0;
        }
    }

    public String j(String str) {
        String str2;
        Objects.requireNonNull(str, "tag shouldn't be null");
        d l = l(str);
        if (l != null) {
            if (!l0.contains(str)) {
                return l.n(this.f1310h);
            }
            if (str.equals("GPSTimeStamp")) {
                int i2 = l.f1314a;
                if (i2 == 5 || i2 == 10) {
                    f[] fVarArr = (f[]) l.o(this.f1310h);
                    if (fVarArr != null && fVarArr.length == 3) {
                        return String.format("%02d:%02d:%02d", Integer.valueOf((int) (fVarArr[0].f1322a / fVarArr[0].f1323b)), Integer.valueOf((int) (fVarArr[1].f1322a / fVarArr[1].f1323b)), Integer.valueOf((int) (fVarArr[2].f1322a / fVarArr[2].f1323b)));
                    }
                    str2 = "Invalid GPS Timestamp array. array=" + Arrays.toString(fVarArr);
                } else {
                    str2 = "GPS Timestamp format is not rational. format=" + l.f1314a;
                }
                Log.w("ExifInterface", str2);
                return null;
            }
            try {
                return Double.toString(l.l(this.f1310h));
            } catch (NumberFormatException unused) {
            }
        }
        return null;
    }

    public int k(String str, int i2) {
        Objects.requireNonNull(str, "tag shouldn't be null");
        d l = l(str);
        if (l == null) {
            return i2;
        }
        try {
            return l.m(this.f1310h);
        } catch (NumberFormatException unused) {
            return i2;
        }
    }

    public byte[] v() {
        int i2 = this.n;
        if (i2 == 6 || i2 == 7) {
            return w();
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0065 A[Catch: Exception -> 0x009e, all -> 0x00bb, TRY_ENTER, TRY_LEAVE, TryCatch #0 {Exception -> 0x009e, blocks: (B:18:0x0065, B:21:0x007b, B:23:0x0087, B:28:0x0092, B:29:0x0097, B:30:0x0098, B:31:0x009d, B:32:0x00a0, B:33:0x00a5), top: B:16:0x0063 }] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00a0 A[Catch: Exception -> 0x009e, all -> 0x00bb, TryCatch #0 {Exception -> 0x009e, blocks: (B:18:0x0065, B:21:0x007b, B:23:0x0087, B:28:0x0092, B:29:0x0097, B:30:0x0098, B:31:0x009d, B:32:0x00a0, B:33:0x00a5), top: B:16:0x0063 }] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00b7  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00c2  */
    /* JADX WARN: Type inference failed for: r1v1, types: [byte[]] */
    /* JADX WARN: Type inference failed for: r1v2 */
    /* JADX WARN: Type inference failed for: r1v5, types: [android.content.res.AssetManager$AssetInputStream, java.io.Closeable, java.io.InputStream] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public byte[] w() {
        /*
            Method dump skipped, instructions count: 198
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.a.a.w():byte[]");
    }
}
