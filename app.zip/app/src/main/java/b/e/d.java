package b.e;

/* loaded from: classes.dex */
public class d<E> implements Cloneable {
    private static final Object r = new Object();
    private boolean n;
    private long[] o;
    private Object[] p;
    private int q;

    public d() {
        this(10);
    }

    public d(int i2) {
        this.n = false;
        if (i2 == 0) {
            this.o = c.f954b;
            this.p = c.f955c;
        } else {
            int f2 = c.f(i2);
            this.o = new long[f2];
            this.p = new Object[f2];
        }
    }

    private void e() {
        int i2 = this.q;
        long[] jArr = this.o;
        Object[] objArr = this.p;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            Object obj = objArr[i4];
            if (obj != r) {
                if (i4 != i3) {
                    jArr[i3] = jArr[i4];
                    objArr[i3] = obj;
                    objArr[i4] = null;
                }
                i3++;
            }
        }
        this.n = false;
        this.q = i3;
    }

    public void a(long j2, E e2) {
        int i2 = this.q;
        if (i2 != 0 && j2 <= this.o[i2 - 1]) {
            i(j2, e2);
            return;
        }
        if (this.n && i2 >= this.o.length) {
            e();
        }
        int i3 = this.q;
        if (i3 >= this.o.length) {
            int f2 = c.f(i3 + 1);
            long[] jArr = new long[f2];
            Object[] objArr = new Object[f2];
            long[] jArr2 = this.o;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr2 = this.p;
            System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
            this.o = jArr;
            this.p = objArr;
        }
        this.o[i3] = j2;
        this.p[i3] = e2;
        this.q = i3 + 1;
    }

    public void c() {
        int i2 = this.q;
        Object[] objArr = this.p;
        for (int i3 = 0; i3 < i2; i3++) {
            objArr[i3] = null;
        }
        this.q = 0;
        this.n = false;
    }

    /* renamed from: d, reason: merged with bridge method [inline-methods] */
    public d<E> clone() {
        try {
            d<E> dVar = (d) super.clone();
            dVar.o = (long[]) this.o.clone();
            dVar.p = (Object[]) this.p.clone();
            return dVar;
        } catch (CloneNotSupportedException e2) {
            throw new AssertionError(e2);
        }
    }

    public E f(long j2) {
        return g(j2, null);
    }

    public E g(long j2, E e2) {
        int b2 = c.b(this.o, this.q, j2);
        if (b2 >= 0) {
            Object[] objArr = this.p;
            if (objArr[b2] != r) {
                return (E) objArr[b2];
            }
        }
        return e2;
    }

    public long h(int i2) {
        if (this.n) {
            e();
        }
        return this.o[i2];
    }

    public void i(long j2, E e2) {
        int b2 = c.b(this.o, this.q, j2);
        if (b2 >= 0) {
            this.p[b2] = e2;
            return;
        }
        int i2 = ~b2;
        int i3 = this.q;
        if (i2 < i3) {
            Object[] objArr = this.p;
            if (objArr[i2] == r) {
                this.o[i2] = j2;
                objArr[i2] = e2;
                return;
            }
        }
        if (this.n && i3 >= this.o.length) {
            e();
            i2 = ~c.b(this.o, this.q, j2);
        }
        int i4 = this.q;
        if (i4 >= this.o.length) {
            int f2 = c.f(i4 + 1);
            long[] jArr = new long[f2];
            Object[] objArr2 = new Object[f2];
            long[] jArr2 = this.o;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr3 = this.p;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.o = jArr;
            this.p = objArr2;
        }
        int i5 = this.q;
        if (i5 - i2 != 0) {
            long[] jArr3 = this.o;
            int i6 = i2 + 1;
            System.arraycopy(jArr3, i2, jArr3, i6, i5 - i2);
            Object[] objArr4 = this.p;
            System.arraycopy(objArr4, i2, objArr4, i6, this.q - i2);
        }
        this.o[i2] = j2;
        this.p[i2] = e2;
        this.q++;
    }

    public void j(long j2) {
        int b2 = c.b(this.o, this.q, j2);
        if (b2 >= 0) {
            Object[] objArr = this.p;
            Object obj = objArr[b2];
            Object obj2 = r;
            if (obj != obj2) {
                objArr[b2] = obj2;
                this.n = true;
            }
        }
    }

    public int k() {
        if (this.n) {
            e();
        }
        return this.q;
    }

    public E m(int i2) {
        if (this.n) {
            e();
        }
        return (E) this.p[i2];
    }

    public String toString() {
        if (k() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.q * 28);
        sb.append('{');
        for (int i2 = 0; i2 < this.q; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            sb.append(h(i2));
            sb.append('=');
            E m = m(i2);
            if (m != this) {
                sb.append(m);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
