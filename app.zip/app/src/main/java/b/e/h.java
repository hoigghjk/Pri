package b.e;

/* loaded from: classes.dex */
public class h<E> implements Cloneable {
    private static final Object r = new Object();
    private boolean n;
    private int[] o;
    private Object[] p;
    private int q;

    public h() {
        this(10);
    }

    public h(int i2) {
        this.n = false;
        if (i2 == 0) {
            this.o = c.f953a;
            this.p = c.f955c;
        } else {
            int e2 = c.e(i2);
            this.o = new int[e2];
            this.p = new Object[e2];
        }
    }

    private void e() {
        int i2 = this.q;
        int[] iArr = this.o;
        Object[] objArr = this.p;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            Object obj = objArr[i4];
            if (obj != r) {
                if (i4 != i3) {
                    iArr[i3] = iArr[i4];
                    objArr[i3] = obj;
                    objArr[i4] = null;
                }
                i3++;
            }
        }
        this.n = false;
        this.q = i3;
    }

    public void a(int i2, E e2) {
        int i3 = this.q;
        if (i3 != 0 && i2 <= this.o[i3 - 1]) {
            j(i2, e2);
            return;
        }
        if (this.n && i3 >= this.o.length) {
            e();
        }
        int i4 = this.q;
        if (i4 >= this.o.length) {
            int e3 = c.e(i4 + 1);
            int[] iArr = new int[e3];
            Object[] objArr = new Object[e3];
            int[] iArr2 = this.o;
            System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
            Object[] objArr2 = this.p;
            System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
            this.o = iArr;
            this.p = objArr;
        }
        this.o[i4] = i2;
        this.p[i4] = e2;
        this.q = i4 + 1;
    }

    public void c() {
        int i2 = this.q;
        Object[] objArr = this.p;
        for (int i3 = 0; i3 < i2; i3++) {
            objArr[i3] = null;
        }
        this.q = 0;
        this.n = false;
    }

    /* renamed from: d, reason: merged with bridge method [inline-methods] */
    public h<E> clone() {
        try {
            h<E> hVar = (h) super.clone();
            hVar.o = (int[]) this.o.clone();
            hVar.p = (Object[]) this.p.clone();
            return hVar;
        } catch (CloneNotSupportedException e2) {
            throw new AssertionError(e2);
        }
    }

    public E f(int i2) {
        return g(i2, null);
    }

    public E g(int i2, E e2) {
        int a2 = c.a(this.o, this.q, i2);
        if (a2 >= 0) {
            Object[] objArr = this.p;
            if (objArr[a2] != r) {
                return (E) objArr[a2];
            }
        }
        return e2;
    }

    public int h(int i2) {
        if (this.n) {
            e();
        }
        return c.a(this.o, this.q, i2);
    }

    public int i(int i2) {
        if (this.n) {
            e();
        }
        return this.o[i2];
    }

    public void j(int i2, E e2) {
        int a2 = c.a(this.o, this.q, i2);
        if (a2 >= 0) {
            this.p[a2] = e2;
            return;
        }
        int i3 = ~a2;
        int i4 = this.q;
        if (i3 < i4) {
            Object[] objArr = this.p;
            if (objArr[i3] == r) {
                this.o[i3] = i2;
                objArr[i3] = e2;
                return;
            }
        }
        if (this.n && i4 >= this.o.length) {
            e();
            i3 = ~c.a(this.o, this.q, i2);
        }
        int i5 = this.q;
        if (i5 >= this.o.length) {
            int e3 = c.e(i5 + 1);
            int[] iArr = new int[e3];
            Object[] objArr2 = new Object[e3];
            int[] iArr2 = this.o;
            System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
            Object[] objArr3 = this.p;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.o = iArr;
            this.p = objArr2;
        }
        int i6 = this.q;
        if (i6 - i3 != 0) {
            int[] iArr3 = this.o;
            int i7 = i3 + 1;
            System.arraycopy(iArr3, i3, iArr3, i7, i6 - i3);
            Object[] objArr4 = this.p;
            System.arraycopy(objArr4, i3, objArr4, i7, this.q - i3);
        }
        this.o[i3] = i2;
        this.p[i3] = e2;
        this.q++;
    }

    public void k(int i2) {
        int a2 = c.a(this.o, this.q, i2);
        if (a2 >= 0) {
            Object[] objArr = this.p;
            Object obj = objArr[a2];
            Object obj2 = r;
            if (obj != obj2) {
                objArr[a2] = obj2;
                this.n = true;
            }
        }
    }

    public int m() {
        if (this.n) {
            e();
        }
        return this.q;
    }

    public E n(int i2) {
        if (this.n) {
            e();
        }
        return (E) this.p[i2];
    }

    public String toString() {
        if (m() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.q * 28);
        sb.append('{');
        for (int i2 = 0; i2 < this.q; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            sb.append(i(i2));
            sb.append('=');
            E n = n(i2);
            if (n != this) {
                sb.append(n);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
