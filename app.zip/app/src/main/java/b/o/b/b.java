package b.o.b;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import b.g.k.h;

/* loaded from: classes.dex */
public class b extends Drawable implements Animatable {
    private static final Interpolator t = new LinearInterpolator();
    private static final Interpolator u = new b.k.a.a.b();
    private static final int[] v = {-16777216};
    private final c n;
    private float o;
    private Resources p;
    private Animator q;
    float r;
    boolean s;

    class a implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ c f1369a;

        a(c cVar) {
            this.f1369a = cVar;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            b.this.n(floatValue, this.f1369a);
            b.this.b(floatValue, this.f1369a, false);
            b.this.invalidateSelf();
        }
    }

    /* renamed from: b.o.b.b$b, reason: collision with other inner class name */
    class C0054b implements Animator.AnimatorListener {

        /* renamed from: a, reason: collision with root package name */
        final /* synthetic */ c f1371a;

        C0054b(c cVar) {
            this.f1371a = cVar;
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(Animator animator) {
            b.this.b(1.0f, this.f1371a, true);
            this.f1371a.A();
            this.f1371a.l();
            b bVar = b.this;
            if (!bVar.s) {
                bVar.r += 1.0f;
                return;
            }
            bVar.s = false;
            animator.cancel();
            animator.setDuration(1332L);
            animator.start();
            this.f1371a.x(false);
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            b.this.r = 0.0f;
        }
    }

    private static class c {

        /* renamed from: a, reason: collision with root package name */
        final RectF f1373a = new RectF();

        /* renamed from: b, reason: collision with root package name */
        final Paint f1374b;

        /* renamed from: c, reason: collision with root package name */
        final Paint f1375c;

        /* renamed from: d, reason: collision with root package name */
        final Paint f1376d;

        /* renamed from: e, reason: collision with root package name */
        float f1377e;

        /* renamed from: f, reason: collision with root package name */
        float f1378f;

        /* renamed from: g, reason: collision with root package name */
        float f1379g;

        /* renamed from: h, reason: collision with root package name */
        float f1380h;

        /* renamed from: i, reason: collision with root package name */
        int[] f1381i;

        /* renamed from: j, reason: collision with root package name */
        int f1382j;

        /* renamed from: k, reason: collision with root package name */
        float f1383k;
        float l;
        float m;
        boolean n;
        Path o;
        float p;
        float q;
        int r;
        int s;
        int t;
        int u;

        c() {
            Paint paint = new Paint();
            this.f1374b = paint;
            Paint paint2 = new Paint();
            this.f1375c = paint2;
            Paint paint3 = new Paint();
            this.f1376d = paint3;
            this.f1377e = 0.0f;
            this.f1378f = 0.0f;
            this.f1379g = 0.0f;
            this.f1380h = 5.0f;
            this.p = 1.0f;
            this.t = 255;
            paint.setStrokeCap(Paint.Cap.SQUARE);
            paint.setAntiAlias(true);
            paint.setStyle(Paint.Style.STROKE);
            paint2.setStyle(Paint.Style.FILL);
            paint2.setAntiAlias(true);
            paint3.setColor(0);
        }

        void A() {
            this.f1383k = this.f1377e;
            this.l = this.f1378f;
            this.m = this.f1379g;
        }

        void a(Canvas canvas, Rect rect) {
            RectF rectF = this.f1373a;
            float f2 = this.q;
            float f3 = (this.f1380h / 2.0f) + f2;
            if (f2 <= 0.0f) {
                f3 = (Math.min(rect.width(), rect.height()) / 2.0f) - Math.max((this.r * this.p) / 2.0f, this.f1380h / 2.0f);
            }
            rectF.set(rect.centerX() - f3, rect.centerY() - f3, rect.centerX() + f3, rect.centerY() + f3);
            float f4 = this.f1377e;
            float f5 = this.f1379g;
            float f6 = (f4 + f5) * 360.0f;
            float f7 = ((this.f1378f + f5) * 360.0f) - f6;
            this.f1374b.setColor(this.u);
            this.f1374b.setAlpha(this.t);
            float f8 = this.f1380h / 2.0f;
            rectF.inset(f8, f8);
            canvas.drawCircle(rectF.centerX(), rectF.centerY(), rectF.width() / 2.0f, this.f1376d);
            float f9 = -f8;
            rectF.inset(f9, f9);
            canvas.drawArc(rectF, f6, f7, false, this.f1374b);
            b(canvas, f6, f7, rectF);
        }

        void b(Canvas canvas, float f2, float f3, RectF rectF) {
            if (this.n) {
                Path path = this.o;
                if (path == null) {
                    Path path2 = new Path();
                    this.o = path2;
                    path2.setFillType(Path.FillType.EVEN_ODD);
                } else {
                    path.reset();
                }
                float min = Math.min(rectF.width(), rectF.height()) / 2.0f;
                float f4 = (this.r * this.p) / 2.0f;
                this.o.moveTo(0.0f, 0.0f);
                this.o.lineTo(this.r * this.p, 0.0f);
                Path path3 = this.o;
                float f5 = this.r;
                float f6 = this.p;
                path3.lineTo((f5 * f6) / 2.0f, this.s * f6);
                this.o.offset((min + rectF.centerX()) - f4, rectF.centerY() + (this.f1380h / 2.0f));
                this.o.close();
                this.f1375c.setColor(this.u);
                this.f1375c.setAlpha(this.t);
                canvas.save();
                canvas.rotate(f2 + f3, rectF.centerX(), rectF.centerY());
                canvas.drawPath(this.o, this.f1375c);
                canvas.restore();
            }
        }

        int c() {
            return this.t;
        }

        float d() {
            return this.f1378f;
        }

        int e() {
            return this.f1381i[f()];
        }

        int f() {
            return (this.f1382j + 1) % this.f1381i.length;
        }

        float g() {
            return this.f1377e;
        }

        int h() {
            return this.f1381i[this.f1382j];
        }

        float i() {
            return this.l;
        }

        float j() {
            return this.m;
        }

        float k() {
            return this.f1383k;
        }

        void l() {
            t(f());
        }

        void m() {
            this.f1383k = 0.0f;
            this.l = 0.0f;
            this.m = 0.0f;
            y(0.0f);
            v(0.0f);
            w(0.0f);
        }

        void n(int i2) {
            this.t = i2;
        }

        void o(float f2, float f3) {
            this.r = (int) f2;
            this.s = (int) f3;
        }

        void p(float f2) {
            if (f2 != this.p) {
                this.p = f2;
            }
        }

        void q(float f2) {
            this.q = f2;
        }

        void r(int i2) {
            this.u = i2;
        }

        void s(ColorFilter colorFilter) {
            this.f1374b.setColorFilter(colorFilter);
        }

        void t(int i2) {
            this.f1382j = i2;
            this.u = this.f1381i[i2];
        }

        void u(int[] iArr) {
            this.f1381i = iArr;
            t(0);
        }

        void v(float f2) {
            this.f1378f = f2;
        }

        void w(float f2) {
            this.f1379g = f2;
        }

        void x(boolean z) {
            if (this.n != z) {
                this.n = z;
            }
        }

        void y(float f2) {
            this.f1377e = f2;
        }

        void z(float f2) {
            this.f1380h = f2;
            this.f1374b.setStrokeWidth(f2);
        }
    }

    public b(Context context) {
        h.b(context);
        this.p = context.getResources();
        c cVar = new c();
        this.n = cVar;
        cVar.u(v);
        k(2.5f);
        m();
    }

    private void a(float f2, c cVar) {
        n(f2, cVar);
        float floor = (float) (Math.floor(cVar.j() / 0.8f) + 1.0d);
        cVar.y(cVar.k() + (((cVar.i() - 0.01f) - cVar.k()) * f2));
        cVar.v(cVar.i());
        cVar.w(cVar.j() + ((floor - cVar.j()) * f2));
    }

    private int c(float f2, int i2, int i3) {
        return ((((i2 >> 24) & 255) + ((int) ((((i3 >> 24) & 255) - r0) * f2))) << 24) | ((((i2 >> 16) & 255) + ((int) ((((i3 >> 16) & 255) - r1) * f2))) << 16) | ((((i2 >> 8) & 255) + ((int) ((((i3 >> 8) & 255) - r2) * f2))) << 8) | ((i2 & 255) + ((int) (f2 * ((i3 & 255) - r8))));
    }

    private void h(float f2) {
        this.o = f2;
    }

    private void i(float f2, float f3, float f4, float f5) {
        c cVar = this.n;
        float f6 = this.p.getDisplayMetrics().density;
        cVar.z(f3 * f6);
        cVar.q(f2 * f6);
        cVar.t(0);
        cVar.o(f4 * f6, f5 * f6);
    }

    private void m() {
        c cVar = this.n;
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        ofFloat.addUpdateListener(new a(cVar));
        ofFloat.setRepeatCount(-1);
        ofFloat.setRepeatMode(1);
        ofFloat.setInterpolator(t);
        ofFloat.addListener(new C0054b(cVar));
        this.q = ofFloat;
    }

    void b(float f2, c cVar, boolean z) {
        float interpolation;
        float f3;
        if (this.s) {
            a(f2, cVar);
            return;
        }
        if (f2 != 1.0f || z) {
            float j2 = cVar.j();
            if (f2 < 0.5f) {
                interpolation = cVar.k();
                f3 = (u.getInterpolation(f2 / 0.5f) * 0.79f) + 0.01f + interpolation;
            } else {
                float k2 = cVar.k() + 0.79f;
                interpolation = k2 - (((1.0f - u.getInterpolation((f2 - 0.5f) / 0.5f)) * 0.79f) + 0.01f);
                f3 = k2;
            }
            float f4 = j2 + (0.20999998f * f2);
            float f5 = (f2 + this.r) * 216.0f;
            cVar.y(interpolation);
            cVar.v(f3);
            cVar.w(f4);
            h(f5);
        }
    }

    public void d(boolean z) {
        this.n.x(z);
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Rect bounds = getBounds();
        canvas.save();
        canvas.rotate(this.o, bounds.exactCenterX(), bounds.exactCenterY());
        this.n.a(canvas, bounds);
        canvas.restore();
    }

    public void e(float f2) {
        this.n.p(f2);
        invalidateSelf();
    }

    public void f(int... iArr) {
        this.n.u(iArr);
        this.n.t(0);
        invalidateSelf();
    }

    public void g(float f2) {
        this.n.w(f2);
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        return this.n.c();
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Animatable
    public boolean isRunning() {
        return this.q.isRunning();
    }

    public void j(float f2, float f3) {
        this.n.y(f2);
        this.n.v(f3);
        invalidateSelf();
    }

    public void k(float f2) {
        this.n.z(f2);
        invalidateSelf();
    }

    public void l(int i2) {
        float f2;
        float f3;
        float f4;
        float f5;
        if (i2 == 0) {
            f2 = 11.0f;
            f3 = 3.0f;
            f4 = 12.0f;
            f5 = 6.0f;
        } else {
            f2 = 7.5f;
            f3 = 2.5f;
            f4 = 10.0f;
            f5 = 5.0f;
        }
        i(f2, f3, f4, f5);
        invalidateSelf();
    }

    void n(float f2, c cVar) {
        cVar.r(f2 > 0.75f ? c((f2 - 0.75f) / 0.25f, cVar.h(), cVar.e()) : cVar.h());
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        this.n.n(i2);
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        this.n.s(colorFilter);
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Animatable
    public void start() {
        Animator animator;
        long j2;
        this.q.cancel();
        this.n.A();
        if (this.n.d() != this.n.g()) {
            this.s = true;
            animator = this.q;
            j2 = 666;
        } else {
            this.n.t(0);
            this.n.m();
            animator = this.q;
            j2 = 1332;
        }
        animator.setDuration(j2);
        this.q.start();
    }

    @Override // android.graphics.drawable.Animatable
    public void stop() {
        this.q.cancel();
        h(0.0f);
        this.n.x(false);
        this.n.t(0);
        this.n.m();
        invalidateSelf();
    }
}
