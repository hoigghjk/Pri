package b.d.f;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;

/* loaded from: classes.dex */
class c implements f {
    c() {
    }

    private g o(e eVar) {
        return (g) eVar.g();
    }

    @Override // b.d.f.f
    public float a(e eVar) {
        return o(eVar).c();
    }

    @Override // b.d.f.f
    public ColorStateList b(e eVar) {
        return o(eVar).b();
    }

    @Override // b.d.f.f
    public void c(e eVar, Context context, ColorStateList colorStateList, float f2, float f3, float f4) {
        eVar.d(new g(colorStateList, f2));
        View a2 = eVar.a();
        a2.setClipToOutline(true);
        a2.setElevation(f3);
        n(eVar, f4);
    }

    @Override // b.d.f.f
    public void d(e eVar, float f2) {
        o(eVar).h(f2);
    }

    @Override // b.d.f.f
    public float e(e eVar) {
        return eVar.a().getElevation();
    }

    @Override // b.d.f.f
    public void f() {
    }

    @Override // b.d.f.f
    public float g(e eVar) {
        return o(eVar).d();
    }

    @Override // b.d.f.f
    public float h(e eVar) {
        return g(eVar) * 2.0f;
    }

    @Override // b.d.f.f
    public float i(e eVar) {
        return g(eVar) * 2.0f;
    }

    @Override // b.d.f.f
    public void j(e eVar) {
        n(eVar, a(eVar));
    }

    @Override // b.d.f.f
    public void k(e eVar, float f2) {
        eVar.a().setElevation(f2);
    }

    @Override // b.d.f.f
    public void l(e eVar) {
        n(eVar, a(eVar));
    }

    @Override // b.d.f.f
    public void m(e eVar, ColorStateList colorStateList) {
        o(eVar).f(colorStateList);
    }

    @Override // b.d.f.f
    public void n(e eVar, float f2) {
        o(eVar).g(f2, eVar.f(), eVar.e());
        p(eVar);
    }

    public void p(e eVar) {
        if (!eVar.f()) {
            eVar.b(0, 0, 0, 0);
            return;
        }
        float a2 = a(eVar);
        float g2 = g(eVar);
        int ceil = (int) Math.ceil(h.c(a2, g2, eVar.e()));
        int ceil2 = (int) Math.ceil(h.d(a2, g2, eVar.e()));
        eVar.b(ceil, ceil2, ceil, ceil2);
    }
}
