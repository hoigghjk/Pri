package b.d.f;

import android.content.Context;
import android.content.res.ColorStateList;

/* loaded from: classes.dex */
interface f {
    float a(e eVar);

    ColorStateList b(e eVar);

    void c(e eVar, Context context, ColorStateList colorStateList, float f2, float f3, float f4);

    void d(e eVar, float f2);

    float e(e eVar);

    void f();

    float g(e eVar);

    float h(e eVar);

    float i(e eVar);

    void j(e eVar);

    void k(e eVar, float f2);

    void l(e eVar);

    void m(e eVar, ColorStateList colorStateList);

    void n(e eVar, float f2);
}
