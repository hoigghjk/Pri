package b.d.f;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import b.d.f.h;

/* loaded from: classes.dex */
class b extends d {

    class a implements h.a {
        a(b bVar) {
        }

        @Override // b.d.f.h.a
        public void a(Canvas canvas, RectF rectF, float f2, Paint paint) {
            canvas.drawRoundRect(rectF, f2, f2, paint);
        }
    }

    b() {
    }

    @Override // b.d.f.d, b.d.f.f
    public void f() {
        h.r = new a(this);
    }
}
