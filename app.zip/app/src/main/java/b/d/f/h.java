package b.d.f;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/* loaded from: classes.dex */
class h extends Drawable {
    private static final double q = Math.cos(Math.toRadians(45.0d));
    static a r;

    /* renamed from: a, reason: collision with root package name */
    private final int f940a;

    /* renamed from: c, reason: collision with root package name */
    private Paint f942c;

    /* renamed from: d, reason: collision with root package name */
    private Paint f943d;

    /* renamed from: e, reason: collision with root package name */
    private final RectF f944e;

    /* renamed from: f, reason: collision with root package name */
    private float f945f;

    /* renamed from: g, reason: collision with root package name */
    private Path f946g;

    /* renamed from: h, reason: collision with root package name */
    private float f947h;

    /* renamed from: i, reason: collision with root package name */
    private float f948i;

    /* renamed from: j, reason: collision with root package name */
    private float f949j;

    /* renamed from: k, reason: collision with root package name */
    private ColorStateList f950k;
    private final int m;
    private final int n;
    private boolean l = true;
    private boolean o = true;
    private boolean p = false;

    /* renamed from: b, reason: collision with root package name */
    private Paint f941b = new Paint(5);

    interface a {
        void a(Canvas canvas, RectF rectF, float f2, Paint paint);
    }

    h(Resources resources, ColorStateList colorStateList, float f2, float f3, float f4) {
        this.m = resources.getColor(b.d.b.f911d);
        this.n = resources.getColor(b.d.b.f910c);
        this.f940a = resources.getDimensionPixelSize(b.d.c.f912a);
        n(colorStateList);
        Paint paint = new Paint(5);
        this.f942c = paint;
        paint.setStyle(Paint.Style.FILL);
        this.f945f = (int) (f2 + 0.5f);
        this.f944e = new RectF();
        Paint paint2 = new Paint(this.f942c);
        this.f943d = paint2;
        paint2.setAntiAlias(false);
        s(f3, f4);
    }

    private void a(Rect rect) {
        float f2 = this.f947h;
        float f3 = 1.5f * f2;
        this.f944e.set(rect.left + f2, rect.top + f3, rect.right - f2, rect.bottom - f3);
        b();
    }

    private void b() {
        float f2 = this.f945f;
        RectF rectF = new RectF(-f2, -f2, f2, f2);
        RectF rectF2 = new RectF(rectF);
        float f3 = this.f948i;
        rectF2.inset(-f3, -f3);
        Path path = this.f946g;
        if (path == null) {
            this.f946g = new Path();
        } else {
            path.reset();
        }
        this.f946g.setFillType(Path.FillType.EVEN_ODD);
        this.f946g.moveTo(-this.f945f, 0.0f);
        this.f946g.rLineTo(-this.f948i, 0.0f);
        this.f946g.arcTo(rectF2, 180.0f, 90.0f, false);
        this.f946g.arcTo(rectF, 270.0f, -90.0f, false);
        this.f946g.close();
        float f4 = this.f945f;
        float f5 = f4 / (this.f948i + f4);
        Paint paint = this.f942c;
        float f6 = this.f945f + this.f948i;
        int i2 = this.m;
        paint.setShader(new RadialGradient(0.0f, 0.0f, f6, new int[]{i2, i2, this.n}, new float[]{0.0f, f5, 1.0f}, Shader.TileMode.CLAMP));
        Paint paint2 = this.f943d;
        float f7 = this.f945f;
        float f8 = this.f948i;
        int i3 = this.m;
        paint2.setShader(new LinearGradient(0.0f, (-f7) + f8, 0.0f, (-f7) - f8, new int[]{i3, i3, this.n}, new float[]{0.0f, 0.5f, 1.0f}, Shader.TileMode.CLAMP));
        this.f943d.setAntiAlias(false);
    }

    static float c(float f2, float f3, boolean z) {
        return z ? (float) (f2 + ((1.0d - q) * f3)) : f2;
    }

    static float d(float f2, float f3, boolean z) {
        float f4 = f2 * 1.5f;
        return z ? (float) (f4 + ((1.0d - q) * f3)) : f4;
    }

    private void e(Canvas canvas) {
        float f2 = this.f945f;
        float f3 = (-f2) - this.f948i;
        float f4 = f2 + this.f940a + (this.f949j / 2.0f);
        float f5 = f4 * 2.0f;
        boolean z = this.f944e.width() - f5 > 0.0f;
        boolean z2 = this.f944e.height() - f5 > 0.0f;
        int save = canvas.save();
        RectF rectF = this.f944e;
        canvas.translate(rectF.left + f4, rectF.top + f4);
        canvas.drawPath(this.f946g, this.f942c);
        if (z) {
            canvas.drawRect(0.0f, f3, this.f944e.width() - f5, -this.f945f, this.f943d);
        }
        canvas.restoreToCount(save);
        int save2 = canvas.save();
        RectF rectF2 = this.f944e;
        canvas.translate(rectF2.right - f4, rectF2.bottom - f4);
        canvas.rotate(180.0f);
        canvas.drawPath(this.f946g, this.f942c);
        if (z) {
            canvas.drawRect(0.0f, f3, this.f944e.width() - f5, (-this.f945f) + this.f948i, this.f943d);
        }
        canvas.restoreToCount(save2);
        int save3 = canvas.save();
        RectF rectF3 = this.f944e;
        canvas.translate(rectF3.left + f4, rectF3.bottom - f4);
        canvas.rotate(270.0f);
        canvas.drawPath(this.f946g, this.f942c);
        if (z2) {
            canvas.drawRect(0.0f, f3, this.f944e.height() - f5, -this.f945f, this.f943d);
        }
        canvas.restoreToCount(save3);
        int save4 = canvas.save();
        RectF rectF4 = this.f944e;
        canvas.translate(rectF4.right - f4, rectF4.top + f4);
        canvas.rotate(90.0f);
        canvas.drawPath(this.f946g, this.f942c);
        if (z2) {
            canvas.drawRect(0.0f, f3, this.f944e.height() - f5, -this.f945f, this.f943d);
        }
        canvas.restoreToCount(save4);
    }

    private void n(ColorStateList colorStateList) {
        if (colorStateList == null) {
            colorStateList = ColorStateList.valueOf(0);
        }
        this.f950k = colorStateList;
        this.f941b.setColor(colorStateList.getColorForState(getState(), this.f950k.getDefaultColor()));
    }

    private void s(float f2, float f3) {
        if (f2 < 0.0f) {
            throw new IllegalArgumentException("Invalid shadow size " + f2 + ". Must be >= 0");
        }
        if (f3 < 0.0f) {
            throw new IllegalArgumentException("Invalid max shadow size " + f3 + ". Must be >= 0");
        }
        float t = t(f2);
        float t2 = t(f3);
        if (t > t2) {
            if (!this.p) {
                this.p = true;
            }
            t = t2;
        }
        if (this.f949j == t && this.f947h == t2) {
            return;
        }
        this.f949j = t;
        this.f947h = t2;
        this.f948i = (int) ((t * 1.5f) + this.f940a + 0.5f);
        this.l = true;
        invalidateSelf();
    }

    private int t(float f2) {
        int i2 = (int) (f2 + 0.5f);
        return i2 % 2 == 1 ? i2 - 1 : i2;
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        if (this.l) {
            a(getBounds());
            this.l = false;
        }
        canvas.translate(0.0f, this.f949j / 2.0f);
        e(canvas);
        canvas.translate(0.0f, (-this.f949j) / 2.0f);
        r.a(canvas, this.f944e, this.f945f, this.f941b);
    }

    ColorStateList f() {
        return this.f950k;
    }

    float g() {
        return this.f945f;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean getPadding(Rect rect) {
        int ceil = (int) Math.ceil(d(this.f947h, this.f945f, this.o));
        int ceil2 = (int) Math.ceil(c(this.f947h, this.f945f, this.o));
        rect.set(ceil2, ceil, ceil2, ceil);
        return true;
    }

    void h(Rect rect) {
        getPadding(rect);
    }

    float i() {
        return this.f947h;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        ColorStateList colorStateList = this.f950k;
        return (colorStateList != null && colorStateList.isStateful()) || super.isStateful();
    }

    float j() {
        float f2 = this.f947h;
        return (Math.max(f2, this.f945f + this.f940a + ((f2 * 1.5f) / 2.0f)) * 2.0f) + (((this.f947h * 1.5f) + this.f940a) * 2.0f);
    }

    float k() {
        float f2 = this.f947h;
        return (Math.max(f2, this.f945f + this.f940a + (f2 / 2.0f)) * 2.0f) + ((this.f947h + this.f940a) * 2.0f);
    }

    float l() {
        return this.f949j;
    }

    void m(boolean z) {
        this.o = z;
        invalidateSelf();
    }

    void o(ColorStateList colorStateList) {
        n(colorStateList);
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    protected void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        this.l = true;
    }

    @Override // android.graphics.drawable.Drawable
    protected boolean onStateChange(int[] iArr) {
        ColorStateList colorStateList = this.f950k;
        int colorForState = colorStateList.getColorForState(iArr, colorStateList.getDefaultColor());
        if (this.f941b.getColor() == colorForState) {
            return false;
        }
        this.f941b.setColor(colorForState);
        this.l = true;
        invalidateSelf();
        return true;
    }

    void p(float f2) {
        if (f2 < 0.0f) {
            throw new IllegalArgumentException("Invalid radius " + f2 + ". Must be >= 0");
        }
        float f3 = (int) (f2 + 0.5f);
        if (this.f945f == f3) {
            return;
        }
        this.f945f = f3;
        this.l = true;
        invalidateSelf();
    }

    void q(float f2) {
        s(this.f949j, f2);
    }

    void r(float f2) {
        s(f2, this.f947h);
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        this.f941b.setAlpha(i2);
        this.f942c.setAlpha(i2);
        this.f943d.setAlpha(i2);
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        this.f941b.setColorFilter(colorFilter);
    }
}
