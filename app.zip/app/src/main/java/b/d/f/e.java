package b.d.f;

import android.graphics.drawable.Drawable;
import android.view.View;

/* loaded from: classes.dex */
interface e {
    View a();

    void b(int i2, int i3, int i4, int i5);

    void c(int i2, int i3);

    void d(Drawable drawable);

    boolean e();

    boolean f();

    Drawable g();
}
