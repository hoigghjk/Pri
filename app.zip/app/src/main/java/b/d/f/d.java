package b.d.f;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import b.d.f.h;

/* loaded from: classes.dex */
class d implements f {

    /* renamed from: a, reason: collision with root package name */
    final RectF f927a = new RectF();

    class a implements h.a {
        a() {
        }

        @Override // b.d.f.h.a
        public void a(Canvas canvas, RectF rectF, float f2, Paint paint) {
            float f3 = 2.0f * f2;
            float width = (rectF.width() - f3) - 1.0f;
            float height = (rectF.height() - f3) - 1.0f;
            if (f2 >= 1.0f) {
                float f4 = f2 + 0.5f;
                float f5 = -f4;
                d.this.f927a.set(f5, f5, f4, f4);
                int save = canvas.save();
                canvas.translate(rectF.left + f4, rectF.top + f4);
                canvas.drawArc(d.this.f927a, 180.0f, 90.0f, true, paint);
                canvas.translate(width, 0.0f);
                canvas.rotate(90.0f);
                canvas.drawArc(d.this.f927a, 180.0f, 90.0f, true, paint);
                canvas.translate(height, 0.0f);
                canvas.rotate(90.0f);
                canvas.drawArc(d.this.f927a, 180.0f, 90.0f, true, paint);
                canvas.translate(width, 0.0f);
                canvas.rotate(90.0f);
                canvas.drawArc(d.this.f927a, 180.0f, 90.0f, true, paint);
                canvas.restoreToCount(save);
                float f6 = (rectF.left + f4) - 1.0f;
                float f7 = rectF.top;
                canvas.drawRect(f6, f7, (rectF.right - f4) + 1.0f, f7 + f4, paint);
                float f8 = (rectF.left + f4) - 1.0f;
                float f9 = rectF.bottom;
                canvas.drawRect(f8, f9 - f4, (rectF.right - f4) + 1.0f, f9, paint);
            }
            canvas.drawRect(rectF.left, rectF.top + f2, rectF.right, rectF.bottom - f2, paint);
        }
    }

    d() {
    }

    private h o(Context context, ColorStateList colorStateList, float f2, float f3, float f4) {
        return new h(context.getResources(), colorStateList, f2, f3, f4);
    }

    private h p(e eVar) {
        return (h) eVar.g();
    }

    @Override // b.d.f.f
    public float a(e eVar) {
        return p(eVar).i();
    }

    @Override // b.d.f.f
    public ColorStateList b(e eVar) {
        return p(eVar).f();
    }

    @Override // b.d.f.f
    public void c(e eVar, Context context, ColorStateList colorStateList, float f2, float f3, float f4) {
        h o = o(context, colorStateList, f2, f3, f4);
        o.m(eVar.e());
        eVar.d(o);
        q(eVar);
    }

    @Override // b.d.f.f
    public void d(e eVar, float f2) {
        p(eVar).p(f2);
        q(eVar);
    }

    @Override // b.d.f.f
    public float e(e eVar) {
        return p(eVar).l();
    }

    @Override // b.d.f.f
    public void f() {
        h.r = new a();
    }

    @Override // b.d.f.f
    public float g(e eVar) {
        return p(eVar).g();
    }

    @Override // b.d.f.f
    public float h(e eVar) {
        return p(eVar).j();
    }

    @Override // b.d.f.f
    public float i(e eVar) {
        return p(eVar).k();
    }

    @Override // b.d.f.f
    public void j(e eVar) {
    }

    @Override // b.d.f.f
    public void k(e eVar, float f2) {
        p(eVar).r(f2);
    }

    @Override // b.d.f.f
    public void l(e eVar) {
        p(eVar).m(eVar.e());
        q(eVar);
    }

    @Override // b.d.f.f
    public void m(e eVar, ColorStateList colorStateList) {
        p(eVar).o(colorStateList);
    }

    @Override // b.d.f.f
    public void n(e eVar, float f2) {
        p(eVar).q(f2);
        q(eVar);
    }

    public void q(e eVar) {
        Rect rect = new Rect();
        p(eVar).h(rect);
        eVar.c((int) Math.ceil(i(eVar)), (int) Math.ceil(h(eVar)));
        eVar.b(rect.left, rect.top, rect.right, rect.bottom);
    }
}
