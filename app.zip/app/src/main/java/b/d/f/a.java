package b.d.f;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

/* loaded from: classes.dex */
public class a extends FrameLayout {
    private static final int[] u = {R.attr.colorBackground};
    private static final f v;
    private boolean n;
    private boolean o;
    int p;
    int q;
    final Rect r;
    final Rect s;
    private final e t;

    /* renamed from: b.d.f.a$a, reason: collision with other inner class name */
    class C0031a implements e {

        /* renamed from: a, reason: collision with root package name */
        private Drawable f925a;

        C0031a() {
        }

        @Override // b.d.f.e
        public View a() {
            return a.this;
        }

        @Override // b.d.f.e
        public void b(int i2, int i3, int i4, int i5) {
            a.this.s.set(i2, i3, i4, i5);
            a aVar = a.this;
            Rect rect = aVar.r;
            a.super.setPadding(i2 + rect.left, i3 + rect.top, i4 + rect.right, i5 + rect.bottom);
        }

        @Override // b.d.f.e
        public void c(int i2, int i3) {
            a aVar = a.this;
            if (i2 > aVar.p) {
                a.super.setMinimumWidth(i2);
            }
            a aVar2 = a.this;
            if (i3 > aVar2.q) {
                a.super.setMinimumHeight(i3);
            }
        }

        @Override // b.d.f.e
        public void d(Drawable drawable) {
            this.f925a = drawable;
            a.this.setBackgroundDrawable(drawable);
        }

        @Override // b.d.f.e
        public boolean e() {
            return a.this.getPreventCornerOverlap();
        }

        @Override // b.d.f.e
        public boolean f() {
            return a.this.getUseCompatPadding();
        }

        @Override // b.d.f.e
        public Drawable g() {
            return this.f925a;
        }
    }

    static {
        int i2 = Build.VERSION.SDK_INT;
        v = i2 >= 21 ? new c() : i2 >= 17 ? new b() : new d();
        v.f();
    }

    public a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b.d.a.f907a);
    }

    public a(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        Resources resources;
        int i3;
        ColorStateList valueOf;
        Rect rect = new Rect();
        this.r = rect;
        this.s = new Rect();
        C0031a c0031a = new C0031a();
        this.t = c0031a;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.d.e.f914a, i2, b.d.d.f913a);
        int i4 = b.d.e.f917d;
        if (obtainStyledAttributes.hasValue(i4)) {
            valueOf = obtainStyledAttributes.getColorStateList(i4);
        } else {
            TypedArray obtainStyledAttributes2 = getContext().obtainStyledAttributes(u);
            int color = obtainStyledAttributes2.getColor(0, 0);
            obtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            if (fArr[2] > 0.5f) {
                resources = getResources();
                i3 = b.d.b.f909b;
            } else {
                resources = getResources();
                i3 = b.d.b.f908a;
            }
            valueOf = ColorStateList.valueOf(resources.getColor(i3));
        }
        ColorStateList colorStateList = valueOf;
        float dimension = obtainStyledAttributes.getDimension(b.d.e.f918e, 0.0f);
        float dimension2 = obtainStyledAttributes.getDimension(b.d.e.f919f, 0.0f);
        float dimension3 = obtainStyledAttributes.getDimension(b.d.e.f920g, 0.0f);
        this.n = obtainStyledAttributes.getBoolean(b.d.e.f922i, false);
        this.o = obtainStyledAttributes.getBoolean(b.d.e.f921h, true);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(b.d.e.f923j, 0);
        rect.left = obtainStyledAttributes.getDimensionPixelSize(b.d.e.l, dimensionPixelSize);
        rect.top = obtainStyledAttributes.getDimensionPixelSize(b.d.e.n, dimensionPixelSize);
        rect.right = obtainStyledAttributes.getDimensionPixelSize(b.d.e.m, dimensionPixelSize);
        rect.bottom = obtainStyledAttributes.getDimensionPixelSize(b.d.e.f924k, dimensionPixelSize);
        float f2 = dimension2 > dimension3 ? dimension2 : dimension3;
        this.p = obtainStyledAttributes.getDimensionPixelSize(b.d.e.f915b, 0);
        this.q = obtainStyledAttributes.getDimensionPixelSize(b.d.e.f916c, 0);
        obtainStyledAttributes.recycle();
        v.c(c0031a, context, colorStateList, dimension, dimension2, f2);
    }

    public ColorStateList getCardBackgroundColor() {
        return v.b(this.t);
    }

    public float getCardElevation() {
        return v.e(this.t);
    }

    public int getContentPaddingBottom() {
        return this.r.bottom;
    }

    public int getContentPaddingLeft() {
        return this.r.left;
    }

    public int getContentPaddingRight() {
        return this.r.right;
    }

    public int getContentPaddingTop() {
        return this.r.top;
    }

    public float getMaxCardElevation() {
        return v.a(this.t);
    }

    public boolean getPreventCornerOverlap() {
        return this.o;
    }

    public float getRadius() {
        return v.g(this.t);
    }

    public boolean getUseCompatPadding() {
        return this.n;
    }

    @Override // android.widget.FrameLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        if (!(v instanceof c)) {
            int mode = View.MeasureSpec.getMode(i2);
            if (mode == Integer.MIN_VALUE || mode == 1073741824) {
                i2 = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil(r0.i(this.t)), View.MeasureSpec.getSize(i2)), mode);
            }
            int mode2 = View.MeasureSpec.getMode(i3);
            if (mode2 == Integer.MIN_VALUE || mode2 == 1073741824) {
                i3 = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil(r0.h(this.t)), View.MeasureSpec.getSize(i3)), mode2);
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCardBackgroundColor(int i2) {
        v.m(this.t, ColorStateList.valueOf(i2));
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        v.m(this.t, colorStateList);
    }

    public void setCardElevation(float f2) {
        v.k(this.t, f2);
    }

    public void setMaxCardElevation(float f2) {
        v.n(this.t, f2);
    }

    @Override // android.view.View
    public void setMinimumHeight(int i2) {
        this.q = i2;
        super.setMinimumHeight(i2);
    }

    @Override // android.view.View
    public void setMinimumWidth(int i2) {
        this.p = i2;
        super.setMinimumWidth(i2);
    }

    @Override // android.view.View
    public void setPadding(int i2, int i3, int i4, int i5) {
    }

    @Override // android.view.View
    public void setPaddingRelative(int i2, int i3, int i4, int i5) {
    }

    public void setPreventCornerOverlap(boolean z) {
        if (z != this.o) {
            this.o = z;
            v.l(this.t);
        }
    }

    public void setRadius(float f2) {
        v.d(this.t, f2);
    }

    public void setUseCompatPadding(boolean z) {
        if (this.n != z) {
            this.n = z;
            v.j(this.t);
        }
    }
}
