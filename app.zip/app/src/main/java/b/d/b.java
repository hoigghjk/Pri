package b.d;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public static final int f908a = 2130968621;

    /* renamed from: b, reason: collision with root package name */
    public static final int f909b = 2130968622;

    /* renamed from: c, reason: collision with root package name */
    public static final int f910c = 2130968623;

    /* renamed from: d, reason: collision with root package name */
    public static final int f911d = 2130968624;
}
