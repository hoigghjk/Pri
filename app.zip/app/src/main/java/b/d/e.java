package b.d;

import android.R;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f914a = {R.attr.minWidth, R.attr.minHeight, com.pichillilorenzo.flutter_inappwebview.R.attr.cardBackgroundColor, com.pichillilorenzo.flutter_inappwebview.R.attr.cardCornerRadius, com.pichillilorenzo.flutter_inappwebview.R.attr.cardElevation, com.pichillilorenzo.flutter_inappwebview.R.attr.cardMaxElevation, com.pichillilorenzo.flutter_inappwebview.R.attr.cardPreventCornerOverlap, com.pichillilorenzo.flutter_inappwebview.R.attr.cardUseCompatPadding, com.pichillilorenzo.flutter_inappwebview.R.attr.contentPadding, com.pichillilorenzo.flutter_inappwebview.R.attr.contentPaddingBottom, com.pichillilorenzo.flutter_inappwebview.R.attr.contentPaddingLeft, com.pichillilorenzo.flutter_inappwebview.R.attr.contentPaddingRight, com.pichillilorenzo.flutter_inappwebview.R.attr.contentPaddingTop};

    /* renamed from: b, reason: collision with root package name */
    public static final int f915b = 0;

    /* renamed from: c, reason: collision with root package name */
    public static final int f916c = 1;

    /* renamed from: d, reason: collision with root package name */
    public static final int f917d = 2;

    /* renamed from: e, reason: collision with root package name */
    public static final int f918e = 3;

    /* renamed from: f, reason: collision with root package name */
    public static final int f919f = 4;

    /* renamed from: g, reason: collision with root package name */
    public static final int f920g = 5;

    /* renamed from: h, reason: collision with root package name */
    public static final int f921h = 6;

    /* renamed from: i, reason: collision with root package name */
    public static final int f922i = 7;

    /* renamed from: j, reason: collision with root package name */
    public static final int f923j = 8;

    /* renamed from: k, reason: collision with root package name */
    public static final int f924k = 9;
    public static final int l = 10;
    public static final int m = 11;
    public static final int n = 12;
}
