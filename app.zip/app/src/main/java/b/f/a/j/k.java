package b.f.a.j;

import b.f.a.j.f;

/* loaded from: classes.dex */
public class k {

    /* renamed from: a, reason: collision with root package name */
    static boolean[] f1067a = new boolean[3];

    /* JADX WARN: Code restructure failed: missing block: B:23:0x006f, code lost:
    
        if (r6 != false) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x00ec, code lost:
    
        r3.i(r1, r7);
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00df, code lost:
    
        r3.j(r1, 1, r17.x());
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x007b, code lost:
    
        if (r6 != false) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0086, code lost:
    
        if (r6 != false) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00dd, code lost:
    
        if (r6 != false) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x00e8, code lost:
    
        r7 = r17.D();
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x00ff, code lost:
    
        if (r6 != false) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:89:0x01aa, code lost:
    
        if (r6 != false) goto L100;
     */
    /* JADX WARN: Code restructure failed: missing block: B:90:0x01ac, code lost:
    
        r4.j(r2, 1, r17.w());
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x01b5, code lost:
    
        r4.i(r2, r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:94:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x01c2, code lost:
    
        if (r6 != false) goto L100;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    static void a(int r16, b.f.a.j.f r17) {
        /*
            Method dump skipped, instructions count: 760
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.j.k.a(int, b.f.a.j.f):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:215:0x0032, code lost:
    
        r2 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:223:0x0040, code lost:
    
        if (r7 == 2) goto L12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x002e, code lost:
    
        if (r7 == 2) goto L12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0030, code lost:
    
        r2 = true;
     */
    /* JADX WARN: Removed duplicated region for block: B:118:0x01ce  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x00ff A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00fc A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    static boolean b(b.f.a.j.g r24, b.f.a.e r25, int r26, int r27, b.f.a.j.d r28) {
        /*
            Method dump skipped, instructions count: 895
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.j.k.b(b.f.a.j.g, b.f.a.e, int, int, b.f.a.j.d):boolean");
    }

    static void c(g gVar, b.f.a.e eVar, f fVar) {
        f.b bVar = gVar.C[0];
        f.b bVar2 = f.b.WRAP_CONTENT;
        if (bVar != bVar2 && fVar.C[0] == f.b.MATCH_PARENT) {
            int i2 = fVar.s.f1036e;
            int D = gVar.D() - fVar.u.f1036e;
            e eVar2 = fVar.s;
            eVar2.f1040i = eVar.r(eVar2);
            e eVar3 = fVar.u;
            eVar3.f1040i = eVar.r(eVar3);
            eVar.f(fVar.s.f1040i, i2);
            eVar.f(fVar.u.f1040i, D);
            fVar.f1042a = 2;
            fVar.f0(i2, D);
        }
        if (gVar.C[1] == bVar2 || fVar.C[1] != f.b.MATCH_PARENT) {
            return;
        }
        int i3 = fVar.t.f1036e;
        int r = gVar.r() - fVar.v.f1036e;
        e eVar4 = fVar.t;
        eVar4.f1040i = eVar.r(eVar4);
        e eVar5 = fVar.v;
        eVar5.f1040i = eVar.r(eVar5);
        eVar.f(fVar.t.f1040i, i3);
        eVar.f(fVar.v.f1040i, r);
        if (fVar.Q > 0 || fVar.C() == 8) {
            e eVar6 = fVar.w;
            eVar6.f1040i = eVar.r(eVar6);
            eVar.f(fVar.w.f1040i, fVar.Q + i3);
        }
        fVar.f1043b = 2;
        fVar.t0(i3, r);
    }

    private static boolean d(f fVar, int i2) {
        f.b[] bVarArr = fVar.C;
        if (bVarArr[i2] != f.b.MATCH_CONSTRAINT) {
            return false;
        }
        if (fVar.G != 0.0f) {
            f.b bVar = bVarArr[i2 != 0 ? (char) 0 : (char) 1];
            return false;
        }
        if (i2 == 0) {
            if (fVar.f1046e != 0 || fVar.f1049h != 0 || fVar.f1050i != 0) {
                return false;
            }
        } else if (fVar.f1047f != 0 || fVar.f1052k != 0 || fVar.l != 0) {
            return false;
        }
        return true;
    }

    static void e(f fVar, int i2, int i3) {
        int i4 = i2 * 2;
        int i5 = i4 + 1;
        fVar.A[i4].f().f1071f = fVar.u().s.f();
        fVar.A[i4].f().f1072g = i3;
        fVar.A[i4].f().f1079b = 1;
        fVar.A[i5].f().f1071f = fVar.A[i4].f();
        fVar.A[i5].f().f1072g = fVar.t(i2);
        fVar.A[i5].f().f1079b = 1;
    }
}
