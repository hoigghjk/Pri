package b.f.a;

/* loaded from: classes.dex */
interface g<T> {
    boolean a(T t);

    T b();

    void c(T[] tArr, int i2);
}
