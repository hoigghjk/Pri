package b.f.a;

import b.f.a.e;
import b.f.a.i;

/* loaded from: classes.dex */
public class b implements e.a {

    /* renamed from: c, reason: collision with root package name */
    boolean f980c;

    /* renamed from: d, reason: collision with root package name */
    public final a f981d;

    /* renamed from: a, reason: collision with root package name */
    i f978a = null;

    /* renamed from: b, reason: collision with root package name */
    float f979b = 0.0f;

    /* renamed from: e, reason: collision with root package name */
    boolean f982e = false;

    public b(c cVar) {
        this.f981d = new a(this, cVar);
    }

    @Override // b.f.a.e.a
    public void a(e.a aVar) {
        if (!(aVar instanceof b)) {
            return;
        }
        b bVar = (b) aVar;
        this.f978a = null;
        this.f981d.c();
        int i2 = 0;
        while (true) {
            a aVar2 = bVar.f981d;
            if (i2 >= aVar2.f967a) {
                return;
            }
            this.f981d.a(aVar2.h(i2), bVar.f981d.i(i2), true);
            i2++;
        }
    }

    @Override // b.f.a.e.a
    public void b(i iVar) {
        int i2 = iVar.f1014d;
        float f2 = 1.0f;
        if (i2 != 1) {
            if (i2 == 2) {
                f2 = 1000.0f;
            } else if (i2 == 3) {
                f2 = 1000000.0f;
            } else if (i2 == 4) {
                f2 = 1.0E9f;
            } else if (i2 == 5) {
                f2 = 1.0E12f;
            }
        }
        this.f981d.l(iVar, f2);
    }

    @Override // b.f.a.e.a
    public i c(e eVar, boolean[] zArr) {
        return this.f981d.g(zArr, null);
    }

    @Override // b.f.a.e.a
    public void clear() {
        this.f981d.c();
        this.f978a = null;
        this.f979b = 0.0f;
    }

    public b d(e eVar, int i2) {
        this.f981d.l(eVar.p(i2, "ep"), 1.0f);
        this.f981d.l(eVar.p(i2, "em"), -1.0f);
        return this;
    }

    b e(i iVar, int i2) {
        this.f981d.l(iVar, i2);
        return this;
    }

    boolean f(e eVar) {
        boolean z;
        i b2 = this.f981d.b(eVar);
        if (b2 == null) {
            z = true;
        } else {
            v(b2);
            z = false;
        }
        if (this.f981d.f967a == 0) {
            this.f982e = true;
        }
        return z;
    }

    b g(i iVar, i iVar2, int i2, float f2, i iVar3, i iVar4, int i3) {
        float f3;
        if (iVar2 == iVar3) {
            this.f981d.l(iVar, 1.0f);
            this.f981d.l(iVar4, 1.0f);
            this.f981d.l(iVar2, -2.0f);
            return this;
        }
        if (f2 == 0.5f) {
            this.f981d.l(iVar, 1.0f);
            this.f981d.l(iVar2, -1.0f);
            this.f981d.l(iVar3, -1.0f);
            this.f981d.l(iVar4, 1.0f);
            if (i2 > 0 || i3 > 0) {
                f3 = (-i2) + i3;
                this.f979b = f3;
            }
        } else {
            if (f2 <= 0.0f) {
                this.f981d.l(iVar, -1.0f);
                this.f981d.l(iVar2, 1.0f);
                f3 = i2;
            } else if (f2 >= 1.0f) {
                this.f981d.l(iVar3, -1.0f);
                this.f981d.l(iVar4, 1.0f);
                f3 = i3;
            } else {
                float f4 = 1.0f - f2;
                this.f981d.l(iVar, f4 * 1.0f);
                this.f981d.l(iVar2, f4 * (-1.0f));
                this.f981d.l(iVar3, (-1.0f) * f2);
                this.f981d.l(iVar4, 1.0f * f2);
                if (i2 > 0 || i3 > 0) {
                    f3 = ((-i2) * f4) + (i3 * f2);
                }
            }
            this.f979b = f3;
        }
        return this;
    }

    @Override // b.f.a.e.a
    public i getKey() {
        return this.f978a;
    }

    b h(i iVar, int i2) {
        this.f978a = iVar;
        float f2 = i2;
        iVar.f1015e = f2;
        this.f979b = f2;
        this.f982e = true;
        return this;
    }

    b i(i iVar, i iVar2, i iVar3, float f2) {
        this.f981d.l(iVar, -1.0f);
        this.f981d.l(iVar2, 1.0f - f2);
        this.f981d.l(iVar3, f2);
        return this;
    }

    public b j(i iVar, i iVar2, i iVar3, i iVar4, float f2) {
        this.f981d.l(iVar, -1.0f);
        this.f981d.l(iVar2, 1.0f);
        this.f981d.l(iVar3, f2);
        this.f981d.l(iVar4, -f2);
        return this;
    }

    public b k(float f2, float f3, float f4, i iVar, i iVar2, i iVar3, i iVar4) {
        this.f979b = 0.0f;
        if (f3 == 0.0f || f2 == f4) {
            this.f981d.l(iVar, 1.0f);
            this.f981d.l(iVar2, -1.0f);
            this.f981d.l(iVar4, 1.0f);
            this.f981d.l(iVar3, -1.0f);
        } else if (f2 == 0.0f) {
            this.f981d.l(iVar, 1.0f);
            this.f981d.l(iVar2, -1.0f);
        } else if (f4 == 0.0f) {
            this.f981d.l(iVar3, 1.0f);
            this.f981d.l(iVar4, -1.0f);
        } else {
            float f5 = (f2 / f3) / (f4 / f3);
            this.f981d.l(iVar, 1.0f);
            this.f981d.l(iVar2, -1.0f);
            this.f981d.l(iVar4, f5);
            this.f981d.l(iVar3, -f5);
        }
        return this;
    }

    public b l(i iVar, int i2) {
        a aVar;
        float f2;
        if (i2 < 0) {
            this.f979b = i2 * (-1);
            aVar = this.f981d;
            f2 = 1.0f;
        } else {
            this.f979b = i2;
            aVar = this.f981d;
            f2 = -1.0f;
        }
        aVar.l(iVar, f2);
        return this;
    }

    public b m(i iVar, i iVar2, int i2) {
        boolean z = false;
        if (i2 != 0) {
            if (i2 < 0) {
                i2 *= -1;
                z = true;
            }
            this.f979b = i2;
        }
        if (z) {
            this.f981d.l(iVar, 1.0f);
            this.f981d.l(iVar2, -1.0f);
        } else {
            this.f981d.l(iVar, -1.0f);
            this.f981d.l(iVar2, 1.0f);
        }
        return this;
    }

    public b n(i iVar, i iVar2, i iVar3, int i2) {
        boolean z = false;
        if (i2 != 0) {
            if (i2 < 0) {
                i2 *= -1;
                z = true;
            }
            this.f979b = i2;
        }
        if (z) {
            this.f981d.l(iVar, 1.0f);
            this.f981d.l(iVar2, -1.0f);
            this.f981d.l(iVar3, -1.0f);
        } else {
            this.f981d.l(iVar, -1.0f);
            this.f981d.l(iVar2, 1.0f);
            this.f981d.l(iVar3, 1.0f);
        }
        return this;
    }

    public b o(i iVar, i iVar2, i iVar3, int i2) {
        boolean z = false;
        if (i2 != 0) {
            if (i2 < 0) {
                i2 *= -1;
                z = true;
            }
            this.f979b = i2;
        }
        if (z) {
            this.f981d.l(iVar, 1.0f);
            this.f981d.l(iVar2, -1.0f);
            this.f981d.l(iVar3, 1.0f);
        } else {
            this.f981d.l(iVar, -1.0f);
            this.f981d.l(iVar2, 1.0f);
            this.f981d.l(iVar3, -1.0f);
        }
        return this;
    }

    public b p(i iVar, i iVar2, i iVar3, i iVar4, float f2) {
        this.f981d.l(iVar3, 0.5f);
        this.f981d.l(iVar4, 0.5f);
        this.f981d.l(iVar, -0.5f);
        this.f981d.l(iVar2, -0.5f);
        this.f979b = -f2;
        return this;
    }

    void q() {
        float f2 = this.f979b;
        if (f2 < 0.0f) {
            this.f979b = f2 * (-1.0f);
            this.f981d.j();
        }
    }

    boolean r() {
        i iVar = this.f978a;
        return iVar != null && (iVar.f1017g == i.a.UNRESTRICTED || this.f979b >= 0.0f);
    }

    boolean s(i iVar) {
        return this.f981d.d(iVar);
    }

    public boolean t() {
        return this.f978a == null && this.f979b == 0.0f && this.f981d.f967a == 0;
    }

    public String toString() {
        return x();
    }

    i u(i iVar) {
        return this.f981d.g(null, iVar);
    }

    void v(i iVar) {
        i iVar2 = this.f978a;
        if (iVar2 != null) {
            this.f981d.l(iVar2, -1.0f);
            this.f978a = null;
        }
        float m = this.f981d.m(iVar, true) * (-1.0f);
        this.f978a = iVar;
        if (m == 1.0f) {
            return;
        }
        this.f979b /= m;
        this.f981d.e(m);
    }

    public void w() {
        this.f978a = null;
        this.f981d.c();
        this.f979b = 0.0f;
        this.f982e = false;
    }

    /*  JADX ERROR: ConcurrentModificationException in pass: ConstructorVisitor
        java.util.ConcurrentModificationException
        	at java.base/java.util.ArrayList$Itr.checkForComodification(ArrayList.java:1013)
        	at java.base/java.util.ArrayList$Itr.next(ArrayList.java:967)
        	at jadx.core.dex.visitors.ConstructorVisitor.insertPhiInsn(ConstructorVisitor.java:139)
        	at jadx.core.dex.visitors.ConstructorVisitor.processInvoke(ConstructorVisitor.java:91)
        	at jadx.core.dex.visitors.ConstructorVisitor.replaceInvoke(ConstructorVisitor.java:56)
        	at jadx.core.dex.visitors.ConstructorVisitor.visit(ConstructorVisitor.java:42)
        */
    java.lang.String x() {
        /*
            r10 = this;
            b.f.a.i r0 = r10.f978a
            java.lang.String r1 = ""
            if (r0 != 0) goto L14
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r0.append(r1)
            java.lang.String r1 = "0"
            r0.append(r1)
            goto L21
        L14:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r0.append(r1)
            b.f.a.i r1 = r10.f978a
            r0.append(r1)
        L21:
            java.lang.String r0 = r0.toString()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " = "
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            float r1 = r10.f979b
            r2 = 0
            r3 = 1
            r4 = 0
            int r1 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r1 == 0) goto L52
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            float r0 = r10.f979b
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            r1 = 1
            goto L53
        L52:
            r1 = 0
        L53:
            b.f.a.a r5 = r10.f981d
            int r5 = r5.f967a
        L57:
            if (r2 >= r5) goto Ld0
            b.f.a.a r6 = r10.f981d
            b.f.a.i r6 = r6.h(r2)
            if (r6 != 0) goto L62
            goto Lcd
        L62:
            b.f.a.a r7 = r10.f981d
            float r7 = r7.i(r2)
            int r8 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r8 != 0) goto L6d
            goto Lcd
        L6d:
            java.lang.String r6 = r6.toString()
            r9 = -1082130432(0xffffffffbf800000, float:-1.0)
            if (r1 != 0) goto L84
            int r1 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r1 >= 0) goto La9
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = "- "
            goto La0
        L84:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            if (r8 <= 0) goto L98
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " + "
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            goto La9
        L98:
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " - "
        La0:
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            float r7 = r7 * r9
        La9:
            r1 = 1065353216(0x3f800000, float:1.0)
            int r1 = (r7 > r1 ? 1 : (r7 == r1 ? 0 : -1))
            if (r1 != 0) goto Lb5
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            goto Lc2
        Lb5:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            r1.append(r7)
            java.lang.String r0 = " "
        Lc2:
            r1.append(r0)
            r1.append(r6)
            java.lang.String r0 = r1.toString()
            r1 = 1
        Lcd:
            int r2 = r2 + 1
            goto L57
        Ld0:
            if (r1 != 0) goto Le3
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = "0.0"
            r1.append(r0)
            java.lang.String r0 = r1.toString()
        Le3:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.b.x():java.lang.String");
    }
}
