package b.f.a.j;

import b.f.a.j.f;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class d {

    /* renamed from: a, reason: collision with root package name */
    protected f f1021a;

    /* renamed from: b, reason: collision with root package name */
    protected f f1022b;

    /* renamed from: c, reason: collision with root package name */
    protected f f1023c;

    /* renamed from: d, reason: collision with root package name */
    protected f f1024d;

    /* renamed from: e, reason: collision with root package name */
    protected f f1025e;

    /* renamed from: f, reason: collision with root package name */
    protected f f1026f;

    /* renamed from: g, reason: collision with root package name */
    protected f f1027g;

    /* renamed from: h, reason: collision with root package name */
    protected ArrayList<f> f1028h;

    /* renamed from: i, reason: collision with root package name */
    protected int f1029i;

    /* renamed from: j, reason: collision with root package name */
    protected int f1030j;

    /* renamed from: k, reason: collision with root package name */
    protected float f1031k = 0.0f;
    private int l;
    private boolean m;
    protected boolean n;
    protected boolean o;
    protected boolean p;
    private boolean q;

    public d(f fVar, int i2, boolean z) {
        this.m = false;
        this.f1021a = fVar;
        this.l = i2;
        this.m = z;
    }

    private void b() {
        int i2 = this.l * 2;
        f fVar = this.f1021a;
        boolean z = false;
        f fVar2 = fVar;
        boolean z2 = false;
        while (!z2) {
            this.f1029i++;
            f[] fVarArr = fVar.i0;
            int i3 = this.l;
            f fVar3 = null;
            fVarArr[i3] = null;
            fVar.h0[i3] = null;
            if (fVar.C() != 8) {
                if (this.f1022b == null) {
                    this.f1022b = fVar;
                }
                this.f1024d = fVar;
                f.b[] bVarArr = fVar.C;
                int i4 = this.l;
                if (bVarArr[i4] == f.b.MATCH_CONSTRAINT) {
                    int[] iArr = fVar.f1048g;
                    if (iArr[i4] == 0 || iArr[i4] == 3 || iArr[i4] == 2) {
                        this.f1030j++;
                        float[] fArr = fVar.g0;
                        float f2 = fArr[i4];
                        if (f2 > 0.0f) {
                            this.f1031k += fArr[i4];
                        }
                        if (c(fVar, i4)) {
                            if (f2 < 0.0f) {
                                this.n = true;
                            } else {
                                this.o = true;
                            }
                            if (this.f1028h == null) {
                                this.f1028h = new ArrayList<>();
                            }
                            this.f1028h.add(fVar);
                        }
                        if (this.f1026f == null) {
                            this.f1026f = fVar;
                        }
                        f fVar4 = this.f1027g;
                        if (fVar4 != null) {
                            fVar4.h0[this.l] = fVar;
                        }
                        this.f1027g = fVar;
                    }
                }
            }
            if (fVar2 != fVar) {
                fVar2.i0[this.l] = fVar;
            }
            e eVar = fVar.A[i2 + 1].f1035d;
            if (eVar != null) {
                f fVar5 = eVar.f1033b;
                e[] eVarArr = fVar5.A;
                if (eVarArr[i2].f1035d != null && eVarArr[i2].f1035d.f1033b == fVar) {
                    fVar3 = fVar5;
                }
            }
            if (fVar3 == null) {
                fVar3 = fVar;
                z2 = true;
            }
            fVar2 = fVar;
            fVar = fVar3;
        }
        this.f1023c = fVar;
        if (this.l == 0 && this.m) {
            this.f1025e = fVar;
        } else {
            this.f1025e = this.f1021a;
        }
        if (this.o && this.n) {
            z = true;
        }
        this.p = z;
    }

    private static boolean c(f fVar, int i2) {
        if (fVar.C() != 8 && fVar.C[i2] == f.b.MATCH_CONSTRAINT) {
            int[] iArr = fVar.f1048g;
            if (iArr[i2] == 0 || iArr[i2] == 3) {
                return true;
            }
        }
        return false;
    }

    public void a() {
        if (!this.q) {
            b();
        }
        this.q = true;
    }
}
