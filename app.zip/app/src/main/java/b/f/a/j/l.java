package b.f.a.j;

import b.f.a.j.e;

/* loaded from: classes.dex */
public class l extends n {

    /* renamed from: c, reason: collision with root package name */
    e f1068c;

    /* renamed from: d, reason: collision with root package name */
    l f1069d;

    /* renamed from: e, reason: collision with root package name */
    float f1070e;

    /* renamed from: f, reason: collision with root package name */
    l f1071f;

    /* renamed from: g, reason: collision with root package name */
    float f1072g;

    /* renamed from: i, reason: collision with root package name */
    private l f1074i;

    /* renamed from: h, reason: collision with root package name */
    int f1073h = 0;

    /* renamed from: j, reason: collision with root package name */
    private m f1075j = null;

    /* renamed from: k, reason: collision with root package name */
    private int f1076k = 1;
    private m l = null;
    private int m = 1;

    public l(e eVar) {
        this.f1068c = eVar;
    }

    @Override // b.f.a.j.n
    public void e() {
        super.e();
        this.f1069d = null;
        this.f1070e = 0.0f;
        this.f1075j = null;
        this.f1076k = 1;
        this.l = null;
        this.m = 1;
        this.f1071f = null;
        this.f1072g = 0.0f;
        this.f1074i = null;
        this.f1073h = 0;
    }

    @Override // b.f.a.j.n
    public void f() {
        int i2;
        l lVar;
        l lVar2;
        l lVar3;
        l lVar4;
        l lVar5;
        l lVar6;
        float D;
        float f2;
        l lVar7;
        float f3;
        boolean z = true;
        if (this.f1079b == 1 || (i2 = this.f1073h) == 4) {
            return;
        }
        m mVar = this.f1075j;
        if (mVar != null) {
            if (mVar.f1079b != 1) {
                return;
            } else {
                this.f1070e = this.f1076k * mVar.f1077c;
            }
        }
        m mVar2 = this.l;
        if (mVar2 != null) {
            if (mVar2.f1079b != 1) {
                return;
            } else {
                float f4 = mVar2.f1077c;
            }
        }
        if (i2 == 1 && ((lVar7 = this.f1069d) == null || lVar7.f1079b == 1)) {
            if (lVar7 == null) {
                this.f1071f = this;
                f3 = this.f1070e;
            } else {
                this.f1071f = lVar7.f1071f;
                f3 = lVar7.f1072g + this.f1070e;
            }
            this.f1072g = f3;
            b();
            return;
        }
        if (i2 == 2 && (lVar4 = this.f1069d) != null && lVar4.f1079b == 1 && (lVar5 = this.f1074i) != null && (lVar6 = lVar5.f1069d) != null && lVar6.f1079b == 1) {
            if (b.f.a.e.x() != null) {
                b.f.a.e.x().v++;
            }
            l lVar8 = this.f1069d;
            this.f1071f = lVar8.f1071f;
            l lVar9 = this.f1074i;
            l lVar10 = lVar9.f1069d;
            lVar9.f1071f = lVar10.f1071f;
            e.d dVar = this.f1068c.f1034c;
            e.d dVar2 = e.d.RIGHT;
            int i3 = 0;
            if (dVar != dVar2 && dVar != e.d.BOTTOM) {
                z = false;
            }
            float f5 = z ? lVar8.f1072g - lVar10.f1072g : lVar10.f1072g - lVar8.f1072g;
            if (dVar == e.d.LEFT || dVar == dVar2) {
                D = f5 - r2.f1033b.D();
                f2 = this.f1068c.f1033b.V;
            } else {
                D = f5 - r2.f1033b.r();
                f2 = this.f1068c.f1033b.W;
            }
            int d2 = this.f1068c.d();
            int d3 = this.f1074i.f1068c.d();
            if (this.f1068c.i() == this.f1074i.f1068c.i()) {
                f2 = 0.5f;
                d3 = 0;
            } else {
                i3 = d2;
            }
            float f6 = i3;
            float f7 = d3;
            float f8 = (D - f6) - f7;
            if (z) {
                l lVar11 = this.f1074i;
                lVar11.f1072g = lVar11.f1069d.f1072g + f7 + (f8 * f2);
                this.f1072g = (this.f1069d.f1072g - f6) - (f8 * (1.0f - f2));
            } else {
                this.f1072g = this.f1069d.f1072g + f6 + (f8 * f2);
                l lVar12 = this.f1074i;
                lVar12.f1072g = (lVar12.f1069d.f1072g - f7) - (f8 * (1.0f - f2));
            }
        } else {
            if (i2 != 3 || (lVar = this.f1069d) == null || lVar.f1079b != 1 || (lVar2 = this.f1074i) == null || (lVar3 = lVar2.f1069d) == null || lVar3.f1079b != 1) {
                if (i2 == 5) {
                    this.f1068c.f1033b.U();
                    return;
                }
                return;
            }
            if (b.f.a.e.x() != null) {
                b.f.a.e.x().w++;
            }
            l lVar13 = this.f1069d;
            this.f1071f = lVar13.f1071f;
            l lVar14 = this.f1074i;
            l lVar15 = lVar14.f1069d;
            lVar14.f1071f = lVar15.f1071f;
            this.f1072g = lVar13.f1072g + this.f1070e;
            lVar14.f1072g = lVar15.f1072g + lVar14.f1070e;
        }
        b();
        this.f1074i.b();
    }

    void g(b.f.a.e eVar) {
        b.f.a.i g2 = this.f1068c.g();
        l lVar = this.f1071f;
        if (lVar == null) {
            eVar.f(g2, (int) (this.f1072g + 0.5f));
        } else {
            eVar.e(g2, eVar.r(lVar.f1068c), (int) (this.f1072g + 0.5f), 6);
        }
    }

    public void h(int i2, l lVar, int i3) {
        this.f1073h = i2;
        this.f1069d = lVar;
        this.f1070e = i3;
        lVar.a(this);
    }

    public void i(l lVar, int i2) {
        this.f1069d = lVar;
        this.f1070e = i2;
        lVar.a(this);
    }

    public void j(l lVar, int i2, m mVar) {
        this.f1069d = lVar;
        lVar.a(this);
        this.f1075j = mVar;
        this.f1076k = i2;
        mVar.a(this);
    }

    public float k() {
        return this.f1072g;
    }

    public void l(l lVar, float f2) {
        int i2 = this.f1079b;
        if (i2 == 0 || !(this.f1071f == lVar || this.f1072g == f2)) {
            this.f1071f = lVar;
            this.f1072g = f2;
            if (i2 == 1) {
                c();
            }
            b();
        }
    }

    String m(int i2) {
        return i2 == 1 ? "DIRECT" : i2 == 2 ? "CENTER" : i2 == 3 ? "MATCH" : i2 == 4 ? "CHAIN" : i2 == 5 ? "BARRIER" : "UNCONNECTED";
    }

    public void n(l lVar, float f2) {
        this.f1074i = lVar;
    }

    public void o(l lVar, int i2, m mVar) {
        this.f1074i = lVar;
        this.l = mVar;
        this.m = i2;
    }

    public void p(int i2) {
        this.f1073h = i2;
    }

    public void q() {
        e i2 = this.f1068c.i();
        if (i2 == null) {
            return;
        }
        if (i2.i() == this.f1068c) {
            this.f1073h = 4;
            i2.f().f1073h = 4;
        }
        int d2 = this.f1068c.d();
        e.d dVar = this.f1068c.f1034c;
        if (dVar == e.d.RIGHT || dVar == e.d.BOTTOM) {
            d2 = -d2;
        }
        i(i2.f(), d2);
    }

    public String toString() {
        StringBuilder sb;
        String str;
        if (this.f1079b != 1) {
            sb = new StringBuilder();
            sb.append("{ ");
            sb.append(this.f1068c);
            str = " UNRESOLVED} type: ";
        } else if (this.f1071f == this) {
            sb = new StringBuilder();
            sb.append("[");
            sb.append(this.f1068c);
            sb.append(", RESOLVED: ");
            sb.append(this.f1072g);
            str = "]  type: ";
        } else {
            sb = new StringBuilder();
            sb.append("[");
            sb.append(this.f1068c);
            sb.append(", RESOLVED: ");
            sb.append(this.f1071f);
            sb.append(":");
            sb.append(this.f1072g);
            str = "] type: ";
        }
        sb.append(str);
        sb.append(m(this.f1073h));
        return sb.toString();
    }
}
