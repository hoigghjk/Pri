package b.f.a;

/* loaded from: classes.dex */
public class f {
    public long A;

    /* renamed from: a, reason: collision with root package name */
    public long f997a;

    /* renamed from: b, reason: collision with root package name */
    public long f998b;

    /* renamed from: c, reason: collision with root package name */
    public long f999c;

    /* renamed from: d, reason: collision with root package name */
    public long f1000d;

    /* renamed from: e, reason: collision with root package name */
    public long f1001e;

    /* renamed from: f, reason: collision with root package name */
    public long f1002f;

    /* renamed from: g, reason: collision with root package name */
    public long f1003g;

    /* renamed from: h, reason: collision with root package name */
    public long f1004h;

    /* renamed from: i, reason: collision with root package name */
    public long f1005i;

    /* renamed from: j, reason: collision with root package name */
    public long f1006j;

    /* renamed from: k, reason: collision with root package name */
    public long f1007k;
    public long l;
    public long m;
    public long n;
    public long o;
    public long p;
    public long q;
    public long r;
    public long s;
    public long t;
    public long u;
    public long v;
    public long w;
    public long x;
    public long y;
    public long z;
}
