package b.f.a;

import b.f.a.i;
import b.f.a.j.e;
import java.util.Arrays;
import java.util.HashMap;

/* loaded from: classes.dex */
public class e {
    private static int p = 1000;
    public static f q;

    /* renamed from: c, reason: collision with root package name */
    private a f988c;

    /* renamed from: f, reason: collision with root package name */
    b[] f991f;
    final c l;
    private final a o;

    /* renamed from: a, reason: collision with root package name */
    int f986a = 0;

    /* renamed from: b, reason: collision with root package name */
    private HashMap<String, i> f987b = null;

    /* renamed from: d, reason: collision with root package name */
    private int f989d = 32;

    /* renamed from: e, reason: collision with root package name */
    private int f990e = 32;

    /* renamed from: g, reason: collision with root package name */
    public boolean f992g = false;

    /* renamed from: h, reason: collision with root package name */
    private boolean[] f993h = new boolean[32];

    /* renamed from: i, reason: collision with root package name */
    int f994i = 1;

    /* renamed from: j, reason: collision with root package name */
    int f995j = 0;

    /* renamed from: k, reason: collision with root package name */
    private int f996k = 32;
    private i[] m = new i[p];
    private int n = 0;

    interface a {
        void a(a aVar);

        void b(i iVar);

        i c(e eVar, boolean[] zArr);

        void clear();

        i getKey();
    }

    public e() {
        this.f991f = null;
        this.f991f = new b[32];
        D();
        c cVar = new c();
        this.l = cVar;
        this.f988c = new d(cVar);
        this.o = new b(cVar);
    }

    private final int C(a aVar, boolean z) {
        f fVar = q;
        if (fVar != null) {
            fVar.f1004h++;
        }
        for (int i2 = 0; i2 < this.f994i; i2++) {
            this.f993h[i2] = false;
        }
        boolean z2 = false;
        int i3 = 0;
        while (!z2) {
            f fVar2 = q;
            if (fVar2 != null) {
                fVar2.f1005i++;
            }
            i3++;
            if (i3 >= this.f994i * 2) {
                return i3;
            }
            if (aVar.getKey() != null) {
                this.f993h[aVar.getKey().f1012b] = true;
            }
            i c2 = aVar.c(this, this.f993h);
            if (c2 != null) {
                boolean[] zArr = this.f993h;
                int i4 = c2.f1012b;
                if (zArr[i4]) {
                    return i3;
                }
                zArr[i4] = true;
            }
            if (c2 != null) {
                float f2 = Float.MAX_VALUE;
                int i5 = -1;
                for (int i6 = 0; i6 < this.f995j; i6++) {
                    b bVar = this.f991f[i6];
                    if (bVar.f978a.f1017g != i.a.UNRESTRICTED && !bVar.f982e && bVar.s(c2)) {
                        float f3 = bVar.f981d.f(c2);
                        if (f3 < 0.0f) {
                            float f4 = (-bVar.f979b) / f3;
                            if (f4 < f2) {
                                i5 = i6;
                                f2 = f4;
                            }
                        }
                    }
                }
                if (i5 > -1) {
                    b bVar2 = this.f991f[i5];
                    bVar2.f978a.f1013c = -1;
                    f fVar3 = q;
                    if (fVar3 != null) {
                        fVar3.f1006j++;
                    }
                    bVar2.v(c2);
                    i iVar = bVar2.f978a;
                    iVar.f1013c = i5;
                    iVar.f(bVar2);
                }
            }
            z2 = true;
        }
        return i3;
    }

    private void D() {
        int i2 = 0;
        while (true) {
            b[] bVarArr = this.f991f;
            if (i2 >= bVarArr.length) {
                return;
            }
            b bVar = bVarArr[i2];
            if (bVar != null) {
                this.l.f983a.a(bVar);
            }
            this.f991f[i2] = null;
            i2++;
        }
    }

    private final void F(b bVar) {
        if (this.f995j > 0) {
            bVar.f981d.o(bVar, this.f991f);
            if (bVar.f981d.f967a == 0) {
                bVar.f982e = true;
            }
        }
    }

    private i a(i.a aVar, String str) {
        i b2 = this.l.f984b.b();
        if (b2 == null) {
            b2 = new i(aVar, str);
        } else {
            b2.d();
        }
        b2.e(aVar, str);
        int i2 = this.n;
        int i3 = p;
        if (i2 >= i3) {
            int i4 = i3 * 2;
            p = i4;
            this.m = (i[]) Arrays.copyOf(this.m, i4);
        }
        i[] iVarArr = this.m;
        int i5 = this.n;
        this.n = i5 + 1;
        iVarArr[i5] = b2;
        return b2;
    }

    private void g(b bVar) {
        bVar.d(this, 0);
    }

    private final void m(b bVar) {
        b[] bVarArr = this.f991f;
        int i2 = this.f995j;
        if (bVarArr[i2] != null) {
            this.l.f983a.a(bVarArr[i2]);
        }
        b[] bVarArr2 = this.f991f;
        int i3 = this.f995j;
        bVarArr2[i3] = bVar;
        i iVar = bVar.f978a;
        iVar.f1013c = i3;
        this.f995j = i3 + 1;
        iVar.f(bVar);
    }

    private void o() {
        for (int i2 = 0; i2 < this.f995j; i2++) {
            b bVar = this.f991f[i2];
            bVar.f978a.f1015e = bVar.f979b;
        }
    }

    public static b t(e eVar, i iVar, i iVar2, i iVar3, float f2, boolean z) {
        b s = eVar.s();
        if (z) {
            eVar.g(s);
        }
        s.i(iVar, iVar2, iVar3, f2);
        return s;
    }

    private int v(a aVar) {
        float f2;
        boolean z;
        int i2 = 0;
        while (true) {
            f2 = 0.0f;
            if (i2 >= this.f995j) {
                z = false;
                break;
            }
            b[] bVarArr = this.f991f;
            if (bVarArr[i2].f978a.f1017g != i.a.UNRESTRICTED && bVarArr[i2].f979b < 0.0f) {
                z = true;
                break;
            }
            i2++;
        }
        if (!z) {
            return 0;
        }
        boolean z2 = false;
        int i3 = 0;
        while (!z2) {
            f fVar = q;
            if (fVar != null) {
                fVar.f1007k++;
            }
            i3++;
            float f3 = Float.MAX_VALUE;
            int i4 = 0;
            int i5 = -1;
            int i6 = -1;
            int i7 = 0;
            while (i4 < this.f995j) {
                b bVar = this.f991f[i4];
                if (bVar.f978a.f1017g != i.a.UNRESTRICTED && !bVar.f982e && bVar.f979b < f2) {
                    int i8 = 1;
                    while (i8 < this.f994i) {
                        i iVar = this.l.f985c[i8];
                        float f4 = bVar.f981d.f(iVar);
                        if (f4 > f2) {
                            for (int i9 = 0; i9 < 7; i9++) {
                                float f5 = iVar.f1016f[i9] / f4;
                                if ((f5 < f3 && i9 == i7) || i9 > i7) {
                                    i6 = i8;
                                    i7 = i9;
                                    f3 = f5;
                                    i5 = i4;
                                }
                            }
                        }
                        i8++;
                        f2 = 0.0f;
                    }
                }
                i4++;
                f2 = 0.0f;
            }
            if (i5 != -1) {
                b bVar2 = this.f991f[i5];
                bVar2.f978a.f1013c = -1;
                f fVar2 = q;
                if (fVar2 != null) {
                    fVar2.f1006j++;
                }
                bVar2.v(this.l.f985c[i6]);
                i iVar2 = bVar2.f978a;
                iVar2.f1013c = i5;
                iVar2.f(bVar2);
            } else {
                z2 = true;
            }
            if (i3 > this.f994i / 2) {
                z2 = true;
            }
            f2 = 0.0f;
        }
        return i3;
    }

    public static f x() {
        return q;
    }

    private void z() {
        int i2 = this.f989d * 2;
        this.f989d = i2;
        this.f991f = (b[]) Arrays.copyOf(this.f991f, i2);
        c cVar = this.l;
        cVar.f985c = (i[]) Arrays.copyOf(cVar.f985c, this.f989d);
        int i3 = this.f989d;
        this.f993h = new boolean[i3];
        this.f990e = i3;
        this.f996k = i3;
        f fVar = q;
        if (fVar != null) {
            fVar.f1000d++;
            fVar.o = Math.max(fVar.o, i3);
            f fVar2 = q;
            fVar2.A = fVar2.o;
        }
    }

    public void A() {
        f fVar = q;
        if (fVar != null) {
            fVar.f1001e++;
        }
        if (this.f992g) {
            if (fVar != null) {
                fVar.q++;
            }
            boolean z = false;
            int i2 = 0;
            while (true) {
                if (i2 >= this.f995j) {
                    z = true;
                    break;
                } else if (!this.f991f[i2].f982e) {
                    break;
                } else {
                    i2++;
                }
            }
            if (z) {
                f fVar2 = q;
                if (fVar2 != null) {
                    fVar2.p++;
                }
                o();
                return;
            }
        }
        B(this.f988c);
    }

    void B(a aVar) {
        f fVar = q;
        if (fVar != null) {
            fVar.s++;
            fVar.t = Math.max(fVar.t, this.f994i);
            f fVar2 = q;
            fVar2.u = Math.max(fVar2.u, this.f995j);
        }
        F((b) aVar);
        v(aVar);
        C(aVar, false);
        o();
    }

    public void E() {
        c cVar;
        int i2 = 0;
        while (true) {
            cVar = this.l;
            i[] iVarArr = cVar.f985c;
            if (i2 >= iVarArr.length) {
                break;
            }
            i iVar = iVarArr[i2];
            if (iVar != null) {
                iVar.d();
            }
            i2++;
        }
        cVar.f984b.c(this.m, this.n);
        this.n = 0;
        Arrays.fill(this.l.f985c, (Object) null);
        HashMap<String, i> hashMap = this.f987b;
        if (hashMap != null) {
            hashMap.clear();
        }
        this.f986a = 0;
        this.f988c.clear();
        this.f994i = 1;
        for (int i3 = 0; i3 < this.f995j; i3++) {
            this.f991f[i3].f980c = false;
        }
        D();
        this.f995j = 0;
    }

    public void b(b.f.a.j.f fVar, b.f.a.j.f fVar2, float f2, int i2) {
        e.d dVar = e.d.LEFT;
        i r = r(fVar.h(dVar));
        e.d dVar2 = e.d.TOP;
        i r2 = r(fVar.h(dVar2));
        e.d dVar3 = e.d.RIGHT;
        i r3 = r(fVar.h(dVar3));
        e.d dVar4 = e.d.BOTTOM;
        i r4 = r(fVar.h(dVar4));
        i r5 = r(fVar2.h(dVar));
        i r6 = r(fVar2.h(dVar2));
        i r7 = r(fVar2.h(dVar3));
        i r8 = r(fVar2.h(dVar4));
        b s = s();
        double d2 = f2;
        double d3 = i2;
        s.p(r2, r4, r6, r8, (float) (Math.sin(d2) * d3));
        d(s);
        b s2 = s();
        s2.p(r, r3, r5, r7, (float) (Math.cos(d2) * d3));
        d(s2);
    }

    public void c(i iVar, i iVar2, int i2, float f2, i iVar3, i iVar4, int i3, int i4) {
        b s = s();
        s.g(iVar, iVar2, i2, f2, iVar3, iVar4, i3);
        if (i4 != 6) {
            s.d(this, i4);
        }
        d(s);
    }

    public void d(b bVar) {
        i u;
        if (bVar == null) {
            return;
        }
        f fVar = q;
        if (fVar != null) {
            fVar.f1002f++;
            if (bVar.f982e) {
                fVar.f1003g++;
            }
        }
        boolean z = true;
        if (this.f995j + 1 >= this.f996k || this.f994i + 1 >= this.f990e) {
            z();
        }
        boolean z2 = false;
        if (!bVar.f982e) {
            F(bVar);
            if (bVar.t()) {
                return;
            }
            bVar.q();
            if (bVar.f(this)) {
                i q2 = q();
                bVar.f978a = q2;
                m(bVar);
                this.o.a(bVar);
                C(this.o, true);
                if (q2.f1013c == -1) {
                    if (bVar.f978a == q2 && (u = bVar.u(q2)) != null) {
                        f fVar2 = q;
                        if (fVar2 != null) {
                            fVar2.f1006j++;
                        }
                        bVar.v(u);
                    }
                    if (!bVar.f982e) {
                        bVar.f978a.f(bVar);
                    }
                    this.f995j--;
                }
            } else {
                z = false;
            }
            if (!bVar.r()) {
                return;
            } else {
                z2 = z;
            }
        }
        if (z2) {
            return;
        }
        m(bVar);
    }

    public b e(i iVar, i iVar2, int i2, int i3) {
        b s = s();
        s.m(iVar, iVar2, i2);
        if (i3 != 6) {
            s.d(this, i3);
        }
        d(s);
        return s;
    }

    public void f(i iVar, int i2) {
        b s;
        int i3 = iVar.f1013c;
        if (i3 != -1) {
            b bVar = this.f991f[i3];
            if (!bVar.f982e) {
                if (bVar.f981d.f967a == 0) {
                    bVar.f982e = true;
                } else {
                    s = s();
                    s.l(iVar, i2);
                }
            }
            bVar.f979b = i2;
            return;
        }
        s = s();
        s.h(iVar, i2);
        d(s);
    }

    public void h(i iVar, i iVar2, boolean z) {
        b s = s();
        i u = u();
        u.f1014d = 0;
        s.n(iVar, iVar2, u, 0);
        if (z) {
            n(s, (int) (s.f981d.f(u) * (-1.0f)), 1);
        }
        d(s);
    }

    public void i(i iVar, i iVar2, int i2, int i3) {
        b s = s();
        i u = u();
        u.f1014d = 0;
        s.n(iVar, iVar2, u, i2);
        if (i3 != 6) {
            n(s, (int) (s.f981d.f(u) * (-1.0f)), i3);
        }
        d(s);
    }

    public void j(i iVar, i iVar2, boolean z) {
        b s = s();
        i u = u();
        u.f1014d = 0;
        s.o(iVar, iVar2, u, 0);
        if (z) {
            n(s, (int) (s.f981d.f(u) * (-1.0f)), 1);
        }
        d(s);
    }

    public void k(i iVar, i iVar2, int i2, int i3) {
        b s = s();
        i u = u();
        u.f1014d = 0;
        s.o(iVar, iVar2, u, i2);
        if (i3 != 6) {
            n(s, (int) (s.f981d.f(u) * (-1.0f)), i3);
        }
        d(s);
    }

    public void l(i iVar, i iVar2, i iVar3, i iVar4, float f2, int i2) {
        b s = s();
        s.j(iVar, iVar2, iVar3, iVar4, f2);
        if (i2 != 6) {
            s.d(this, i2);
        }
        d(s);
    }

    void n(b bVar, int i2, int i3) {
        bVar.e(p(i3, null), i2);
    }

    public i p(int i2, String str) {
        f fVar = q;
        if (fVar != null) {
            fVar.l++;
        }
        if (this.f994i + 1 >= this.f990e) {
            z();
        }
        i a2 = a(i.a.ERROR, str);
        int i3 = this.f986a + 1;
        this.f986a = i3;
        this.f994i++;
        a2.f1012b = i3;
        a2.f1014d = i2;
        this.l.f985c[i3] = a2;
        this.f988c.b(a2);
        return a2;
    }

    public i q() {
        f fVar = q;
        if (fVar != null) {
            fVar.n++;
        }
        if (this.f994i + 1 >= this.f990e) {
            z();
        }
        i a2 = a(i.a.SLACK, null);
        int i2 = this.f986a + 1;
        this.f986a = i2;
        this.f994i++;
        a2.f1012b = i2;
        this.l.f985c[i2] = a2;
        return a2;
    }

    public i r(Object obj) {
        i iVar = null;
        if (obj == null) {
            return null;
        }
        if (this.f994i + 1 >= this.f990e) {
            z();
        }
        if (obj instanceof b.f.a.j.e) {
            b.f.a.j.e eVar = (b.f.a.j.e) obj;
            iVar = eVar.g();
            if (iVar == null) {
                eVar.n(this.l);
                iVar = eVar.g();
            }
            int i2 = iVar.f1012b;
            if (i2 == -1 || i2 > this.f986a || this.l.f985c[i2] == null) {
                if (i2 != -1) {
                    iVar.d();
                }
                int i3 = this.f986a + 1;
                this.f986a = i3;
                this.f994i++;
                iVar.f1012b = i3;
                iVar.f1017g = i.a.UNRESTRICTED;
                this.l.f985c[i3] = iVar;
            }
        }
        return iVar;
    }

    public b s() {
        b b2 = this.l.f983a.b();
        if (b2 == null) {
            b2 = new b(this.l);
        } else {
            b2.w();
        }
        i.b();
        return b2;
    }

    public i u() {
        f fVar = q;
        if (fVar != null) {
            fVar.m++;
        }
        if (this.f994i + 1 >= this.f990e) {
            z();
        }
        i a2 = a(i.a.SLACK, null);
        int i2 = this.f986a + 1;
        this.f986a = i2;
        this.f994i++;
        a2.f1012b = i2;
        this.l.f985c[i2] = a2;
        return a2;
    }

    public c w() {
        return this.l;
    }

    public int y(Object obj) {
        i g2 = ((b.f.a.j.e) obj).g();
        if (g2 != null) {
            return (int) (g2.f1015e + 0.5f);
        }
        return 0;
    }
}
