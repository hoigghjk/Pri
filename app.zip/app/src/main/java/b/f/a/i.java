package b.f.a;

import java.util.Arrays;

/* loaded from: classes.dex */
public class i {

    /* renamed from: k, reason: collision with root package name */
    private static int f1010k = 1;

    /* renamed from: a, reason: collision with root package name */
    private String f1011a;

    /* renamed from: e, reason: collision with root package name */
    public float f1015e;

    /* renamed from: g, reason: collision with root package name */
    a f1017g;

    /* renamed from: b, reason: collision with root package name */
    public int f1012b = -1;

    /* renamed from: c, reason: collision with root package name */
    int f1013c = -1;

    /* renamed from: d, reason: collision with root package name */
    public int f1014d = 0;

    /* renamed from: f, reason: collision with root package name */
    float[] f1016f = new float[7];

    /* renamed from: h, reason: collision with root package name */
    b[] f1018h = new b[8];

    /* renamed from: i, reason: collision with root package name */
    int f1019i = 0;

    /* renamed from: j, reason: collision with root package name */
    public int f1020j = 0;

    public enum a {
        UNRESTRICTED,
        CONSTANT,
        SLACK,
        ERROR,
        UNKNOWN
    }

    public i(a aVar, String str) {
        this.f1017g = aVar;
    }

    static void b() {
        f1010k++;
    }

    public final void a(b bVar) {
        int i2 = 0;
        while (true) {
            int i3 = this.f1019i;
            if (i2 >= i3) {
                b[] bVarArr = this.f1018h;
                if (i3 >= bVarArr.length) {
                    this.f1018h = (b[]) Arrays.copyOf(bVarArr, bVarArr.length * 2);
                }
                b[] bVarArr2 = this.f1018h;
                int i4 = this.f1019i;
                bVarArr2[i4] = bVar;
                this.f1019i = i4 + 1;
                return;
            }
            if (this.f1018h[i2] == bVar) {
                return;
            } else {
                i2++;
            }
        }
    }

    public final void c(b bVar) {
        int i2 = this.f1019i;
        for (int i3 = 0; i3 < i2; i3++) {
            if (this.f1018h[i3] == bVar) {
                for (int i4 = 0; i4 < (i2 - i3) - 1; i4++) {
                    b[] bVarArr = this.f1018h;
                    int i5 = i3 + i4;
                    bVarArr[i5] = bVarArr[i5 + 1];
                }
                this.f1019i--;
                return;
            }
        }
    }

    public void d() {
        this.f1011a = null;
        this.f1017g = a.UNKNOWN;
        this.f1014d = 0;
        this.f1012b = -1;
        this.f1013c = -1;
        this.f1015e = 0.0f;
        this.f1019i = 0;
        this.f1020j = 0;
    }

    public void e(a aVar, String str) {
        this.f1017g = aVar;
    }

    public final void f(b bVar) {
        int i2 = this.f1019i;
        for (int i3 = 0; i3 < i2; i3++) {
            b[] bVarArr = this.f1018h;
            bVarArr[i3].f981d.n(bVarArr[i3], bVar, false);
        }
        this.f1019i = 0;
    }

    public String toString() {
        return "" + this.f1011a;
    }
}
