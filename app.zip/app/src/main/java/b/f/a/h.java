package b.f.a;

/* loaded from: classes.dex */
class h<T> implements g<T> {

    /* renamed from: a, reason: collision with root package name */
    private final Object[] f1008a;

    /* renamed from: b, reason: collision with root package name */
    private int f1009b;

    h(int i2) {
        if (i2 <= 0) {
            throw new IllegalArgumentException("The max pool size must be > 0");
        }
        this.f1008a = new Object[i2];
    }

    @Override // b.f.a.g
    public boolean a(T t) {
        int i2 = this.f1009b;
        Object[] objArr = this.f1008a;
        if (i2 >= objArr.length) {
            return false;
        }
        objArr[i2] = t;
        this.f1009b = i2 + 1;
        return true;
    }

    @Override // b.f.a.g
    public T b() {
        int i2 = this.f1009b;
        if (i2 <= 0) {
            return null;
        }
        int i3 = i2 - 1;
        Object[] objArr = this.f1008a;
        T t = (T) objArr[i3];
        objArr[i3] = null;
        this.f1009b = i2 - 1;
        return t;
    }

    @Override // b.f.a.g
    public void c(T[] tArr, int i2) {
        if (i2 > tArr.length) {
            i2 = tArr.length;
        }
        for (int i3 = 0; i3 < i2; i3++) {
            T t = tArr[i3];
            int i4 = this.f1009b;
            Object[] objArr = this.f1008a;
            if (i4 < objArr.length) {
                objArr[i4] = t;
                this.f1009b = i4 + 1;
            }
        }
    }
}
