package b.f.a.j;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/* loaded from: classes.dex */
public class h {

    /* renamed from: a, reason: collision with root package name */
    public List<f> f1055a;

    /* renamed from: b, reason: collision with root package name */
    int f1056b;

    /* renamed from: c, reason: collision with root package name */
    int f1057c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f1058d;

    /* renamed from: e, reason: collision with root package name */
    public final int[] f1059e;

    /* renamed from: f, reason: collision with root package name */
    List<f> f1060f;

    /* renamed from: g, reason: collision with root package name */
    List<f> f1061g;

    /* renamed from: h, reason: collision with root package name */
    HashSet<f> f1062h;

    /* renamed from: i, reason: collision with root package name */
    HashSet<f> f1063i;

    /* renamed from: j, reason: collision with root package name */
    List<f> f1064j;

    /* renamed from: k, reason: collision with root package name */
    List<f> f1065k;

    h(List<f> list) {
        this.f1056b = -1;
        this.f1057c = -1;
        this.f1058d = false;
        this.f1059e = new int[]{-1, -1};
        this.f1060f = new ArrayList();
        this.f1061g = new ArrayList();
        this.f1062h = new HashSet<>();
        this.f1063i = new HashSet<>();
        this.f1064j = new ArrayList();
        this.f1065k = new ArrayList();
        this.f1055a = list;
    }

    h(List<f> list, boolean z) {
        this.f1056b = -1;
        this.f1057c = -1;
        this.f1058d = false;
        this.f1059e = new int[]{-1, -1};
        this.f1060f = new ArrayList();
        this.f1061g = new ArrayList();
        this.f1062h = new HashSet<>();
        this.f1063i = new HashSet<>();
        this.f1064j = new ArrayList();
        this.f1065k = new ArrayList();
        this.f1055a = list;
        this.f1058d = z;
    }

    private void e(ArrayList<f> arrayList, f fVar) {
        if (fVar.d0) {
            return;
        }
        arrayList.add(fVar);
        fVar.d0 = true;
        if (fVar.L()) {
            return;
        }
        if (fVar instanceof j) {
            j jVar = (j) fVar;
            int i2 = jVar.l0;
            for (int i3 = 0; i3 < i2; i3++) {
                e(arrayList, jVar.k0[i3]);
            }
        }
        int length = fVar.A.length;
        for (int i4 = 0; i4 < length; i4++) {
            e eVar = fVar.A[i4].f1035d;
            if (eVar != null) {
                f fVar2 = eVar.f1033b;
                if (eVar != null && fVar2 != fVar.u()) {
                    e(arrayList, fVar2);
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0044  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0067  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0083  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x004c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void f(b.f.a.j.f r7) {
        /*
            Method dump skipped, instructions count: 215
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.j.h.f(b.f.a.j.f):void");
    }

    void a(f fVar, int i2) {
        HashSet<f> hashSet;
        if (i2 == 0) {
            hashSet = this.f1062h;
        } else if (i2 != 1) {
            return;
        } else {
            hashSet = this.f1063i;
        }
        hashSet.add(fVar);
    }

    public List<f> b(int i2) {
        if (i2 == 0) {
            return this.f1060f;
        }
        if (i2 == 1) {
            return this.f1061g;
        }
        return null;
    }

    Set<f> c(int i2) {
        if (i2 == 0) {
            return this.f1062h;
        }
        if (i2 == 1) {
            return this.f1063i;
        }
        return null;
    }

    List<f> d() {
        if (!this.f1064j.isEmpty()) {
            return this.f1064j;
        }
        int size = this.f1055a.size();
        for (int i2 = 0; i2 < size; i2++) {
            f fVar = this.f1055a.get(i2);
            if (!fVar.b0) {
                e((ArrayList) this.f1064j, fVar);
            }
        }
        this.f1065k.clear();
        this.f1065k.addAll(this.f1055a);
        this.f1065k.removeAll(this.f1064j);
        return this.f1064j;
    }

    void g() {
        int size = this.f1065k.size();
        for (int i2 = 0; i2 < size; i2++) {
            f(this.f1065k.get(i2));
        }
    }
}
