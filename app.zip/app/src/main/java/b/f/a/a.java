package b.f.a;

import b.f.a.i;
import java.util.Arrays;

/* loaded from: classes.dex */
public class a {

    /* renamed from: b, reason: collision with root package name */
    private final b f968b;

    /* renamed from: c, reason: collision with root package name */
    private final c f969c;

    /* renamed from: a, reason: collision with root package name */
    int f967a = 0;

    /* renamed from: d, reason: collision with root package name */
    private int f970d = 8;

    /* renamed from: e, reason: collision with root package name */
    private i f971e = null;

    /* renamed from: f, reason: collision with root package name */
    private int[] f972f = new int[8];

    /* renamed from: g, reason: collision with root package name */
    private int[] f973g = new int[8];

    /* renamed from: h, reason: collision with root package name */
    private float[] f974h = new float[8];

    /* renamed from: i, reason: collision with root package name */
    private int f975i = -1;

    /* renamed from: j, reason: collision with root package name */
    private int f976j = -1;

    /* renamed from: k, reason: collision with root package name */
    private boolean f977k = false;

    a(b bVar, c cVar) {
        this.f968b = bVar;
        this.f969c = cVar;
    }

    private boolean k(i iVar, e eVar) {
        return iVar.f1020j <= 1;
    }

    final void a(i iVar, float f2, boolean z) {
        if (f2 == 0.0f) {
            return;
        }
        int i2 = this.f975i;
        if (i2 == -1) {
            this.f975i = 0;
            this.f974h[0] = f2;
            this.f972f[0] = iVar.f1012b;
            this.f973g[0] = -1;
            iVar.f1020j++;
            iVar.a(this.f968b);
            this.f967a++;
            if (this.f977k) {
                return;
            }
            int i3 = this.f976j + 1;
            this.f976j = i3;
            int[] iArr = this.f972f;
            if (i3 >= iArr.length) {
                this.f977k = true;
                this.f976j = iArr.length - 1;
                return;
            }
            return;
        }
        int i4 = -1;
        for (int i5 = 0; i2 != -1 && i5 < this.f967a; i5++) {
            int[] iArr2 = this.f972f;
            int i6 = iArr2[i2];
            int i7 = iVar.f1012b;
            if (i6 == i7) {
                float[] fArr = this.f974h;
                fArr[i2] = fArr[i2] + f2;
                if (fArr[i2] == 0.0f) {
                    if (i2 == this.f975i) {
                        this.f975i = this.f973g[i2];
                    } else {
                        int[] iArr3 = this.f973g;
                        iArr3[i4] = iArr3[i2];
                    }
                    if (z) {
                        iVar.c(this.f968b);
                    }
                    if (this.f977k) {
                        this.f976j = i2;
                    }
                    iVar.f1020j--;
                    this.f967a--;
                    return;
                }
                return;
            }
            if (iArr2[i2] < i7) {
                i4 = i2;
            }
            i2 = this.f973g[i2];
        }
        int i8 = this.f976j;
        int i9 = i8 + 1;
        if (this.f977k) {
            int[] iArr4 = this.f972f;
            if (iArr4[i8] != -1) {
                i8 = iArr4.length;
            }
        } else {
            i8 = i9;
        }
        int[] iArr5 = this.f972f;
        if (i8 >= iArr5.length && this.f967a < iArr5.length) {
            int i10 = 0;
            while (true) {
                int[] iArr6 = this.f972f;
                if (i10 >= iArr6.length) {
                    break;
                }
                if (iArr6[i10] == -1) {
                    i8 = i10;
                    break;
                }
                i10++;
            }
        }
        int[] iArr7 = this.f972f;
        if (i8 >= iArr7.length) {
            i8 = iArr7.length;
            int i11 = this.f970d * 2;
            this.f970d = i11;
            this.f977k = false;
            this.f976j = i8 - 1;
            this.f974h = Arrays.copyOf(this.f974h, i11);
            this.f972f = Arrays.copyOf(this.f972f, this.f970d);
            this.f973g = Arrays.copyOf(this.f973g, this.f970d);
        }
        this.f972f[i8] = iVar.f1012b;
        this.f974h[i8] = f2;
        int[] iArr8 = this.f973g;
        if (i4 != -1) {
            iArr8[i8] = iArr8[i4];
            iArr8[i4] = i8;
        } else {
            iArr8[i8] = this.f975i;
            this.f975i = i8;
        }
        iVar.f1020j++;
        iVar.a(this.f968b);
        this.f967a++;
        if (!this.f977k) {
            this.f976j++;
        }
        int i12 = this.f976j;
        int[] iArr9 = this.f972f;
        if (i12 >= iArr9.length) {
            this.f977k = true;
            this.f976j = iArr9.length - 1;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0042  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0083 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    b.f.a.i b(b.f.a.e r15) {
        /*
            r14 = this;
            int r0 = r14.f975i
            r1 = 0
            r2 = 0
            r3 = 0
            r2 = r1
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
        Lb:
            r9 = -1
            if (r0 == r9) goto L8a
            int r9 = r14.f967a
            if (r4 >= r9) goto L8a
            float[] r9 = r14.f974h
            r10 = r9[r0]
            r11 = 981668463(0x3a83126f, float:0.001)
            b.f.a.c r12 = r14.f969c
            b.f.a.i[] r12 = r12.f985c
            int[] r13 = r14.f972f
            r13 = r13[r0]
            r12 = r12[r13]
            int r13 = (r10 > r3 ? 1 : (r10 == r3 ? 0 : -1))
            if (r13 >= 0) goto L31
            r11 = -1165815185(0xffffffffba83126f, float:-0.001)
            int r11 = (r10 > r11 ? 1 : (r10 == r11 ? 0 : -1))
            if (r11 <= 0) goto L3d
            r9[r0] = r3
            goto L37
        L31:
            int r11 = (r10 > r11 ? 1 : (r10 == r11 ? 0 : -1))
            if (r11 >= 0) goto L3d
            r9[r0] = r3
        L37:
            b.f.a.b r9 = r14.f968b
            r12.c(r9)
            r10 = 0
        L3d:
            r9 = 1
            int r11 = (r10 > r3 ? 1 : (r10 == r3 ? 0 : -1))
            if (r11 == 0) goto L83
            b.f.a.i$a r11 = r12.f1017g
            b.f.a.i$a r13 = b.f.a.i.a.UNRESTRICTED
            if (r11 != r13) goto L63
            if (r2 != 0) goto L52
        L4a:
            boolean r2 = r14.k(r12, r15)
            r5 = r2
            r7 = r10
            r2 = r12
            goto L83
        L52:
            int r11 = (r7 > r10 ? 1 : (r7 == r10 ? 0 : -1))
            if (r11 <= 0) goto L57
            goto L4a
        L57:
            if (r5 != 0) goto L83
            boolean r11 = r14.k(r12, r15)
            if (r11 == 0) goto L83
            r7 = r10
            r2 = r12
            r5 = 1
            goto L83
        L63:
            if (r2 != 0) goto L83
            int r11 = (r10 > r3 ? 1 : (r10 == r3 ? 0 : -1))
            if (r11 >= 0) goto L83
            if (r1 != 0) goto L73
        L6b:
            boolean r1 = r14.k(r12, r15)
            r6 = r1
            r8 = r10
            r1 = r12
            goto L83
        L73:
            int r11 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r11 <= 0) goto L78
            goto L6b
        L78:
            if (r6 != 0) goto L83
            boolean r11 = r14.k(r12, r15)
            if (r11 == 0) goto L83
            r8 = r10
            r1 = r12
            r6 = 1
        L83:
            int[] r9 = r14.f973g
            r0 = r9[r0]
            int r4 = r4 + 1
            goto Lb
        L8a:
            if (r2 == 0) goto L8d
            return r2
        L8d:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.a.b(b.f.a.e):b.f.a.i");
    }

    public final void c() {
        int i2 = this.f975i;
        for (int i3 = 0; i2 != -1 && i3 < this.f967a; i3++) {
            i iVar = this.f969c.f985c[this.f972f[i2]];
            if (iVar != null) {
                iVar.c(this.f968b);
            }
            i2 = this.f973g[i2];
        }
        this.f975i = -1;
        this.f976j = -1;
        this.f977k = false;
        this.f967a = 0;
    }

    final boolean d(i iVar) {
        int i2 = this.f975i;
        if (i2 == -1) {
            return false;
        }
        for (int i3 = 0; i2 != -1 && i3 < this.f967a; i3++) {
            if (this.f972f[i2] == iVar.f1012b) {
                return true;
            }
            i2 = this.f973g[i2];
        }
        return false;
    }

    void e(float f2) {
        int i2 = this.f975i;
        for (int i3 = 0; i2 != -1 && i3 < this.f967a; i3++) {
            float[] fArr = this.f974h;
            fArr[i2] = fArr[i2] / f2;
            i2 = this.f973g[i2];
        }
    }

    public final float f(i iVar) {
        int i2 = this.f975i;
        for (int i3 = 0; i2 != -1 && i3 < this.f967a; i3++) {
            if (this.f972f[i2] == iVar.f1012b) {
                return this.f974h[i2];
            }
            i2 = this.f973g[i2];
        }
        return 0.0f;
    }

    i g(boolean[] zArr, i iVar) {
        i.a aVar;
        int i2 = this.f975i;
        i iVar2 = null;
        float f2 = 0.0f;
        for (int i3 = 0; i2 != -1 && i3 < this.f967a; i3++) {
            float[] fArr = this.f974h;
            if (fArr[i2] < 0.0f) {
                i iVar3 = this.f969c.f985c[this.f972f[i2]];
                if ((zArr == null || !zArr[iVar3.f1012b]) && iVar3 != iVar && ((aVar = iVar3.f1017g) == i.a.SLACK || aVar == i.a.ERROR)) {
                    float f3 = fArr[i2];
                    if (f3 < f2) {
                        f2 = f3;
                        iVar2 = iVar3;
                    }
                }
            }
            i2 = this.f973g[i2];
        }
        return iVar2;
    }

    final i h(int i2) {
        int i3 = this.f975i;
        for (int i4 = 0; i3 != -1 && i4 < this.f967a; i4++) {
            if (i4 == i2) {
                return this.f969c.f985c[this.f972f[i3]];
            }
            i3 = this.f973g[i3];
        }
        return null;
    }

    final float i(int i2) {
        int i3 = this.f975i;
        for (int i4 = 0; i3 != -1 && i4 < this.f967a; i4++) {
            if (i4 == i2) {
                return this.f974h[i3];
            }
            i3 = this.f973g[i3];
        }
        return 0.0f;
    }

    void j() {
        int i2 = this.f975i;
        for (int i3 = 0; i2 != -1 && i3 < this.f967a; i3++) {
            float[] fArr = this.f974h;
            fArr[i2] = fArr[i2] * (-1.0f);
            i2 = this.f973g[i2];
        }
    }

    public final void l(i iVar, float f2) {
        if (f2 == 0.0f) {
            m(iVar, true);
            return;
        }
        int i2 = this.f975i;
        if (i2 == -1) {
            this.f975i = 0;
            this.f974h[0] = f2;
            this.f972f[0] = iVar.f1012b;
            this.f973g[0] = -1;
            iVar.f1020j++;
            iVar.a(this.f968b);
            this.f967a++;
            if (this.f977k) {
                return;
            }
            int i3 = this.f976j + 1;
            this.f976j = i3;
            int[] iArr = this.f972f;
            if (i3 >= iArr.length) {
                this.f977k = true;
                this.f976j = iArr.length - 1;
                return;
            }
            return;
        }
        int i4 = -1;
        for (int i5 = 0; i2 != -1 && i5 < this.f967a; i5++) {
            int[] iArr2 = this.f972f;
            int i6 = iArr2[i2];
            int i7 = iVar.f1012b;
            if (i6 == i7) {
                this.f974h[i2] = f2;
                return;
            }
            if (iArr2[i2] < i7) {
                i4 = i2;
            }
            i2 = this.f973g[i2];
        }
        int i8 = this.f976j;
        int i9 = i8 + 1;
        if (this.f977k) {
            int[] iArr3 = this.f972f;
            if (iArr3[i8] != -1) {
                i8 = iArr3.length;
            }
        } else {
            i8 = i9;
        }
        int[] iArr4 = this.f972f;
        if (i8 >= iArr4.length && this.f967a < iArr4.length) {
            int i10 = 0;
            while (true) {
                int[] iArr5 = this.f972f;
                if (i10 >= iArr5.length) {
                    break;
                }
                if (iArr5[i10] == -1) {
                    i8 = i10;
                    break;
                }
                i10++;
            }
        }
        int[] iArr6 = this.f972f;
        if (i8 >= iArr6.length) {
            i8 = iArr6.length;
            int i11 = this.f970d * 2;
            this.f970d = i11;
            this.f977k = false;
            this.f976j = i8 - 1;
            this.f974h = Arrays.copyOf(this.f974h, i11);
            this.f972f = Arrays.copyOf(this.f972f, this.f970d);
            this.f973g = Arrays.copyOf(this.f973g, this.f970d);
        }
        this.f972f[i8] = iVar.f1012b;
        this.f974h[i8] = f2;
        int[] iArr7 = this.f973g;
        if (i4 != -1) {
            iArr7[i8] = iArr7[i4];
            iArr7[i4] = i8;
        } else {
            iArr7[i8] = this.f975i;
            this.f975i = i8;
        }
        iVar.f1020j++;
        iVar.a(this.f968b);
        int i12 = this.f967a + 1;
        this.f967a = i12;
        if (!this.f977k) {
            this.f976j++;
        }
        int[] iArr8 = this.f972f;
        if (i12 >= iArr8.length) {
            this.f977k = true;
        }
        if (this.f976j >= iArr8.length) {
            this.f977k = true;
            this.f976j = iArr8.length - 1;
        }
    }

    public final float m(i iVar, boolean z) {
        if (this.f971e == iVar) {
            this.f971e = null;
        }
        int i2 = this.f975i;
        if (i2 == -1) {
            return 0.0f;
        }
        int i3 = 0;
        int i4 = -1;
        while (i2 != -1 && i3 < this.f967a) {
            if (this.f972f[i2] == iVar.f1012b) {
                if (i2 == this.f975i) {
                    this.f975i = this.f973g[i2];
                } else {
                    int[] iArr = this.f973g;
                    iArr[i4] = iArr[i2];
                }
                if (z) {
                    iVar.c(this.f968b);
                }
                iVar.f1020j--;
                this.f967a--;
                this.f972f[i2] = -1;
                if (this.f977k) {
                    this.f976j = i2;
                }
                return this.f974h[i2];
            }
            i3++;
            i4 = i2;
            i2 = this.f973g[i2];
        }
        return 0.0f;
    }

    final void n(b bVar, b bVar2, boolean z) {
        int i2 = this.f975i;
        while (true) {
            for (int i3 = 0; i2 != -1 && i3 < this.f967a; i3++) {
                int i4 = this.f972f[i2];
                i iVar = bVar2.f978a;
                if (i4 == iVar.f1012b) {
                    float f2 = this.f974h[i2];
                    m(iVar, z);
                    a aVar = bVar2.f981d;
                    int i5 = aVar.f975i;
                    for (int i6 = 0; i5 != -1 && i6 < aVar.f967a; i6++) {
                        a(this.f969c.f985c[aVar.f972f[i5]], aVar.f974h[i5] * f2, z);
                        i5 = aVar.f973g[i5];
                    }
                    bVar.f979b += bVar2.f979b * f2;
                    if (z) {
                        bVar2.f978a.c(bVar);
                    }
                    i2 = this.f975i;
                } else {
                    i2 = this.f973g[i2];
                }
            }
            return;
        }
    }

    void o(b bVar, b[] bVarArr) {
        int i2 = this.f975i;
        while (true) {
            for (int i3 = 0; i2 != -1 && i3 < this.f967a; i3++) {
                i iVar = this.f969c.f985c[this.f972f[i2]];
                if (iVar.f1013c != -1) {
                    float f2 = this.f974h[i2];
                    m(iVar, true);
                    b bVar2 = bVarArr[iVar.f1013c];
                    if (!bVar2.f982e) {
                        a aVar = bVar2.f981d;
                        int i4 = aVar.f975i;
                        for (int i5 = 0; i4 != -1 && i5 < aVar.f967a; i5++) {
                            a(this.f969c.f985c[aVar.f972f[i4]], aVar.f974h[i4] * f2, true);
                            i4 = aVar.f973g[i4];
                        }
                    }
                    bVar.f979b += bVar2.f979b * f2;
                    bVar2.f978a.c(bVar);
                    i2 = this.f975i;
                } else {
                    i2 = this.f973g[i2];
                }
            }
            return;
        }
    }

    public String toString() {
        int i2 = this.f975i;
        String str = "";
        for (int i3 = 0; i2 != -1 && i3 < this.f967a; i3++) {
            str = ((str + " -> ") + this.f974h[i2] + " : ") + this.f969c.f985c[this.f972f[i2]];
            i2 = this.f973g[i2];
        }
        return str;
    }
}
