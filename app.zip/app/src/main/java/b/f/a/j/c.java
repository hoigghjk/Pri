package b.f.a.j;

/* loaded from: classes.dex */
class c {
    static void a(g gVar, b.f.a.e eVar, int i2) {
        int i3;
        int i4;
        d[] dVarArr;
        if (i2 == 0) {
            int i5 = gVar.s0;
            dVarArr = gVar.v0;
            i4 = i5;
            i3 = 0;
        } else {
            i3 = 2;
            i4 = gVar.t0;
            dVarArr = gVar.u0;
        }
        for (int i6 = 0; i6 < i4; i6++) {
            d dVar = dVarArr[i6];
            dVar.a();
            if (!gVar.X0(4) || !k.b(gVar, eVar, i2, i3, dVar)) {
                b(gVar, eVar, i2, i3, dVar);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0031, code lost:
    
        if (r8 == 2) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0044, code lost:
    
        r5 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:293:0x0042, code lost:
    
        r5 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:301:0x0040, code lost:
    
        if (r8 == 2) goto L25;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:127:0x04ad  */
    /* JADX WARN: Removed duplicated region for block: B:130:0x04b6  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x04bd  */
    /* JADX WARN: Removed duplicated region for block: B:137:0x04cd  */
    /* JADX WARN: Removed duplicated region for block: B:147:0x04b9  */
    /* JADX WARN: Removed duplicated region for block: B:148:0x04b0  */
    /* JADX WARN: Removed duplicated region for block: B:172:0x0361  */
    /* JADX WARN: Removed duplicated region for block: B:175:0x0362 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:184:0x02e5  */
    /* JADX WARN: Removed duplicated region for block: B:186:0x030c  */
    /* JADX WARN: Removed duplicated region for block: B:188:0x0313  */
    /* JADX WARN: Removed duplicated region for block: B:194:0x0326  */
    /* JADX WARN: Removed duplicated region for block: B:197:0x0331  */
    /* JADX WARN: Removed duplicated region for block: B:199:0x0340  */
    /* JADX WARN: Removed duplicated region for block: B:201:0x0343  */
    /* JADX WARN: Removed duplicated region for block: B:202:0x033c  */
    /* JADX WARN: Removed duplicated region for block: B:203:0x02f7  */
    /* JADX WARN: Removed duplicated region for block: B:229:0x0381  */
    /* JADX WARN: Removed duplicated region for block: B:282:0x0453  */
    /* JADX WARN: Removed duplicated region for block: B:290:0x0488  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0149  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0182  */
    /* JADX WARN: Type inference failed for: r2v50, types: [b.f.a.j.f] */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v2, types: [b.f.a.j.f] */
    /* JADX WARN: Type inference failed for: r7v32 */
    /* JADX WARN: Type inference failed for: r7v33 */
    /* JADX WARN: Type inference failed for: r7v34 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    static void b(b.f.a.j.g r37, b.f.a.e r38, int r39, int r40, b.f.a.j.d r41) {
        /*
            Method dump skipped, instructions count: 1272
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.j.c.b(b.f.a.j.g, b.f.a.e, int, int, b.f.a.j.d):void");
    }
}
