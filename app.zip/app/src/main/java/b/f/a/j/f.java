package b.f.a.j;

import b.f.a.j.e;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class f {
    public static float j0 = 0.5f;
    protected e[] A;
    protected ArrayList<e> B;
    protected b[] C;
    f D;
    int E;
    int F;
    protected float G;
    protected int H;
    protected int I;
    protected int J;
    int K;
    int L;
    private int M;
    private int N;
    protected int O;
    protected int P;
    int Q;
    protected int R;
    protected int S;
    private int T;
    private int U;
    float V;
    float W;
    private Object X;
    private int Y;
    private String Z;
    private String a0;
    boolean b0;

    /* renamed from: c, reason: collision with root package name */
    m f1044c;
    boolean c0;

    /* renamed from: d, reason: collision with root package name */
    m f1045d;
    boolean d0;
    int e0;
    int f0;
    float[] g0;
    protected f[] h0;
    protected f[] i0;
    e z;

    /* renamed from: a, reason: collision with root package name */
    public int f1042a = -1;

    /* renamed from: b, reason: collision with root package name */
    public int f1043b = -1;

    /* renamed from: e, reason: collision with root package name */
    int f1046e = 0;

    /* renamed from: f, reason: collision with root package name */
    int f1047f = 0;

    /* renamed from: g, reason: collision with root package name */
    int[] f1048g = new int[2];

    /* renamed from: h, reason: collision with root package name */
    int f1049h = 0;

    /* renamed from: i, reason: collision with root package name */
    int f1050i = 0;

    /* renamed from: j, reason: collision with root package name */
    float f1051j = 1.0f;

    /* renamed from: k, reason: collision with root package name */
    int f1052k = 0;
    int l = 0;
    float m = 1.0f;
    int n = -1;
    float o = 1.0f;
    h p = null;
    private int[] q = {Integer.MAX_VALUE, Integer.MAX_VALUE};
    private float r = 0.0f;
    e s = new e(this, e.d.LEFT);
    e t = new e(this, e.d.TOP);
    e u = new e(this, e.d.RIGHT);
    e v = new e(this, e.d.BOTTOM);
    e w = new e(this, e.d.BASELINE);
    e x = new e(this, e.d.CENTER_X);
    e y = new e(this, e.d.CENTER_Y);

    static /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f1053a;

        /* renamed from: b, reason: collision with root package name */
        static final /* synthetic */ int[] f1054b;

        static {
            int[] iArr = new int[b.values().length];
            f1054b = iArr;
            try {
                iArr[b.FIXED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1054b[b.WRAP_CONTENT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1054b[b.MATCH_PARENT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f1054b[b.MATCH_CONSTRAINT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            int[] iArr2 = new int[e.d.values().length];
            f1053a = iArr2;
            try {
                iArr2[e.d.LEFT.ordinal()] = 1;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f1053a[e.d.TOP.ordinal()] = 2;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f1053a[e.d.RIGHT.ordinal()] = 3;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                f1053a[e.d.BOTTOM.ordinal()] = 4;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                f1053a[e.d.BASELINE.ordinal()] = 5;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                f1053a[e.d.CENTER.ordinal()] = 6;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                f1053a[e.d.CENTER_X.ordinal()] = 7;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                f1053a[e.d.CENTER_Y.ordinal()] = 8;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                f1053a[e.d.NONE.ordinal()] = 9;
            } catch (NoSuchFieldError unused13) {
            }
        }
    }

    public enum b {
        FIXED,
        WRAP_CONTENT,
        MATCH_CONSTRAINT,
        MATCH_PARENT
    }

    public f() {
        e eVar = new e(this, e.d.CENTER);
        this.z = eVar;
        this.A = new e[]{this.s, this.u, this.t, this.v, this.w, eVar};
        this.B = new ArrayList<>();
        b bVar = b.FIXED;
        this.C = new b[]{bVar, bVar};
        this.D = null;
        this.E = 0;
        this.F = 0;
        this.G = 0.0f;
        this.H = -1;
        this.I = 0;
        this.J = 0;
        this.K = 0;
        this.L = 0;
        this.M = 0;
        this.N = 0;
        this.O = 0;
        this.P = 0;
        this.Q = 0;
        float f2 = j0;
        this.V = f2;
        this.W = f2;
        this.Y = 0;
        this.Z = null;
        this.a0 = null;
        this.b0 = false;
        this.c0 = false;
        this.d0 = false;
        this.e0 = 0;
        this.f0 = 0;
        this.g0 = new float[]{-1.0f, -1.0f};
        this.h0 = new f[]{null, null};
        this.i0 = new f[]{null, null};
        a();
    }

    private boolean K(int i2) {
        int i3 = i2 * 2;
        e[] eVarArr = this.A;
        if (eVarArr[i3].f1035d != null && eVarArr[i3].f1035d.f1035d != eVarArr[i3]) {
            int i4 = i3 + 1;
            if (eVarArr[i4].f1035d != null && eVarArr[i4].f1035d.f1035d == eVarArr[i4]) {
                return true;
            }
        }
        return false;
    }

    private void a() {
        this.B.add(this.s);
        this.B.add(this.t);
        this.B.add(this.u);
        this.B.add(this.v);
        this.B.add(this.x);
        this.B.add(this.y);
        this.B.add(this.z);
        this.B.add(this.w);
    }

    /* JADX WARN: Code restructure failed: missing block: B:76:0x01e9, code lost:
    
        if (r26 != false) goto L117;
     */
    /* JADX WARN: Removed duplicated region for block: B:101:0x0283  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x02da  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x02e1 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:111:0x02ee A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:114:0x02fc  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x0305  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x02dd  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x02ca  */
    /* JADX WARN: Removed duplicated region for block: B:150:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:168:0x01be A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00db  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x030c  */
    /* JADX WARN: Removed duplicated region for block: B:72:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void e(b.f.a.e r25, boolean r26, b.f.a.i r27, b.f.a.i r28, b.f.a.j.f.b r29, boolean r30, b.f.a.j.e r31, b.f.a.j.e r32, int r33, int r34, int r35, int r36, float r37, boolean r38, boolean r39, int r40, int r41, int r42, float r43, boolean r44) {
        /*
            Method dump skipped, instructions count: 804
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.j.f.e(b.f.a.e, boolean, b.f.a.i, b.f.a.i, b.f.a.j.f$b, boolean, b.f.a.j.e, b.f.a.j.e, int, int, int, int, float, boolean, boolean, int, int, int, float, boolean):void");
    }

    protected int A() {
        return this.J + this.P;
    }

    public void A0(int i2) {
        this.U = i2;
    }

    public b B() {
        return this.C[1];
    }

    public void B0(int i2) {
        this.T = i2;
    }

    public int C() {
        return this.Y;
    }

    public void C0(int i2) {
        this.I = i2;
    }

    public int D() {
        if (this.Y == 8) {
            return 0;
        }
        return this.E;
    }

    public void D0(int i2) {
        this.J = i2;
    }

    public int E() {
        return this.U;
    }

    public void E0(boolean z, boolean z2, boolean z3, boolean z4) {
        if (this.n == -1) {
            if (z3 && !z4) {
                this.n = 0;
            } else if (!z3 && z4) {
                this.n = 1;
                if (this.H == -1) {
                    this.o = 1.0f / this.o;
                }
            }
        }
        if (this.n == 0 && (!this.t.k() || !this.v.k())) {
            this.n = 1;
        } else if (this.n == 1 && (!this.s.k() || !this.u.k())) {
            this.n = 0;
        }
        if (this.n == -1 && (!this.t.k() || !this.v.k() || !this.s.k() || !this.u.k())) {
            if (this.t.k() && this.v.k()) {
                this.n = 0;
            } else if (this.s.k() && this.u.k()) {
                this.o = 1.0f / this.o;
                this.n = 1;
            }
        }
        if (this.n == -1) {
            if (z && !z2) {
                this.n = 0;
            } else if (!z && z2) {
                this.o = 1.0f / this.o;
                this.n = 1;
            }
        }
        if (this.n == -1) {
            int i2 = this.f1049h;
            if (i2 > 0 && this.f1052k == 0) {
                this.n = 0;
            } else if (i2 == 0 && this.f1052k > 0) {
                this.o = 1.0f / this.o;
                this.n = 1;
            }
        }
        if (this.n == -1 && z && z2) {
            this.o = 1.0f / this.o;
            this.n = 1;
        }
    }

    public int F() {
        return this.T;
    }

    public void F0() {
        int i2 = this.I;
        int i3 = this.J;
        this.M = i2;
        this.N = i3;
    }

    public int G() {
        return this.I;
    }

    public void G0(b.f.a.e eVar) {
        int y = eVar.y(this.s);
        int y2 = eVar.y(this.t);
        int y3 = eVar.y(this.u);
        int y4 = eVar.y(this.v);
        int i2 = y4 - y2;
        if (y3 - y < 0 || i2 < 0 || y == Integer.MIN_VALUE || y == Integer.MAX_VALUE || y2 == Integer.MIN_VALUE || y2 == Integer.MAX_VALUE || y3 == Integer.MIN_VALUE || y3 == Integer.MAX_VALUE || y4 == Integer.MIN_VALUE || y4 == Integer.MAX_VALUE) {
            y4 = 0;
            y = 0;
            y2 = 0;
            y3 = 0;
        }
        a0(y, y2, y3, y4);
    }

    public int H() {
        return this.J;
    }

    public void H0() {
        for (int i2 = 0; i2 < 6; i2++) {
            this.A[i2].f().q();
        }
    }

    public boolean I() {
        return this.Q > 0;
    }

    public void J(e.d dVar, f fVar, e.d dVar2, int i2, int i3) {
        h(dVar).a(fVar.h(dVar2), i2, i3, e.c.STRONG, 0, true);
    }

    public boolean L() {
        return this.s.f().f1079b == 1 && this.u.f().f1079b == 1 && this.t.f().f1079b == 1 && this.v.f().f1079b == 1;
    }

    public boolean M() {
        e eVar = this.s;
        e eVar2 = eVar.f1035d;
        if (eVar2 != null && eVar2.f1035d == eVar) {
            return true;
        }
        e eVar3 = this.u;
        e eVar4 = eVar3.f1035d;
        return eVar4 != null && eVar4.f1035d == eVar3;
    }

    public boolean N() {
        e eVar = this.t;
        e eVar2 = eVar.f1035d;
        if (eVar2 != null && eVar2.f1035d == eVar) {
            return true;
        }
        e eVar3 = this.v;
        e eVar4 = eVar3.f1035d;
        return eVar4 != null && eVar4.f1035d == eVar3;
    }

    public boolean O() {
        return this.f1047f == 0 && this.G == 0.0f && this.f1052k == 0 && this.l == 0 && this.C[1] == b.MATCH_CONSTRAINT;
    }

    public boolean P() {
        return this.f1046e == 0 && this.G == 0.0f && this.f1049h == 0 && this.f1050i == 0 && this.C[0] == b.MATCH_CONSTRAINT;
    }

    public void Q() {
        this.s.m();
        this.t.m();
        this.u.m();
        this.v.m();
        this.w.m();
        this.x.m();
        this.y.m();
        this.z.m();
        this.D = null;
        this.r = 0.0f;
        this.E = 0;
        this.F = 0;
        this.G = 0.0f;
        this.H = -1;
        this.I = 0;
        this.J = 0;
        this.M = 0;
        this.N = 0;
        this.O = 0;
        this.P = 0;
        this.Q = 0;
        this.R = 0;
        this.S = 0;
        this.T = 0;
        this.U = 0;
        float f2 = j0;
        this.V = f2;
        this.W = f2;
        b[] bVarArr = this.C;
        b bVar = b.FIXED;
        bVarArr[0] = bVar;
        bVarArr[1] = bVar;
        this.X = null;
        this.Y = 0;
        this.a0 = null;
        this.e0 = 0;
        this.f0 = 0;
        float[] fArr = this.g0;
        fArr[0] = -1.0f;
        fArr[1] = -1.0f;
        this.f1042a = -1;
        this.f1043b = -1;
        int[] iArr = this.q;
        iArr[0] = Integer.MAX_VALUE;
        iArr[1] = Integer.MAX_VALUE;
        this.f1046e = 0;
        this.f1047f = 0;
        this.f1051j = 1.0f;
        this.m = 1.0f;
        this.f1050i = Integer.MAX_VALUE;
        this.l = Integer.MAX_VALUE;
        this.f1049h = 0;
        this.f1052k = 0;
        this.n = -1;
        this.o = 1.0f;
        m mVar = this.f1044c;
        if (mVar != null) {
            mVar.e();
        }
        m mVar2 = this.f1045d;
        if (mVar2 != null) {
            mVar2.e();
        }
        this.p = null;
        this.b0 = false;
        this.c0 = false;
        this.d0 = false;
    }

    public void R() {
        f u = u();
        if (u != null && (u instanceof g) && ((g) u()).S0()) {
            return;
        }
        int size = this.B.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.B.get(i2).m();
        }
    }

    public void S() {
        for (int i2 = 0; i2 < 6; i2++) {
            this.A[i2].f().e();
        }
    }

    public void T(b.f.a.c cVar) {
        this.s.n(cVar);
        this.t.n(cVar);
        this.u.n(cVar);
        this.v.n(cVar);
        this.w.n(cVar);
        this.z.n(cVar);
        this.x.n(cVar);
        this.y.n(cVar);
    }

    public void U() {
    }

    public void V(int i2) {
        this.Q = i2;
    }

    public void W(Object obj) {
        this.X = obj;
    }

    public void X(String str) {
        this.Z = str;
    }

    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:38:0x0084 -> B:31:0x0085). Please report as a decompilation issue!!! */
    public void Y(String str) {
        float f2;
        int i2 = 0;
        if (str == null || str.length() == 0) {
            this.G = 0.0f;
            return;
        }
        int i3 = -1;
        int length = str.length();
        int indexOf = str.indexOf(44);
        int i4 = 0;
        if (indexOf > 0 && indexOf < length - 1) {
            String substring = str.substring(0, indexOf);
            if (substring.equalsIgnoreCase("W")) {
                i3 = 0;
            } else if (substring.equalsIgnoreCase("H")) {
                i3 = 1;
            }
            i4 = indexOf + 1;
        }
        int indexOf2 = str.indexOf(58);
        if (indexOf2 < 0 || indexOf2 >= length - 1) {
            String substring2 = str.substring(i4);
            if (substring2.length() > 0) {
                f2 = Float.parseFloat(substring2);
            }
            f2 = 0.0f;
        } else {
            String substring3 = str.substring(i4, indexOf2);
            String substring4 = str.substring(indexOf2 + 1);
            if (substring3.length() > 0 && substring4.length() > 0) {
                float parseFloat = Float.parseFloat(substring3);
                float parseFloat2 = Float.parseFloat(substring4);
                if (parseFloat > 0.0f && parseFloat2 > 0.0f) {
                    f2 = i3 == 1 ? Math.abs(parseFloat2 / parseFloat) : Math.abs(parseFloat / parseFloat2);
                }
            }
            f2 = 0.0f;
        }
        i2 = (f2 > i2 ? 1 : (f2 == i2 ? 0 : -1));
        if (i2 > 0) {
            this.G = f2;
            this.H = i3;
        }
    }

    public void Z(int i2, int i3, int i4) {
        if (i4 == 0) {
            f0(i2, i3);
        } else if (i4 == 1) {
            t0(i2, i3);
        }
        this.c0 = true;
    }

    public void a0(int i2, int i3, int i4, int i5) {
        int i6;
        int i7;
        int i8 = i4 - i2;
        int i9 = i5 - i3;
        this.I = i2;
        this.J = i3;
        if (this.Y == 8) {
            this.E = 0;
            this.F = 0;
            return;
        }
        b[] bVarArr = this.C;
        b bVar = bVarArr[0];
        b bVar2 = b.FIXED;
        if (bVar == bVar2 && i8 < (i7 = this.E)) {
            i8 = i7;
        }
        if (bVarArr[1] == bVar2 && i9 < (i6 = this.F)) {
            i9 = i6;
        }
        this.E = i8;
        this.F = i9;
        int i10 = this.S;
        if (i9 < i10) {
            this.F = i10;
        }
        int i11 = this.R;
        if (i8 < i11) {
            this.E = i11;
        }
        this.c0 = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:115:0x0295  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x02a4  */
    /* JADX WARN: Removed duplicated region for block: B:121:0x02e3  */
    /* JADX WARN: Removed duplicated region for block: B:127:0x0311  */
    /* JADX WARN: Removed duplicated region for block: B:129:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:131:0x0307  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x02ac  */
    /* JADX WARN: Removed duplicated region for block: B:133:0x029e  */
    /* JADX WARN: Removed duplicated region for block: B:142:0x0222  */
    /* JADX WARN: Removed duplicated region for block: B:145:0x0196 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:73:0x018c  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x01a2  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x01bb  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x0233 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:95:0x0234  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void b(b.f.a.e r42) {
        /*
            Method dump skipped, instructions count: 818
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.j.f.b(b.f.a.e):void");
    }

    public void b0(int i2) {
        this.F = i2;
        int i3 = this.S;
        if (i2 < i3) {
            this.F = i3;
        }
    }

    public boolean c() {
        return this.Y != 8;
    }

    public void c0(boolean z) {
    }

    public void d(int i2) {
        k.a(i2, this);
    }

    public void d0(float f2) {
        this.V = f2;
    }

    public void e0(int i2) {
        this.e0 = i2;
    }

    public void f(f fVar, float f2, int i2) {
        e.d dVar = e.d.CENTER;
        J(dVar, fVar, dVar, i2, 0);
        this.r = f2;
    }

    public void f0(int i2, int i3) {
        this.I = i2;
        int i4 = i3 - i2;
        this.E = i4;
        int i5 = this.R;
        if (i4 < i5) {
            this.E = i5;
        }
    }

    public void g(b.f.a.e eVar) {
        eVar.r(this.s);
        eVar.r(this.t);
        eVar.r(this.u);
        eVar.r(this.v);
        if (this.Q > 0) {
            eVar.r(this.w);
        }
    }

    public void g0(b bVar) {
        this.C[0] = bVar;
        if (bVar == b.WRAP_CONTENT) {
            y0(this.T);
        }
    }

    public e h(e.d dVar) {
        switch (a.f1053a[dVar.ordinal()]) {
            case 1:
                return this.s;
            case 2:
                return this.t;
            case 3:
                return this.u;
            case 4:
                return this.v;
            case 5:
                return this.w;
            case 6:
                return this.z;
            case 7:
                return this.x;
            case 8:
                return this.y;
            case 9:
                return null;
            default:
                throw new AssertionError(dVar.name());
        }
    }

    public void h0(int i2, int i3, int i4, float f2) {
        this.f1046e = i2;
        this.f1049h = i3;
        this.f1050i = i4;
        this.f1051j = f2;
        if (f2 >= 1.0f || i2 != 0) {
            return;
        }
        this.f1046e = 2;
    }

    public ArrayList<e> i() {
        return this.B;
    }

    public void i0(float f2) {
        this.g0[0] = f2;
    }

    public int j() {
        return this.Q;
    }

    public void j0(int i2) {
        this.q[1] = i2;
    }

    public float k(int i2) {
        if (i2 == 0) {
            return this.V;
        }
        if (i2 == 1) {
            return this.W;
        }
        return -1.0f;
    }

    public void k0(int i2) {
        this.q[0] = i2;
    }

    public int l() {
        return H() + this.F;
    }

    public void l0(int i2) {
        if (i2 < 0) {
            i2 = 0;
        }
        this.S = i2;
    }

    public Object m() {
        return this.X;
    }

    public void m0(int i2) {
        if (i2 < 0) {
            i2 = 0;
        }
        this.R = i2;
    }

    public String n() {
        return this.Z;
    }

    public void n0(int i2, int i3) {
        this.O = i2;
        this.P = i3;
    }

    public b o(int i2) {
        if (i2 == 0) {
            return s();
        }
        if (i2 == 1) {
            return B();
        }
        return null;
    }

    public void o0(int i2, int i3) {
        this.I = i2;
        this.J = i3;
    }

    public int p() {
        return this.M + this.O;
    }

    public void p0(f fVar) {
        this.D = fVar;
    }

    public int q() {
        return this.N + this.P;
    }

    void q0(int i2, int i3) {
        if (i3 == 0) {
            this.K = i2;
        } else if (i3 == 1) {
            this.L = i2;
        }
    }

    public int r() {
        if (this.Y == 8) {
            return 0;
        }
        return this.F;
    }

    public void r0(float f2) {
        this.W = f2;
    }

    public b s() {
        return this.C[0];
    }

    public void s0(int i2) {
        this.f0 = i2;
    }

    public int t(int i2) {
        if (i2 == 0) {
            return D();
        }
        if (i2 == 1) {
            return r();
        }
        return 0;
    }

    public void t0(int i2, int i3) {
        this.J = i2;
        int i4 = i3 - i2;
        this.F = i4;
        int i5 = this.S;
        if (i4 < i5) {
            this.F = i5;
        }
    }

    public String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        String str2 = "";
        if (this.a0 != null) {
            str = "type: " + this.a0 + " ";
        } else {
            str = "";
        }
        sb.append(str);
        if (this.Z != null) {
            str2 = "id: " + this.Z + " ";
        }
        sb.append(str2);
        sb.append("(");
        sb.append(this.I);
        sb.append(", ");
        sb.append(this.J);
        sb.append(") - (");
        sb.append(this.E);
        sb.append(" x ");
        sb.append(this.F);
        sb.append(") wrap: (");
        sb.append(this.T);
        sb.append(" x ");
        sb.append(this.U);
        sb.append(")");
        return sb.toString();
    }

    public f u() {
        return this.D;
    }

    public void u0(b bVar) {
        this.C[1] = bVar;
        if (bVar == b.WRAP_CONTENT) {
            b0(this.U);
        }
    }

    int v(int i2) {
        if (i2 == 0) {
            return this.K;
        }
        if (i2 == 1) {
            return this.L;
        }
        return 0;
    }

    public void v0(int i2, int i3, int i4, float f2) {
        this.f1047f = i2;
        this.f1052k = i3;
        this.l = i4;
        this.m = f2;
        if (f2 >= 1.0f || i2 != 0) {
            return;
        }
        this.f1047f = 2;
    }

    public m w() {
        if (this.f1045d == null) {
            this.f1045d = new m();
        }
        return this.f1045d;
    }

    public void w0(float f2) {
        this.g0[1] = f2;
    }

    public m x() {
        if (this.f1044c == null) {
            this.f1044c = new m();
        }
        return this.f1044c;
    }

    public void x0(int i2) {
        this.Y = i2;
    }

    public int y() {
        return G() + this.E;
    }

    public void y0(int i2) {
        this.E = i2;
        int i3 = this.R;
        if (i2 < i3) {
            this.E = i3;
        }
    }

    protected int z() {
        return this.I + this.O;
    }

    public void z0(boolean z) {
    }
}
