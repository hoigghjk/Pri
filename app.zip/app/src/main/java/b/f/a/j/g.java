package b.f.a.j;

import b.f.a.j.e;
import b.f.a.j.f;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* loaded from: classes.dex */
public class g extends p {
    private o n0;
    int o0;
    int p0;
    int q0;
    int r0;
    private boolean l0 = false;
    protected b.f.a.e m0 = new b.f.a.e();
    int s0 = 0;
    int t0 = 0;
    d[] u0 = new d[4];
    d[] v0 = new d[4];
    public List<h> w0 = new ArrayList();
    public boolean x0 = false;
    public boolean y0 = false;
    public boolean z0 = false;
    public int A0 = 0;
    public int B0 = 0;
    private int C0 = 7;
    public boolean D0 = false;
    private boolean E0 = false;
    private boolean F0 = false;

    private void P0(f fVar) {
        int i2 = this.s0 + 1;
        d[] dVarArr = this.v0;
        if (i2 >= dVarArr.length) {
            this.v0 = (d[]) Arrays.copyOf(dVarArr, dVarArr.length * 2);
        }
        this.v0[this.s0] = new d(fVar, 0, U0());
        this.s0++;
    }

    private void Q0(f fVar) {
        int i2 = this.t0 + 1;
        d[] dVarArr = this.u0;
        if (i2 >= dVarArr.length) {
            this.u0 = (d[]) Arrays.copyOf(dVarArr, dVarArr.length * 2);
        }
        this.u0[this.t0] = new d(fVar, 1, U0());
        this.t0++;
    }

    private void b1() {
        this.s0 = 0;
        this.t0 = 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:110:0x027e  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x018b  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x0180  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x01d9  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x0254  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x0271  */
    /* JADX WARN: Removed duplicated region for block: B:94:0x0283  */
    /* JADX WARN: Type inference failed for: r8v20 */
    /* JADX WARN: Type inference failed for: r8v21, types: [boolean] */
    /* JADX WARN: Type inference failed for: r8v25 */
    @Override // b.f.a.j.p
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void K0() {
        /*
            Method dump skipped, instructions count: 831
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.j.g.K0():void");
    }

    void N0(f fVar, int i2) {
        if (i2 == 0) {
            P0(fVar);
        } else if (i2 == 1) {
            Q0(fVar);
        }
    }

    public boolean O0(b.f.a.e eVar) {
        b(eVar);
        int size = this.k0.size();
        for (int i2 = 0; i2 < size; i2++) {
            f fVar = this.k0.get(i2);
            if (fVar instanceof g) {
                f.b[] bVarArr = fVar.C;
                f.b bVar = bVarArr[0];
                f.b bVar2 = bVarArr[1];
                f.b bVar3 = f.b.WRAP_CONTENT;
                if (bVar == bVar3) {
                    fVar.g0(f.b.FIXED);
                }
                if (bVar2 == bVar3) {
                    fVar.u0(f.b.FIXED);
                }
                fVar.b(eVar);
                if (bVar == bVar3) {
                    fVar.g0(bVar);
                }
                if (bVar2 == bVar3) {
                    fVar.u0(bVar2);
                }
            } else {
                k.c(this, eVar, fVar);
                fVar.b(eVar);
            }
        }
        if (this.s0 > 0) {
            c.a(this, eVar, 0);
        }
        if (this.t0 > 0) {
            c.a(this, eVar, 1);
        }
        return true;
    }

    @Override // b.f.a.j.p, b.f.a.j.f
    public void Q() {
        this.m0.E();
        this.o0 = 0;
        this.q0 = 0;
        this.p0 = 0;
        this.r0 = 0;
        this.w0.clear();
        this.D0 = false;
        super.Q();
    }

    public int R0() {
        return this.C0;
    }

    public boolean S0() {
        return false;
    }

    public boolean T0() {
        return this.F0;
    }

    public boolean U0() {
        return this.l0;
    }

    public boolean V0() {
        return this.E0;
    }

    public void W0() {
        if (!X0(8)) {
            d(this.C0);
        }
        e1();
    }

    public boolean X0(int i2) {
        return (this.C0 & i2) == i2;
    }

    public void Y0(int i2, int i3) {
        m mVar;
        m mVar2;
        f.b bVar = this.C[0];
        f.b bVar2 = f.b.WRAP_CONTENT;
        if (bVar != bVar2 && (mVar2 = this.f1044c) != null) {
            mVar2.h(i2);
        }
        if (this.C[1] == bVar2 || (mVar = this.f1045d) == null) {
            return;
        }
        mVar.h(i3);
    }

    public void Z0() {
        int size = this.k0.size();
        S();
        for (int i2 = 0; i2 < size; i2++) {
            this.k0.get(i2).S();
        }
    }

    public void a1() {
        Z0();
        d(this.C0);
    }

    public void c1(int i2) {
        this.C0 = i2;
    }

    @Override // b.f.a.j.f
    public void d(int i2) {
        super.d(i2);
        int size = this.k0.size();
        for (int i3 = 0; i3 < size; i3++) {
            this.k0.get(i3).d(i2);
        }
    }

    public void d1(boolean z) {
        this.l0 = z;
    }

    public void e1() {
        l f2 = h(e.d.LEFT).f();
        l f3 = h(e.d.TOP).f();
        f2.l(null, 0.0f);
        f3.l(null, 0.0f);
    }

    public void f1(b.f.a.e eVar, boolean[] zArr) {
        zArr[2] = false;
        G0(eVar);
        int size = this.k0.size();
        for (int i2 = 0; i2 < size; i2++) {
            f fVar = this.k0.get(i2);
            fVar.G0(eVar);
            f.b bVar = fVar.C[0];
            f.b bVar2 = f.b.MATCH_CONSTRAINT;
            if (bVar == bVar2 && fVar.D() < fVar.F()) {
                zArr[2] = true;
            }
            if (fVar.C[1] == bVar2 && fVar.r() < fVar.E()) {
                zArr[2] = true;
            }
        }
    }
}
