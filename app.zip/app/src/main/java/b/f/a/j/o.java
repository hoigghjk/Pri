package b.f.a.j;

import b.f.a.j.e;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class o {

    /* renamed from: a, reason: collision with root package name */
    private int f1080a;

    /* renamed from: b, reason: collision with root package name */
    private int f1081b;

    /* renamed from: c, reason: collision with root package name */
    private int f1082c;

    /* renamed from: d, reason: collision with root package name */
    private int f1083d;

    /* renamed from: e, reason: collision with root package name */
    private ArrayList<a> f1084e = new ArrayList<>();

    static class a {

        /* renamed from: a, reason: collision with root package name */
        private e f1085a;

        /* renamed from: b, reason: collision with root package name */
        private e f1086b;

        /* renamed from: c, reason: collision with root package name */
        private int f1087c;

        /* renamed from: d, reason: collision with root package name */
        private e.c f1088d;

        /* renamed from: e, reason: collision with root package name */
        private int f1089e;

        public a(e eVar) {
            this.f1085a = eVar;
            this.f1086b = eVar.i();
            this.f1087c = eVar.d();
            this.f1088d = eVar.h();
            this.f1089e = eVar.c();
        }

        public void a(f fVar) {
            fVar.h(this.f1085a.j()).b(this.f1086b, this.f1087c, this.f1088d, this.f1089e);
        }

        public void b(f fVar) {
            int i2;
            e h2 = fVar.h(this.f1085a.j());
            this.f1085a = h2;
            if (h2 != null) {
                this.f1086b = h2.i();
                this.f1087c = this.f1085a.d();
                this.f1088d = this.f1085a.h();
                i2 = this.f1085a.c();
            } else {
                this.f1086b = null;
                i2 = 0;
                this.f1087c = 0;
                this.f1088d = e.c.STRONG;
            }
            this.f1089e = i2;
        }
    }

    public o(f fVar) {
        this.f1080a = fVar.G();
        this.f1081b = fVar.H();
        this.f1082c = fVar.D();
        this.f1083d = fVar.r();
        ArrayList<e> i2 = fVar.i();
        int size = i2.size();
        for (int i3 = 0; i3 < size; i3++) {
            this.f1084e.add(new a(i2.get(i3)));
        }
    }

    public void a(f fVar) {
        fVar.C0(this.f1080a);
        fVar.D0(this.f1081b);
        fVar.y0(this.f1082c);
        fVar.b0(this.f1083d);
        int size = this.f1084e.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f1084e.get(i2).a(fVar);
        }
    }

    public void b(f fVar) {
        this.f1080a = fVar.G();
        this.f1081b = fVar.H();
        this.f1082c = fVar.D();
        this.f1083d = fVar.r();
        int size = this.f1084e.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f1084e.get(i2).b(fVar);
        }
    }
}
