package b.f.a.j;

import java.util.HashSet;
import java.util.Iterator;

/* loaded from: classes.dex */
public class n {

    /* renamed from: a, reason: collision with root package name */
    HashSet<n> f1078a = new HashSet<>(2);

    /* renamed from: b, reason: collision with root package name */
    int f1079b = 0;

    public void a(n nVar) {
        this.f1078a.add(nVar);
    }

    public void b() {
        this.f1079b = 1;
        Iterator<n> it = this.f1078a.iterator();
        while (it.hasNext()) {
            it.next().f();
        }
    }

    public void c() {
        this.f1079b = 0;
        Iterator<n> it = this.f1078a.iterator();
        while (it.hasNext()) {
            it.next().c();
        }
    }

    public boolean d() {
        return this.f1079b == 1;
    }

    public void e() {
        this.f1079b = 0;
        this.f1078a.clear();
    }

    public void f() {
    }
}
