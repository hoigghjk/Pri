package b.f.a;

/* loaded from: classes.dex */
public class c {

    /* renamed from: a, reason: collision with root package name */
    g<b> f983a = new h(256);

    /* renamed from: b, reason: collision with root package name */
    g<i> f984b = new h(256);

    /* renamed from: c, reason: collision with root package name */
    i[] f985c = new i[32];
}
