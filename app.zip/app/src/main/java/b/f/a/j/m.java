package b.f.a.j;

/* loaded from: classes.dex */
public class m extends n {

    /* renamed from: c, reason: collision with root package name */
    float f1077c = 0.0f;

    @Override // b.f.a.j.n
    public void e() {
        super.e();
        this.f1077c = 0.0f;
    }

    public void g() {
        this.f1079b = 2;
    }

    public void h(int i2) {
        int i3 = this.f1079b;
        if (i3 == 0 || this.f1077c != i2) {
            this.f1077c = i2;
            if (i3 == 1) {
                c();
            }
            b();
        }
    }
}
