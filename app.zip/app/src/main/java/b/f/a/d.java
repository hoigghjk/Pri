package b.f.a;

/* loaded from: classes.dex */
public class d extends b {
    public d(c cVar) {
        super(cVar);
    }

    @Override // b.f.a.b, b.f.a.e.a
    public void b(i iVar) {
        super.b(iVar);
        iVar.f1020j--;
    }
}
