package b.f.a.j;

import b.f.a.j.f;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public class a {
    public static void a(g gVar) {
        if ((gVar.R0() & 32) != 32) {
            j(gVar);
            return;
        }
        gVar.D0 = true;
        gVar.x0 = false;
        gVar.y0 = false;
        gVar.z0 = false;
        ArrayList<f> arrayList = gVar.k0;
        List<h> list = gVar.w0;
        f.b s = gVar.s();
        f.b bVar = f.b.WRAP_CONTENT;
        boolean z = s == bVar;
        boolean z2 = gVar.B() == bVar;
        boolean z3 = z || z2;
        list.clear();
        for (f fVar : arrayList) {
            fVar.p = null;
            fVar.d0 = false;
            fVar.S();
        }
        for (f fVar2 : arrayList) {
            if (fVar2.p == null && !b(fVar2, list, z3)) {
                j(gVar);
                gVar.D0 = false;
                return;
            }
        }
        int i2 = 0;
        int i3 = 0;
        for (h hVar : list) {
            i2 = Math.max(i2, c(hVar, 0));
            i3 = Math.max(i3, c(hVar, 1));
        }
        if (z) {
            gVar.g0(f.b.FIXED);
            gVar.y0(i2);
            gVar.x0 = true;
            gVar.y0 = true;
            gVar.A0 = i2;
        }
        if (z2) {
            gVar.u0(f.b.FIXED);
            gVar.b0(i3);
            gVar.x0 = true;
            gVar.z0 = true;
            gVar.B0 = i3;
        }
        i(list, 0, gVar.D());
        i(list, 1, gVar.r());
    }

    private static boolean b(f fVar, List<h> list, boolean z) {
        h hVar = new h(new ArrayList(), true);
        list.add(hVar);
        return k(fVar, hVar, list, z);
    }

    private static int c(h hVar, int i2) {
        int i3 = i2 * 2;
        List<f> b2 = hVar.b(i2);
        int size = b2.size();
        int i4 = 0;
        for (int i5 = 0; i5 < size; i5++) {
            f fVar = b2.get(i5);
            e[] eVarArr = fVar.A;
            int i6 = i3 + 1;
            i4 = Math.max(i4, d(fVar, i2, eVarArr[i6].f1035d == null || !(eVarArr[i3].f1035d == null || eVarArr[i6].f1035d == null), 0));
        }
        hVar.f1059e[i2] = i4;
        return i4;
    }

    private static int d(f fVar, int i2, boolean z, int i3) {
        int r;
        int j2;
        int i4;
        int i5;
        int i6;
        int D;
        int i7;
        int i8;
        int i9;
        int i10 = 0;
        if (!fVar.b0) {
            return 0;
        }
        boolean z2 = fVar.w.f1035d != null && i2 == 1;
        if (z) {
            r = fVar.j();
            j2 = fVar.r() - fVar.j();
            i5 = i2 * 2;
            i4 = i5 + 1;
        } else {
            r = fVar.r() - fVar.j();
            j2 = fVar.j();
            i4 = i2 * 2;
            i5 = i4 + 1;
        }
        e[] eVarArr = fVar.A;
        if (eVarArr[i4].f1035d == null || eVarArr[i5].f1035d != null) {
            i6 = 1;
        } else {
            i6 = -1;
            int i11 = i4;
            i4 = i5;
            i5 = i11;
        }
        int i12 = z2 ? i3 - r : i3;
        int d2 = (eVarArr[i5].d() * i6) + e(fVar, i2);
        int i13 = i12 + d2;
        int D2 = (i2 == 0 ? fVar.D() : fVar.r()) * i6;
        Iterator<n> it = fVar.A[i5].f().f1078a.iterator();
        while (it.hasNext()) {
            i10 = Math.max(i10, d(((l) it.next()).f1068c.f1033b, i2, z, i13));
        }
        int i14 = 0;
        for (Iterator<n> it2 = fVar.A[i4].f().f1078a.iterator(); it2.hasNext(); it2 = it2) {
            i14 = Math.max(i14, d(((l) it2.next()).f1068c.f1033b, i2, z, D2 + i13));
        }
        if (z2) {
            i10 -= r;
            D = i14 + j2;
        } else {
            D = i14 + ((i2 == 0 ? fVar.D() : fVar.r()) * i6);
        }
        int i15 = 1;
        if (i2 == 1) {
            Iterator<n> it3 = fVar.w.f().f1078a.iterator();
            int i16 = 0;
            while (it3.hasNext()) {
                Iterator<n> it4 = it3;
                l lVar = (l) it3.next();
                if (i6 == i15) {
                    i16 = Math.max(i16, d(lVar.f1068c.f1033b, i2, z, r + i13));
                    i9 = i4;
                } else {
                    i9 = i4;
                    i16 = Math.max(i16, d(lVar.f1068c.f1033b, i2, z, (j2 * i6) + i13));
                }
                it3 = it4;
                i4 = i9;
                i15 = 1;
            }
            i7 = i4;
            int i17 = i16;
            i8 = (fVar.w.f().f1078a.size() <= 0 || z2) ? i17 : i6 == 1 ? i17 + r : i17 - j2;
        } else {
            i7 = i4;
            i8 = 0;
        }
        int max = d2 + Math.max(i10, Math.max(D, i8));
        int i18 = D2 + i13;
        if (i6 == -1) {
            i18 = i13;
            i13 = i18;
        }
        if (z) {
            k.e(fVar, i2, i13);
            fVar.Z(i13, i18, i2);
        } else {
            fVar.p.a(fVar, i2);
            fVar.q0(i13, i2);
        }
        if (fVar.o(i2) == f.b.MATCH_CONSTRAINT && fVar.G != 0.0f) {
            fVar.p.a(fVar, i2);
        }
        e[] eVarArr2 = fVar.A;
        if (eVarArr2[i5].f1035d != null && eVarArr2[i7].f1035d != null) {
            f u = fVar.u();
            e[] eVarArr3 = fVar.A;
            if (eVarArr3[i5].f1035d.f1033b == u && eVarArr3[i7].f1035d.f1033b == u) {
                fVar.p.a(fVar, i2);
            }
        }
        return max;
    }

    private static int e(f fVar, int i2) {
        e eVar;
        int i3 = i2 * 2;
        e[] eVarArr = fVar.A;
        e eVar2 = eVarArr[i3];
        e eVar3 = eVarArr[i3 + 1];
        e eVar4 = eVar2.f1035d;
        if (eVar4 == null) {
            return 0;
        }
        f fVar2 = eVar4.f1033b;
        f fVar3 = fVar.D;
        if (fVar2 != fVar3 || (eVar = eVar3.f1035d) == null || eVar.f1033b != fVar3) {
            return 0;
        }
        return (int) ((((fVar3.t(i2) - eVar2.d()) - eVar3.d()) - fVar.t(i2)) * (i2 == 0 ? fVar.V : fVar.W));
    }

    private static void f(g gVar, f fVar, h hVar) {
        hVar.f1058d = false;
        gVar.D0 = false;
        fVar.b0 = false;
    }

    private static int g(f fVar) {
        f.b s = fVar.s();
        f.b bVar = f.b.MATCH_CONSTRAINT;
        if (s == bVar) {
            int r = (int) (fVar.H == 0 ? fVar.r() * fVar.G : fVar.r() / fVar.G);
            fVar.y0(r);
            return r;
        }
        if (fVar.B() != bVar) {
            return -1;
        }
        int D = (int) (fVar.H == 1 ? fVar.D() * fVar.G : fVar.D() / fVar.G);
        fVar.b0(D);
        return D;
    }

    private static void h(e eVar) {
        l f2 = eVar.f();
        e eVar2 = eVar.f1035d;
        if (eVar2 == null || eVar2.f1035d == eVar) {
            return;
        }
        eVar2.f().a(f2);
    }

    public static void i(List<h> list, int i2, int i3) {
        int size = list.size();
        for (int i4 = 0; i4 < size; i4++) {
            for (f fVar : list.get(i4).c(i2)) {
                if (fVar.b0) {
                    l(fVar, i2, i3);
                }
            }
        }
    }

    private static void j(g gVar) {
        gVar.w0.clear();
        gVar.w0.add(0, new h(gVar.k0));
    }

    /* JADX WARN: Code restructure failed: missing block: B:135:0x015b, code lost:
    
        if (r4.f1033b == r5) goto L115;
     */
    /* JADX WARN: Code restructure failed: missing block: B:151:0x0112, code lost:
    
        if (r4.f1033b == r5) goto L88;
     */
    /* JADX WARN: Removed duplicated region for block: B:131:0x0151  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x017a  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x019c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static boolean k(b.f.a.j.f r8, b.f.a.j.h r9, java.util.List<b.f.a.j.h> r10, boolean r11) {
        /*
            Method dump skipped, instructions count: 520
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.f.a.j.a.k(b.f.a.j.f, b.f.a.j.h, java.util.List, boolean):boolean");
    }

    private static void l(f fVar, int i2, int i3) {
        int i4 = i2 * 2;
        e[] eVarArr = fVar.A;
        e eVar = eVarArr[i4];
        e eVar2 = eVarArr[i4 + 1];
        if ((eVar.f1035d == null || eVar2.f1035d == null) ? false : true) {
            k.e(fVar, i2, e(fVar, i2) + eVar.d());
            return;
        }
        if (fVar.G == 0.0f || fVar.o(i2) != f.b.MATCH_CONSTRAINT) {
            int v = i3 - fVar.v(i2);
            int t = v - fVar.t(i2);
            fVar.Z(t, v, i2);
            k.e(fVar, i2, t);
            return;
        }
        int g2 = g(fVar);
        int i5 = (int) fVar.A[i4].f().f1072g;
        eVar2.f().f1071f = eVar.f();
        eVar2.f().f1072g = g2;
        eVar2.f().f1079b = 1;
        fVar.Z(i5, i5 + g2, i2);
    }
}
