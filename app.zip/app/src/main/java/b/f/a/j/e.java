package b.f.a.j;

import b.f.a.i;

/* loaded from: classes.dex */
public class e {

    /* renamed from: b, reason: collision with root package name */
    final f f1033b;

    /* renamed from: c, reason: collision with root package name */
    final d f1034c;

    /* renamed from: d, reason: collision with root package name */
    e f1035d;

    /* renamed from: h, reason: collision with root package name */
    private int f1039h;

    /* renamed from: i, reason: collision with root package name */
    b.f.a.i f1040i;

    /* renamed from: a, reason: collision with root package name */
    private l f1032a = new l(this);

    /* renamed from: e, reason: collision with root package name */
    public int f1036e = 0;

    /* renamed from: f, reason: collision with root package name */
    int f1037f = -1;

    /* renamed from: g, reason: collision with root package name */
    private c f1038g = c.NONE;

    static /* synthetic */ class a {

        /* renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f1041a;

        static {
            int[] iArr = new int[d.values().length];
            f1041a = iArr;
            try {
                iArr[d.CENTER.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1041a[d.LEFT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1041a[d.RIGHT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f1041a[d.TOP.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f1041a[d.BOTTOM.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f1041a[d.BASELINE.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f1041a[d.CENTER_X.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                f1041a[d.CENTER_Y.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                f1041a[d.NONE.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
        }
    }

    public enum b {
        RELAXED,
        STRICT
    }

    public enum c {
        NONE,
        STRONG,
        WEAK
    }

    public enum d {
        NONE,
        LEFT,
        TOP,
        RIGHT,
        BOTTOM,
        BASELINE,
        CENTER,
        CENTER_X,
        CENTER_Y
    }

    public e(f fVar, d dVar) {
        b bVar = b.RELAXED;
        this.f1039h = 0;
        this.f1033b = fVar;
        this.f1034c = dVar;
    }

    public boolean a(e eVar, int i2, int i3, c cVar, int i4, boolean z) {
        if (eVar == null) {
            this.f1035d = null;
            this.f1036e = 0;
            this.f1037f = -1;
            this.f1038g = c.NONE;
            this.f1039h = 2;
            return true;
        }
        if (!z && !l(eVar)) {
            return false;
        }
        this.f1035d = eVar;
        if (i2 > 0) {
            this.f1036e = i2;
        } else {
            this.f1036e = 0;
        }
        this.f1037f = i3;
        this.f1038g = cVar;
        this.f1039h = i4;
        return true;
    }

    public boolean b(e eVar, int i2, c cVar, int i3) {
        return a(eVar, i2, -1, cVar, i3, false);
    }

    public int c() {
        return this.f1039h;
    }

    public int d() {
        e eVar;
        if (this.f1033b.C() == 8) {
            return 0;
        }
        return (this.f1037f <= -1 || (eVar = this.f1035d) == null || eVar.f1033b.C() != 8) ? this.f1036e : this.f1037f;
    }

    public f e() {
        return this.f1033b;
    }

    public l f() {
        return this.f1032a;
    }

    public b.f.a.i g() {
        return this.f1040i;
    }

    public c h() {
        return this.f1038g;
    }

    public e i() {
        return this.f1035d;
    }

    public d j() {
        return this.f1034c;
    }

    public boolean k() {
        return this.f1035d != null;
    }

    public boolean l(e eVar) {
        if (eVar == null) {
            return false;
        }
        d j2 = eVar.j();
        d dVar = this.f1034c;
        if (j2 == dVar) {
            return dVar != d.BASELINE || (eVar.e().I() && e().I());
        }
        switch (a.f1041a[dVar.ordinal()]) {
            case 1:
                return (j2 == d.BASELINE || j2 == d.CENTER_X || j2 == d.CENTER_Y) ? false : true;
            case 2:
            case 3:
                boolean z = j2 == d.LEFT || j2 == d.RIGHT;
                if (eVar.e() instanceof i) {
                    return z || j2 == d.CENTER_X;
                }
                return z;
            case 4:
            case 5:
                boolean z2 = j2 == d.TOP || j2 == d.BOTTOM;
                if (eVar.e() instanceof i) {
                    return z2 || j2 == d.CENTER_Y;
                }
                return z2;
            case 6:
            case 7:
            case 8:
            case 9:
                return false;
            default:
                throw new AssertionError(this.f1034c.name());
        }
    }

    public void m() {
        this.f1035d = null;
        this.f1036e = 0;
        this.f1037f = -1;
        this.f1038g = c.STRONG;
        this.f1039h = 0;
        b bVar = b.RELAXED;
        this.f1032a.e();
    }

    public void n(b.f.a.c cVar) {
        b.f.a.i iVar = this.f1040i;
        if (iVar == null) {
            this.f1040i = new b.f.a.i(i.a.UNRESTRICTED, null);
        } else {
            iVar.d();
        }
    }

    public String toString() {
        return this.f1033b.n() + ":" + this.f1034c.toString();
    }
}
