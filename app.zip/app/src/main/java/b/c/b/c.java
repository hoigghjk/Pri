package b.c.b;

import a.b.a.a;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;

/* loaded from: classes.dex */
public class c {

    /* renamed from: a, reason: collision with root package name */
    private final a.b.a.b f888a;

    /* renamed from: b, reason: collision with root package name */
    private final ComponentName f889b;

    class a extends a.AbstractBinderC0002a {

        /* renamed from: a, reason: collision with root package name */
        private Handler f890a = new Handler(Looper.getMainLooper());

        /* renamed from: b, reason: collision with root package name */
        final /* synthetic */ b.c.b.b f891b;

        /* renamed from: b.c.b.c$a$a, reason: collision with other inner class name */
        class RunnableC0029a implements Runnable {
            final /* synthetic */ int n;
            final /* synthetic */ Bundle o;

            RunnableC0029a(int i2, Bundle bundle) {
                this.n = i2;
                this.o = bundle;
            }

            @Override // java.lang.Runnable
            public void run() {
                a.this.f891b.onNavigationEvent(this.n, this.o);
            }
        }

        class b implements Runnable {
            final /* synthetic */ String n;
            final /* synthetic */ Bundle o;

            b(String str, Bundle bundle) {
                this.n = str;
                this.o = bundle;
            }

            @Override // java.lang.Runnable
            public void run() {
                a.this.f891b.extraCallback(this.n, this.o);
            }
        }

        /* renamed from: b.c.b.c$a$c, reason: collision with other inner class name */
        class RunnableC0030c implements Runnable {
            final /* synthetic */ Bundle n;

            RunnableC0030c(Bundle bundle) {
                this.n = bundle;
            }

            @Override // java.lang.Runnable
            public void run() {
                a.this.f891b.onMessageChannelReady(this.n);
            }
        }

        class d implements Runnable {
            final /* synthetic */ String n;
            final /* synthetic */ Bundle o;

            d(String str, Bundle bundle) {
                this.n = str;
                this.o = bundle;
            }

            @Override // java.lang.Runnable
            public void run() {
                a.this.f891b.onPostMessage(this.n, this.o);
            }
        }

        class e implements Runnable {
            final /* synthetic */ int n;
            final /* synthetic */ Uri o;
            final /* synthetic */ boolean p;
            final /* synthetic */ Bundle q;

            e(int i2, Uri uri, boolean z, Bundle bundle) {
                this.n = i2;
                this.o = uri;
                this.p = z;
                this.q = bundle;
            }

            @Override // java.lang.Runnable
            public void run() {
                a.this.f891b.onRelationshipValidationResult(this.n, this.o, this.p, this.q);
            }
        }

        a(c cVar, b.c.b.b bVar) {
            this.f891b = bVar;
        }

        @Override // a.b.a.a
        public Bundle I0(String str, Bundle bundle) {
            b.c.b.b bVar = this.f891b;
            if (bVar == null) {
                return null;
            }
            return bVar.extraCallbackWithResult(str, bundle);
        }

        @Override // a.b.a.a
        public void d1(String str, Bundle bundle) {
            if (this.f891b == null) {
                return;
            }
            this.f890a.post(new d(str, bundle));
        }

        @Override // a.b.a.a
        public void g0(String str, Bundle bundle) {
            if (this.f891b == null) {
                return;
            }
            this.f890a.post(new b(str, bundle));
        }

        @Override // a.b.a.a
        public void n1(Bundle bundle) {
            if (this.f891b == null) {
                return;
            }
            this.f890a.post(new RunnableC0030c(bundle));
        }

        @Override // a.b.a.a
        public void r1(int i2, Uri uri, boolean z, Bundle bundle) {
            if (this.f891b == null) {
                return;
            }
            this.f890a.post(new e(i2, uri, z, bundle));
        }

        @Override // a.b.a.a
        public void w0(int i2, Bundle bundle) {
            if (this.f891b == null) {
                return;
            }
            this.f890a.post(new RunnableC0029a(i2, bundle));
        }
    }

    c(a.b.a.b bVar, ComponentName componentName, Context context) {
        this.f888a = bVar;
        this.f889b = componentName;
    }

    public static boolean a(Context context, String str, e eVar) {
        eVar.setApplicationContext(context.getApplicationContext());
        Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
        if (!TextUtils.isEmpty(str)) {
            intent.setPackage(str);
        }
        return context.bindService(intent, eVar, 33);
    }

    private a.AbstractBinderC0002a b(b bVar) {
        return new a(this, bVar);
    }

    private f d(b bVar, PendingIntent pendingIntent) {
        boolean Y;
        a.AbstractBinderC0002a b2 = b(bVar);
        try {
            if (pendingIntent != null) {
                Bundle bundle = new Bundle();
                bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", pendingIntent);
                Y = this.f888a.a0(b2, bundle);
            } else {
                Y = this.f888a.Y(b2);
            }
            if (Y) {
                return new f(this.f888a, b2, this.f889b, pendingIntent);
            }
            return null;
        } catch (RemoteException unused) {
            return null;
        }
    }

    public f c(b bVar) {
        return d(bVar, null);
    }

    public boolean e(long j2) {
        try {
            return this.f888a.o1(j2);
        } catch (RemoteException unused) {
            return false;
        }
    }
}
