package b.c.b;

import android.os.Bundle;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final Integer f880a;

    /* renamed from: b, reason: collision with root package name */
    public final Integer f881b;

    /* renamed from: c, reason: collision with root package name */
    public final Integer f882c;

    /* renamed from: d, reason: collision with root package name */
    public final Integer f883d;

    /* renamed from: b.c.b.a$a, reason: collision with other inner class name */
    public static final class C0028a {

        /* renamed from: a, reason: collision with root package name */
        private Integer f884a;

        /* renamed from: b, reason: collision with root package name */
        private Integer f885b;

        /* renamed from: c, reason: collision with root package name */
        private Integer f886c;

        /* renamed from: d, reason: collision with root package name */
        private Integer f887d;

        public a a() {
            return new a(this.f884a, this.f885b, this.f886c, this.f887d);
        }

        public C0028a b(int i2) {
            this.f884a = Integer.valueOf(i2 | (-16777216));
            return this;
        }
    }

    a(Integer num, Integer num2, Integer num3, Integer num4) {
        this.f880a = num;
        this.f881b = num2;
        this.f882c = num3;
        this.f883d = num4;
    }

    Bundle a() {
        Bundle bundle = new Bundle();
        Integer num = this.f880a;
        if (num != null) {
            bundle.putInt("android.support.customtabs.extra.TOOLBAR_COLOR", num.intValue());
        }
        Integer num2 = this.f881b;
        if (num2 != null) {
            bundle.putInt("android.support.customtabs.extra.SECONDARY_TOOLBAR_COLOR", num2.intValue());
        }
        Integer num3 = this.f882c;
        if (num3 != null) {
            bundle.putInt("androidx.browser.customtabs.extra.NAVIGATION_BAR_COLOR", num3.intValue());
        }
        Integer num4 = this.f883d;
        if (num4 != null) {
            bundle.putInt("androidx.browser.customtabs.extra.NAVIGATION_BAR_DIVIDER_COLOR", num4.intValue());
        }
        return bundle;
    }
}
