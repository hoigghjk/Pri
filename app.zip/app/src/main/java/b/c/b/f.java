package b.c.b;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import java.util.List;

/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    private final a.b.a.b f903a;

    /* renamed from: b, reason: collision with root package name */
    private final a.b.a.a f904b;

    /* renamed from: c, reason: collision with root package name */
    private final ComponentName f905c;

    /* renamed from: d, reason: collision with root package name */
    private final PendingIntent f906d;

    f(a.b.a.b bVar, a.b.a.a aVar, ComponentName componentName, PendingIntent pendingIntent) {
        this.f903a = bVar;
        this.f904b = aVar;
        this.f905c = componentName;
        this.f906d = pendingIntent;
    }

    private void a(Bundle bundle) {
        PendingIntent pendingIntent = this.f906d;
        if (pendingIntent != null) {
            bundle.putParcelable("android.support.customtabs.extra.SESSION_ID", pendingIntent);
        }
    }

    private Bundle b(Bundle bundle) {
        Bundle bundle2 = new Bundle();
        if (bundle != null) {
            bundle2.putAll(bundle);
        }
        a(bundle2);
        return bundle2;
    }

    IBinder c() {
        return this.f904b.asBinder();
    }

    ComponentName d() {
        return this.f905c;
    }

    PendingIntent e() {
        return this.f906d;
    }

    public boolean f(Uri uri, Bundle bundle, List<Bundle> list) {
        try {
            return this.f903a.V(this.f904b, uri, b(bundle), list);
        } catch (RemoteException unused) {
            return false;
        }
    }
}
